-- PBAT Smart Nation Initiative - Extended Profile KYC Table Schema
-- Supports multi-step profile data, security question hashes, document paths, and verification states.

CREATE TABLE IF NOT EXISTS `user_kyc_extended` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL UNIQUE,
  
  -- Step 1: Basic Info
  `username` VARCHAR(50) DEFAULT NULL,
  `dob` DATE DEFAULT NULL,
  `nationality` VARCHAR(50) DEFAULT 'Nigerian',
  `state_of_origin` VARCHAR(50) DEFAULT NULL,
  `state_of_residence` VARCHAR(50) DEFAULT NULL,
  
  -- Step 2: Contact & Location & Digital Details
  `whatsapp_number` VARCHAR(30) DEFAULT NULL,
  `telegram_username` VARCHAR(50) DEFAULT NULL,
  `x_handle` VARCHAR(50) DEFAULT NULL,
  `facebook_profile` VARCHAR(255) DEFAULT NULL,
  `instagram_username` VARCHAR(50) DEFAULT NULL,
  `linkedin_profile` VARCHAR(255) DEFAULT NULL,
  
  -- Step 3: Education & Professional
  `highest_qualification` VARCHAR(100) DEFAULT NULL,
  `institution` VARCHAR(255) DEFAULT NULL,
  `course_of_study` VARCHAR(255) DEFAULT NULL,
  `graduation_year` INT DEFAULT NULL,
  `employer` VARCHAR(255) DEFAULT NULL,
  `industry` VARCHAR(100) DEFAULT NULL,
  `skills_expertise` TEXT DEFAULT NULL,
  
  -- Step 4: Digital Skills & Specialisation (options: have_skill / need_training)
  `digital_skills_data` TEXT DEFAULT NULL, 
  `tech_interests` TEXT DEFAULT NULL,
  `innovation_interests` TEXT DEFAULT NULL,
  `ai_knowledge_level` VARCHAR(50) DEFAULT NULL,
  `entrepreneurial_interests` TEXT DEFAULT NULL,
  `preferred_training_areas` TEXT DEFAULT NULL,
  
  -- Step 5: Ambassadorship, Volunteer & Document Upload Center
  `why_join` TEXT DEFAULT NULL,
  `preferred_role` VARCHAR(100) DEFAULT NULL,
  `areas_of_interest` TEXT DEFAULT NULL,
  `volunteer_availability` VARCHAR(100) DEFAULT NULL,
  `outreach_experience` TEXT DEFAULT NULL,
  `leadership_experience` TEXT DEFAULT NULL,
  `community_engagement` TEXT DEFAULT NULL,
  `smart_nation_topics` TEXT DEFAULT NULL,
  
  -- Security
  `two_factor_enabled` TINYINT(1) DEFAULT 0,
  `security_question` VARCHAR(255) DEFAULT NULL,
  `security_answer_hash` VARCHAR(255) DEFAULT NULL,
  
  -- Documents Upload
  `government_id_path` VARCHAR(255) DEFAULT NULL,
  `selfie_path` VARCHAR(255) DEFAULT NULL,
  `passport_photo_path` VARCHAR(255) DEFAULT NULL,
  `utility_bill_path` VARCHAR(255) DEFAULT NULL,
  `cv_path` VARCHAR(255) DEFAULT NULL,
  `recommendation_letter_path` VARCHAR(255) DEFAULT NULL,
  `proof_of_address_path` VARCHAR(255) DEFAULT NULL,
  
  -- Verification Coordinates & Status
  `kyc_status` VARCHAR(50) DEFAULT 'pending_review', -- pending_review, under_verification, approved, rejected, requires_update
  `kyc_status_message` TEXT DEFAULT NULL,
  `face_match_score` DECIMAL(5,2) DEFAULT NULL,
  `digital_signature` TEXT DEFAULT NULL, -- base64 canvas drawing
  `latitude` DECIMAL(10,8) DEFAULT NULL,
  `longitude` DECIMAL(11,8) DEFAULT NULL,
  
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
