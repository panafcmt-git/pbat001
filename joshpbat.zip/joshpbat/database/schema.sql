-- PBAT Smart Nation Initiative Database Schema
-- Version 1.0.0

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS `command_resources`;
DROP TABLE IF EXISTS `contact_submissions`;
DROP TABLE IF EXISTS `project_sponsors`;
DROP TABLE IF EXISTS `newsletters`;
DROP TABLE IF EXISTS `youtube_videos`;
DROP TABLE IF EXISTS `volunteers`;
DROP TABLE IF EXISTS `talent_pipeline`;
DROP TABLE IF EXISTS `user_kyc_extended`;
DROP TABLE IF EXISTS `login_history`;
DROP TABLE IF EXISTS `messages`;
DROP TABLE IF EXISTS `system_settings`;
DROP TABLE IF EXISTS `campaign_analytics`;
DROP TABLE IF EXISTS `campaigns`;
DROP TABLE IF EXISTS `role_permissions`;
DROP TABLE IF EXISTS `permissions`;
DROP TABLE IF EXISTS `nsc_tasks`;
DROP TABLE IF EXISTS `nsc_polls`;
DROP TABLE IF EXISTS `founder_notes`;
DROP TABLE IF EXISTS `founder_expansion`;
DROP TABLE IF EXISTS `founder_awards`;
DROP TABLE IF EXISTS `founder_thinktank`;
DROP TABLE IF EXISTS `founder_partnerships`;
DROP TABLE IF EXISTS `founder_visions`;
DROP TABLE IF EXISTS `sent_emails`;
DROP TABLE IF EXISTS `audit_logs`;
DROP TABLE IF EXISTS `analytics_summary`;
DROP TABLE IF EXISTS `qr_verifications`;
DROP TABLE IF EXISTS `media_uploads`;
DROP TABLE IF EXISTS `notifications`;
DROP TABLE IF EXISTS `blog_posts`;
DROP TABLE IF EXISTS `livestreams`;
DROP TABLE IF EXISTS `reports`;
DROP TABLE IF EXISTS `event_registrants`;
DROP TABLE IF EXISTS `events`;
DROP TABLE IF EXISTS `ambassadors`;
DROP TABLE IF EXISTS `user_leadership`;
DROP TABLE IF EXISTS `leadership_tiers`;
DROP TABLE IF EXISTS `wards`;
DROP TABLE IF EXISTS `lgas`;
DROP TABLE IF EXISTS `states`;
DROP TABLE IF EXISTS `users`;
DROP TABLE IF EXISTS `roles`;
-- FOREIGN_KEY_CHECKS disabled during table creations

-- 1. Roles Table
CREATE TABLE `roles` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(50) NOT NULL UNIQUE,
  `display_name` VARCHAR(100) NOT NULL,
  `description` TEXT,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. Users Table
CREATE TABLE `users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(150) NOT NULL,
  `email` VARCHAR(100) NOT NULL UNIQUE,
  `password` VARCHAR(255) NOT NULL,
  `role_id` INT NOT NULL,
  `phone` VARCHAR(20) DEFAULT NULL,
  `avatar` VARCHAR(255) DEFAULT 'assets/img/default-avatar.png',
  `status` ENUM('pending', 'active', 'suspended') DEFAULT 'active',
  `email_verified` TINYINT(1) DEFAULT 0,
  `email_token` VARCHAR(100) DEFAULT NULL,
  `reset_token` VARCHAR(100) DEFAULT NULL,
  `reset_expires` DATETIME DEFAULT NULL,
  `address` VARCHAR(255) DEFAULT NULL,
  `age` INT DEFAULT NULL,
  `gender` VARCHAR(20) DEFAULT NULL,
  `occupation` VARCHAR(100) DEFAULT NULL,
  `profile_completed` TINYINT(1) DEFAULT 0,
  `membership_code` VARCHAR(50) DEFAULT NULL,
  `last_reminder_sent` TIMESTAMP NULL DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. States Table
CREATE TABLE `states` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL UNIQUE,
  `code` VARCHAR(5) NOT NULL UNIQUE,
  `zone` VARCHAR(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4. Local Government Areas (LGAs) Table
CREATE TABLE `lgas` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `state_id` INT NOT NULL,
  `name` VARCHAR(100) NOT NULL,
  FOREIGN KEY (`state_id`) REFERENCES `states` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4.5 Wards Table
CREATE TABLE `wards` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `lga_id` INT NOT NULL,
  `name` VARCHAR(100) NOT NULL,
  FOREIGN KEY (`lga_id`) REFERENCES `lgas` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 5. Leadership Tiers Table
CREATE TABLE `leadership_tiers` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL UNIQUE,
  `level` INT NOT NULL UNIQUE, -- 1 for National, 2 Zonal, 3 State, 4 LGA, 5 Grassroots
  `description` TEXT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 6. Ambassadors Table
CREATE TABLE `ambassadors` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL UNIQUE,
  `uuid` VARCHAR(64) NOT NULL UNIQUE,
  `bio` TEXT DEFAULT NULL,
  `skills` TEXT DEFAULT NULL,
  `interests` TEXT DEFAULT NULL,
  `state_id` INT NOT NULL,
  `lga_id` INT NOT NULL,
  `ward_id` INT DEFAULT NULL,
  `impact_score` INT DEFAULT 10,
  `qr_code_hash` VARCHAR(64) NOT NULL UNIQUE,
  `card_generated_at` TIMESTAMP NULL DEFAULT NULL,
  `is_verified` TINYINT(1) DEFAULT 0,
  `verified_by` INT DEFAULT NULL,
  `verified_at` TIMESTAMP NULL DEFAULT NULL,
  FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  FOREIGN KEY (`state_id`) REFERENCES `states` (`id`) ON DELETE RESTRICT,
  FOREIGN KEY (`lga_id`) REFERENCES `lgas` (`id`) ON DELETE RESTRICT,
  FOREIGN KEY (`ward_id`) REFERENCES `wards` (`id`) ON DELETE RESTRICT,
  FOREIGN KEY (`verified_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 7. User Leadership (For tiers higher than Ambassadors)
CREATE TABLE `user_leadership` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL UNIQUE,
  `tier_id` INT NOT NULL,
  `zone` VARCHAR(50) DEFAULT NULL,
  `state_id` INT DEFAULT NULL,
  `lga_id` INT DEFAULT NULL,
  `ward_id` INT DEFAULT NULL,
  `appointed_by` INT DEFAULT NULL,
  `appointed_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  FOREIGN KEY (`tier_id`) REFERENCES `leadership_tiers` (`id`) ON DELETE RESTRICT,
  FOREIGN KEY (`state_id`) REFERENCES `states` (`id`) ON DELETE SET NULL,
  FOREIGN KEY (`lga_id`) REFERENCES `lgas` (`id`) ON DELETE SET NULL,
  FOREIGN KEY (`ward_id`) REFERENCES `wards` (`id`) ON DELETE SET NULL,
  FOREIGN KEY (`appointed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 8. Reports Table
CREATE TABLE `reports` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `title` VARCHAR(255) NOT NULL,
  `description` TEXT NOT NULL,
  `file_path` VARCHAR(255) DEFAULT NULL,
  `status` ENUM('submitted', 'reviewed', 'approved', 'rejected') DEFAULT 'submitted',
  `state_id` INT NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  FOREIGN KEY (`state_id`) REFERENCES `states` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 9. Events Table
CREATE TABLE `events` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `title` VARCHAR(255) NOT NULL,
  `description` TEXT NOT NULL,
  `event_date` DATETIME NOT NULL,
  `location` VARCHAR(255) NOT NULL,
  `event_type` VARCHAR(100) DEFAULT 'Town Hall',
  `is_virtual` TINYINT(1) DEFAULT 0,
  `stream_url` VARCHAR(255) DEFAULT NULL,
  `meeting_platform` VARCHAR(50) DEFAULT 'none',
  `meeting_link`     VARCHAR(255) DEFAULT NULL,
  `meeting_id`       VARCHAR(100) DEFAULT NULL,
  `meeting_passcode` VARCHAR(50) DEFAULT NULL,
  `max_capacity`     INT DEFAULT 0,
  `created_by` INT NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 9.5. Event Registrants (RSVPs) Table
CREATE TABLE `event_registrants` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `event_id` INT NOT NULL,
  `user_id` INT NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`event_id`) REFERENCES `events` (`id`) ON DELETE CASCADE,
  FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  UNIQUE KEY `user_event` (`user_id`, `event_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 10. Notifications Table
CREATE TABLE `notifications` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `message` VARCHAR(255) NOT NULL,
  `is_read` TINYINT(1) DEFAULT 0,
  `type` VARCHAR(50) DEFAULT 'general',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 11. Livestreams Table
CREATE TABLE `livestreams` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `title` VARCHAR(255) NOT NULL,
  `description` TEXT NOT NULL,
  `stream_url` VARCHAR(255) NOT NULL,
  `scheduled_at` DATETIME NOT NULL,
  `duration` INT DEFAULT 60, -- minutes
  `status` ENUM('scheduled', 'live', 'completed', 'cancelled') DEFAULT 'scheduled',
  `created_by` INT NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 12. Blog Posts (News & Media) Table
CREATE TABLE `blog_posts` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `title` VARCHAR(255) NOT NULL,
  `summary` TEXT NOT NULL,
  `content` LONGTEXT NOT NULL,
  `cover_image` VARCHAR(255) DEFAULT NULL,
  `status` ENUM('draft', 'published') DEFAULT 'published',
  `author_id` INT NOT NULL,
  `category` VARCHAR(50) NOT NULL DEFAULT 'News',
  `is_approved` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`author_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 13. Audit Logs Table
CREATE TABLE `audit_logs` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT DEFAULT NULL,
  `action` VARCHAR(150) NOT NULL,
  `ip_address` VARCHAR(45) NOT NULL,
  `user_agent` VARCHAR(255) DEFAULT NULL,
  `details` TEXT DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 14. Media Uploads Table
CREATE TABLE `media_uploads` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `title` VARCHAR(150) NOT NULL,
  `file_path` VARCHAR(255) NOT NULL,
  `file_type` VARCHAR(100) NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 15. QR Verifications Table
CREATE TABLE `qr_verifications` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `qr_hash` VARCHAR(64) NOT NULL,
  `verified_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `ip_address` VARCHAR(45) NOT NULL,
  `status` VARCHAR(50) DEFAULT 'success'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 16. Analytics Summary Table (State-by-state details for chart rendering)
CREATE TABLE `analytics_summary` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `state_id` INT NOT NULL,
  `ambassador_count` INT DEFAULT 0,
  `events_count` INT DEFAULT 0,
  `reports_filed` INT DEFAULT 0,
  `impact_score` INT DEFAULT 0,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`state_id`) REFERENCES `states` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==========================================
-- SEED DATA
-- ==========================================

-- Seed Roles
INSERT INTO `roles` (`id`, `name`, `display_name`, `description`) VALUES
(1, 'super_admin', 'Super Admin', 'Full system control, settings, security & user provisioning.'),
(2, 'founder_circle', 'Founder Circle', 'Strategic oversight, national updates and leadership appointments.'),
(3, 'national_steering', 'National Steering Council', 'National level campaign and programmatic execution oversight.'),
(4, 'zonal_chairman', 'Zonal Chairman', 'Coordinates geo-political zones (e.g. Southwest, Northcentral).'),
(5, 'state_chairman', 'State Chairman', 'Manages state chapter activities, events, and reports.'),
(6, 'coordinator', 'LGA Coordinator', 'Local Government level coordinator driving direct grassroot engagement.'),
(7, 'ambassador', 'Grassroots Ambassador', 'Digital revolution advocate on the ground, mobilizing community.');

-- Seed Leadership Tiers
INSERT INTO `leadership_tiers` (`id`, `name`, `level`, `description`) VALUES
(1, 'National Council', 1, 'Top strategic body directing smart advocacy plans.'),
(2, 'Zonal Directorate', 2, 'Coordinating operations across geopolitical zones.'),
(3, 'State Chapter executive', 3, 'Driving structural state tech programs.'),
(4, 'LGA Coordination Council', 4, 'Direct localized grassroots tracking.'),
(5, 'Grassroots Unit', 5, 'Individually driven ambassador network.');

-- Seed States (representing major zones)
INSERT INTO `states` (`id`, `name`, `code`, `zone`) VALUES
(1, 'Lagos', 'LA', 'South-West'),
(2, 'Federal Capital Territory', 'FCT', 'North-Central'),
(3, 'Rivers', 'RV', 'South-South'),
(4, 'Kano', 'KN', 'North-West'),
(5, 'Enugu', 'EN', 'South-East'),
(6, 'Borno', 'BO', 'North-East'),
(7, 'Abia', 'AB', 'South-East'),
(8, 'Adamawa', 'AD', 'North-East'),
(9, 'Akwa Ibom', 'AK', 'South-South'),
(10, 'Anambra', 'AN', 'South-East'),
(11, 'Bauchi', 'BA', 'North-East'),
(12, 'Bayelsa', 'BY', 'South-South'),
(13, 'Benue', 'BE', 'North-Central'),
(14, 'Cross River', 'CR', 'South-South'),
(15, 'Delta', 'DE', 'South-South'),
(16, 'Ebonyi', 'EB', 'South-East'),
(17, 'Edo', 'ED', 'South-South'),
(18, 'Ekiti', 'EK', 'South-West'),
(19, 'Gombe', 'GO', 'North-East'),
(20, 'Imo', 'IM', 'South-East'),
(21, 'Jigawa', 'JI', 'North-West'),
(22, 'Kaduna', 'KD', 'North-West'),
(23, 'Katsina', 'KT', 'North-West'),
(24, 'Kebbi', 'KE', 'North-West'),
(25, 'Kogi', 'KO', 'North-Central'),
(26, 'Kwara', 'KW', 'North-Central'),
(27, 'Nasarawa', 'NA', 'North-Central'),
(28, 'Niger', 'NI', 'North-Central'),
(29, 'Ogun', 'OG', 'South-West'),
(30, 'Ondo', 'ON', 'South-West'),
(31, 'Osun', 'OS', 'South-West'),
(32, 'Oyo', 'OY', 'South-West'),
(33, 'Plateau', 'PL', 'North-Central'),
(34, 'Sokoto', 'SO', 'North-West'),
(35, 'Taraba', 'TA', 'North-East'),
(36, 'Yobe', 'YO', 'North-East'),
(37, 'Zamfara', 'ZA', 'North-West');

-- Seed LGAs for Lagos (State 1)
INSERT INTO `lgas` (`state_id`, `name`) VALUES
(1, 'Ikeja'),
(1, 'Alimosho'),
(1, 'Lagos Island'),
(1, 'Epe');

-- Seed LGAs for FCT (State 2)
INSERT INTO `lgas` (`state_id`, `name`) VALUES
(2, 'Municipal Area Council (AMAC)'),
(2, 'Bwari'),
(2, 'Gwagwalada');

-- Seed LGAs for Rivers (State 3)
INSERT INTO `lgas` (`state_id`, `name`) VALUES
(3, 'Port Harcourt'),
(3, 'Obio-Akpor'),
(3, 'Eleme');

-- Seed default users
-- Default Password is 'password123' hashed using PHP BCRYPT: $2y$12$T4ykmBFNGsG00ChxfZTzLeEGt26Toy8L7NXsFKKIdloFSEJT5jmYi
INSERT INTO `users` (`id`, `name`, `email`, `password`, `role_id`, `phone`, `status`, `email_verified`) VALUES
(1, 'Hon. Yusuf Bello (Super Admin)', 'admin@pbat-smartnation.ng', '$2y$12$T4ykmBFNGsG00ChxfZTzLeEGt26Toy8L7NXsFKKIdloFSEJT5jmYi', 1, '+2348030000001', 'active', 1),
(2, 'Alhaji Ibrahim Dan-Ina (Founder)', 'founder@pbat-smartnation.ng', '$2y$12$T4ykmBFNGsG00ChxfZTzLeEGt26Toy8L7NXsFKKIdloFSEJT5jmYi', 2, '+2348030000002', 'active', 1),
(3, 'Dr. Chioma Nnaji (National Steering)', 'nsc@pbat-smartnation.ng', '$2y$12$T4ykmBFNGsG00ChxfZTzLeEGt26Toy8L7NXsFKKIdloFSEJT5jmYi', 3, '+2348030000003', 'active', 1),
(4, 'Chief Adebayo Adeola (Zonal South-West)', 'zonal@pbat-smartnation.ng', '$2y$12$T4ykmBFNGsG00ChxfZTzLeEGt26Toy8L7NXsFKKIdloFSEJT5jmYi', 4, '+2348030000004', 'active', 1),
(5, 'Engr. Funsho Balogun (State Chairman Lagos)', 'state@pbat-smartnation.ng', '$2y$12$T4ykmBFNGsG00ChxfZTzLeEGt26Toy8L7NXsFKKIdloFSEJT5jmYi', 5, '+2348030000005', 'active', 1),
(6, 'Mallam Abubakar Sadiq (LGA Coordinator Ikeja)', 'coordinator@pbat-smartnation.ng', '$2y$12$T4ykmBFNGsG00ChxfZTzLeEGt26Toy8L7NXsFKKIdloFSEJT5jmYi', 6, '+2348030000006', 'active', 1),
(7, 'Tunde Coker (Ambassador Alimosho)', 'ambassador1@pbat-smartnation.ng', '$2y$12$T4ykmBFNGsG00ChxfZTzLeEGt26Toy8L7NXsFKKIdloFSEJT5jmYi', 7, '+2348030000007', 'active', 1),
(8, 'Amara Eke (Ambassador Ikeja)', 'ambassador2@pbat-smartnation.ng', '$2y$12$T4ykmBFNGsG00ChxfZTzLeEGt26Toy8L7NXsFKKIdloFSEJT5jmYi', 7, '+2348030000008', 'active', 1);

-- Seed Ambassador Details
INSERT INTO `ambassadors` (`id`, `user_id`, `uuid`, `bio`, `skills`, `interests`, `state_id`, `lga_id`, `impact_score`, `qr_code_hash`, `is_verified`, `verified_by`, `verified_at`) VALUES
(1, 7, 'amb-uuid-tunde-coker-990182', 'Grassroots digital strategist dedicated to youth tech literacy in Alimosho.', 'Community Mobilization, Social Media, Web Design', 'Coding, Youth Training, Open-source', 1, 2, 75, 'hash-tunde-coker-990182', 1, 1, CURRENT_TIMESTAMP),
(2, 8, 'amb-uuid-amara-eke-481923', 'AI researcher and Smart Tech advocate based in Ikeja.', 'Data Analysis, Coding, Digital Literacy Advocacy', 'Machine Learning, Tech Policy', 1, 1, 120, 'hash-amara-eke-481923', 1, 5, CURRENT_TIMESTAMP);

-- Seed user leadership mapping
INSERT INTO `user_leadership` (`user_id`, `tier_id`, `zone`, `state_id`, `lga_id`, `appointed_by`) VALUES
(3, 1, NULL, NULL, NULL, 1),
(4, 2, 'South-West', NULL, NULL, 1),
(5, 3, 'South-West', 1, NULL, 2),
(6, 4, 'South-West', 1, 1, 5);

-- Seed Analytical Summary for Dashboard representation
INSERT INTO `analytics_summary` (`state_id`, `ambassador_count`, `events_count`, `reports_filed`, `impact_score`) VALUES
(1, 480, 14, 38, 9200), -- Lagos
(2, 220, 8, 19, 4400),  -- FCT
(3, 310, 11, 25, 6100), -- Rivers
(4, 390, 6, 31, 7800),  -- Kano
(5, 140, 4, 12, 2800),  -- Enugu
(6, 85, 2, 7, 1500),    -- Borno
(7, 95, 3, 8, 1850),    -- Abia
(8, 70, 2, 5, 1200),    -- Adamawa
(9, 150, 5, 11, 3100),   -- Akwa Ibom
(10, 130, 4, 10, 2600),  -- Anambra
(11, 80, 2, 6, 1400),   -- Bauchi
(12, 65, 1, 4, 980),    -- Bayelsa
(13, 90, 3, 7, 1700),   -- Benue
(14, 110, 3, 9, 2100),  -- Cross River
(15, 145, 5, 12, 2900),  -- Delta
(16, 60, 1, 3, 850),    -- Ebonyi
(17, 125, 4, 8, 2300),   -- Edo
(18, 75, 2, 5, 1300),   -- Ekiti
(19, 55, 1, 3, 750),    -- Gombe
(20, 115, 3, 8, 2200),  -- Imo
(21, 68, 2, 4, 1100),   -- Jigawa
(22, 180, 6, 15, 3700),  -- Kaduna
(23, 95, 3, 7, 1800),   -- Katsina
(24, 72, 2, 5, 1250),   -- Kebbi
(25, 88, 3, 6, 1600),   -- Kogi
(26, 92, 3, 7, 1750),   -- Kwara
(27, 84, 2, 6, 1550),   -- Nasarawa
(28, 102, 3, 8, 2050),  -- Niger
(29, 160, 5, 13, 3300),  -- Ogun
(30, 110, 3, 9, 2150),  -- Ondo
(31, 105, 3, 8, 2000),  -- Osun
(32, 175, 6, 14, 3600),  -- Oyo
(33, 98, 3, 7, 1900),   -- Plateau
(34, 82, 2, 5, 1450),   -- Sokoto
(35, 62, 1, 4, 900),    -- Taraba
(36, 58, 1, 3, 800),    -- Yobe
(37, 78, 2, 5, 1350);   -- Zamfara

-- Seed news/blog posts
INSERT INTO `blog_posts` (`title`, `summary`, `content`, `cover_image`, `author_id`) VALUES
('PBAT Smart Nation System Performance', 'An overview of our advocacy reach across the six geo-political zones of Nigeria.', '<p>Our primary objective as an advocacy team is to ensure that digital transformation models reach every local community. We have successfully onboarded and certified thousands of grassroots ambassadors through our structured curriculum.</p>', 'assets/img/blog1.jpg', 1),
('AI Revolution and National Development', 'Exploring how Artificial Intelligence can catalyze growth in small and medium enterprises.', '<p>AI is not just for tech companies. In our latest policy draft, we outline how smart algorithms can be demystified to help local farmers and trade organizations scale operations effectively.</p>', 'assets/img/blog2.jpg', 2),
('Infrastructure Strategy for Smart Cities', 'Developing modern templates for internet connectivity, secure cloud nodes, and community digital workspaces.', '<p>Establishing physical technology centers (Smart Hubs) is the pillar of rural inclusion. We review our active proposal for localized community workspaces.</p>', 'assets/img/blog3.jpg', 3);

-- Seed events
INSERT INTO `events` (`title`, `description`, `event_date`, `location`, `event_type`, `is_virtual`, `stream_url`, `created_by`) VALUES
('Digital Revolution Town Hall', 'Discussing Smart Governance and local community mobilization through technology.', DATE_ADD(CURRENT_TIMESTAMP, INTERVAL 5 DAY), 'Interactive Virtual Hub & YouTube Live', 'Digital Town Hall', 1, 'https://www.youtube.com/embed/dQw4w9WgXcQ', 1),
('State Tech Leadership Forum', 'Strategic alignment meeting for state and LGA coordinators across South-West Nigeria.', DATE_ADD(CURRENT_TIMESTAMP, INTERVAL 12 DAY), 'Ikeja Innovation Hub, Lagos', 'Conference', 0, NULL, 5);

-- Seed audit logs
INSERT INTO `audit_logs` (`user_id`, `action`, `ip_address`, `user_agent`, `details`) VALUES
(1, 'DATABASE_INIT', '127.0.0.1', 'System Installer', 'Database successfully populated with core configuration schemas.'),
(1, 'USER_PROVISION', '127.0.0.1', 'System Installer', 'Created default accounts for Super Admin, Founder, Steering, Chairmen, Coordinators, and Ambassadors.');

-- Campaigns Table
CREATE TABLE `campaigns` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `title` VARCHAR(255) NOT NULL,
  `description` TEXT NOT NULL,
  `category` VARCHAR(100) DEFAULT 'General',
  `status` ENUM('draft', 'scheduled', 'active', 'completed') DEFAULT 'draft',
  `scheduled_at` DATETIME DEFAULT NULL,
  `leader_id` INT DEFAULT NULL,
  `created_by` INT NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`leader_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Campaign Analytics Table
CREATE TABLE `campaign_analytics` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `campaign_id` INT NOT NULL,
  `reach_count` INT DEFAULT 0,
  `engagement_rate` FLOAT DEFAULT 0.0,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`campaign_id`) REFERENCES `campaigns` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Permissions Table
CREATE TABLE `permissions` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL UNIQUE,
  `display_name` VARCHAR(150) NOT NULL,
  `description` TEXT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Role Permissions Mapping Table
CREATE TABLE `role_permissions` (
  `role_id` INT NOT NULL,
  `permission_id` INT NOT NULL,
  PRIMARY KEY (`role_id`, `permission_id`),
  FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
  FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Login History Table
CREATE TABLE `login_history` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `ip_address` VARCHAR(45) NOT NULL,
  `device_info` VARCHAR(255) DEFAULT NULL,
  `status` ENUM('success', 'failed') DEFAULT 'success',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Messages Table
CREATE TABLE `messages` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `sender_id` INT NOT NULL,
  `recipient_id` INT DEFAULT NULL,
  `channel` VARCHAR(50) DEFAULT 'general',
  `subject` VARCHAR(255) DEFAULT NULL,
  `body` TEXT NOT NULL,
  `is_read` TINYINT(1) DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`sender_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  FOREIGN KEY (`recipient_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- System Settings Table
CREATE TABLE `system_settings` (
  `setting_key` VARCHAR(100) PRIMARY KEY,
  `setting_value` TEXT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- User KYC Extended Table
CREATE TABLE `user_kyc_extended` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL UNIQUE,
  `username` VARCHAR(50) DEFAULT NULL,
  `dob` DATE DEFAULT NULL,
  `nationality` VARCHAR(50) DEFAULT 'Nigerian',
  `state_of_origin` VARCHAR(50) DEFAULT NULL,
  `state_of_residence` VARCHAR(50) DEFAULT NULL,
  `whatsapp_number` VARCHAR(30) DEFAULT NULL,
  `telegram_username` VARCHAR(50) DEFAULT NULL,
  `x_handle` VARCHAR(50) DEFAULT NULL,
  `facebook_profile` VARCHAR(255) DEFAULT NULL,
  `instagram_username` VARCHAR(50) DEFAULT NULL,
  `linkedin_profile` VARCHAR(255) DEFAULT NULL,
  `highest_qualification` VARCHAR(100) DEFAULT NULL,
  `institution` VARCHAR(255) DEFAULT NULL,
  `course_of_study` VARCHAR(255) DEFAULT NULL,
  `graduation_year` INT DEFAULT NULL,
  `employer` VARCHAR(255) DEFAULT NULL,
  `industry` VARCHAR(100) DEFAULT NULL,
  `skills_expertise` TEXT DEFAULT NULL,
  `digital_skills_data` TEXT DEFAULT NULL, 
  `tech_interests` TEXT DEFAULT NULL,
  `innovation_interests` TEXT DEFAULT NULL,
  `ai_knowledge_level` VARCHAR(50) DEFAULT NULL,
  `entrepreneurial_interests` TEXT DEFAULT NULL,
  `preferred_training_areas` TEXT DEFAULT NULL,
  `why_join` TEXT DEFAULT NULL,
  `preferred_role` VARCHAR(100) DEFAULT NULL,
  `areas_of_interest` TEXT DEFAULT NULL,
  `volunteer_availability` VARCHAR(100) DEFAULT NULL,
  `outreach_experience` TEXT DEFAULT NULL,
  `leadership_experience` TEXT DEFAULT NULL,
  `community_engagement` TEXT DEFAULT NULL,
  `smart_nation_topics` TEXT DEFAULT NULL,
  `two_factor_enabled` TINYINT(1) DEFAULT 0,
  `security_question` VARCHAR(255) DEFAULT NULL,
  `security_answer_hash` VARCHAR(255) DEFAULT NULL,
  `government_id_path` VARCHAR(255) DEFAULT NULL,
  `selfie_path` VARCHAR(255) DEFAULT NULL,
  `passport_photo_path` VARCHAR(255) DEFAULT NULL,
  `utility_bill_path` VARCHAR(255) DEFAULT NULL,
  `cv_path` VARCHAR(255) DEFAULT NULL,
  `recommendation_letter_path` VARCHAR(255) DEFAULT NULL,
  `proof_of_address_path` VARCHAR(255) DEFAULT NULL,
  `kyc_status` VARCHAR(50) DEFAULT 'pending_review',
  `kyc_status_message` TEXT DEFAULT NULL,
  `face_match_score` DECIMAL(5,2) DEFAULT NULL,
  `digital_signature` TEXT DEFAULT NULL,
  `latitude` DECIMAL(10,8) DEFAULT NULL,
  `longitude` DECIMAL(11,8) DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- NSC Tasks Table
CREATE TABLE `nsc_tasks` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `title` VARCHAR(255) NOT NULL,
  `description` TEXT NOT NULL,
  `target_type` ENUM('zone', 'state') NOT NULL,
  `target_name` VARCHAR(100) NOT NULL,
  `deadline` DATE NOT NULL,
  `status` ENUM('pending', 'completed') DEFAULT 'pending',
  `created_by` INT NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- NSC Polls Table
CREATE TABLE `nsc_polls` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `question` VARCHAR(255) NOT NULL,
  `options_json` TEXT NOT NULL,
  `votes_json` TEXT NOT NULL,
  `status` ENUM('active', 'closed') DEFAULT 'active',
  `created_by` INT NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Re-enable foreign key checks at the end
SET FOREIGN_KEY_CHECKS = 1;

-- 17. Sent Emails Table
CREATE TABLE `sent_emails` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `to_email` VARCHAR(150) NOT NULL,
  `subject` VARCHAR(255) NOT NULL,
  `body` LONGTEXT NOT NULL,
  `status` VARCHAR(50) DEFAULT 'sent',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 18. Founder Circle Tables
CREATE TABLE `founder_visions` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `title` VARCHAR(255) NOT NULL,
  `content` TEXT NOT NULL,
  `category` VARCHAR(100) NOT NULL,
  `created_by` INT NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `founder_partnerships` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(255) NOT NULL,
  `type` VARCHAR(100) NOT NULL,
  `description` TEXT,
  `contact_name` VARCHAR(150),
  `contact_email` VARCHAR(150),
  `sponsor_amount` DECIMAL(15,2) DEFAULT 0.00,
  `status` ENUM('active', 'inactive', 'pending') DEFAULT 'pending',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `founder_thinktank` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `title` VARCHAR(255) NOT NULL,
  `content` TEXT NOT NULL,
  `category` VARCHAR(100) NOT NULL,
  `user_id` INT NOT NULL,
  `upvotes` INT DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `founder_awards` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `recipient_id` INT NOT NULL,
  `award_title` VARCHAR(255) NOT NULL,
  `award_type` VARCHAR(100) NOT NULL,
  `description` TEXT,
  `granted_by` INT NOT NULL,
  `granted_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`recipient_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  FOREIGN KEY (`granted_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `founder_expansion` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `state_id` INT NOT NULL,
  `target_date` DATE NOT NULL,
  `status` ENUM('planning', 'rolling_out', 'active') DEFAULT 'planning',
  `regional_head_id` INT DEFAULT NULL,
  `funding_allocated` DECIMAL(15,2) DEFAULT 0.00,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`state_id`) REFERENCES `states` (`id`) ON DELETE CASCADE,
  FOREIGN KEY (`regional_head_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `founder_notes` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `title` VARCHAR(255) NOT NULL,
  `content` TEXT NOT NULL,
  `created_by` INT NOT NULL,
  `is_confidential` TINYINT(1) DEFAULT 1,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Seed Founder Circle Data
INSERT INTO `founder_visions` (`id`, `title`, `content`, `category`, `created_by`) VALUES
(1, 'National Broadband and Cyber Inclusion Framework', 'Our roadmap to bring high-speed fiber connectivity to all 774 Local Government Area secretariats across Nigeria.', 'roadmap', 2),
(2, 'Empowering Grassroots with Artificial Intelligence Literacy', 'Define strategy guidelines to empower local youth chapters on prompting, machine learning applications, and modern automation tools.', 'advocacy_direction', 2);

INSERT INTO `founder_partnerships` (`id`, `name`, `type`, `description`, `contact_name`, `contact_email`, `sponsor_amount`, `status`) VALUES
(1, 'Microsoft Africa Development Center (ADC)', 'tech_company', 'Joint youth tech training sponsorships and startup accelerator support.', 'Dr. John Olayemi', 'john.olayemi@microsoft.com', 25000000.00, 'active'),
(2, 'Youth Empowerment & Innovation Hub (YEIH)', 'ngo', 'Local digital hubs provision and community coordinator certifications.', 'Fatima Bello', 'info@yeih.org.ng', 5000000.00, 'active');

INSERT INTO `founder_thinktank` (`id`, `title`, `content`, `category`, `user_id`, `upvotes`) VALUES
(1, 'Decentralizing Digital Workspaces for Rural Inclusion', 'Should we establish mini-hubs at ward levels rather than keeping them centralized at state capitals? Discussing funding allocation.', 'digital_strategy', 2, 12),
(2, 'Enabling Sovereign Cloud Infrastructure for Public Security Data', 'Proposed policy direction to mandate local hosting of citizen digital ID records.', 'tech_policy', 3, 8);

INSERT INTO `founder_expansion` (`id`, `state_id`, `target_date`, `status`, `regional_head_id`, `funding_allocated`) VALUES
(1, 5, '2026-09-01', 'rolling_out', 5, 1200000.00),
(2, 6, '2026-11-15', 'planning', NULL, 800000.00);

INSERT INTO `founder_notes` (`id`, `title`, `content`, `created_by`, `is_confidential`) VALUES
(1, 'Private Executive Briefing on Zonal Leadership Adjustments', 'Confidential note regarding alignment of Zonal Chairman roles for North-Central region.', 2, 1);

-- Seed Default Permissions
INSERT INTO `permissions` (`id`, `name`, `display_name`, `description`) VALUES
(1, 'create_campaign', 'Create Campaigns', 'Allows writing and scheduling regional tech campaigns.'),
(2, 'approve_report', 'Approve Reports', 'Allows reviewing and verifying activity reports from ambassadors.'),
(3, 'manage_states', 'Manage States', 'Allows editing regional coordinates and state metrics.'),
(4, 'view_analytics', 'View Analytics', 'Allows checking comprehensive national participation heatmaps.'),
(5, 'manage_livestreams', 'Manage Livestreams', 'Allows adding stream countdowns and television links.');

-- Map Permissions to Super Admin (Role 1), Founder Circle (Role 2)
INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES
(1, 1), (1, 2), (1, 3), (1, 4), (1, 5),
(2, 1), (2, 2), (2, 4), (2, 5);

-- Seed Default System Settings
INSERT INTO `system_settings` (`setting_key`, `setting_value`) VALUES
('site_name', 'PBAT Smart Nation Initiative'),
('logo_url', ''),
('theme_primary', '#063C1E'),
('theme_accent', '#D4AF37'),
('footer_copyright', '&copy; 2026 PBAT Smart Nation Initiative. All rights reserved.'),
('contact_email', 'info@pbat-smartnation.ng'),
('contact_phone', '+2348030000001'),
('hero_badge', 'Nigeria\'s Smart Evolution'),
('hero_title', 'PBAT SMART \r\nNATION INITIATIVE'),
('hero_desc', 'An independent, high-impact advocacy platform driving youth tech capacity building, AI sensitization, localized innovation hubs, and community technology leadership templates.'),
('hero_btn1_text', 'JOIN ADVOCATES'),
('hero_btn1_url', 'register.php'),
('hero_btn2_text', 'READ OUR CHARTER'),
('hero_btn2_url', '#about'),
('hero_image_url', 'uploads/pbat_hero.jpg'),
('hero_patron_name', 'PRESIDENT BOLA AHMED TINUBU'),
('hero_patron_tag', 'Patron'),
('hero_widget_label', 'Digital Literacy Campaign'),
('hero_widget_val', '36 States + FCT'),
('about_image_url', 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=500&q=80'),
('about_badge', 'Strategic Mandate'),
('about_heading', 'As an Advocacy Group, our vision is to work with the Presidency, the States, Local Governments, Communities and Private Investors in Empowering Every Citizen Through Digital Excellence.'),
('about_content', 'The PBAT Smart Nation Initiative functions as a catalyst. We are dedicated to ensuring that digital technologies are not localized inside financial hubs alone, but integrated thoroughly into agricultural sectors, state primary education programs, and municipal workflows.'),
('about_val1_title', 'PUBLIC TRUST'),
('about_val1_text', 'Ensuring clear, unbiased, state-level monitoring and performance indexes.'),
('about_val2_title', 'CAPACITY BUILDING'),
('about_val2_text', 'Standardizing coding bootcamps and tech skill classes for local youths.'),
('about_val3_title', 'INCLUSIVE GROWTH'),
('about_val3_text', 'Targeting underserved LGAs and giving direct access to software pathways.'),
('banner_badge', 'National Core Ideology'),
('banner_title', '"BUILDING A SMART, UNITED NIGERIA"'),
('banner_subtitle', 'Our initiative envisions a tech-driven nation where innovation drives prosperity, administration guarantees seamless transparency, and communities unified through digital access.'),
('banner_btn_text', 'Register as Grassroots Ambassador'),
('banner_btn_url', 'register.php'),
('pillars_badge', 'Development Pillars'),
('pillars_heading', 'Our Key Pillars'),
('pillars_subtitle', 'Focus areas driving national digital transformation awareness and skills training.'),
('pillars_intro_title', 'Building Nigeria\'s Digital Future'),
('pillars_intro_desc1', 'The PBAT Smart Nation Initiative is anchored on a vision of technological empowerment, civic transparency, and sustainable development. By dividing our focus into five specialized strategic pillars, we ensure that every community, local business, and public department gets custom advocacy, sensitization, and practical digital training.'),
('pillars_intro_desc2', 'Explore each pillar below to understand how we are coordinating grassroots ambassadors, deploying community coding hubs, advocating for fiber-optic expansion, and promoting telehealth and digital security awareness across Nigeria.'),
('page_about_banner_badge', 'Advocacy Identity'),
('page_about_banner_title', 'Who We Are'),
('page_about_banner_desc', 'Understanding the structural mandate, vision guidelines, and national coordinator network driving inclusive digital evolution.'),
('page_about_vision_title', 'Our Strategic Vision'),
('page_about_vision_desc', 'To serve as a premier non-governmental technology sensitizer across Nigeria, actively bridging connectivity gaps, fostering data intelligence literacy, and establishing active technology centers within rural local government areas.'),
('page_about_mission_title', 'Our Core Mission'),
('page_about_mission_desc', 'We are structured to design regional educational templates, provision certified digital skill paths for youth organizations, and partner with private capital entities to enable robust, inclusive digital transformations.'),
('page_about_org_title', 'Organizational Structure'),
('page_about_org_desc', 'PBAT Smart Nation operates a disciplined multi-tiered network coordinating digital awareness across geo-political zones.'),
('page_about_charter_title', 'Our Independence Charter'),
('page_about_charter_desc', 'Important Security & Scope Announcement: The PBAT Smart Nation Initiative is a 100% independent, non-governmental public advocacy movement. We function strictly to sensitize citizens on digital policy parameters and empower local youths.'),
('page_pillars_banner_badge', 'Development Vectors'),
('page_pillars_banner_title', 'Our Key Pillars'),
('page_pillars_banner_desc', 'Exploring the structural parameters driving open administration, cashless trading, and broadband accessibility.'),
('page_pillars_intro_desc1', 'Our Key Pillars represent the core values and strategic focus areas that drive our vision for growth, innovation, and sustainable impact. They serve as the foundation for every initiative, program, and partnership we undertake, ensuring that our efforts remain aligned with our mission to empower people, strengthen communities, and create lasting transformation.'),
('page_pillars_intro_desc2', 'Through these pillars, we are committed to advancing opportunities in education, technology, entrepreneurship, leadership, and social development. Each pillar is carefully designed to address critical challenges, encourage innovation, and promote inclusive progress across different sectors and communities.'),
('page_pillars_intro_desc3', 'We believe that meaningful development is achieved through collaboration, creativity, and consistent investment in people and ideas. By focusing on these essential areas, we create pathways for individuals and organizations to grow, thrive, and contribute positively to society.'),
('page_pillars_intro_desc4', 'Our Key Pillars are more than just areas of focus — they are a reflection of our commitment to building a future driven by knowledge, empowerment, sustainability, and measurable impact. Together, they guide our journey toward creating innovative solutions and transformative opportunities for generations to come.'),
('page_courses_banner_badge', 'Smart Academy'),
('page_courses_banner_title', 'Digital Skills & Innovation'),
('page_courses_banner_desc', 'Free verified courses and educational pathways created to sensitize Nigerian youths and local representatives on emerging technologies, smart city developments, and AI solutions.'),
('system_version', '1.0.0');


-- Seed Mock Campaigns
INSERT INTO `campaigns` (`id`, `title`, `description`, `category`, `status`, `scheduled_at`, `leader_id`, `created_by`) VALUES
(1, 'Smart Nation Awareness Week', 'Driving digital skill development and internet accessibility briefings in municipal halls.', 'Tech Sensitization', 'active', NOW(), 7, 1),
(2, 'AI Education Campaign', 'Demystifying machine learning tools and coding logic for local youth groups.', 'AI Education', 'scheduled', DATE_ADD(NOW(), INTERVAL 5 DAY), 8, 1),
(3, 'Digital Revolution Town Hall', 'Discussing e-governance and online service channels with regional stakeholders.', 'Civic Mobilization', 'completed', DATE_SUB(NOW(), INTERVAL 3 DAY), 7, 2);

-- Seed Mock Campaign Analytics
INSERT INTO `campaign_analytics` (`campaign_id`, `reach_count`, `engagement_rate`) VALUES
(1, 12850, 68.5),
(2, 0, 0.0),
(3, 24500, 82.4);

-- Seed Mock Login History
INSERT INTO `login_history` (`user_id`, `ip_address`, `device_info`, `status`) VALUES
(1, '127.0.0.1', 'Chrome 125.0 / Windows 11', 'success'),
(1, '192.168.1.10', 'Firefox 126.0 / macOS Sonoma', 'success'),
(2, '127.0.0.1', 'Safari / iPhone 15', 'success');

-- Seed Default Tasks for testing
INSERT INTO `nsc_tasks` (`id`, `title`, `description`, `target_type`, `target_name`, `deadline`, `status`, `created_by`) VALUES
(1, 'Broadband Sensitization Rollout', 'Deploy training materials for community leaders.', 'zone', 'South West', '2026-07-01', 'pending', 3),
(2, 'Ambassador ID QR Check', 'Perform manual identity checks on grassroots representatives.', 'state', 'Lagos', '2026-06-15', 'completed', 3);

-- Seed Default Polls for testing
INSERT INTO `nsc_polls` (`id`, `question`, `options_json`, `votes_json`, `status`, `created_by`) VALUES
(1, 'Should mini tech hubs be decentralized to ward levels?', '["Yes, at ward levels", "No, keep state capitals", "Undecided"]', '[245, 80, 15]', 'active', 3),
(2, 'Priority area for the upcoming national training initiative?', '["AI Prompts", "Cyber-security", "Web Development"]', '[180, 220, 95]', 'active', 3);

-- Talent Pipeline Table
CREATE TABLE `talent_pipeline` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `skill` VARCHAR(100) NOT NULL,
  `role_type` ENUM('trainer', 'trainee') NOT NULL,
  `experience_years` INT DEFAULT 0,
  `additional_notes` TEXT DEFAULT NULL,
  `status` ENUM('pending', 'shortlisted', 'approved', 'rejected') DEFAULT 'pending',
  `moderation_notes` TEXT DEFAULT NULL,
  `moderated_by` INT DEFAULT NULL,
  `moderated_at` TIMESTAMP NULL DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `registration_type` VARCHAR(50) DEFAULT 'self',
  `talent_name` VARCHAR(150) DEFAULT NULL,
  `talent_email` VARCHAR(100) DEFAULT NULL,
  `talent_phone` VARCHAR(20) DEFAULT NULL,
  FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  FOREIGN KEY (`moderated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Volunteers Table
CREATE TABLE `volunteers` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `volunteer_areas` TEXT NOT NULL,
  `availability` VARCHAR(100) DEFAULT NULL,
  `experience` TEXT DEFAULT NULL,
  `status` ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Youtube Videos Table
CREATE TABLE `youtube_videos` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `title` VARCHAR(255) NOT NULL,
  `description` TEXT DEFAULT NULL,
  `youtube_id` VARCHAR(100) DEFAULT NULL,
  `video_source` VARCHAR(50) DEFAULT 'youtube',
  `video_url` VARCHAR(255) DEFAULT NULL,
  `duration` VARCHAR(50) DEFAULT NULL,
  `is_featured` TINYINT(1) DEFAULT 0,
  `created_by` INT NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Newsletters Table
CREATE TABLE `newsletters` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `email` VARCHAR(150) UNIQUE NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Project Sponsors Table
CREATE TABLE `project_sponsors` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `company_name` VARCHAR(255) NOT NULL,
  `contact_name` VARCHAR(150) NOT NULL,
  `contact_email` VARCHAR(150) NOT NULL,
  `contact_phone` VARCHAR(20) DEFAULT NULL,
  `sponsorship_category` VARCHAR(100) DEFAULT 'General',
  `sponsor_amount` DECIMAL(15,2) DEFAULT 0.00,
  `message` TEXT DEFAULT NULL,
  `status` VARCHAR(50) DEFAULT 'pending',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Contact Submissions Table
CREATE TABLE `contact_submissions` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(150) NOT NULL,
  `email` VARCHAR(150) NOT NULL,
  `subject` VARCHAR(255) NOT NULL,
  `message` TEXT NOT NULL,
  `status` VARCHAR(50) DEFAULT 'pending',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Command Resources Table
CREATE TABLE `command_resources` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `title` VARCHAR(255) NOT NULL,
  `description` TEXT DEFAULT NULL,
  `file_path` VARCHAR(255) NOT NULL,
  `file_type` VARCHAR(100) NOT NULL,
  `target_role` VARCHAR(50) DEFAULT 'all',
  `uploaded_by` INT NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`uploaded_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Seed user_kyc_extended for default users 7 and 8
INSERT INTO `user_kyc_extended` (`user_id`, `kyc_status`, `username`, `dob`, `nationality`, `state_of_origin`, `state_of_residence`) VALUES
(7, 'approved', 'tunde_coker', '1998-05-15', 'Nigerian', 'Lagos', 'Lagos'),
(8, 'approved', 'amara_eke', '1999-10-20', 'Nigerian', 'Enugu', 'Lagos');

-- Seed YouTube Videos
INSERT INTO `youtube_videos` (`id`, `title`, `description`, `youtube_id`, `duration`, `is_featured`, `created_by`) VALUES
(1, 'Decentralized Digital Workspaces for Rural Inclusion', 'A strategic walkthrough outlining how mini tech hubs are deployed to local ward units to scale tech skills.', 'dQw4w9WgXcQ', '10:15', 1, 1),
(2, 'Empowering Grassroots with AI Prompts', 'Demonstrating dynamic AI prompting models to youths inside local community training circles.', 'tgbNymZ7vqY', '15:30', 0, 1);

