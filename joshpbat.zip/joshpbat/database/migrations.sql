-- PBAT Smart Nation Initiative - Schema Migrations (v1.1.0)
-- Extending DB for Campaigns, Permissions, Messaging, Settings, and Audits

SET FOREIGN_KEY_CHECKS = 0;

-- 1. Create Campaigns Table
CREATE TABLE IF NOT EXISTS `campaigns` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `title` VARCHAR(255) NOT NULL,
  `description` TEXT NOT NULL,
  `category` VARCHAR(100) DEFAULT 'General',
  `status` ENUM('draft', 'scheduled', 'active', 'completed') DEFAULT 'draft',
  `scheduled_at` DATETIME DEFAULT NULL,
  `leader_id` INT DEFAULT NULL,
  `created_by` INT NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`leader_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. Create Campaign Analytics Table
CREATE TABLE IF NOT EXISTS `campaign_analytics` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `campaign_id` INT NOT NULL,
  `reach_count` INT DEFAULT 0,
  `engagement_rate` FLOAT DEFAULT 0.0,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`campaign_id`) REFERENCES `campaigns` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. Create Permissions Table
CREATE TABLE IF NOT EXISTS `permissions` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL UNIQUE,
  `display_name` VARCHAR(150) NOT NULL,
  `description` TEXT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4. Create Role Permissions Mapping
CREATE TABLE IF NOT EXISTS `role_permissions` (
  `role_id` INT NOT NULL,
  `permission_id` INT NOT NULL,
  PRIMARY KEY (`role_id`, `permission_id`),
  FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
  FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 5. Create Login History / Device Track Table
CREATE TABLE IF NOT EXISTS `login_history` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `ip_address` VARCHAR(45) NOT NULL,
  `device_info` VARCHAR(255) DEFAULT NULL,
  `status` ENUM('success', 'failed') DEFAULT 'success',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 6. Create Messages / Leadership Broadcast Table
CREATE TABLE IF NOT EXISTS `messages` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `sender_id` INT NOT NULL,
  `recipient_id` INT DEFAULT NULL, -- NULL implies global broadcast
  `channel` VARCHAR(50) DEFAULT 'general',
  `subject` VARCHAR(255) DEFAULT NULL,
  `body` TEXT NOT NULL,
  `is_read` TINYINT(1) DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`sender_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  FOREIGN KEY (`recipient_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 7. Create Dynamic Settings Table
CREATE TABLE IF NOT EXISTS `system_settings` (
  `setting_key` VARCHAR(100) PRIMARY KEY,
  `setting_value` TEXT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;

-- Seed Default Permissions
INSERT IGNORE INTO `permissions` (`id`, `name`, `display_name`, `description`) VALUES
(1, 'create_campaign', 'Create Campaigns', 'Allows writing and scheduling regional tech campaigns.'),
(2, 'approve_report', 'Approve Reports', 'Allows reviewing and verifying activity reports from ambassadors.'),
(3, 'manage_states', 'Manage States', 'Allows editing regional coordinates and state metrics.'),
(4, 'view_analytics', 'View Analytics', 'Allows checking comprehensive national participation heatmaps.'),
(5, 'manage_livestreams', 'Manage Livestreams', 'Allows adding stream countdowns and television links.');

-- Map Permissions to Super Admin (Role 1), Founder Circle (Role 2)
INSERT IGNORE INTO `role_permissions` (`role_id`, `permission_id`) VALUES
(1, 1), (1, 2), (1, 3), (1, 4), (1, 5),
(2, 1), (2, 2), (2, 4), (2, 5);

-- Seed Default System Settings
INSERT IGNORE INTO `system_settings` (`setting_key`, `setting_value`) VALUES
('site_name', 'PBAT Smart Nation Initiative'),
('logo_url', ''),
('theme_primary', '#063C1E'),
('theme_accent', '#D4AF37'),
('footer_copyright', '&copy; 2026 PBAT Smart Nation Initiative. All rights reserved.'),
('contact_email', 'info@pbat-smartnation.ng'),
('contact_phone', '+2348030000001');

-- Seed Mock Campaigns
INSERT IGNORE INTO `campaigns` (`id`, `title`, `description`, `category`, `status`, `scheduled_at`, `leader_id`, `created_by`) VALUES
(1, 'Smart Nation Awareness Week', 'Driving digital skill development and internet accessibility briefings in municipal halls.', 'Tech Sensitization', 'active', NOW(), 7, 1),
(2, 'AI Education Campaign', 'Demystifying machine learning tools and coding logic for local youth groups.', 'AI Education', 'scheduled', DATE_ADD(NOW(), INTERVAL 5 DAY), 8, 1),
(3, 'Digital Revolution Town Hall', 'Discussing e-governance and online service channels with regional stakeholders.', 'Civic Mobilization', 'completed', DATE_SUB(NOW(), INTERVAL 3 DAY), 7, 2);

-- Seed Mock Campaign Analytics
INSERT IGNORE INTO `campaign_analytics` (`campaign_id`, `reach_count`, `engagement_rate`) VALUES
(1, 12850, 68.5),
(2, 0, 0.0),
(3, 24500, 82.4);

-- Seed Mock Login History
INSERT IGNORE INTO `login_history` (`user_id`, `ip_address`, `device_info`, `status`) VALUES
(1, '127.0.0.1', 'Chrome 125.0 / Windows 11', 'success'),
(1, '192.168.1.10', 'Firefox 126.0 / macOS Sonoma', 'success'),
(2, '127.0.0.1', 'Safari / iPhone 15', 'success');
