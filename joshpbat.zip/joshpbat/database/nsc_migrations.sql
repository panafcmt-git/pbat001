-- v1.3.0 - National Steering Council Schema Migration
CREATE TABLE IF NOT EXISTS `nsc_tasks` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `title` VARCHAR(255) NOT NULL,
  `description` TEXT NOT NULL,
  `target_type` ENUM('zone', 'state') NOT NULL,
  `target_name` VARCHAR(100) NOT NULL,
  `deadline` DATE NOT NULL,
  `status` ENUM('pending', 'completed') DEFAULT 'pending',
  `created_by` INT NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `nsc_polls` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `question` VARCHAR(255) NOT NULL,
  `options_json` TEXT NOT NULL, -- e.g. ["Option A", "Option B"]
  `votes_json` TEXT NOT NULL,   -- e.g. [120, 45]
  `status` ENUM('active', 'closed') DEFAULT 'active',
  `created_by` INT NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Seed Default Tasks for testing
INSERT IGNORE INTO `nsc_tasks` (`id`, `title`, `description`, `target_type`, `target_name`, `deadline`, `status`, `created_by`) VALUES
(1, 'Broadband Sensitization Rollout', 'Deploy training materials for community leaders.', 'zone', 'South West', '2026-07-01', 'pending', 3),
(2, 'Ambassador ID QR Check', 'Perform manual identity checks on grassroots representatives.', 'state', 'Lagos', '2026-06-15', 'completed', 3);

-- Seed Default Polls for testing
INSERT IGNORE INTO `nsc_polls` (`id`, `question`, `options_json`, `votes_json`, `status`, `created_by`) VALUES
(1, 'Should mini tech hubs be decentralized to ward levels?', '["Yes, at ward levels", "No, keep state capitals", "Undecided"]', '[245, 80, 15]', 'active', 3),
(2, 'Priority area for the upcoming national training initiative?', '["AI Prompts", "Cyber-security", "Web Development"]', '[180, 220, 95]', 'active', 3);
