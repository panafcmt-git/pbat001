-- PBAT Smart Nation Initiative - Profile KYC & Membership Code Migrations
-- v1.2.0

ALTER TABLE `users` 
  ADD COLUMN `address` VARCHAR(255) DEFAULT NULL,
  ADD COLUMN `age` INT DEFAULT NULL,
  ADD COLUMN `gender` VARCHAR(20) DEFAULT NULL,
  ADD COLUMN `occupation` VARCHAR(100) DEFAULT NULL,
  ADD COLUMN `profile_completed` TINYINT(1) DEFAULT 0,
  ADD COLUMN `membership_code` VARCHAR(50) DEFAULT NULL,
  ADD COLUMN `last_reminder_sent` TIMESTAMP NULL DEFAULT NULL;
