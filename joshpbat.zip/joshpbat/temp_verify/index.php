<?php
/**
 * PBAT Smart Nation Initiative - Homepage
 * Highly polished premium landing page with responsive layouts, modern grids,
 * glassmorphism sections, media hubs, and real-time database-driven events/blogs.
 */
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/helpers/auth.php';
require_once __DIR__ . '/helpers/common.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$rsvp_success = '';
$rsvp_error = '';
$sponsor_success = '';
$sponsor_error = '';
$contact_success = '';
$contact_error = '';

// Note: POST handlers for sponsors and contact forms have been moved to sponsors.php and contact.php respectively.

// Handle RSVP Form Submission directly from homepage
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'homepage_rsvp') {
    if (!Auth::isLoggedIn()) {
        header("Location: login.php");
        exit;
    }
    
    if (!Auth::validateCsrf($_POST['csrf_token'] ?? '')) {
        $rsvp_error = "CSRF Token validation failed.";
    } else {
        $event_id = (int)$_POST['event_id'];
        $user_id = Auth::user()['id'];
        
        try {
            $db = Database::connect();
            // Check if already registered
            $check = $db->prepare("SELECT id FROM `event_registrants` WHERE user_id = ? AND event_id = ?");
            $check->execute([$user_id, $event_id]);
            if ($check->fetch()) {
                $rsvp_error = "You have already registered for this event!";
            } else {
                // Register user
                $stmt = $db->prepare("INSERT INTO `event_registrants` (event_id, user_id) VALUES (?, ?)");
                $stmt->execute([$event_id, $user_id]);
                
                // Try to reward points if they are an ambassador
                $stmt_amb = $db->prepare("SELECT id FROM `ambassadors` WHERE user_id = ?");
                $stmt_amb->execute([$user_id]);
                if ($stmt_amb->fetch()) {
                    $db->prepare("UPDATE `ambassadors` SET `impact_score` = `impact_score` + 10 WHERE user_id = ?")->execute([$user_id]);
                    Auth::logAction($user_id, 'AMBASSADOR_EVENT_RSVP', "Ambassador RSVPed to Event ID {$event_id} from homepage");
                    $_SESSION['success_msg'] = "You have successfully RSVPed and earned +10 Impact Points!";
                } else {
                    $_SESSION['success_msg'] = "You have successfully RSVPed for this event!";
                }
                
                header("Location: index.php#townhall");
                exit;
            }
        } catch (Exception $e) {
            $rsvp_error = "Error recording RSVP: " . $e->getMessage();
        }
    }
}

// Initialize SEO metadata for homepage
require_once __DIR__ . '/helpers/seo.php';
SEO::init([
    'title' => 'PBAT Smart Nation Initiative | Digital Transformation & Smart Nation Advocacy in Nigeria',
    'description' => 'PBAT Smart Nation Initiative is a national digital advocacy and innovation movement founded by Joshua Omeiza Emmanuel (TechLord) in 2022 to promote Smart Nation awareness, digital transformation, youth empowerment, civic technology participation, and future innovation education across Nigeria.',
    'keywords' => 'PBAT Smart Nation Initiative, Smart Nation Nigeria, Digital Transformation Nigeria, Digital Advocacy, Innovation Nigeria, AI Awareness Nigeria, Youth Empowerment Nigeria, TechLord, Nigeria Tech Onboarding',
    'type' => 'website'
]);

require_once __DIR__ . '/includes/header.php';

// Prepare variables for dynamic rendering with gorgeous hardcoded fallbacks
$events = [];
$blog_posts = [];
$livestreams = [];
$stats = [
    'ambassadors' => 1625,
    'states' => 36,
    'lgas' => 774,
    'impact_score' => 31800
];

$user_rsvps = [];

try {
    $db = Database::connect();
    
    // 1. Fetch upcoming events
    $stmt = $db->query("SELECT * FROM `events` ORDER BY `event_date` ASC LIMIT 3");
    $events = $stmt->fetchAll();

    // Fetch user RSVPs if logged in
    if (Auth::isLoggedIn()) {
        $user_id = Auth::user()['id'];
        $stmt_rsvps = $db->prepare("SELECT event_id FROM `event_registrants` WHERE user_id = ?");
        $stmt_rsvps->execute([$user_id]);
        $user_rsvps = $stmt_rsvps->fetchAll(PDO::FETCH_COLUMN);
    }

    // 2. Fetch featured blog posts
    $stmt = $db->query("SELECT b.*, u.name as author_name FROM `blog_posts` b JOIN `users` u ON b.author_id = u.id ORDER BY b.created_at DESC LIMIT 3");
    $blog_posts = $stmt->fetchAll();

    // 4. Fetch recently registered ambassadors for the scroll animation
    $stmt = $db->query("SELECT u.name, u.avatar, s.name as state_name, l.name as lga_name FROM users u JOIN ambassadors a ON a.user_id = u.id JOIN states s ON a.state_id = s.id JOIN lgas l ON a.lga_id = l.id WHERE u.role_id = 7 ORDER BY u.created_at DESC LIMIT 10");
    $recent_ambassadors = $stmt->fetchAll();

    // 5. Summarize statistics
    $stmt = $db->query("SELECT SUM(ambassador_count) as total_amb, SUM(impact_score) as total_impact FROM `analytics_summary`");
    $db_stats = $stmt->fetch();
    if ($db_stats && $db_stats['total_amb'] > 0) {
        $stats['ambassadors'] = $db_stats['total_amb'];
        $stats['impact_score'] = $db_stats['total_impact'];
    }

    // 6. Fetch scheduled or live broadcasts
    $stmt_ls = $db->query("SELECT l.*, u.name as author_name FROM `livestreams` l JOIN `users` u ON l.created_by = u.id WHERE l.status IN ('scheduled', 'live') ORDER BY l.scheduled_at ASC LIMIT 4");
    $livestreams = $stmt_ls->fetchAll();

} catch (Exception $e) {
    // Graceful error handle - Use elegant pre-defined dummy arrays
    $recent_ambassadors = [];
    $events = [
        [
            'id' => 1,
            'title' => 'Digital Revolution Town Hall',
            'description' => 'Discussing Smart Governance and local community mobilization through technology.',
            'event_date' => '2026-06-15 14:00:00',
            'location' => 'Interactive Virtual Hub & YouTube Live',
            'event_type' => 'Digital Town Hall',
            'is_virtual' => 1,
            'stream_url' => 'https://www.youtube.com/embed/dQw4w9WgXcQ'
        ],
        [
            'id' => 2,
            'title' => 'State Tech Leadership Forum',
            'description' => 'Strategic alignment meeting for state and LGA coordinators across South-West Nigeria.',
            'event_date' => '2026-06-25 10:00:00',
            'location' => 'Ikeja Innovation Hub, Lagos',
            'event_type' => 'Conference',
            'is_virtual' => 0,
            'stream_url' => NULL
        ]
    ];

    $blog_posts = [
        [
            'id' => 1,
            'title' => 'PBAT Smart Nation System Performance',
            'summary' => 'An overview of our advocacy reach across the six geo-political zones of Nigeria.',
            'cover_image' => 'assets/img/blog1.jpg',
            'author_name' => 'Hon. Yusuf Bello',
            'created_at' => '2026-06-01'
        ],
        [
            'id' => 2,
            'title' => 'AI Revolution and National Development',
            'summary' => 'Exploring how Artificial Intelligence can catalyze growth in small and medium enterprises.',
            'cover_image' => 'assets/img/blog2.jpg',
            'author_name' => 'Alhaji Ibrahim Dan-Ina',
            'created_at' => '2026-05-28'
        ],
        [
            'id' => 3,
            'title' => 'Infrastructure Strategy for Smart Cities',
            'summary' => 'Developing modern templates for internet connectivity, secure cloud nodes, and community digital workspaces.',
            'cover_image' => 'assets/img/blog3.jpg',
            'author_name' => 'Dr. Chioma Nnaji',
            'created_at' => '2026-05-25'
        ]
    ];

    $livestreams = [];
}

// Backfill scheduled broadcasts if database is empty
if (empty($livestreams)) {
    $livestreams = [
        [
            'id' => 901,
            'title' => 'PBAT National Tech Transition Briefing',
            'description' => 'A strategic briefing for regional ambassadors on launching the nationwide digital literacy workshops and cyber-hygiene seminars.',
            'stream_url' => 'https://www.youtube.com/embed/dQw4w9WgXcQ',
            'scheduled_at' => date('Y-m-d H:i:s', strtotime('+1 day 16:00:00')),
            'duration' => 60,
            'status' => 'scheduled',
            'author_name' => 'Dr. Amina Olayemi'
        ],
        [
            'id' => 902,
            'title' => 'Smart Agriculture & Digital Cooperatives Forum',
            'description' => 'Exploring e-marketplace apps and mobile inventory software to link local farmers directly with bulk commodity buyers.',
            'stream_url' => 'https://www.youtube.com/embed/dQw4w9WgXcQ',
            'scheduled_at' => date('Y-m-d H:i:s', strtotime('+3 days 10:00:00')),
            'duration' => 90,
            'status' => 'scheduled',
            'author_name' => 'Hon. Yusuf Bello'
        ],
        [
            'id' => 903,
            'title' => 'Grassroots Broadband & Smart Infrastructure Panel',
            'description' => 'Discussing community micro solar grid projects and regional public Wi-Fi hotspot deployments in South-West Nigeria.',
            'stream_url' => 'https://www.youtube.com/embed/dQw4w9WgXcQ',
            'scheduled_at' => date('Y-m-d H:i:s', strtotime('+5 days 14:00:00')),
            'duration' => 75,
            'status' => 'scheduled',
            'author_name' => 'Engr. Emeka Okafor'
        ]
    ];
}

// Backfill and clean up avatars for recently registered ambassadors
if (!isset($recent_ambassadors) || count($recent_ambassadors) < 8) {
    if (!isset($recent_ambassadors)) {
        $recent_ambassadors = [];
    }
    $mock_avatars = [
        'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&h=150&q=80',
        'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&h=150&q=80',
        'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=150&h=150&q=80',
        'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=150&h=150&q=80',
        'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=150&h=150&q=80',
        'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=150&h=150&q=80',
        'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=150&h=150&q=80',
        'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=150&h=150&q=80'
    ];
    $mock_names = ['Chinedu Okafor', 'Fatima Umar', 'Oluwaseun Balogun', 'Musa Ibrahim', 'Blessing Johnson', 'Yusuf Ayoola', 'Nkechi Diala', 'Zainab Bello'];
    $mock_states = ['Enugu', 'Kano', 'Lagos', 'Kaduna', 'Edo', 'Oyo', 'Anambra', 'Bauchi'];
    $mock_lgas = ['Enugu North', 'Kano Municipal', 'Ikeja', 'Kaduna North', 'Oredo', 'Ibadan North', 'Awka South', 'Bauchi'];
    
    $start_count = count($recent_ambassadors);
    for ($i = $start_count; $i < 8; $i++) {
        $idx = $i % count($mock_names);
        $recent_ambassadors[] = [
            'name' => $mock_names[$idx],
            'avatar' => $mock_avatars[$idx],
            'state_name' => $mock_states[$idx],
            'lga_name' => $mock_lgas[$idx]
        ];
    }
}

foreach ($recent_ambassadors as &$amb) {
    if (empty($amb['avatar']) || $amb['avatar'] === 'assets/img/default-avatar.png') {
        $hash = abs(crc32($amb['name']));
        $avatar_id = $hash % 8;
        $mock_avatars = [
            'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&h=150&q=80',
            'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&h=150&q=80',
            'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=150&h=150&q=80',
            'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=150&h=150&q=80',
            'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=150&h=150&q=80',
            'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=150&h=150&q=80',
            'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=150&h=150&q=80',
            'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=150&h=150&q=80'
        ];
        $amb['avatar'] = $mock_avatars[$avatar_id];
    }
}
unset($amb);
?>

<!-- Section 1: Hero Section -->
<section id="home" class="relative bg-bushgreen text-white min-h-[90vh] flex items-center overflow-hidden pb-12 md:pb-20 z-0">
    <!-- Visual background overlay matching mockup curved panels -->
    <div class="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-bushgreen-light/80 via-bushgreen to-bushgreen opacity-95"></div>
    
    <!-- Abstract futuristic tech grid lines -->
    <div class="absolute inset-0 bg-[linear-gradient(to_right,#ffffff05_1px,transparent_1px),linear-gradient(to_bottom,#ffffff05_1px,transparent_1px)] bg-[size:4rem_4rem]"></div>
    
    <!-- Big glowing mesh -->
    <div class="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-gold/10 rounded-full blur-[120px] pointer-events-none"></div>

    <!-- Waving Flag & Cloud Abstract Watermark Overlay -->
    <style>
        @keyframes flag-wave {
            0%, 100% { transform: translateY(0) rotate(0deg) scale(1); }
            50% { transform: translateY(-15px) rotate(1.5deg) scale(1.02); }
        }
        .animate-flag-wave {
            animation: flag-wave 12s ease-in-out infinite;
        }
    </style>
    <div class="absolute right-0 top-10 w-full md:w-1/2 h-full opacity-[0.07] pointer-events-none select-none z-0 overflow-hidden animate-flag-wave">
        <svg viewBox="0 0 800 600" class="w-full h-full text-white" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
            <!-- Stylized cloud/wave segments overlaying like a waving flag -->
            <path d="M100,220 C220,180 340,300 480,220 C620,140 700,240 760,200 L760,450 C700,490 620,390 480,470 C340,550 220,430 100,470 Z" />
            <!-- Representing Nigeria's Green-White-Green stripes vertically on the flag -->
            <path d="M320,180 C325,230 330,420 320,490" stroke="currentColor" stroke-width="12" stroke-dasharray="15 15" fill="none" opacity="0.4" />
            <path d="M540,180 C535,230 530,420 540,490" stroke="currentColor" stroke-width="12" stroke-dasharray="15 15" fill="none" opacity="0.4" />
            
            <!-- Additional cloud-like circles around the flag to add the cloud motif -->
            <circle cx="200" cy="150" r="40" opacity="0.3"/>
            <circle cx="600" cy="130" r="50" opacity="0.3"/>
            <circle cx="450" cy="120" r="30" opacity="0.2"/>
        </svg>
    </div>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-16 md:py-20 relative z-10 w-full">
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
            
            <!-- Hero Left Texts -->
            <div class="lg:col-span-7 space-y-4 sm:space-y-6 text-left">
                <div class="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/10 border border-white/20 backdrop-blur-sm">
                    <span class="w-2 h-2 rounded-full bg-gold animate-pulse"></span>
                    <span class="text-gold font-bold text-xs uppercase tracking-widest leading-none font-display"><?php echo htmlspecialchars(getSystemSetting('hero_badge', "Nigeria's Smart Evolution")); ?></span>
                </div>
                <h1 class="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight leading-[1.1] font-display">
                    <?php
                    $hero_title = getSystemSetting('hero_title', "PBAT SMART \r\nNATION INITIATIVE");
                    $lines = explode("\n", $hero_title);
                    if (count($lines) >= 2) {
                        echo htmlspecialchars(trim($lines[0])) . '<br>';
                        echo '<span class="text-transparent bg-clip-text bg-gradient-to-r from-gold via-gold-light to-gold font-black">' . htmlspecialchars(trim($lines[1])) . '</span>';
                    } else {
                        echo htmlspecialchars($hero_title);
                    }
                    ?>
                </h1>
                <p class="text-slate-300 text-xs sm:text-sm md:text-base max-w-xl font-light leading-relaxed">
                    <?php echo htmlspecialchars(getSystemSetting('hero_desc', "An independent, high-impact advocacy platform driving youth tech capacity building, AI sensitization, localized innovation hubs, and community technology leadership templates.")); ?>
                </p>
                <div class="flex flex-col sm:flex-row gap-3 pt-2">
                    <a href="<?php echo htmlspecialchars(getSystemSetting('hero_btn1_url', "register.php")); ?>" class="px-6 py-3 bg-gold hover:bg-gold-light text-bushgreen hover:scale-105 transition-all duration-300 font-extrabold text-xs sm:text-sm tracking-wide rounded-xl shadow-lg shadow-gold/10 text-center flex items-center justify-center gap-2">
                        <?php echo htmlspecialchars(getSystemSetting('hero_btn1_text', "JOIN ADVOCATES")); ?>
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"/></svg>
                    </a>
                    <a href="<?php echo htmlspecialchars(getSystemSetting('hero_btn2_url', "#about")); ?>" class="px-6 py-3 bg-white/10 hover:bg-white/15 text-white font-bold text-xs sm:text-sm tracking-wide rounded-xl border border-white/20 hover:border-white/30 transition-all text-center flex items-center justify-center gap-2">
                        <?php echo htmlspecialchars(getSystemSetting('hero_btn2_text', "READ OUR CHARTER")); ?>
                    </a>
                </div>

                <!-- Stats summary micro cards -->
                <div class="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-6 border-t border-white/10">
                    <div class="p-2.5 bg-white/5 rounded-xl border border-white/5">
                        <div class="text-gold text-xl sm:text-2xl font-bold font-display"><?php echo formatNumber($stats['ambassadors']); ?>+</div>
                        <div class="text-slate-400 text-[9px] uppercase font-semibold mt-0.5">Ambassadors</div>
                    </div>
                    <div class="p-2.5 bg-white/5 rounded-xl border border-white/5">
                        <div class="text-gold text-xl sm:text-2xl font-bold font-display"><?php echo $stats['states']; ?></div>
                        <div class="text-slate-400 text-[9px] uppercase font-semibold mt-0.5">States Mobilized</div>
                    </div>
                    <div class="p-2.5 bg-white/5 rounded-xl border border-white/5">
                        <div class="text-gold text-xl sm:text-2xl font-bold font-display"><?php echo $stats['lgas']; ?></div>
                        <div class="text-slate-400 text-[9px] uppercase font-semibold mt-0.5">LGAs Catalogued</div>
                    </div>
                    <div class="p-2.5 bg-white/5 rounded-xl border border-white/5">
                        <div class="text-gold text-xl sm:text-2xl font-bold font-display"><?php echo formatNumber($stats['impact_score']); ?></div>
                        <div class="text-slate-400 text-[9px] uppercase font-semibold mt-0.5">Advocacy Units</div>
                    </div>
                </div>
            </div>

            <!-- Hero Right Mock Visual Representation (matching mockup) -->
            <div class="lg:col-span-5 relative">
                <style>
                    @keyframes pbat-pan {
                        0% { transform: scale(1.15) translateX(-4%); }
                        50% { transform: scale(1.15) translateX(4%); }
                        100% { transform: scale(1.15) translateX(-4%); }
                    }
                    .animate-pbat-pan {
                        animation: pbat-pan 24s ease-in-out infinite;
                    }
                </style>
                <div class="relative mx-auto max-w-[340px] sm:max-w-[400px] aspect-[4/3.2] sm:aspect-[4/5] bg-bushgreen-dark rounded-3xl p-1 border-2 border-gold/45 shadow-2xl overflow-hidden group">
                    <!-- Dynamic panning background image -->
                    <div class="absolute inset-0 overflow-hidden rounded-[22px]">
                        <img src="<?php echo htmlspecialchars(getSystemSetting('hero_image_url', "uploads/pbat_hero.jpg")); ?>" alt="President Bola Ahmed Tinubu" class="w-full h-full object-cover animate-pbat-pan origin-center opacity-85">
                    </div>
                    <!-- Futuristic dashboard preview visualizer overlay -->
                    <div class="relative h-full w-full bg-gradient-to-t from-bushgreen-dark/95 via-bushgreen-dark/40 to-bushgreen-dark/70 rounded-[22px] p-4 sm:p-6 flex flex-col justify-between overflow-hidden border border-white/10">
                        
                        <!-- Mini widget -->
                        <div class="flex justify-between items-center bg-bushgreen-dark/60 backdrop-blur-sm p-2 sm:p-3 rounded-xl border border-white/15">
                            <span class="text-[10px] sm:text-xs font-semibold text-gold tracking-wider font-display"><?php echo htmlspecialchars(getSystemSetting('hero_patron_name', "PRESIDENT BOLA AHMED TINUBU")); ?></span>
                            <span class="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 text-[8px] sm:text-[9px] font-bold uppercase tracking-widest animate-pulse"><?php echo htmlspecialchars(getSystemSetting('hero_patron_tag', "Patron")); ?></span>
                        </div>

                        <!-- Central spacing or secondary element -->
                        <div class="my-auto flex items-center justify-center relative">
                            <!-- Subtle golden radial glow behind the center -->
                            <div class="absolute w-24 h-24 bg-gold/10 rounded-full blur-xl pointer-events-none"></div>
                        </div>

                        <!-- Card footer data -->
                        <div class="bg-bushgreen-dark/70 backdrop-blur-md rounded-xl border border-white/15 p-2.5 sm:p-3.5 space-y-1.5 sm:space-y-2">
                            <div class="flex justify-between text-[11px] sm:text-xs">
                                <span class="text-slate-200 font-medium"><?php echo htmlspecialchars(getSystemSetting('hero_widget_label', "Digital Literacy Campaign")); ?></span>
                                <span class="font-bold text-gold"><?php echo htmlspecialchars(getSystemSetting('hero_widget_val', "36 States + FCT")); ?></span>
                            </div>
                            <div class="w-full bg-white/10 rounded-full h-1 sm:h-1.5 overflow-hidden">
                                <div class="bg-gold h-full rounded-full" style="width: 100%"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
        </div>
    </div>

    <!-- Waving flag & cloud bottom shape divider -->
    <div class="absolute bottom-0 left-0 right-0 w-full overflow-hidden leading-none z-20 translate-y-[1px]">
        <svg class="relative block w-full h-[40px] md:h-[80px]" viewBox="0 0 1200 120" preserveAspectRatio="none" xmlns="http://www.w3.org/2000/svg">
            <!-- Wave layer 1: Gold accent -->
            <path d="M0,30 C300,120 900,-30 1200,60 L1200,120 L0,120 Z" class="fill-gold opacity-40"></path>
            <!-- Wave layer 2: Bushgreen-light accent -->
            <path d="M0,50 C400,110 800,10 1200,90 L1200,120 L0,120 Z" class="fill-bushgreen-light opacity-60"></path>
            <!-- Wave layer 3: Solid White (blends into the next white section) -->
            <path d="M0,60 C360,130 840,20 1200,100 L1200,120 L0,120 Z" class="fill-white"></path>
        </svg>
    </div>
</section>

<!-- Section 2: About Vision Section -->
<section id="about" class="py-12 sm:py-16 md:py-20 bg-white">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
            
            <!-- About Left Graphic Diagram -->
            <div class="lg:col-span-5">
                <div class="relative rounded-2xl overflow-hidden border border-slate-100 shadow-lg bg-slate-50 p-4 sm:p-6 flex flex-col items-center">
                    <div class="absolute inset-0 bg-gradient-to-br from-emerald-500/5 to-gold/5 pointer-events-none"></div>
                    <img src="<?php echo htmlspecialchars(getSystemSetting('about_image_url', "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=500&q=80")); ?>" 
                         alt="Digital Map of Nigeria Representation" 
                         class="rounded-xl shadow-md border border-slate-200 mb-4 object-cover h-52 sm:h-64 w-full">
                    
                    <div class="w-full space-y-3.5">
                        <div class="flex gap-3 items-start">
                            <div class="w-7 h-7 rounded-lg bg-bushgreen/10 flex items-center justify-center flex-shrink-0">
                                <svg class="w-3.5 h-3.5 text-bushgreen" fill="currentColor" viewBox="0 0 20 20"><path d="M9 2a1 1 0 000 2h2a1 1 0 100-2H9z"/><path fill-rule="evenodd" d="M4 5a2 2 0 012-2 3 3 0 003 3h2a3 3 0 003-3 2 2 0 012 2v11a2 2 0 01-2 2H6a2 2 0 01-2-2V5zm3 4a1 1 0 000 2h.01a1 1 0 100-2H7zm3 0a1 1 0 000 2h3a1 1 0 100-2h-3zm-3 4a1 1 0 100 2h.01a1 1 0 100-2H7zm3 0a1 1 0 100 2h3a1 1 0 100-2h-3z" clip-rule="evenodd"/></svg>
                            </div>
                            <div>
                                <h4 class="text-xs sm:text-sm font-bold text-slate-800">Strategic Roadmaps</h4>
                                <p class="text-[11px] text-slate-500 mt-0.5 leading-normal">We formulate detailed, community-centric advocacy frameworks for state governments.</p>
                            </div>
                        </div>
                        <div class="flex gap-3 items-start">
                            <div class="w-7 h-7 rounded-lg bg-bushgreen/10 flex items-center justify-center flex-shrink-0">
                                <svg class="w-3.5 h-3.5 text-bushgreen" fill="currentColor" viewBox="0 0 20 20"><path d="M13 6a3 3 0 11-6 0 3 3 0 016 0zM18 8a2 2 0 11-4 0 2 2 0 014 0zM14 15a4 4 0 00-8 0v3h8v-3zM6 8a2 2 0 11-4 0 2 2 0 014 0zM16 18v-3a5.972 5.972 0 00-.75-2.906A6.005 6.005 0 0121 15v3h-5z"/></svg>
                            </div>
                            <div>
                                <h4 class="text-xs sm:text-sm font-bold text-slate-800">Youth Centric Networks</h4>
                                <p class="text-[11px] text-slate-500 mt-0.5 leading-normal">Onboarding grassroots leaders to lead technological inclusion courses locally.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- About Right Text Contents -->
            <div class="lg:col-span-7 space-y-4">
                <span class="text-gold font-bold text-xs uppercase tracking-widest font-display block"><?php echo htmlspecialchars(getSystemSetting('about_badge', "Strategic Mandate")); ?></span>
                <h2 class="text-2xl sm:text-3xl font-extrabold text-bushgreen leading-snug font-display">
                    <?php echo htmlspecialchars(getSystemSetting('about_heading', "As an Advocacy Group, our vision is to work with the Presidency, the States, Local Governments, Communities and Private Investors in Empowering Every Citizen Through Digital Excellence.")); ?>
                </h2>
                <p class="text-slate-600 text-xs sm:text-sm leading-relaxed font-light">
                    <?php echo htmlspecialchars(getSystemSetting('about_content', "The PBAT Smart Nation Initiative functions as a catalyst. We are dedicated to ensuring that digital technologies are not localized inside financial hubs alone, but integrated thoroughly into agricultural sectors, state primary education programs, and municipal workflows.")); ?>
                </p>
                
                <div class="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
                    <div class="p-3 bg-slate-50 border border-slate-100 rounded-xl hover:border-gold/25 transition-all">
                        <div class="text-bushgreen font-bold text-xs sm:text-sm flex items-center gap-1.5">
                            <span class="w-1 h-4 bg-gold block rounded"></span>
                            <?php echo htmlspecialchars(getSystemSetting('about_val1_title', "PUBLIC TRUST")); ?>
                        </div>
                        <p class="text-slate-500 text-[11px] leading-relaxed font-light mt-1.5"><?php echo htmlspecialchars(getSystemSetting('about_val1_text', "Ensuring clear, unbiased, state-level monitoring and performance indexes.")); ?></p>
                    </div>
                    <div class="p-3 bg-slate-50 border border-slate-100 rounded-xl hover:border-gold/25 transition-all">
                        <div class="text-bushgreen font-bold text-xs sm:text-sm flex items-center gap-1.5">
                            <span class="w-1 h-4 bg-gold block rounded"></span>
                            <?php echo htmlspecialchars(getSystemSetting('about_val2_title', "CAPACITY BUILDING")); ?>
                        </div>
                        <p class="text-slate-500 text-[11px] leading-relaxed font-light mt-1.5"><?php echo htmlspecialchars(getSystemSetting('about_val2_text', "Standardizing coding bootcamps and tech skill classes for local youths.")); ?></p>
                    </div>
                    <div class="p-3 bg-slate-50 border border-slate-100 rounded-xl hover:border-gold/25 transition-all">
                        <div class="text-bushgreen font-bold text-xs sm:text-sm flex items-center gap-1.5">
                            <span class="w-1 h-4 bg-gold block rounded"></span>
                            <?php echo htmlspecialchars(getSystemSetting('about_val3_title', "INCLUSIVE GROWTH")); ?>
                        </div>
                        <p class="text-slate-500 text-[11px] leading-relaxed font-light mt-1.5"><?php echo htmlspecialchars(getSystemSetting('about_val3_text', "Targeting underserved LGAs and giving direct access to software pathways.")); ?></p>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>

<!-- Section 3: Green Banner Separator (Building a Smart United Nigeria) -->
<section class="bg-bushgreen text-white py-10 sm:py-12 relative overflow-hidden border-y-4 border-gold">
    <div class="absolute inset-0 bg-cover bg-center opacity-10 bg-[url('https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?auto=format&fit=crop&w=800&q=80')]"></div>
    <div class="max-w-4xl mx-auto text-center px-4 relative z-10 space-y-3">
        <span class="text-gold font-bold text-[10px] sm:text-xs uppercase tracking-widest font-display block"><?php echo htmlspecialchars(getSystemSetting('banner_badge', "National Core Ideology")); ?></span>
        <h2 class="text-2xl sm:text-3.5xl font-extrabold font-display uppercase tracking-tight leading-tight">
            <?php 
                $banner_title = getSystemSetting('banner_title', '"BUILDING A SMART, UNITED NIGERIA"');
                echo str_replace("UNITED NIGERIA", '<span class="text-gold">UNITED NIGERIA</span>', htmlspecialchars($banner_title));
            ?>
        </h2>
        <p class="text-slate-200 text-xs sm:text-sm max-w-2xl mx-auto font-light leading-relaxed">
            <?php echo htmlspecialchars(getSystemSetting('banner_subtitle', "Our initiative envisions a tech-driven nation where innovation drives prosperity, administration guarantees seamless transparency, and communities unified through digital access.")); ?>
        </p>
        <div class="pt-2">
            <a href="<?php echo htmlspecialchars(getSystemSetting('banner_btn_url', "register.php")); ?>" class="inline-flex items-center gap-2 px-5 py-2 bg-white text-bushgreen hover:bg-gold hover:text-bushgreen hover:scale-105 transition-all duration-300 font-bold text-xs rounded-lg shadow-md">
                <?php echo htmlspecialchars(getSystemSetting('banner_btn_text', "Register as Grassroots Ambassador")); ?>
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 8l4 4m0 0l-4 4m4-4H3"/></svg>
            </a>
        </div>
    </div>
</section>

<!-- Section 4: Key Pillars -->
<section id="pillars" class="py-12 sm:py-16 bg-slate-50 border-b border-slate-100">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-8">
        <div class="max-w-xl mx-auto space-y-1.5">
            <span class="text-gold font-bold text-xs uppercase tracking-widest font-display block"><?php echo htmlspecialchars(getSystemSetting('pillars_badge', "Development Pillars")); ?></span>
            <h2 class="text-2xl sm:text-3xl font-extrabold text-bushgreen font-display"><?php echo htmlspecialchars(getSystemSetting('pillars_heading', "Our Key Pillars")); ?></h2>
            <p class="text-slate-500 text-xs font-light"><?php echo htmlspecialchars(getSystemSetting('pillars_subtitle', "Focus areas driving national digital transformation awareness and skills training.")); ?></p>
        </div>

        <!-- Introductory Content Block -->
        <div class="max-w-3xl mx-auto bg-white rounded-2xl p-6 sm:p-8 border border-slate-100 shadow-sm text-left space-y-4">
            <h3 class="text-sm sm:text-base font-bold text-bushgreen font-display flex items-center gap-2">
                <span class="w-1.5 h-6 bg-gold rounded-full"></span>
                <?php echo htmlspecialchars(getSystemSetting('pillars_intro_title', "Building Nigeria's Digital Future")); ?>
            </h3>
            <p class="text-slate-600 text-xs leading-relaxed font-light">
                <?php echo htmlspecialchars(getSystemSetting('pillars_intro_desc1', "The PBAT Smart Nation Initiative is anchored on a vision of technological empowerment, civic transparency, and sustainable development. By dividing our focus into five specialized strategic pillars, we ensure that every community, local business, and public department gets custom advocacy, sensitization, and practical digital training.")); ?>
            </p>
            <p class="text-slate-600 text-xs leading-relaxed font-light">
                <?php echo htmlspecialchars(getSystemSetting('pillars_intro_desc2', "Explore each pillar below to understand how we are coordinating grassroots ambassadors, deploying community coding hubs, advocating for fiber-optic expansion, and promoting telehealth and digital security awareness across Nigeria.")); ?>
            </p>
        </div>

        <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4 md:gap-6">
            <!-- Card 1 -->
            <a href="pillar-detail.php?type=governance" class="bg-white rounded-2xl p-4 sm:p-5 border border-slate-100 shadow-sm hover:shadow-md hover:border-gold hover:ring-1 hover:ring-gold/40 hover:-translate-y-1.5 transition-all duration-300 group flex flex-col justify-between text-center">
                <div class="space-y-3">
                    <div class="w-10 h-10 rounded-xl bg-bushgreen/5 flex items-center justify-center text-bushgreen group-hover:bg-bushgreen group-hover:text-white transition-colors duration-300 mx-auto">
                        <svg class="w-5.5 h-5.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/></svg>
                    </div>
                    <h3 class="text-slate-800 font-bold text-xs sm:text-sm">Smart Governance</h3>
                    <p class="text-slate-500 text-[10px] sm:text-[11px] leading-relaxed font-light">Promoting open source state portals, secure identity systems, and paperless administrative models.</p>
                </div>
            </a>
            <!-- Card 2 -->
            <a href="pillar-detail.php?type=economy" class="bg-white rounded-2xl p-4 sm:p-5 border border-slate-100 shadow-sm hover:shadow-md hover:border-gold hover:ring-1 hover:ring-gold/40 hover:-translate-y-1.5 transition-all duration-300 group flex flex-col justify-between text-center">
                <div class="space-y-3">
                    <div class="w-10 h-10 rounded-xl bg-bushgreen/5 flex items-center justify-center text-bushgreen group-hover:bg-bushgreen group-hover:text-white transition-colors duration-300 mx-auto">
                        <svg class="w-5.5 h-5.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                    </div>
                    <h3 class="text-slate-800 font-bold text-xs sm:text-sm">Smart Economy</h3>
                    <p class="text-slate-500 text-[10px] sm:text-[11px] leading-relaxed font-light">Encouraging cashless transactions, digital farm cooperatives, and small business tech training.</p>
                </div>
            </a>
            <!-- Card 3 -->
            <a href="pillar-detail.php?type=people" class="bg-white rounded-2xl p-4 sm:p-5 border border-slate-100 shadow-sm hover:shadow-md hover:border-gold hover:ring-1 hover:ring-gold/40 hover:-translate-y-1.5 transition-all duration-300 group flex flex-col justify-between text-center">
                <div class="space-y-3">
                    <div class="w-10 h-10 rounded-xl bg-bushgreen/5 flex items-center justify-center text-bushgreen group-hover:bg-bushgreen group-hover:text-white transition-colors duration-300 mx-auto">
                        <svg class="w-5.5 h-5.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"/></svg>
                    </div>
                    <h3 class="text-slate-800 font-bold text-xs sm:text-sm">Smart People</h3>
                    <p class="text-slate-500 text-[10px] sm:text-[11px] leading-relaxed font-light">Developing computer labs in low-income schools and establishing technical libraries.</p>
                </div>
            </a>
            <!-- Card 4 -->
            <a href="pillar-detail.php?type=infrastructure" class="bg-white rounded-2xl p-4 sm:p-5 border border-slate-100 shadow-sm hover:shadow-md hover:border-gold hover:ring-1 hover:ring-gold/40 hover:-translate-y-1.5 transition-all duration-300 group flex flex-col justify-between text-center">
                <div class="space-y-3">
                    <div class="w-10 h-10 rounded-xl bg-bushgreen/5 flex items-center justify-center text-bushgreen group-hover:bg-bushgreen group-hover:text-white transition-colors duration-300 mx-auto">
                        <svg class="w-5.5 h-5.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"/></svg>
                    </div>
                    <h3 class="text-slate-800 font-bold text-xs sm:text-sm">Smart Infrastructure</h3>
                    <p class="text-slate-500 text-[10px] sm:text-[11px] leading-relaxed font-light">Facilitating rural broadband expansion advocacy and neighborhood micro solar grids.</p>
                </div>
            </a>
            <!-- Card 5 -->
            <a href="pillar-detail.php?type=living" class="bg-white rounded-2xl p-4 sm:p-5 border border-slate-100 shadow-sm hover:shadow-md hover:border-gold hover:ring-1 hover:ring-gold/40 hover:-translate-y-1.5 transition-all duration-300 group flex flex-col justify-between text-center">
                <div class="space-y-3">
                    <div class="w-10 h-10 rounded-xl bg-bushgreen/5 flex items-center justify-center text-bushgreen group-hover:bg-bushgreen group-hover:text-white transition-colors duration-300 mx-auto">
                        <svg class="w-5.5 h-5.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"/></svg>
                    </div>
                    <h3 class="text-slate-800 font-bold text-xs sm:text-sm">Smart Living</h3>
                    <p class="text-slate-500 text-[10px] sm:text-[11px] leading-relaxed font-light">Promoting digital security safety awareness, health-tech applications, and civic tools.</p>
                </div>
            </a>
        </div>
    </div>
</section>

<!-- Section 5: Scheduled TV Broadcasts & Episodes -->
<section id="tv-broadcasts" class="py-12 sm:py-16 bg-white border-b border-slate-100">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8" x-data="{ reminderSet: false }">
        <div class="text-center space-y-1.5 max-w-xl mx-auto">
            <span class="text-gold font-bold text-xs uppercase tracking-widest font-display block">Media Center</span>
            <h2 class="text-2xl sm:text-3xl font-extrabold text-bushgreen font-display">Scheduled TV Broadcasts & Episodes</h2>
            <p class="text-slate-500 text-xs font-light">Tune in to our real-time broadcasts, technology masterclasses, and national transformation briefings.</p>
        </div>

        <!-- Success Toast Notification -->
        <div x-show="reminderSet" 
             x-transition:enter="transition ease-out duration-300"
             x-transition:enter-start="opacity-0 translate-y-2"
             x-transition:enter-end="opacity-100 translate-y-0"
             x-transition:leave="transition ease-in duration-250"
             x-transition:leave-start="opacity-100 translate-y-0"
             x-transition:leave-end="opacity-0 translate-y-2"
             class="fixed bottom-5 right-5 z-50 max-w-sm bg-bushgreen border border-gold/30 text-white px-4 py-3 rounded-xl shadow-lg flex items-center gap-3"
             style="display: none;">
            <svg class="w-5 h-5 text-gold flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
            <div>
                <h4 class="text-xs font-bold text-gold">Reminder Registered!</h4>
                <p class="text-[10px] text-slate-300 font-light mt-0.5">We will notify you via email 15 minutes before the broadcast begins.</p>
            </div>
        </div>

        <!-- Broadcast Grid -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <?php foreach ($livestreams as $ls): 
                $sched_time = strtotime($ls['scheduled_at']);
                $duration_secs = ($ls['duration'] ?? 60) * 60;
                $is_live = ($ls['status'] === 'live') || ($ls['status'] === 'scheduled' && $sched_time <= time() && time() <= ($sched_time + $duration_secs));
            ?>
                <div class="bg-slate-50 rounded-2xl border border-slate-100 p-5 shadow-sm hover:shadow-md hover:border-gold hover:ring-1 hover:ring-gold/30 transition-all duration-300 flex flex-col justify-between group relative overflow-hidden">
                    
                    <div class="space-y-4">
                        <!-- Top status badge -->
                        <div class="flex justify-between items-center">
                            <?php if ($is_live): ?>
                                <span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-red-100 text-red-800 text-[10px] font-bold uppercase tracking-wider animate-pulse">
                                    <span class="w-1.5 h-1.5 rounded-full bg-red-600"></span>
                                    Live Now
                                </span>
                            <?php else: ?>
                                <span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-gold/10 text-gold-dark text-[10px] font-bold uppercase tracking-wider">
                                    <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                                    Scheduled
                                </span>
                            <?php endif; ?>
                            <span class="text-[10px] text-slate-400 font-semibold font-mono">
                                <?php echo htmlspecialchars($ls['duration']); ?> Mins
                            </span>
                        </div>

                        <!-- Info details -->
                        <div class="space-y-1.5">
                            <h3 class="text-slate-800 font-bold text-sm sm:text-base line-clamp-1 group-hover:text-bushgreen transition-colors font-display">
                                <?php echo htmlspecialchars($ls['title']); ?>
                            </h3>
                            <p class="text-slate-500 text-xs leading-relaxed font-light line-clamp-2">
                                <?php echo htmlspecialchars($ls['description']); ?>
                            </p>
                        </div>
                    </div>

                    <!-- Countdown & Action panel -->
                    <div class="mt-5 pt-4 border-t border-slate-100 space-y-4 w-full">
                        <div class="flex justify-between items-center text-xs">
                            <span class="text-slate-400 font-light text-[11px]">Host: <span class="text-slate-600 font-semibold"><?php echo htmlspecialchars($ls['author_name'] ?? 'Smart Nation Admin'); ?></span></span>
                            <span class="text-slate-500 font-semibold font-mono text-[10px]">
                                <?php echo date('M d, Y @ h:i A', $sched_time); ?>
                            </span>
                        </div>

                        <?php if (!$is_live): ?>
                            <!-- Countdown container using Alpine.js -->
                            <div x-data="{
                                target: <?php echo $sched_time * 1000; ?>,
                                timeLeft: '00d 00h 00m 00s',
                                init() {
                                    this.updateTime();
                                    setInterval(() => { this.updateTime(); }, 1000);
                                },
                                updateTime() {
                                    const now = new Date().getTime();
                                    const diff = this.target - now;
                                    if (diff <= 0) {
                                        this.timeLeft = 'Starting...';
                                        return;
                                    }
                                    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
                                    const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                                    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
                                    const seconds = Math.floor((diff % (1000 * 60)) / 1000);
                                    this.timeLeft = days.toString().padStart(2, '0') + 'd ' + 
                                                    hours.toString().padStart(2, '0') + 'h ' + 
                                                    minutes.toString().padStart(2, '0') + 'm ' + 
                                                    seconds.toString().padStart(2, '0') + 's';
                                }
                            }" class="bg-bushgreen/5 rounded-xl p-2.5 text-center border border-bushgreen/10">
                                <span class="text-[9px] text-slate-400 uppercase tracking-widest font-bold block">Broadcast Countdown</span>
                                <span class="text-xs sm:text-sm font-bold font-mono text-bushgreen mt-0.5 block" x-text="timeLeft">00d 00h 00m 00s</span>
                            </div>
                        <?php endif; ?>

                        <div class="flex gap-2">
                            <?php if ($is_live): ?>
                                <a href="media.php" class="w-full text-center py-2 bg-red-600 hover:bg-red-700 text-white font-bold text-xs rounded-xl shadow-sm transition-all hover:scale-[1.02] flex items-center justify-center gap-1.5">
                                    <span class="w-2 h-2 rounded-full bg-white animate-ping"></span>
                                    Watch Stream Now
                                </a>
                            <?php else: ?>
                                <button @click="reminderSet = true; setTimeout(() => reminderSet = false, 4000)" 
                                        class="w-full py-2 bg-bushgreen hover:bg-bushgreen-light text-white font-bold text-xs rounded-xl transition-all flex items-center justify-center gap-1.5">
                                    <svg class="w-3.5 h-3.5 text-gold" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"/></svg>
                                    Notify Me
                                </button>
                                <a href="https://calendar.google.com/calendar/render?action=TEMPLATE&text=<?php echo urlencode($ls['title']); ?>&details=<?php echo urlencode($ls['description']); ?>&dates=<?php echo date('Ymd\THis', $sched_time); ?>/<?php echo date('Ymd\THis', $sched_time + $duration_secs); ?>" 
                                   target="_blank" 
                                   class="px-3 py-2 border border-slate-200 hover:border-gold text-slate-600 hover:text-gold rounded-xl transition flex items-center justify-center"
                                   title="Add to Google Calendar">
                                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>

                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- Section 6: Upcoming Program Town Halls -->
<section id="townhall" class="py-12 sm:py-16 bg-slate-50 border-y border-slate-100">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <div class="text-center space-y-1.5 max-w-xl mx-auto">
            <span class="text-gold font-bold text-xs uppercase tracking-widest font-display block">Community Gatherings</span>
            <h2 class="text-2xl sm:text-3xl font-extrabold text-bushgreen font-display">Upcoming Town Halls & Conferences</h2>
            <p class="text-slate-500 text-xs font-light">Join active webinars or attend local physical digital training programs scheduled near you.</p>
        </div>

        <!-- Alerts / Feedbacks -->
        <?php if (!empty($rsvp_error)): ?>
            <div class="max-w-md mx-auto p-3 bg-red-50 border border-red-200 text-red-800 text-xs font-semibold rounded-xl text-center">
                <?php echo htmlspecialchars($rsvp_error); ?>
            </div>
        <?php elseif (isset($_SESSION['success_msg'])): ?>
            <div class="max-w-md mx-auto p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-semibold rounded-xl text-center">
                <?php 
                    echo htmlspecialchars($_SESSION['success_msg']); 
                    unset($_SESSION['success_msg']);
                ?>
            </div>
        <?php endif; ?>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-6">
            <?php foreach ($events as $event): ?>
                <div class="bg-white rounded-2xl p-4 sm:p-5 border border-slate-100 shadow-sm hover:shadow-md hover:border-gold hover:ring-1 hover:ring-gold/40 transition-all flex flex-col justify-between">
                    <div class="space-y-3">
                        <div class="flex justify-between items-center">
                            <span class="px-2 py-0.5 rounded bg-bushgreen/10 text-bushgreen font-bold text-[9px] uppercase tracking-widest leading-none">
                                <?php echo htmlspecialchars($event['event_type']); ?>
                            </span>
                            <span class="text-[11px] text-slate-400 font-semibold">
                                <?php echo date('M d, Y @ h:i A', strtotime($event['event_date'])); ?>
                            </span>
                        </div>
                        <h3 class="text-slate-800 font-bold text-sm sm:text-base"><?php echo htmlspecialchars($event['title']); ?></h3>
                        <p class="text-slate-500 text-xs leading-relaxed font-light"><?php echo htmlspecialchars($event['description']); ?></p>

                        <?php if ($event['is_virtual'] && !empty($event['meeting_platform']) && $event['meeting_platform'] !== 'none'): ?>
                            <div class="p-3 bg-slate-50 border border-slate-100 rounded-xl text-[11px] text-slate-600 space-y-1">
                                <div class="flex items-center gap-1.5 font-bold text-bushgreen text-[10px] uppercase">
                                    <?php if ($event['meeting_platform'] === 'zoom'): ?>
                                        <span class="w-2 h-2 rounded-full bg-blue-500"></span>
                                        <span>Zoom Meeting Info</span>
                                    <?php elseif ($event['meeting_platform'] === 'google_meet'): ?>
                                        <span class="w-2 h-2 rounded-full bg-emerald-500"></span>
                                        <span>Google Meet Info</span>
                                    <?php elseif ($event['meeting_platform'] === 'youtube_live'): ?>
                                        <span class="w-2 h-2 rounded-full bg-red-500"></span>
                                        <span>YouTube Livestream</span>
                                    <?php else: ?>
                                        <span class="w-2 h-2 rounded-full bg-gold"></span>
                                        <span>Virtual Platform Info</span>
                                    <?php endif; ?>
                                </div>
                                <?php if (!empty($event['meeting_id'])): ?>
                                    <div><strong>Meeting ID:</strong> <span class="font-mono"><?php echo htmlspecialchars($event['meeting_id']); ?></span></div>
                                <?php endif; ?>
                                <?php if (!empty($event['meeting_passcode'])): ?>
                                    <div><strong>Passcode:</strong> <span class="font-mono"><?php echo htmlspecialchars($event['meeting_passcode']); ?></span></div>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center pt-4 mt-4 border-t border-slate-100 gap-3 w-full">
                        <span class="text-[11px] text-slate-500 font-semibold flex items-center gap-1.5">
                            <svg class="w-3.5 h-3.5 text-gold flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                            Location: <?php echo htmlspecialchars($event['location']); ?>
                        </span>
                        
                        <div class="flex gap-2 items-center self-end sm:self-auto">
                            <?php if ($event['is_virtual']): ?>
                                <?php if (!empty($event['meeting_link'])): ?>
                                    <a href="<?php echo htmlspecialchars($event['meeting_link']); ?>" target="_blank" class="px-4 py-2 bg-gold hover:bg-gold-light text-bushgreen font-bold text-xs rounded-lg transition inline-flex items-center gap-1">
                                        Join Meeting
                                    </a>
                                <?php elseif (!empty($event['stream_url'])): ?>
                                    <a href="media.php" class="px-4 py-2 bg-bushgreen hover:bg-bushgreen-light text-white font-bold text-xs rounded-lg transition">
                                        Watch Stream
                                    </a>
                                <?php endif; ?>
                            <?php endif; ?>
                            
                            <?php if (Auth::isLoggedIn()): ?>
                                <?php if (in_array($event['id'], $user_rsvps)): ?>
                                    <span class="px-4 py-2 bg-emerald-50 border border-emerald-200 text-emerald-800 font-bold text-xs rounded-lg flex items-center gap-1">
                                        <svg class="w-3.5 h-3.5 text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
                                        RSVPed
                                    </span>
                                <?php else: ?>
                                    <form method="POST" action="">
                                        <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                                        <input type="hidden" name="action" value="homepage_rsvp">
                                        <input type="hidden" name="event_id" value="<?php echo $event['id']; ?>">
                                        <button type="submit" class="px-4 py-2 border border-slate-200 hover:border-gold hover:text-gold text-slate-600 font-bold text-xs rounded-lg transition">
                                            RSVP Attendance
                                        </button>
                                    </form>
                                <?php endif; ?>
                            <?php else: ?>
                                <a href="login.php" class="px-4 py-2 border border-slate-200 hover:border-gold hover:text-gold text-slate-600 font-bold text-xs rounded-lg transition">
                                    RSVP Attendance
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- Section 7: News, Updates & Policy Drafts -->
<section class="py-12 sm:py-16 bg-white">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <div class="flex flex-col sm:flex-row justify-between items-start sm:items-end gap-4">
            <div class="space-y-1.5">
                <span class="text-gold font-bold text-xs uppercase tracking-widest font-display block">Advocacy Feed</span>
                <h2 class="text-2xl sm:text-3xl font-extrabold text-bushgreen font-display">News, Updates & Policy Drafts</h2>
                <p class="text-slate-500 text-xs font-light">Read recent circulars and strategic briefs regarding administrative tech performance.</p>
            </div>
            <a href="register.php" class="text-bushgreen hover:text-gold font-semibold text-xs flex items-center gap-1 group mt-2 sm:mt-0">
                Browse Publications
                <svg class="w-4 h-4 group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"/></svg>
            </a>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-5 sm:gap-6">
            <?php foreach ($blog_posts as $post): 
                $cover = $post['cover_image'] ?? '';
                if (empty($cover) || strpos($cover, 'assets/') === 0) {
                    if (strpos($cover, 'blog1') !== false) {
                        $cover = 'https://images.unsplash.com/photo-1557804506-669a67965ba0?auto=format&fit=crop&w=800&q=80';
                    } elseif (strpos($cover, 'blog2') !== false) {
                        $cover = 'https://images.unsplash.com/photo-1531482615713-2afd69097998?auto=format&fit=crop&w=800&q=80';
                    } elseif (strpos($cover, 'blog3') !== false) {
                        $cover = 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=800&q=80';
                    } else {
                        $cover = 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=800&q=80';
                    }
                }
            ?>
                <div class="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden hover:shadow-md hover:border-gold/30 transition flex flex-col justify-between">
                    <div>
                        <div class="h-40 sm:h-44 w-full bg-slate-100 relative">
                            <!-- Visual Placeholder or Post Image -->
                            <div class="absolute inset-0 bg-cover bg-center" style="background-image: url('<?php echo htmlspecialchars($cover); ?>');"></div>
                            <span class="absolute left-3 bottom-3 bg-bushgreen text-white font-bold text-[9px] px-2 py-0.5 rounded uppercase tracking-widest"><?php echo htmlspecialchars($post['category'] ?? 'News'); ?></span>
                        </div>
                        <div class="p-4 sm:p-5 space-y-2">
                            <h3 class="text-slate-800 font-bold text-sm sm:text-base line-clamp-2"><?php echo htmlspecialchars($post['title']); ?></h3>
                            <p class="text-slate-500 text-xs leading-relaxed font-light line-clamp-3">
                                <?php echo htmlspecialchars($post['summary']); ?>
                            </p>
                        </div>
                    </div>
                    <div class="p-4 sm:p-5 pt-0 flex justify-between items-center border-t border-slate-50 mt-2 text-[10px] text-slate-400 font-semibold">
                        <span>By: <?php echo htmlspecialchars($post['author_name']); ?></span>
                        <a href="article.php?id=<?php echo $post['id']; ?>" class="text-bushgreen hover:text-gold font-bold">Read Full &rarr;</a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- Section: Recently Registered Ambassadors (Scrolling Marquee) -->
<section class="py-10 sm:py-12 bg-slate-50 border-b border-slate-100 overflow-hidden">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-6 sm:mb-8 text-center space-y-1.5">
        <span class="text-gold font-bold text-xs uppercase tracking-widest font-display block">Community Network</span>
        <h2 class="text-2xl sm:text-3xl font-extrabold text-bushgreen font-display">Recently Registered Ambassadors</h2>
        <p class="text-slate-500 text-xs font-light">Meet our newly onboarded tech advocates mobilizing local governments nationwide.</p>
    </div>

    <!-- Scrolling Marquee Wrapper -->
    <div class="relative w-full overflow-hidden py-2 select-none">
        <!-- Glow gradient overlays on left and right for seamless blend -->
        <div class="absolute inset-y-0 left-0 w-24 bg-gradient-to-r from-slate-50 to-transparent z-10 pointer-events-none"></div>
        <div class="absolute inset-y-0 right-0 w-24 bg-gradient-to-l from-slate-50 to-transparent z-10 pointer-events-none"></div>

        <!-- Marquee inner list (duplicated for infinite loop) -->
        <div class="flex animate-marquee hover:[animation-play-state:paused] gap-4 sm:gap-6">
            <?php 
            $double_ambassadors = array_merge($recent_ambassadors, $recent_ambassadors);
            foreach ($double_ambassadors as $amb): 
            ?>
                <div class="flex items-center gap-3 bg-white border border-slate-100 p-2.5 sm:p-3 rounded-xl w-56 sm:w-64 shadow-sm flex-shrink-0">
                    <img src="<?php echo htmlspecialchars($amb['avatar']); ?>" 
                         alt="<?php echo htmlspecialchars($amb['name']); ?>" 
                         class="w-10 h-10 sm:w-12 sm:h-12 rounded-full border-2 border-gold/45 object-cover flex-shrink-0">
                    <div class="min-w-0">
                        <h4 class="text-slate-800 font-bold text-xs truncate leading-tight"><?php echo htmlspecialchars($amb['name']); ?></h4>
                        <span class="text-[9px] text-slate-400 block truncate mt-0.5"><?php echo htmlspecialchars($amb['lga_name'] ?? 'Ikeja'); ?>, <?php echo htmlspecialchars($amb['state_name']); ?> State</span>
                        <span class="inline-flex items-center gap-1 mt-1 text-[8px] font-bold text-emerald-600 bg-emerald-50 border border-emerald-100/50 px-1.5 py-0.5 rounded-md">
                            <span class="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                            New Advocate
                        </span>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- Styles for Scrolling Marquee -->
    <style>
        @keyframes marquee {
            0% { transform: translateX(0); }
            100% { transform: translateX(-50%); }
        }
        .animate-marquee {
            display: flex;
            width: max-content;
            animation: marquee 35s linear infinite;
        }
    </style>
</section>

<!-- Section 8: Public Ambassador Verification (Interactive search) -->
<section id="ambassador-verification" class="py-12 sm:py-16 bg-slate-50 border-t border-slate-100">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <div class="text-center space-y-1.5 max-w-xl mx-auto">
            <span class="text-gold font-bold text-xs uppercase tracking-widest font-display block">Verification Gateway</span>
            <h2 class="text-2xl sm:text-3xl font-extrabold text-bushgreen font-display">Ambassador Credential Validation</h2>
            <p class="text-slate-500 text-xs font-light">Confirm the identity and valid credentials of any local PBAT Smart Nation representative below.</p>
        </div>

        <!-- Search Form Card -->
        <div class="max-w-xl mx-auto bg-white p-4 sm:p-6 rounded-2xl border border-slate-100 shadow-md">
            <form action="verify.php" method="GET" class="space-y-4">
                <div>
                    <label class="block text-slate-700 text-xs font-semibold mb-1.5" for="uuid">Verify Ambassador by ID Hash or UUID:</label>
                    <div class="flex gap-2">
                        <input type="text" name="uuid" id="uuid" placeholder="e.g. AMB-6A3B91-3829" required
                               class="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 focus:outline-none focus:ring-2 focus:ring-bushgreen/20 focus:border-bushgreen transition text-xs font-mono">
                        <button type="submit" class="bg-bushgreen hover:bg-emerald-800 text-white font-bold text-xs px-5 py-2 rounded-lg transition shadow-md shadow-bushgreen/10 flex-shrink-0 flex items-center gap-1.5">
                            <svg class="w-3.5 h-3.5 text-gold" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/></svg>
                            Verify
                        </button>
                    </div>
                </div>
            </form>
        </div>

    </div>
</section>


<!-- Section 9: CTA - Become an Ambassador -->
<section class="py-12 sm:py-16 bg-white relative overflow-hidden">
    <div class="absolute inset-0 bg-slate-50/50 pointer-events-none"></div>
    <div class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div class="bg-gradient-to-tr from-bushgreen-dark to-bushgreen border border-gold/30 rounded-3xl p-6 sm:p-8 md:p-10 shadow-xl relative overflow-hidden flex flex-col md:flex-row justify-between items-center gap-6 md:gap-8">
            <div class="absolute top-0 right-0 w-[300px] h-[300px] bg-gold/5 rounded-full blur-[80px] pointer-events-none"></div>
            
            <div class="space-y-3 max-w-xl text-center md:text-left">
                <span class="text-gold font-bold text-xs uppercase tracking-widest font-display block">Grassroots Mobilization</span>
                <h2 class="text-xl sm:text-2xl md:text-3xl font-extrabold text-white font-display">Become a Smart Nation Ambassador Today!</h2>
                <p class="text-slate-300 text-xs leading-relaxed font-light">
                    Join thousands of young leaders, tech advocates, and community organizers championing digital literacy and technology programs in local governments across the country.
                </p>
            </div>
            
            <div class="flex-shrink-0 w-full md:w-auto flex flex-col sm:flex-row md:flex-col gap-2.5 sm:justify-center">
                <a href="register.php" class="px-6 py-3 bg-gold hover:bg-gold-light text-bushgreen hover:scale-105 transition-all text-center rounded-xl font-extrabold text-xs sm:text-sm tracking-wide shadow-md">
                    REGISTER NOW
                </a>
                <a href="login.php" class="px-6 py-3 bg-white/10 text-white hover:bg-white/15 text-center rounded-xl font-bold text-xs sm:text-sm tracking-wide transition border border-white/20">
                    PORTAL LOGIN
                </a>
            </div>
        </div>
    </div>
</section>

<?php 
require_once __DIR__ . '/includes/footer.php';
?>
