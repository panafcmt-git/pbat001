<?php
/**
 * PBAT Smart Nation Initiative - Forgot Password Account Recovery Gateway
 * Generates cryptographic reset tokens and dispatches colorful recovery emails.
 */
require_once __DIR__ . '/helpers/auth.php';
require_once __DIR__ . '/helpers/common.php';
require_once __DIR__ . '/helpers/notifications.php';
require_once __DIR__ . '/config/database.php';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!Auth::validateCsrf($_POST['csrf_token'] ?? '')) {
        $error = "Security validation token expired. Please try again.";
    } else {
        $email = trim($_POST['email']);
        if (empty($email)) {
            $error = "Please provide your registered email address.";
        } else {
            try {
                $db = Database::connect();
                
                // Verify email exists
                $stmt = $db->prepare("SELECT `id`, `name`, `email` FROM `users` WHERE `email` = ? LIMIT 1");
                $stmt->execute([$email]);
                $user = $stmt->fetch();
                
                if (!$user) {
                    $error = "No registered administrative account found with that email address.";
                } else {
                    // Generate cryptographic token expiring in 1 hour
                    $reset_token = bin2hex(random_bytes(32));
                    
                    $stmt = $db->prepare("UPDATE `users` SET `reset_token` = ?, `reset_expires` = DATE_ADD(NOW(), INTERVAL 1 HOUR) WHERE `id` = ?");
                    $stmt->execute([$reset_token, $user['id']]);
                    
                    // Dispatch highly-styled HTML email recovery
                    $http_host = $_SERVER['HTTP_HOST'] ?? 'localhost';
                    $reset_link = "http://{$http_host}" . dirname($_SERVER['PHP_SELF']) . "/reset-password.php?token=" . $reset_token;
                    NotificationEmail::sendPasswordRecovery($email, $user['name'], $reset_link);
                    
                    $success = "A secure reset link has been successfully dispatched to your email address.";
                }
            } catch (Exception $e) {
                $error = "System Database Exception: " . $e->getMessage();
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password - PBAT Smart Nation</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        bushgreen: {
                            DEFAULT: '#063C1E',
                            light: '#0A4D27',
                            dark: '#03200F',
                        },
                        gold: '#D4AF37'
                    }
                }
            }
        }
    </script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Outfit', sans-serif; }
    </style>
</head>
<body class="bg-slate-50 min-h-screen flex items-center justify-center p-4 relative overflow-hidden">
    <!-- Visual background glows -->
    <div class="absolute w-[500px] h-[500px] bg-bushgreen/10 rounded-full blur-[100px] -top-40 -left-40 pointer-events-none"></div>
    <div class="absolute w-[500px] h-[500px] bg-gold/5 rounded-full blur-[100px] -bottom-40 -right-40 pointer-events-none"></div>

    <div class="max-w-md w-full bg-white rounded-3xl shadow-2xl overflow-hidden border border-slate-100 relative z-10 transition-all duration-300">
        
        <!-- Curved Banner -->
        <div class="bg-bushgreen p-8 text-center relative overflow-hidden">
            <div class="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-emerald-800/50 via-bushgreen to-bushgreen opacity-95"></div>
            <div class="relative z-10 space-y-2">
                <a href="index.php" class="inline-block">
                    <div class="w-12 h-12 bg-white/10 rounded-xl flex items-center justify-center mx-auto border border-white/20 hover:scale-105 transition">
                        <svg class="w-6 h-6 text-gold" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/>
                        </svg>
                    </div>
                </a>
                <h1 class="text-white text-xl font-bold tracking-tight">Account Recovery Gateway</h1>
                <p class="text-gold/90 text-xs uppercase tracking-widest font-semibold">Retrieve Access Keys</p>
            </div>
        </div>

        <div class="p-8">
            <!-- Alert Display -->
            <?php if (!empty($error)): ?>
                <div class="mb-5 p-3.5 bg-red-50 border-l-4 border-red-500 rounded-r-lg text-xs text-red-700 font-semibold flex items-center gap-2">
                    <svg class="w-4 h-4 text-red-500 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clip-rule="evenodd"/></svg>
                    <?php echo $error; ?>
                </div>
            <?php endif; ?>

            <?php if (!empty($success)): ?>
                <div class="mb-5 p-3.5 bg-emerald-50 border-l-4 border-emerald-500 rounded-r-lg text-xs text-emerald-800 font-semibold">
                    <?php echo $success; ?>
                </div>
            <?php endif; ?>

            <form method="POST" action="" class="space-y-5">
                <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">

                <div>
                    <label class="block text-slate-700 text-xs font-semibold mb-1.5" for="email">Provide Registered Email Address</label>
                    <input type="email" name="email" id="email" required placeholder="e.g. ambassador@pbat-smartnation.ng"
                           class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 focus:outline-none focus:ring-2 focus:ring-bushgreen/20 focus:border-bushgreen transition text-xs">
                </div>

                <button type="submit" class="w-full py-3 bg-bushgreen hover:bg-bushgreen-light text-white font-bold rounded-xl text-xs shadow-md shadow-bushgreen/10 transition-all flex items-center justify-center gap-1.5 hover:scale-105">
                    DISPATCH PASSKEY RESET
                </button>
            </form>

            <div class="mt-8 border-t border-slate-100 pt-6 text-center text-xs">
                <span class="text-slate-500">Remembered credentials?</span>
                <a href="login.php" class="text-bushgreen hover:text-gold font-bold ml-1.5">Portal Log In</a>
            </div>
        </div>
    </div>
</body>
</html>
