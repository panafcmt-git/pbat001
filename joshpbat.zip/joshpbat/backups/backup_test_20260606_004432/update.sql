-- Add a dummy/test config key to system_settings for verification
INSERT INTO `system_settings` (`setting_key`, `setting_value`) VALUES ('update_test_marker', 'success') ON DUPLICATE KEY UPDATE `setting_value`='success';
