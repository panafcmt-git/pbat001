<?php
/**
 * PBAT Smart Nation Initiative - Authentication & RBAC Helper
 * Handles secure session state, authentication checks, CSRF security, and route guards.
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once dirname(__DIR__) . '/config/database.php';

class Auth {
    
    // Login user and configure session data
    public static function login($user) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_name'] = $user['name'];
        $_SESSION['user_email'] = $user['email'];
        $_SESSION['role_id'] = $user['role_id'];
        $_SESSION['role_name'] = self::getRoleNameById($user['role_id']);
        $_SESSION['last_activity'] = time();
        
        // Log authentication audit log
        self::logAction($user['id'], 'USER_LOGIN', 'Logged into the portal successfully.');
    }

    // Terminate session state
    public static function logout() {
        if (self::isLoggedIn()) {
            self::logAction($_SESSION['user_id'], 'USER_LOGOUT', 'Logged out of the portal.');
        }
        
        $_SESSION = [];
        if (ini_get("session.use_cookies")) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000,
                $params["path"], $params["domain"],
                $params["secure"], $params["httponly"]
            );
        }
        session_destroy();
    }

    // Verify session active
    public static function isLoggedIn() {
        return isset($_SESSION['user_id']);
    }

    // Get current user session info
    public static function user() {
        if (!self::isLoggedIn()) {
            return null;
        }
        return [
            'id' => $_SESSION['user_id'],
            'name' => $_SESSION['user_name'],
            'email' => $_SESSION['user_email'],
            'role_id' => $_SESSION['role_id'],
            'role' => $_SESSION['role_name']
        ];
    }

    // Fetch Role Name from DB or local lookup
    public static function getRoleNameById($role_id) {
        $roles = [
            1 => 'super_admin',
            2 => 'founder_circle',
            3 => 'national_steering',
            4 => 'zonal_chairman',
            5 => 'state_chairman',
            6 => 'coordinator',
            7 => 'ambassador'
        ];
        return $roles[$role_id] ?? 'unknown';
    }

    // Permission-based authorization check
    public static function hasPermission($permission_name) {
        if (!self::isLoggedIn()) {
            return false;
        }
        $role_id = $_SESSION['role_id'];
        try {
            $db = Database::connect();
            $stmt = $db->prepare("
                SELECT COUNT(1) 
                FROM `role_permissions` rp 
                JOIN `permissions` p ON rp.permission_id = p.id 
                WHERE rp.role_id = ? AND p.name = ?
            ");
            $stmt->execute([$role_id, $permission_name]);
            return $stmt->fetchColumn() > 0;
        } catch (Exception $e) {
            return false;
        }
    }

    // RBAC check for single or multiple allowed roles
    public static function hasRole($allowed_roles) {
        if (!self::isLoggedIn()) {
            return false;
        }
        
        $user_role = $_SESSION['role_name'];
        if (is_array($allowed_roles)) {
            return in_array($user_role, $allowed_roles);
        }
        
        return $user_role === $allowed_roles;
    }

    // Route protector middleware
    public static function requireRole($allowed_roles, $redirect_to = '../login.php') {
        if (!self::isLoggedIn()) {
            $_SESSION['auth_error'] = "Authentication required. Please login first.";
            header("Location: " . $redirect_to);
            exit;
        }

        // Validate session timeout (30 minutes)
        if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > 1800)) {
            self::logout();
            $_SESSION['auth_error'] = "Your session has expired due to inactivity. Please login again.";
            header("Location: " . $redirect_to);
            exit;
        }
        $_SESSION['last_activity'] = time();

        if (!self::hasRole($allowed_roles)) {
            $_SESSION['auth_error'] = "Access Denied. You do not have permissions to access that module.";
            
            // Redirect based on current role hierarchy
            $user_role = $_SESSION['role_name'];
            header("Location: " . dirname($_SERVER['PHP_SELF']) . "/dashboard.php");
            exit;
        }
    }

    // Generate CSRF token for forms
    public static function csrfToken() {
        if (empty($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['csrf_token'];
    }

    // Validate CSRF request token
    public static function validateCsrf($token) {
        if (!isset($_SESSION['csrf_token']) || empty($token)) {
            return false;
        }
        return hash_equals($_SESSION['csrf_token'], $token);
    }

    // Log administrative actions inside MySQL database
    public static function logAction($user_id, $action, $details = '') {
        try {
            $db = Database::connect();
            $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
            $ua = $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown';

            $stmt = $db->prepare("INSERT INTO `audit_logs` (`user_id`, `action`, `ip_address`, `user_agent`, `details`) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$user_id, $action, $ip, $ua, $details]);
        } catch (Exception $e) {
            // Silently ignore or write to error log to avoid breaking critical processes
            error_log("Audit logging failed: " . $e->getMessage());
        }
    }
}
