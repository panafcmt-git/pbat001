<?php
/**
 * PBAT Smart Nation Initiative - Amazon S3 Upload Utility
 * Lightweight, self-contained AWS Signature Version 4 implementation for S3 uploads.
 */

class S3Uploader {
    private $bucket;
    private $region;
    private $accessKey;
    private $secretKey;

    public function __construct($bucket, $region, $accessKey, $secretKey) {
        $this->bucket = $bucket;
        $this->region = $region;
        $this->accessKey = $accessKey;
        $this->secretKey = $secretKey;
    }

    public function uploadFile($filePath, $destinationKey, $mimeType = 'video/mp4') {
        if (!file_exists($filePath)) {
            return false;
        }

        $fileData = file_get_contents($filePath);
        $host = "{$this->bucket}.s3.{$this->region}.amazonaws.com";
        $endpoint = "https://{$host}/" . ltrim($destinationKey, '/');
        
        $now = time();
        $amzDate = gmdate('Ymd\THis\Z', $now);
        $amzDateShort = gmdate('Ymd', $now);
        
        // Canonical Request
        $httpMethod = 'PUT';
        $canonicalUri = '/' . ltrim($destinationKey, '/');
        $canonicalQueryString = '';
        
        $payloadHash = hash('sha256', $fileData);
        
        $canonicalHeaders = "host:{$host}\n" .
                            "x-amz-content-sha256:{$payloadHash}\n" .
                            "x-amz-date:{$amzDate}\n";
        
        $signedHeaders = 'host;x-amz-content-sha256;x-amz-date';
        
        $canonicalRequest = "{$httpMethod}\n" .
                            "{$canonicalUri}\n" .
                            "{$canonicalQueryString}\n" .
                            "{$canonicalHeaders}\n" .
                            "{$signedHeaders}\n" .
                            "{$payloadHash}";
        
        $stringToSign = "AWS4-HMAC-SHA256\n" .
                        "{$amzDate}\n" .
                        "{$amzDateShort}/{$this->region}/s3/aws4_request\n" .
                        hash('sha256', $canonicalRequest);
        
        // Signing Key
        $dateKey = hash_hmac('sha256', $amzDateShort, 'AWS4' . $this->secretKey, true);
        $regionKey = hash_hmac('sha256', $this->region, $dateKey, true);
        $serviceKey = hash_hmac('sha256', 's3', $regionKey, true);
        $signingKey = hash_hmac('sha256', 'aws4_request', $serviceKey, true);
        
        $signature = hash_hmac('sha256', $stringToSign, $signingKey);
        
        $authorization = "AWS4-HMAC-SHA256 " .
                         "Credential={$this->accessKey}/{$amzDateShort}/{$this->region}/s3/aws4_request, " .
                         "SignedHeaders={$signedHeaders}, " .
                         "Signature={$signature}";
        
        $headers = [
            "Host: {$host}",
            "x-amz-date: {$amzDate}",
            "x-amz-content-sha256: {$payloadHash}",
            "Authorization: {$authorization}",
            "Content-Type: {$mimeType}",
            "Content-Length: " . strlen($fileData)
        ];
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $endpoint);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PUT');
        curl_setopt($ch, CURLOPT_POSTFIELDS, $fileData);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_HEADER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpCode === 200) {
            return $endpoint;
        }
        return false;
    }
}

function uploadFileToS3IfActive($file_tmp_path, $original_filename, $mime_type = 'video/mp4') {
    require_once dirname(__DIR__) . '/config/database.php';
    try {
        $db = Database::connect();
        
        // Fetch S3 settings
        $stmt = $db->query("SELECT setting_key, setting_value FROM system_settings WHERE setting_key LIKE 's3_%'");
        $settings = [];
        while ($row = $stmt->fetch()) {
            $settings[$row['setting_key']] = $row['setting_value'];
        }
        
        $s3_enabled = isset($settings['s3_enabled']) && $settings['s3_enabled'] == '1';
        if (!$s3_enabled) {
            return false;
        }
        
        $bucket = $settings['s3_bucket'] ?? '';
        $region = $settings['s3_region'] ?? 'us-east-1';
        $accessKey = $settings['s3_key'] ?? '';
        $secretKey = $settings['s3_secret'] ?? '';
        
        if (empty($bucket) || empty($accessKey) || empty($secretKey)) {
            return false;
        }
        
        $file_ext = strtolower(pathinfo($original_filename, PATHINFO_EXTENSION));
        $destinationKey = 'uploads/video_' . time() . '_' . rand(1000, 9999) . '.' . $file_ext;
        
        $uploader = new S3Uploader($bucket, $region, $accessKey, $secretKey);
        return $uploader->uploadFile($file_tmp_path, $destinationKey, $mime_type);
    } catch (Exception $e) {
        return false;
    }
}
