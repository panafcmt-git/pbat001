<?php
/**
 * PBAT Smart Nation Initiative - Production-Grade SEO Architecture Helper
 * Handles dynamic meta tags, canonical systems, Open Graph, Twitter Cards, security headers,
 * performance optimizations, and structured JSON-LD schema generation.
 */

class SEO {
    // Primary Brand Configurations
    private static $baseUrl = 'https://app.pbatsmartnation.org.ng';
    private static $orgName = 'PBAT Smart Nation Initiative';
    private static $founderName = 'Joshua Omeiza Emmanuel';
    private static $alternateName = 'TechLord';
    private static $foundingDate = '2022';
    private static $orgType = 'National Non-Governmental Digital Advocacy Initiative';
    private static $orgDescription = 'PBAT Smart Nation Initiative is a national digital advocacy movement promoting Smart Nation awareness, innovation, digital transformation, youth empowerment, AI education, and technology-driven civic participation in Nigeria.';
    
    // Default Metadata Fallbacks
    private static $meta = [
        'title' => 'PBAT Smart Nation Initiative | Digital Transformation & Smart Nation Advocacy in Nigeria',
        'description' => 'PBAT Smart Nation Initiative is a national digital advocacy and innovation movement founded by Joshua Omeiza Emmanuel (TechLord) in 2022 to promote Smart Nation awareness, digital transformation, youth empowerment, civic technology participation, and future innovation education across Nigeria.',
        'keywords' => 'PBAT Smart Nation Initiative, Smart Nation Nigeria, Digital Transformation Nigeria, Digital Advocacy, Innovation Nigeria, AI Awareness Nigeria, Youth Empowerment Nigeria, TechLord, Nigeria Technology, Future Technology',
        'image' => 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=1200&h=630&q=80', // Premium Tech Background
        'type' => 'website',
        'author' => 'PBAT Smart Nation Initiative',
        'breadcrumbs' => [],
        'schemas' => [],
        'faqs' => []
    ];

    /**
     * Initializes or overrides the current page metadata.
     * @param array $pageMeta Key-value pairs of metadata overrides.
     */
    public static function init($pageMeta = []) {
        self::$meta = array_merge(self::$meta, $pageMeta);
        self::sendSecurityHeaders();
    }

    /**
     * Sends production-grade security headers to protect against clickjacking, XSS, and MIME-sniffing.
     */
    public static function sendSecurityHeaders() {
        if (!headers_sent()) {
            // HTTPS Enforcement Security Headers
            header("X-Frame-Options: SAMEORIGIN");
            header("X-Content-Type-Options: nosniff");
            header("X-XSS-Protection: 1; mode=block");
            header("Referrer-Policy: strict-origin-when-cross-origin");
            
            // Comprehensive Content Security Policy supporting CDN styles, fonts, and YouTube embeds
            header("Content-Security-Policy: default-src 'self' https: data: 'unsafe-inline' 'unsafe-eval'; frame-src 'self' https://www.youtube.com https://youtube.com;");
        }
    }

    /**
     * Resolves the canonical URL of the current page.
     * @return string
     */
    public static function getCanonicalUrl() {
        $uri = $_SERVER['REQUEST_URI'] ?? '';
        $path = parse_url($uri, PHP_URL_PATH);
        
        // Clean up trailing slash and index files
        if ($path === '/' || $path === '/index.php') {
            return self::$baseUrl . '/';
        }
        
        // Keep essential query strings for dynamic views (like articles and pillars)
        $queryStr = '';
        if (strpos($path, 'article.php') !== false && isset($_GET['id'])) {
            $queryStr = '?id=' . (int)$_GET['id'];
        } elseif (strpos($path, 'pillar-detail.php') !== false && isset($_GET['id'])) {
            $queryStr = '?id=' . (int)$_GET['id'];
        }
        
        // Return cleaned canonical URL mapping to rewrite routes if possible
        $cleanPath = preg_replace('/\.php$/', '', $path);
        return self::$baseUrl . $cleanPath . $queryStr;
    }

    /**
     * Renders all dynamic meta tags, Open Graph tags, Twitter cards, and canonical links.
     */
    public static function renderMeta() {
        $title = htmlspecialchars(self::$meta['title']);
        $description = htmlspecialchars(self::$meta['description']);
        $keywords = htmlspecialchars(self::$meta['keywords']);
        $image = htmlspecialchars(self::$meta['image']);
        $type = htmlspecialchars(self::$meta['type']);
        $author = htmlspecialchars(self::$meta['author']);
        $canonical = htmlspecialchars(self::getCanonicalUrl());
        
        echo "\n    <!-- SEO Dynamic Meta Tags -->\n";
        echo "    <title>{$title}</title>\n";
        echo "    <meta name=\"description\" content=\"{$description}\">\n";
        echo "    <meta name=\"keywords\" content=\"{$keywords}\">\n";
        echo "    <meta name=\"author\" content=\"{$author}\">\n";
        echo "    <link rel=\"canonical\" href=\"{$canonical}\">\n";
        
        echo "\n    <!-- Open Graph Tags (Facebook, LinkedIn, WhatsApp) -->\n";
        echo "    <meta property=\"og:title\" content=\"{$title}\">\n";
        echo "    <meta property=\"og:description\" content=\"{$description}\">\n";
        echo "    <meta property=\"og:image\" content=\"{$image}\">\n";
        echo "    <meta property=\"og:url\" content=\"{$canonical}\">\n";
        echo "    <meta property=\"og:type\" content=\"{$type}\">\n";
        echo "    <meta property=\"og:site_name\" content=\"" . htmlspecialchars(self::$orgName) . "\">\n";
        echo "    <meta property=\"og:locale\" content=\"en_NG\">\n";
        
        echo "\n    <!-- Twitter Cards (X Previews) -->\n";
        echo "    <meta name=\"twitter:card\" content=\"summary_large_image\">\n";
        echo "    <meta name=\"twitter:title\" content=\"{$title}\">\n";
        echo "    <meta name=\"twitter:description\" content=\"{$description}\">\n";
        echo "    <meta name=\"twitter:image\" content=\"{$image}\">\n";
        echo "    <meta name=\"twitter:site\" content=\"@pbatsmartnation\">\n";
        echo "    <meta name=\"twitter:creator\" content=\"@techlord\">\n";
    }

    /**
     * Renders all structured JSON-LD schemas inside script tags.
     */
    public static function renderSchemas() {
        $schemas = [];
        
        // 1. Organization Schema
        $schemas[] = [
            '@context' => 'https://schema.org',
            '@type' => 'NGO',
            'name' => self::$orgName,
            'alternateName' => self::$alternateName,
            'url' => self::$baseUrl,
            'logo' => self::$baseUrl . '/uploads/logo_1780429255.png',
            'foundingDate' => self::$foundingDate,
            'founder' => [
                '@type' => 'Person',
                'name' => self::$founderName,
                'alternateName' => self::$alternateName,
                'jobTitle' => 'Founder & Tech Lead'
            ],
            'description' => self::$orgDescription,
            'address' => [
                '@type' => 'PostalAddress',
                'addressLocality' => 'Abuja',
                'addressCountry' => 'Nigeria'
            ]
        ];

        // 2. WebSite Schema (with dynamic site search)
        $schemas[] = [
            '@context' => 'https://schema.org',
            '@type' => 'WebSite',
            'name' => self::$orgName,
            'url' => self::$baseUrl,
            'potentialAction' => [
                '@type' => 'SearchAction',
                'target' => self::$baseUrl . '/media.php?search={search_term_string}',
                'query-input' => 'required name=search_term_string'
            ]
        ];

        // 3. Breadcrumbs Schema
        if (!empty(self::$meta['breadcrumbs'])) {
            $itemListElement = [];
            // Always prepend Home
            $crumbs = array_merge([['name' => 'Home', 'url' => '/']], self::$meta['breadcrumbs']);
            foreach ($crumbs as $index => $crumb) {
                $itemListElement[] = [
                    '@type' => 'ListItem',
                    'position' => $index + 1,
                    'name' => $crumb['name'],
                    'item' => self::$baseUrl . $crumb['url']
                ];
            }
            $schemas[] = [
                '@context' => 'https://schema.org',
                '@type' => 'BreadcrumbList',
                'itemListElement' => $itemListElement
            ];
        }

        // 4. Custom Page Schemas (FAQ, Article, Event, Course)
        if (!empty(self::$meta['schemas'])) {
            foreach (self::$meta['schemas'] as $customSchema) {
                $schemas[] = $customSchema;
            }
        }
        
        // 5. FAQ Page Schema
        if (!empty(self::$meta['faqs'])) {
            $mainEntity = [];
            foreach (self::$meta['faqs'] as $faq) {
                $mainEntity[] = [
                    '@type' => 'Question',
                    'name' => $faq['question'],
                    'acceptedAnswer' => [
                        '@type' => 'Answer',
                        'text' => $faq['answer']
                    ]
                ];
            }
            $schemas[] = [
                '@context' => 'https://schema.org',
                '@type' => 'FAQPage',
                'mainEntity' => $mainEntity
            ];
        }

        // Print all JSON-LD blocks
        echo "\n    <!-- Structured Data JSON-LD Schemas -->\n";
        foreach ($schemas as $schema) {
            echo "    <script type=\"application/ld+json\">\n";
            echo json_encode($schema, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT) . "\n";
            echo "    </script>\n";
        }
    }

    /**
     * Premium CSS Minification tool to optimize styling assets in production.
     * @param string $css Raw CSS content.
     * @return string Minified CSS.
     */
    public static function minCss($css) {
        // Remove comments
        $css = preg_replace('!/\*[^*]*\*+([^/*][^*]*\*+)*/!', '', $css);
        // Remove spaces around colons, semicolons, brackets
        $css = str_replace(array("\r\n", "\r", "\n", "\t", '  ', '    ', '    '), '', $css);
        $css = preg_replace('/ ?([,:;{}]) ?/', '$1', $css);
        return trim($css);
    }

    /**
     * Outputs deferred JavaScript scripts to improve First Contentful Paint (FCP).
     * @param string $src JavaScript source link.
     * @return string
     */
    public static function deferJs($src) {
        return '<script defer src="' . htmlspecialchars($src) . '"></script>';
    }

    /**
     * Generates a fully responsive, lazy loaded image element complying with modern SEO layout rules.
     * @param string $src Image source.
     * @param string $alt Image descriptive alternative text.
     * @param string $class Additional CSS classes.
     * @param string $style Optional inline styling.
     * @return string
     */
    public static function lazyImage($src, $alt, $class = '', $style = '') {
        $cleanSrc = htmlspecialchars($src);
        $cleanAlt = htmlspecialchars($alt);
        $cleanClass = htmlspecialchars($class);
        $cleanStyle = htmlspecialchars($style);
        
        return "<img src=\"{$cleanSrc}\" alt=\"{$cleanAlt}\" class=\"{$cleanClass}\" style=\"{$cleanStyle}\" loading=\"lazy\" fetchpriority=\"low\">";
    }
}
