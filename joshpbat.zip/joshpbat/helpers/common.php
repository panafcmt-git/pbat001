<?php
/**
 * PBAT Smart Nation Initiative - Common Helpers & Security Utilities
 * Includes XSS prevention, sanitization, and alert notifications.
 */

require_once __DIR__ . '/s3.php';

// XSS Prevention wrap
function sanitize($data) {
    if (is_array($data)) {
        return array_map('sanitize', $data);
    }
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}

// Format numbers (e.g., impact scores or ambassador counts)
function formatNumber($num) {
    if ($num >= 1000) {
        return round($num / 1000, 1) . 'k';
    }
    return $num;
}

// Generate unique UUIDs for ambassador credential tracking
function generateUuid($prefix = 'AMB-') {
    return $prefix . strtoupper(substr(md5(uniqid(mt_rand(), true)), 0, 8)) . '-' . rand(1000, 9999);
}

// Render dynamic flash notifications
function displayAlerts() {
    $html = '';
    
    // Auth errors / generic warnings
    if (isset($_SESSION['auth_error'])) {
        $html .= '
        <div class="mb-5 p-4 bg-red-50 border-l-4 border-red-500 rounded-r-lg text-sm text-red-700 flex items-center gap-3 relative" id="alert-banner">
            <svg class="w-5 h-5 text-red-500 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
            </svg>
            <div>' . htmlspecialchars($_SESSION['auth_error']) . '</div>
            <button onclick="document.getElementById(\'alert-banner\').remove()" class="absolute right-3 top-3 text-red-400 hover:text-red-600 focus:outline-none">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
            </button>
        </div>';
        unset($_SESSION['auth_error']);
    }

    // Success notifications
    if (isset($_SESSION['success_msg'])) {
        $html .= '
        <div class="mb-5 p-4 bg-emerald-50 border-l-4 border-emerald-500 rounded-r-lg text-sm text-emerald-800 flex items-center gap-3 relative" id="alert-banner-success">
            <svg class="w-5 h-5 text-emerald-500 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <div>' . htmlspecialchars($_SESSION['success_msg']) . '</div>
            <button onclick="document.getElementById(\'alert-banner-success\').remove()" class="absolute right-3 top-3 text-emerald-400 hover:text-emerald-600 focus:outline-none">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
            </button>
        </div>';
        unset($_SESSION['success_msg']);
    }

    return $html;
}

// Send a dynamic, colorful HTML email notifications (database logging and optional SMTP socket/local outbox mock)
function sendMail($to_email, $subject, $html_body) {
    try {
        $db = Database::connect();
        
        $smtp_config_file = dirname(__DIR__) . '/config/smtp.php';
        if (file_exists($smtp_config_file)) {
            require_once $smtp_config_file;
        }
        
        $smtp_success = false;
        $smtp_log = '';
        
        if (defined('SMTP_ENABLED') && SMTP_ENABLED) {
            require_once __DIR__ . '/smtp.php';
            $mailer = new SMTPMailer(SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS, SMTP_ENCRYPTION);
            $smtp_success = $mailer->send(SMTP_FROM_EMAIL, SMTP_FROM_NAME, $to_email, $subject, $html_body);
            $smtp_log = $mailer->getLog();
        }
        
        // Log to sent_emails table in the database
        $status = $smtp_success ? 'sent' : (defined('SMTP_ENABLED') && SMTP_ENABLED ? 'failed' : 'mock_sent');
        $stmt = $db->prepare("INSERT INTO `sent_emails` (`to_email`, `subject`, `body`, `status`) VALUES (?, ?, ?, ?)");
        $stmt->execute([$to_email, $subject, $html_body, $status]);
        
        // Save as a local HTML preview file inside /emails/ folder
        $outbox_dir = dirname(__DIR__) . '/emails/';
        if (!is_dir($outbox_dir)) {
            mkdir($outbox_dir, 0755, true);
        }
        
        // Generate a clean filename based on subject and timestamp
        $clean_subject = preg_replace('/[^a-zA-Z0-9_-]/', '_', strtolower($subject));
        $file_name = time() . '_' . $clean_subject . '.html';
        file_put_contents($outbox_dir . $file_name, $html_body);
        
        return $smtp_success || !(defined('SMTP_ENABLED') && SMTP_ENABLED);
    } catch (Exception $e) {
        error_log("Mail delivery failed: " . $e->getMessage());
        return false;
    }
}

// Helper to get the absolute logo URL for HTML emails
function getAbsoluteLogoUrl() {
    try {
        $db = Database::connect();
        $stmt = $db->query("SELECT `setting_value` FROM `system_settings` WHERE `setting_key` = 'logo_url' LIMIT 1");
        $logo_url = $stmt->fetchColumn();
        if (!empty($logo_url)) {
            $http_host = $_SERVER['HTTP_HOST'] ?? 'localhost:8000';
            if (!preg_match('/^(http|https)/', $logo_url)) {
                return "http://{$http_host}/" . ltrim($logo_url, '/');
            }
            return $logo_url;
        }
    } catch (Exception $e) {}
    // Fallback default image representing technology
    return "https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=150&h=150&q=80";
}

// Build a highly stylized, premium, and responsive Bush Green & Gold HTML email layout
function getEmailTemplate($title, $subtitle, $greeting, $message_html, $button_url = '', $button_text = '') {
    $button_section = '';
    if (!empty($button_url) && !empty($button_text)) {
        // Resolve absolute URL for the button link if it is relative
        $http_host = $_SERVER['HTTP_HOST'] ?? 'localhost:8000';
        $full_button_url = $button_url;
        if (!preg_match('/^(http|https)/', $button_url)) {
            $full_button_url = "http://{$http_host}/" . ltrim($button_url, '/');
        }
        
        $button_section = '
        <tr>
            <td align="center" style="padding: 30px 0 10px 0;">
                <table border="0" cellspacing="0" cellpadding="0">
                    <tr>
                        <td align="center" style="border-radius: 12px;" bgcolor="#063C1E">
                            <a href="' . htmlspecialchars($full_button_url) . '" target="_blank" style="font-size: 13px; font-family: \'Outfit\', Helvetica, Arial, sans-serif; color: #ffffff; text-decoration: none; border-radius: 12px; padding: 14px 28px; border: 1px solid #D4AF37; display: inline-block; font-weight: bold; letter-spacing: 0.5px;">
                                ' . htmlspecialchars($button_text) . '
                            </a>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>';
    }

    $http_host = $_SERVER['HTTP_HOST'] ?? 'localhost:8000';
    $base_url = "http://{$http_host}";

    return '
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>' . htmlspecialchars($title) . '</title>
        <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700&display=swap" rel="stylesheet">
        <style>
            body { background-color: #f8fafc; margin: 0; padding: 0; -webkit-text-size-adjust: none; text-size-adjust: none; }
            table { border-collapse: collapse; }
            td { font-family: \'Outfit\', Helvetica, Arial, sans-serif; }
        </style>
    </head>
    <body style="background-color: #f8fafc; padding: 20px 0; margin: 0;">
        <table width="100%" border="0" cellspacing="0" cellpadding="0">
            <tr>
                <td align="center">
                    <table width="600" border="0" cellspacing="0" cellpadding="0" style="background-color: #ffffff; border-radius: 24px; overflow: hidden; border: 1px solid #e2e8f0; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05);">
                        <!-- Header Banner -->
                        <tr bgcolor="#063C1E">
                            <td align="center" style="padding: 40px 30px; position: relative;">
                                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                    <tr>
                                        <td align="center" style="padding-bottom: 15px;">
                                            <img src="' . htmlspecialchars(getAbsoluteLogoUrl()) . '" alt="PBAT Logo" style="height: 52px; width: auto; display: block;" height="52">
                                        </td>
                                    </tr>
                                    <tr>
                                        <td align="center" style="font-size: 22px; font-weight: 800; color: #ffffff; letter-spacing: 1px;">
                                            PBAT SMART NATION
                                        </td>
                                    </tr>
                                    <tr>
                                        <td align="center" style="font-size: 10px; font-weight: 700; color: #D4AF37; text-transform: uppercase; letter-spacing: 2px; padding-top: 5px;">
                                            ' . htmlspecialchars($subtitle) . '
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                        <!-- Body Content -->
                        <tr>
                            <td style="padding: 40px 40px 30px 40px;">
                                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                    <tr>
                                        <td style="font-size: 18px; font-weight: 700; color: #0f172a; padding-bottom: 20px;">
                                            ' . htmlspecialchars($greeting) . '
                                        </td>
                                    </tr>
                                    <tr>
                                        <td style="font-size: 14px; line-height: 1.6; color: #334155; font-weight: 300;">
                                            ' . $message_html . '
                                        </td>
                                    </tr>
                                    ' . $button_section . '
                                </table>
                            </td>
                        </tr>
                        <!-- Footer -->
                        <tr bgcolor="#f1f5f9">
                            <td align="center" style="padding: 30px; border-top: 1px solid #e2e8f0;">
                                <table width="100%" border="0" cellspacing="0" cellpadding="0" style="text-align: center;">
                                    <tr>
                                        <td style="font-size: 11px; font-weight: bold; color: #063C1E; text-transform: uppercase; letter-spacing: 0.5px;">
                                            PBAT Smart Nation Advocacy Initiative
                                        </td>
                                    </tr>
                                    <tr>
                                        <td style="font-size: 10px; color: #64748b; padding-top: 8px; font-weight: 300; line-height: 1.4;">
                                            This is an automated administrative notification. Please do not reply directly to this mailer outbox.
                                        </td>
                                    </tr>
                                    <tr>
                                        <td style="font-size: 11px; padding-top: 15px;">
                                            <a href="' . $base_url . '/index.php" target="_blank" style="color: #063C1E; text-decoration: none; font-weight: bold; margin: 0 10px;">Visit Site</a>
                                            <span style="color: #cbd5e1;">&bull;</span>
                                            <a href="' . $base_url . '/login.php" target="_blank" style="color: #063C1E; text-decoration: none; font-weight: bold; margin: 0 10px;">Portal Login</a>
                                            <span style="color: #cbd5e1;">&bull;</span>
                                            <a href="' . $base_url . '/about.php" target="_blank" style="color: #063C1E; text-decoration: none; font-weight: bold; margin: 0 10px;">Our Vision</a>
                                            <span style="color: #cbd5e1;">&bull;</span>
                                            <a href="' . $base_url . '/pillars.php" target="_blank" style="color: #063C1E; text-decoration: none; font-weight: bold; margin: 0 10px;">Development Pillars</a>
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
        </table>
    </body>
    </html>';
}

/**
 * Dynamic User Avatar Path Resolver
 * Prepends directory traversals when evaluated from scripts inside administrative subdirectories.
 */
function getUserAvatarUrl($avatar_path) {
    $fallback = 'assets/img/default-avatar.png';
    $path = !empty($avatar_path) ? $avatar_path : $fallback;
    
    // If it's already an absolute or network URL, return it
    if (preg_match('/^(http|https|\/)/', $path)) {
        return $path;
    }
    
    // Determine active workspace directory level
    $current_dir = basename(getcwd());
    if ($current_dir === 'admin') {
        return '../' . $path;
    }
    
    return $path;
}

function getAppLogoHtml($class_img = 'w-10 h-10 object-contain', $fallback_type = 'header') {
    try {
        require_once dirname(__DIR__) . '/config/database.php';
        $db = Database::connect();
        
        $is_footer = ($fallback_type === 'footer');
        $url_key = $is_footer ? 'footer_logo_url' : 'logo_url';
        $size_key = $is_footer ? 'footer_logo_size' : 'logo_size';
        
        $stmt = $db->prepare("SELECT `setting_value` FROM `system_settings` WHERE `setting_key` = ? LIMIT 1");
        $stmt->execute([$url_key]);
        $logo_url = $stmt->fetchColumn();
        
        // Fallback to main logo URL for footer if specific footer logo is not set
        if ($is_footer && empty($logo_url)) {
            $stmt->execute(['logo_url']);
            $logo_url = $stmt->fetchColumn();
            $size_key = 'logo_size';
        }
        
        if (!empty($logo_url)) {
            $path = $logo_url;
            $current_dir = basename(getcwd());
            if ($current_dir === 'admin') {
                if (!preg_match('/^(http|https|\/)/', $path)) {
                    $path = '../' . $path;
                }
            }
            
            // Retrieve logo size adjustment
            $stmt_size = $db->prepare("SELECT `setting_value` FROM `system_settings` WHERE `setting_key` = ? LIMIT 1");
            $stmt_size->execute([$size_key]);
            $logo_size = $stmt_size->fetchColumn();
            
            if (empty($logo_size)) {
                $logo_size = $is_footer ? '32' : '40';
            }
            
            $size_style = 'height: ' . (int)$logo_size . 'px; width: auto; max-height: none !important; max-width: 100% !important; object-fit: contain;';
            
            // Dynamic CSS to hide original brand text and symbol boundaries 100%
            if ($is_footer) {
                $css_override = '<style>
                    footer span.font-display,
                    footer span.text-gold,
                    footer a span,
                    footer .flex span {
                        display: none !important;
                    }
                    footer div.w-10.h-10,
                    footer div.w-8.h-8,
                    footer div.rounded,
                    footer div.rounded-lg {
                        width: auto !important;
                        height: auto !important;
                        background: transparent !important;
                        background-color: transparent !important;
                        border: none !important;
                        padding: 0 !important;
                        box-shadow: none !important;
                    }
                </style>';
            } else {
                $css_override = '<style>
                    header a.group div.flex-col,
                    header a div.flex-col,
                    header a span,
                    header a.group span,
                    header a.group div.flex-col span {
                        display: none !important;
                    }
                    header a div.rounded,
                    header a div.rounded-xl,
                    header a div.w-12,
                    header a div.w-8 {
                        width: auto !important;
                        height: auto !important;
                        background: transparent !important;
                        border: none !important;
                        padding: 0 !important;
                        box-shadow: none !important;
                    }
                </style>';
            }
            
            return '<img src="' . htmlspecialchars($path) . '" alt="App Logo" class="' . $class_img . '" style="' . $size_style . '">' . $css_override;
        }
    } catch (Exception $e) {
        // Fallback to SVG
    }

    // Fallback SVG icons
    if ($fallback_type === 'login') {
        return '<svg class="w-6 h-6 text-gold mx-auto animate-pulse" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/>
        </svg>';
    } elseif ($fallback_type === 'footer') {
        return '<svg class="w-6 h-6 text-gold" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z" />
        </svg>';
    } else { // header or dashboard
        return '<svg class="w-7 h-7 text-gold group-hover:scale-105 transition-transform duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
        </svg>';
    }
}

/**
 * Calculates KYC profile completion percentage.
 */
function calculateKycPercentage($user, $kyc) {
    if (is_array($user)) {
        $user_obj = (object)$user;
    } else {
        $user_obj = $user;
    }
    
    if (is_array($kyc)) {
        $kyc_obj = (object)$kyc;
    } else {
        $kyc_obj = $kyc;
    }

    // If KYC is successfully submitted/completed (status is not draft and not empty), completeness is 100%
    if (isset($kyc_obj->kyc_status) && !empty($kyc_obj->kyc_status) && $kyc_obj->kyc_status !== 'draft') {
        return 100;
    }

    $score = 0;

    // 1. Basic Profile details (Step 1): 25%
    $basic_fields = [
        !empty($user_obj->name) ? 1 : 0,
        !empty($user_obj->email) ? 1 : 0,
        !empty($user_obj->phone) ? 1 : 0,
        !empty($user_obj->gender) ? 1 : 0,
        (!empty($user_obj->avatar) && $user_obj->avatar !== 'assets/img/default-avatar.png') ? 1 : 0,
        !empty($kyc_obj->dob) ? 1 : 0,
        !empty($kyc_obj->nationality) ? 1 : 0,
        !empty($kyc_obj->state_of_origin) ? 1 : 0,
        !empty($kyc_obj->state_of_residence) ? 1 : 0
    ];
    $basic_completed = array_sum($basic_fields) / count($basic_fields);
    $score += $basic_completed * 25;

    // 2. Social/Digital coordinates (Step 2): 15%
    $social_fields = [
        !empty($kyc_obj->whatsapp_number) ? 1 : 0,
        !empty($kyc_obj->telegram_username) ? 1 : 0,
        !empty($kyc_obj->x_handle) ? 1 : 0,
        !empty($kyc_obj->facebook_profile) ? 1 : 0,
        !empty($kyc_obj->instagram_username) ? 1 : 0,
        !empty($kyc_obj->linkedin_profile) ? 1 : 0
    ];
    $social_completed = array_sum($social_fields) / count($social_fields);
    $score += $social_completed * 15;

    // 3. Education/Professional details (Step 3): 20%
    $edu_fields = [
        !empty($kyc_obj->highest_qualification) ? 1 : 0,
        !empty($kyc_obj->institution) ? 1 : 0,
        !empty($kyc_obj->course_of_study) ? 1 : 0,
        !empty($kyc_obj->graduation_year) ? 1 : 0,
        !empty($kyc_obj->employer) ? 1 : 0,
        !empty($kyc_obj->industry) ? 1 : 0,
        !empty($kyc_obj->skills_expertise) ? 1 : 0
    ];
    $edu_completed = array_sum($edu_fields) / count($edu_fields);
    $score += $edu_completed * 20;

    // 4. Digital skills selections (Step 4): 20%
    $skills_fields = [
        !empty($kyc_obj->digital_skills_data) ? 1 : 0,
        !empty($kyc_obj->tech_interests) ? 1 : 0,
        !empty($kyc_obj->innovation_interests) ? 1 : 0,
        !empty($kyc_obj->ai_knowledge_level) ? 1 : 0,
        !empty($kyc_obj->preferred_training_areas) ? 1 : 0
    ];
    $skills_completed = array_sum($skills_fields) / count($skills_fields);
    $score += $skills_completed * 20;

    // 5. Ambassadorship, Security & Uploads (Step 5): 20%
    $step5_fields = [
        !empty($kyc_obj->why_join) ? 1 : 0,
        !empty($kyc_obj->security_question) ? 1 : 0,
        !empty($kyc_obj->security_answer_hash) ? 1 : 0,
        !empty($kyc_obj->government_id_path) ? 1 : 0,
        !empty($kyc_obj->passport_photo_path) ? 1 : 0,
        !empty($kyc_obj->digital_signature) ? 1 : 0
    ];
    $step5_completed = array_sum($step5_fields) / count($step5_fields);
    $score += $step5_completed * 20;

    return round($score);
}

/**
 * Maps role and status coordinates into styled visual badges.
 */
function getKycBadgeHtml($role_id, $kyc_status) {
    $role_id = (int)$role_id;
    if ($kyc_status !== 'approved') {
        switch ($kyc_status) {
            case 'pending_review':
                return '<span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium bg-emerald-50 text-emerald-700 border border-emerald-200 dark:bg-emerald-950/30 dark:text-emerald-400 dark:border-emerald-900/50">
                    <span class="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                    KYC Submitted &#8212; Pending Review
                </span>';
            case 'under_verification':
                return '<span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium bg-blue-50 text-blue-700 border border-blue-200 dark:bg-blue-950/30 dark:text-blue-400 dark:border-blue-900/50">
                    <span class="w-1.5 h-1.5 rounded-full bg-blue-500 animate-pulse"></span>
                    KYC Verifying
                </span>';
            case 'rejected':
                return '<span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium bg-red-50 text-red-700 border border-red-200 dark:bg-red-950/30 dark:text-red-400 dark:border-red-900/50">
                    <span class="w-1.5 h-1.5 rounded-full bg-red-500"></span>
                    KYC Rejected
                </span>';
            case 'requires_update':
                return '<span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium bg-purple-50 text-purple-700 border border-purple-200 dark:bg-purple-950/30 dark:text-purple-400 dark:border-purple-900/50">
                    <span class="w-1.5 h-1.5 rounded-full bg-purple-500"></span>
                    KYC Update Required
                </span>';
            default:
                return '<span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium bg-slate-50 text-slate-500 border border-slate-200 dark:bg-slate-900 dark:text-slate-400 dark:border-slate-800">
                    <span class="w-1.5 h-1.5 rounded-full bg-slate-400"></span>
                    KYC Uninitiated
                </span>';
        }
    }

    // Approved KYC: role-based premium badges
    switch ($role_id) {
        case 1: // super_admin
        case 2: // founder_circle
        case 3: // national_steering
            return '<span class="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold bg-gradient-to-r from-amber-500 to-yellow-600 text-white shadow-sm border border-amber-400/30">
                <svg class="w-3 h-3 text-yellow-200" fill="currentColor" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg>
                Executive Verified
            </span>';
        case 4: // zonal_chairman
        case 5: // state_chairman
            return '<span class="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-sm border border-emerald-400/30">
                <svg class="w-3 h-3 text-emerald-200" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M2.166 4.9L10 1.154l7.834 3.746a1 1 0 01.567.904v4.305c0 4.887-3.376 9.176-8 10-4.624-.824-8-5.113-8-10V5.804a1 1 0 01.567-.904zM10 3.3l-6 2.87v3.23c0 3.86 2.628 7.304 6 8.016 3.372-.712 6-4.156 6-8.017V6.17l-6-2.87zM12.3 8.3a1 1 0 00-1.4-1.4L9 8.7 7.7 7.4a1 1 0 00-1.4 1.4l2 2a1 1 0 001.4 0l3-3z" clip-rule="evenodd"/></svg>
                Regional Leader
            </span>';
        case 6: // coordinator
            return '<span class="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold bg-gradient-to-r from-sky-600 to-indigo-600 text-white shadow-sm border border-sky-400/30">
                <svg class="w-3 h-3 text-sky-200" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M6.267 3.455a.75.75 0 00-.708.523L4.17 9H3a1 1 0 100 2h1.5a1 1 0 00.948-.684l.9-2.7h6.3l.9 2.7a1 1 0 00.948.684H17a1 1 0 100-2h-1.17l-1.39-5.022a.75.75 0 00-.707-.523H6.268zM6 14a1 1 0 100-2 1 1 0 000 2zm8 0a1 1 0 100-2 1 1 0 000 2z" clip-rule="evenodd"/></svg>
                Verified Leader
            </span>';
        case 7: // ambassador
            return '<span class="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold bg-gradient-to-r from-bushgreen to-emerald-700 text-white shadow-sm border border-emerald-500/30">
                <svg class="w-3 h-3 text-gold" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/></svg>
                Verified Ambassador
            </span>';
        default:
            return '<span class="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold bg-gradient-to-r from-slate-600 to-slate-700 text-white shadow-sm">
                <svg class="w-3 h-3 text-slate-300" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/></svg>
                Verified Member
            </span>';
    }
}

/**
 * Dynamic System Settings cache resolver
 * Fetches all settings from system_settings table on first call and caches them statically.
 * Falls back gracefully to the provided default if the key is not set or empty.
 */
function getSystemSetting($key, $default = '') {
    static $settings = null;
    if ($settings === null) {
        $settings = [];
        try {
            $db = Database::connect();
            $stmt = $db->query("SELECT `setting_key`, `setting_value` FROM `system_settings`");
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
            if ($rows) {
                foreach ($rows as $row) {
                    $settings[$row['setting_key']] = $row['setting_value'];
                }
            }
        } catch (Exception $e) {
            // Fail silently to allow offline/local sandbox setups to use default parameters
        }
    }
    return isset($settings[$key]) && $settings[$key] !== '' ? $settings[$key] : $default;
}

