<?php
/**
 * PBAT Smart Nation Initiative - Custom SMTP Socket Client
 * Lightweight, robust SMTP socket mailer with support for TLS/SSL encryption and AUTH LOGIN.
 */

class SMTPMailer {
    private $host;
    private $port;
    private $username;
    private $password;
    private $encryption;
    private $timeout;
    private $log = [];

    public function __construct($host, $port, $username = '', $password = '', $encryption = 'tls', $timeout = 10) {
        $this->host = $host;
        $this->port = (int)$port;
        $this->username = $username;
        $this->password = $password;
        $this->encryption = strtolower($encryption);
        $this->timeout = $timeout;
    }

    public function send($from_email, $from_name, $to_email, $subject, $body_html) {
        $this->log = [];
        $header_to = $to_email;
        $header_from = empty($from_name) ? $from_email : "\"{$from_name}\" <{$from_email}>";

        // Build headers and body
        $boundary = '----=' . md5(uniqid(rand(), true));
        $headers = [
            "MIME-Version: 1.0",
            "To: {$header_to}",
            "From: {$header_from}",
            "Subject: =?UTF-8?B?" . base64_encode($subject) . "?=",
            "Date: " . date('r'),
            "Content-Type: multipart/alternative; boundary=\"{$boundary}\"",
            "Message-ID: <" . time() . rand(1000, 9999) . "@" . ($_SERVER['SERVER_NAME'] ?? 'localhost') . ">"
        ];

        // Format message body
        $message = implode("\r\n", $headers) . "\r\n\r\n";
        $message .= "--{$boundary}\r\n";
        $message .= "Content-Type: text/plain; charset=\"UTF-8\"\r\n";
        $message .= "Content-Transfer-Encoding: 7bit\r\n\r\n";
        $message .= strip_tags(str_replace(['<br>', '<br/>', '<br />', '</p>'], "\r\n", $body_html)) . "\r\n\r\n";
        $message .= "--{$boundary}\r\n";
        $message .= "Content-Type: text/html; charset=\"UTF-8\"\r\n";
        $message .= "Content-Transfer-Encoding: base64\r\n\r\n";
        $message .= chunk_split(base64_encode($body_html)) . "\r\n";
        $message .= "--{$boundary}--";

        // Open socket connection
        $host = $this->host;
        if ($this->encryption === 'ssl') {
            $host = 'ssl://' . $host;
        }

        $socket = @fsockopen($host, $this->port, $errno, $errstr, $this->timeout);
        if (!$socket) {
            $this->log[] = "Connection failed: {$errstr} ({$errno})";
            return false;
        }

        // Get welcome message
        $response = $this->readResponse($socket);
        if (!$this->checkCode($response, 220)) {
            fclose($socket);
            return false;
        }

        // Send EHLO
        $response = $this->sendCommand($socket, "EHLO " . ($_SERVER['SERVER_NAME'] ?? 'localhost'));
        if (!$this->checkCode($response, 250)) {
            // Fallback to HELO
            $response = $this->sendCommand($socket, "HELO " . ($_SERVER['SERVER_NAME'] ?? 'localhost'));
            if (!$this->checkCode($response, 250)) {
                $this->sendCommand($socket, "QUIT");
                fclose($socket);
                return false;
            }
        }

        // Handle TLS encryption
        if ($this->encryption === 'tls') {
            $response = $this->sendCommand($socket, "STARTTLS");
            if (!$this->checkCode($response, 220)) {
                $this->sendCommand($socket, "QUIT");
                fclose($socket);
                return false;
            }

            // Enable crypto
            $crypto_method = STREAM_CRYPTO_METHOD_TLS_CLIENT;
            if (defined('STREAM_CRYPTO_METHOD_TLSv1_2_CLIENT')) {
                $crypto_method |= STREAM_CRYPTO_METHOD_TLSv1_2_CLIENT;
            }
            if (defined('STREAM_CRYPTO_METHOD_TLSv1_3_CLIENT')) {
                $crypto_method |= STREAM_CRYPTO_METHOD_TLSv1_3_CLIENT;
            }

            if (!stream_socket_enable_crypto($socket, true, $crypto_method)) {
                $this->log[] = "STARTTLS encryption failed";
                fclose($socket);
                return false;
            }

            // Re-send EHLO after TLS handshake
            $response = $this->sendCommand($socket, "EHLO " . ($_SERVER['SERVER_NAME'] ?? 'localhost'));
            if (!$this->checkCode($response, 250)) {
                $this->sendCommand($socket, "QUIT");
                fclose($socket);
                return false;
            }
        }

        // Authenticate if credentials are provided
        if (!empty($this->username)) {
            $response = $this->sendCommand($socket, "AUTH LOGIN");
            if (!$this->checkCode($response, 334)) {
                $this->sendCommand($socket, "QUIT");
                fclose($socket);
                return false;
            }

            $response = $this->sendCommand($socket, base64_encode($this->username));
            if (!$this->checkCode($response, 334)) {
                $this->sendCommand($socket, "QUIT");
                fclose($socket);
                return false;
            }

            $response = $this->sendCommand($socket, base64_encode($this->password));
            if (!$this->checkCode($response, 235)) {
                $this->sendCommand($socket, "QUIT");
                fclose($socket);
                return false;
            }
        }

        // MAIL FROM
        $response = $this->sendCommand($socket, "MAIL FROM:<{$from_email}>");
        if (!$this->checkCode($response, 250)) {
            $this->sendCommand($socket, "QUIT");
            fclose($socket);
            return false;
        }

        // RCPT TO
        $response = $this->sendCommand($socket, "RCPT TO:<{$to_email}>");
        if (!$this->checkCode($response, 250)) {
            $this->sendCommand($socket, "QUIT");
            fclose($socket);
            return false;
        }

        // DATA
        $response = $this->sendCommand($socket, "DATA");
        if (!$this->checkCode($response, 354)) {
            $this->sendCommand($socket, "QUIT");
            fclose($socket);
            return false;
        }

        // Send message body and finalize data
        $response = $this->sendCommand($socket, $message . "\r\n.");
        if (!$this->checkCode($response, 250)) {
            $this->sendCommand($socket, "QUIT");
            fclose($socket);
            return false;
        }

        // QUIT
        $this->sendCommand($socket, "QUIT");
        fclose($socket);
        return true;
    }

    public function getLog() {
        return implode("\n", $this->log);
    }

    private function sendCommand($socket, $cmd) {
        $this->log[] = "> " . preg_replace('/^(AUTH LOGIN|AUTH PLAIN|base64_encoded_pass).*$/i', '$1 [HIDDEN]', $cmd);
        fwrite($socket, $cmd . "\r\n");
        return $this->readResponse($socket);
    }

    private function readResponse($socket) {
        $response = '';
        while (($line = fgets($socket, 512)) !== false) {
            $response .= $line;
            if (substr($line, 3, 1) === ' ') {
                break;
            }
        }
        $this->log[] = "< " . trim($response);
        return $response;
    }

    private function checkCode($response, $expected) {
        $code = (int)substr($response, 0, 3);
        return $code === $expected;
    }
}
