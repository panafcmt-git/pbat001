<?php
/**
 * PBAT Smart Nation Initiative - Pillar Detail Page
 * A highly polished detail page for each development pillar with rich content.
 */


// Get target type
$type = $_GET['type'] ?? 'governance';
$valid_types = ['governance', 'economy', 'people', 'infrastructure', 'living'];

if (!in_array($type, $valid_types)) {
    $type = 'governance'; // Fallback
}

// Pillar configurations
$pillars = [
    'governance' => [
        'title' => 'Smart Governance',
        'subtitle' => 'Transforming public service delivery through technology and open administrative models.',
        'icon' => '<svg class="w-8 h-8 text-gold" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/></svg>',
        'bg_gradient' => 'from-amber-500/10 to-gold/10',
        'badge' => 'Transparency & Efficiency',
        'stats' => [
            'Target Reach' => 'All 774 Local Government Areas',
            'Administrative Goal' => '100% Paperless Workflows',
            'Core Technology' => 'Secure Biometrics & Open Data Portals',
            'Estimated Impact' => 'Real-Time Public Auditing & Feedback'
        ],
        'highlights' => [
            'Unified citizen profile portal for swift public document requests.',
            'Open-source government registries for transparent budget tracking.',
            'In-depth digital training workshops for local government workers.',
            'Real-time municipal hazard reporting and feedback channels.'
        ],
        'content' => "The Smart Governance pillar of the PBAT Smart Nation Initiative represents a fundamental shift in how public institutions connect with and serve Nigerian citizens. Traditionally, administrative processes have been hindered by bureaucratic delay, lack of centralization, and slow paper-based systems. Our advocacy centers on replacing these models with cloud-native digital infrastructure that promotes absolute transparency, security, and accessibility.

At the core of Smart Governance is the integration of biometric identity systems and secure, centralized citizen portals. By establishing unified databases, we enable public offices to process document requests, business licensing, and civic registrations in a fraction of the time. We advocate for the deployment of open-source government registries, which permit real-time auditing of development funds and project statuses. This transparency is critical for building trust between the administration and the public.

Furthermore, we focus on digital capacity building for civil servants. We conduct workshops to train local government workers on document digitization, encrypted communication channels, and secure cloud storage. This ensures that the digital transition is not just a technological change but a cultural one, with public workers equipped to leverage modern software tools.

Through public-private partnerships, we aim to establish citizen feedback loops, where residents can report municipal issues, request emergency responses, or rate administrative performance directly from their mobile phones. This democratizes the governance process, transforming citizens from passive recipients of government actions into active participants in civic progress.

Ultimately, Smart Governance is about creating an efficient, responsive, and corrupt-free public sector. By reducing administrative friction and making government services paperless, we save taxpayer resources, optimize regional budgets, and ensure that every Nigerian can interact with public offices securely, dignity, and speed, regardless of their location.

Additionally, we are promoting the adoption of intelligent analytics for municipal resource deployment. By analyzing public service request trends, government offices can allocate resources where they are needed most, reducing waste. This data-driven decision-making model improves response times and maximizes the utility of public amenities, creating a governance structure that is truly smart, proactive, and citizen-centric."
    ],
    'economy' => [
        'title' => 'Smart Economy',
        'subtitle' => 'Powering local businesses, digital farm cooperatives, and cashless digital commerce.',
        'icon' => '<svg class="w-8 h-8 text-gold" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>',
        'bg_gradient' => 'from-emerald-500/10 to-gold/10',
        'badge' => 'Financial Inclusion & Growth',
        'stats' => [
            'Target Reach' => '1 Million MSMEs Sensitized',
            'Economic Goal' => 'Cashless & Digital Ledger Adoption',
            'Core Technology' => 'Mobile Pay & Cooperative Trade Software',
            'Estimated Impact' => 'Enhanced Local Trade & Credit Access'
        ],
        'highlights' => [
            'Cashless transaction facilitation for market traders and vendors.',
            'Digital agricultural cooperatives linking farmers to bulk buyers.',
            'Entrepreneurship bootcamps focused on global freelance markets.',
            'Advocating startup-friendly state regulations and tax credits.'
        ],
        'content' => "The Smart Economy pillar of the PBAT Smart Nation Initiative is designed to accelerate national prosperity by integrating technology into local commerce, agriculture, and small business operations. We believe that sustainable economic growth must begin at the grassroots level, empowering micro, small, and medium enterprises (MSMEs) with the digital tools required to thrive in a globalized marketplace.

Our primary focus is on expanding financial inclusion through cashless transactions and mobile payment applications. By providing simple software solutions and point-of-sale training, we help local merchants transition away from insecure cash-only models. This shift not only protects business owners but also enables them to build verified transaction histories, which are essential for securing formal credit and micro-loans from financial institutions.

In agriculture, we advocate for digital cooperatives and mobile-based marketplaces. These platforms connect rural farmers directly with buyers and supply chains, eliminating exploitative intermediaries and ensuring fair pricing for crops. Farmers can also access real-time weather forecasts, market price trends, and digital agronomy advice, boosting productivity and food security.

Furthermore, we support regional tech-incubation hubs and entrepreneurship bootcamps. These programs train youths in e-commerce, digital marketing, and remote freelance skills, opening up global employment opportunities that bypass domestic job shortages. We also champion policy reforms that support tech startups, fostering a culture of innovation and venture investment.

Ultimately, the Smart Economy pillar aims to build a resilient, digitized national market. By bridging the digital divide for local traders and farmers, we stimulate economic diversification, create sustainable jobs, and ensure that Nigeria's economic growth is inclusive, modern, and driven by digital innovation.

Furthermore, we are driving digital literacy for market cooperatives, helping traditional trader associations form digital alliances. By standardizing digital inventory management, these cooperatives can purchase goods in bulk online, reducing logistics costs and sharing storage infrastructure. This collective digital bargaining power stabilizes commodity prices, protects consumer interests, and ensures that even the smallest retail shops can participate in the digital economy."
    ],
    'people' => [
        'title' => 'Smart People',
        'subtitle' => 'Developing digital skills, technology hubs, and cyber awareness for youth.',
        'icon' => '<svg class="w-8 h-8 text-gold" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"/></svg>',
        'bg_gradient' => 'from-blue-500/10 to-gold/10',
        'badge' => 'Tech Skills & Literacy',
        'stats' => [
            'Target Reach' => '500k Youths Certified',
            'Education Goal' => 'Coding & AI Basics in Schools',
            'Core Technology' => 'Virtual Labs & Global Certifications',
            'Estimated Impact' => 'Global remote workforce pipeline'
        ],
        'highlights' => [
            'Setting up modern computer laboratories in public schools.',
            'Coding bootcamps and artificial intelligence awareness campaigns.',
            'Teacher sensitization programs to modernize digital pedagogy.',
            'Specialized tech literacy initiatives for young women.'
        ],
        'content' => "The Smart People pillar is dedicated to bridging the digital literacy divide and preparing Nigeria's massive youth population for the jobs of the future. We believe that infrastructure and technology are only as powerful as the people who operate them. Therefore, our mission is to cultivate a highly skilled, tech-savvy generation capable of driving local innovation and competing globally.

A cornerstone of our strategy is the establishment of community digital learning centers and modern computer laboratories in public schools. We advocate for curriculum reforms that introduce coding, data analytics, and artificial intelligence fundamentals at the primary and secondary education levels. By partnering with international technology companies, we provide students with subsidized access to globally recognized certifications.

We also focus on training educators. Our 'Train the Trainer' initiatives equip local teachers with the skills and pedagogical tools needed to teach digital courses effectively. This ensures that even rural schools can deliver high-quality technology instruction. Additionally, we run cybersecurity awareness campaigns to teach digital safety, helping youth protect their personal data and navigate the internet responsibly.

To ensure inclusivity, we design specialized training programs for young women and marginalized groups, ensuring that the digital revolution leaves no one behind. We believe that digital skills are the ultimate equalizer, offering a pathway out of poverty and enabling self-reliance.

Ultimately, the Smart People pillar is an investment in human capital. By empowering citizens with digital skills, we are building a national talent pool that will attract international tech investments, foster local software and hardware startups, and transform Nigeria into a leading hub of digital innovation and technological excellence.

We are also launching virtual mentorship networks that pair young Nigerian developers with experienced global industry professionals. These networks provide students with guidance on software architecture, project management, and career progression. By creating these direct channels to global knowledge, we help local talent bridge the gap between academic theory and practical, commercial application, accelerating their entry into high-paying remote roles."
    ],
    'infrastructure' => [
        'title' => 'Smart Infrastructure',
        'subtitle' => 'Facilitating broadband expansion, solar grid advocacy, and smart utility links.',
        'icon' => '<svg class="w-8 h-8 text-gold" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"/></svg>',
        'bg_gradient' => 'from-indigo-500/10 to-gold/10',
        'badge' => 'Connectivity & Energy',
        'stats' => [
            'Target Reach' => 'Broadband Access in 250 Rural Communities',
            'Grid Goal' => 'Solar Powered Coding Hubs',
            'Core Technology' => 'Fiber Optics & IoT Municipal Networks',
            'Estimated Impact' => '24/7 Power & Internet Availability'
        ],
        'highlights' => [
            'Rural broadband network expansion advocacy.',
            'Deploying solar micro-grids to power community study hubs.',
            'IoT-driven municipal waste and water monitoring system links.',
            'Promoting community-accessible hardware prototyping labs.'
        ],
        'content' => "The Smart Infrastructure pillar focuses on advocating for and implementing the physical technological foundations required to support a modern digital society. Without reliable internet connectivity, stable power grids, and accessible hardware, the benefits of digital transformation remain out of reach for millions of Nigerians. Our mission is to accelerate the deployment of these critical utilities across the country.

Our primary advocacy area is the expansion of rural broadband networks. We collaborate with telecommunications companies and public regulators to support policies that incentivize fiber-optic deployment in underserved regions. By establishing community public Wi-Fi hotspots in public squares, markets, and libraries, we ensure that digital access is affordable and accessible to every citizen, regardless of socio-economic status.

In tandem with connectivity, we promote green, decentralized energy solutions. We advocate for solar-powered community grids to power local coding centers, schools, and healthcare facilities. This ensures that critical digital systems remain online 24/7, bypassing the instability of the national electricity grid and reducing reliance on fossil fuels.

We are also championing the integration of Internet of Things (IoT) technologies in municipal management. This includes smart waste management sensors, solar-powered intelligent traffic lights, and digital clean water monitoring systems. These tools help municipal authorities manage resources efficiently, reduce environmental impact, and build cleaner, safer cities.

Ultimately, Smart Infrastructure is the bedrock of our national digital vision. By building resilient, eco-friendly, and connected communities, we lay the groundwork for all other smart pillars to succeed, ensuring that Nigeria's digital future is anchored on a stable, high-performance, and sustainable physical foundation.

We also advocate for the establishment of open-access community hardware laboratories. These spaces provide grassroots innovators with access to 3D printers, IoT testing kits, and electronics assembly tools. By offering free access to prototyping equipment, we lower the barrier to entry for young hardware inventors, allowing them to design and build local solutions for agriculture, healthcare, and energy management."
    ],
    'living' => [
        'title' => 'Smart Living',
        'subtitle' => 'Enhancing quality of life through civic tech, health-tech, and cyber hygiene.',
        'icon' => '<svg class="w-8 h-8 text-gold" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"/></svg>',
        'bg_gradient' => 'from-purple-500/10 to-gold/10',
        'badge' => 'Quality of Life & Health',
        'stats' => [
            'Target Reach' => 'Telehealth Access in 100 Clinics',
            'Safety Goal' => 'Zero Local Cyber Fraud Incidents',
            'Core Technology' => 'Telemedicine Apps & Civic Safety Grids',
            'Estimated Impact' => 'Reduced Emergency Response & Direct Health Aid'
        ],
        'highlights' => [
            'Telemedicine app links connecting rural citizens with doctors.',
            'Neighborhood safety and civic hazard reporting programs.',
            'Community-wide cybersecurity hygiene seminars.',
            'Environmental air/water sensors for healthy urban living.'
        ],
        'content' => "The Smart Living pillar of the PBAT Smart Nation Initiative is dedicated to improving the quality of life, health, safety, and civic well-being of every citizen through the deployment of user-friendly technology. We believe that the ultimate measure of a smart nation is how effectively its digital advancements translate into healthier, safer, and more connected daily lives for its population.

One of our key areas of focus is health-tech and telemedicine. We advocate for the creation of mobile health portals that connect rural and underserved communities with qualified medical professionals. Through these platforms, citizens can receive remote consultations, digital prescriptions, and basic health education without the need for expensive and time-consuming travel to urban hospitals.

We also focus on civic technology and safety. We promote the development of neighborhood reporting tools that allow citizens to report local hazards, road defects, or security incidents directly to municipal response teams. By integrating geolocations, these platforms ensure rapid dispatch and real-time tracking of public safety responses, making communities safer and more collaborative.

Digital literacy in cyber-hygiene is another cornerstone of Smart Living. We run community campaigns to educate families on protecting their online identities, preventing financial fraud, and securing their smart devices. This ensures that as citizens adopt digital tools, they do so with the awareness required to stay safe online.

Ultimately, the Smart Living pillar is about humanizing technology. By integrating digital solutions into healthcare, safety, and community coordination, we create a secure, healthy, and high-quality environment where families can thrive and feel empowered by the national digital revolution.

Additionally, we are partnering with local environmental organizations to deploy air and water quality sensor networks in municipal areas. These sensors upload real-time environmental data to a public dashboard, giving citizens the information they need to protect their health and enabling community groups to advocate for greener urban planning. This crowdsourced ecological monitoring turns daily living spaces into active ecosystems of health awareness."
    ]
];

$current = $pillars[$type];

require_once __DIR__ . '/helpers/seo.php';
SEO::init([
    'title' => $current['title'] . ' | PBAT Smart Nation Development Pillars',
    'description' => $current['subtitle'],
    'keywords' => $current['title'] . ', ' . $current['badge'] . ', Smart Nation Nigeria Development, Technology Sensitization, Youth Training',
    'breadcrumbs' => [
        ['name' => 'Development Pillars', 'url' => '/pillars'],
        ['name' => $current['title'], 'url' => '/pillar-detail.php?type=' . $type]
    ]
]);

require_once __DIR__ . '/includes/header.php';
?>

<!-- Detail Banner Hero -->
<section class="relative bg-bushgreen text-white py-24 overflow-hidden border-b-4 border-gold">
    <!-- Gradient Overlay & Grid BG -->
    <div class="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-bushgreen-light/70 via-bushgreen to-bushgreen-dark opacity-95"></div>
    <div class="absolute inset-0 bg-[linear-gradient(to_right,#ffffff02_1px,transparent_1px),linear-gradient(to_bottom,#ffffff02_1px,transparent_1px)] bg-[size:3rem_3rem]"></div>
    
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 space-y-6">
        <div class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 text-gold border border-gold/20 text-xs font-bold font-display uppercase tracking-widest leading-none">
            <?php echo $current['badge']; ?>
        </div>
        <div class="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
            <div class="space-y-3 max-w-3xl">
                <div class="flex items-center gap-4">
                    <div class="w-16 h-16 rounded-2xl bg-white/10 flex items-center justify-center border border-gold/30 backdrop-blur-sm">
                        <?php echo $current['icon']; ?>
                    </div>
                    <h1 class="text-3xl sm:text-5xl font-black font-display tracking-tight uppercase"><?php echo $current['title']; ?></h1>
                </div>
                <p class="text-slate-300 text-xs sm:text-sm font-light leading-relaxed max-w-2xl">
                    <?php echo $current['subtitle']; ?>
                </p>
            </div>
            <a href="pillars.php" class="px-5 py-2.5 bg-white/10 hover:bg-white/20 border border-white/20 text-white font-bold text-xs rounded-xl transition-all flex items-center gap-2 hover:-translate-x-1">
                <svg class="w-4 h-4 text-gold" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/></svg>
                All Focus Areas
            </a>
        </div>
    </div>
</section>

<!-- Content Layout -->
<section class="py-16 sm:py-20 bg-slate-50">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8 sm:gap-12 items-start">
            
            <!-- Left Info Panel (Sidebar) -->
            <div class="space-y-6 lg:col-span-1 lg:sticky lg:top-24">
                <!-- Statistics Card -->
                <div class="bg-white rounded-2xl p-6 border border-slate-100 shadow-sm space-y-5">
                    <h3 class="text-slate-800 font-extrabold text-base font-display pb-3 border-b border-slate-100">
                        Strategic Targets
                    </h3>
                    <div class="space-y-4">
                        <?php foreach ($current['stats'] as $label => $val): ?>
                            <div>
                                <span class="text-[10px] text-slate-400 font-bold uppercase tracking-wider block"><?php echo $label; ?></span>
                                <span class="text-xs sm:text-sm text-bushgreen font-bold block mt-0.5"><?php echo $val; ?></span>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- Navigation List Card -->
                <div class="bg-bushgreen rounded-2xl p-6 text-white space-y-4 border border-gold/15 shadow-md relative overflow-hidden">
                    <div class="absolute -right-16 -bottom-16 w-32 h-32 bg-gold/10 rounded-full blur-2xl"></div>
                    <h3 class="text-gold font-bold text-sm uppercase tracking-widest font-display pb-2 border-b border-white/10">
                        Navigate Pillars
                    </h3>
                    <nav class="flex flex-col gap-2 relative z-10">
                        <?php foreach ($pillars as $key => $p): ?>
                            <a href="pillar-detail.php?type=<?php echo $key; ?>" 
                               class="flex items-center justify-between py-2 px-3 rounded-xl transition text-xs font-semibold <?php echo $key === $type ? 'bg-gold text-bushgreen' : 'hover:bg-white/5 text-slate-200'; ?>">
                                <span><?php echo $p['title']; ?></span>
                                <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/></svg>
                            </a>
                        <?php endforeach; ?>
                    </nav>
                </div>
            </div>

            <!-- Right Main Content -->
            <div class="lg:col-span-2 space-y-8 bg-white rounded-3xl p-6 sm:p-10 border border-slate-100 shadow-sm">
                <!-- Main Description -->
                <div class="prose prose-slate max-w-none text-slate-600 font-light text-xs sm:text-sm leading-relaxed space-y-6">
                    <p class="text-sm sm:text-base font-medium text-slate-800 leading-relaxed italic border-l-4 border-gold pl-4 py-1">
                        How the PBAT Smart Nation Initiative drives grassroots digital sensitization and operational technology alignment under <?php echo $current['title']; ?>.
                    </p>
                    
                    <?php 
                    // Render description paragraphs
                    $paragraphs = explode("\n\n", $current['content']);
                    foreach ($paragraphs as $para) {
                        echo '<p>' . nl2br(htmlspecialchars($para)) . '</p>';
                    }
                    ?>
                </div>

                <!-- Key Highlights Bullet List -->
                <div class="pt-6 border-t border-slate-100 space-y-4">
                    <h3 class="text-slate-800 font-bold text-base font-display">Key Focus Areas & Milestones</h3>
                    <ul class="grid grid-cols-1 md:grid-cols-2 gap-3">
                        <?php foreach ($current['highlights'] as $hl): ?>
                            <li class="flex items-start gap-2.5 text-xs text-slate-600 font-light">
                                <svg class="w-4 h-4 text-gold flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/></svg>
                                <span><?php echo htmlspecialchars($hl); ?></span>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </div>

                <!-- Join/CTA Block -->
                <div class="pt-6 border-t border-slate-100 flex flex-col sm:flex-row justify-between items-center gap-4">
                    <div class="text-center sm:text-left">
                        <h4 class="text-bushgreen font-bold text-sm">Become a Grassroots Ambassador</h4>
                        <p class="text-[11px] text-slate-500 font-light">Help us advocate for <?php echo $current['title']; ?> in your community.</p>
                    </div>
                    <a href="register.php" class="px-5 py-2.5 bg-bushgreen hover:bg-bushgreen-light text-white font-bold text-xs rounded-xl shadow-md transition-all hover:scale-105 border border-gold/25">
                        Register Now &rarr;
                    </a>
                </div>
            </div>

        </div>
    </div>
</section>

<?php
require_once __DIR__ . '/includes/footer.php';
?>
