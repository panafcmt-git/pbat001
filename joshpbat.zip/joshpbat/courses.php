<?php
/**
 * PBAT Smart Nation Initiative - Dynamic Courses & Digital Academy
 * Premium page listing technology courses, training curricula, and innovation education.
 */
require_once __DIR__ . '/helpers/seo.php';

// Initialize Page Metadata and Course JSON-LD Schema
$courseSchema = [
    '@context' => 'https://schema.org',
    '@graph' => [
        [
            '@type' => 'Course',
            'name' => 'Digital Literacy & Smart Cities Foundation',
            'description' => 'Master the fundamentals of smart city infrastructures, broadband deployment, and localized technology ecosystems in Nigeria.',
            'provider' => [
                '@type' => 'Organization',
                'name' => 'PBAT Smart Nation Initiative',
                'sameAs' => 'https://app.pbatsmartnation.org.ng'
            ]
        ],
        [
            '@type' => 'Course',
            'name' => 'Artificial Intelligence Literacy & Prompting',
            'description' => 'Learn basic machine learning workflows, artificial intelligence guidelines, and prompt engineering methods to enhance regional productivity.',
            'provider' => [
                '@type' => 'Organization',
                'name' => 'PBAT Smart Nation Initiative',
                'sameAs' => 'https://app.pbatsmartnation.org.ng'
            ]
        ],
        [
            '@type' => 'Course',
            'name' => 'Grassroots Digital Advocacy & Tech Leadership',
            'description' => 'Train on community mobilization, digital transparency tracking, organizing local town halls, and managing innovation networks.',
            'provider' => [
                '@type' => 'Organization',
                'name' => 'PBAT Smart Nation Initiative',
                'sameAs' => 'https://app.pbatsmartnation.org.ng'
            ]
        ]
    ]
];

SEO::init([
    'title' => 'Digital Skills & Smart Nation Training Programs | PBAT Smart Nation',
    'description' => 'Browse educational courses in smart city foundations, artificial intelligence literacy, and grassroots digital advocacy offered by the PBAT Smart Nation Initiative.',
    'keywords' => 'AI Awareness Nigeria, Smart Nation Education, Digital Literacy Training, Youth Innovation Nigeria, Tech Leadership Courses, Nigeria Tech Onboarding',
    'breadcrumbs' => [
        ['name' => 'Academy', 'url' => '/courses']
    ],
    'schemas' => [$courseSchema]
]);

require_once __DIR__ . '/includes/header.php';
?>

<!-- Academy Hero Banner -->
<section class="relative bg-bushgreen text-white py-24 overflow-hidden border-b-4 border-gold">
    <div class="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-bushgreen-light/70 via-bushgreen to-bushgreen-dark opacity-95"></div>
    <div class="absolute inset-0 bg-[linear-gradient(to_right,#ffffff02_1px,transparent_1px),linear-gradient(to_bottom,#ffffff02_1px,transparent_1px)] bg-[size:3rem_3rem]"></div>
    
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center space-y-4">
        <span class="text-gold font-bold text-xs uppercase tracking-widest font-display block"><?php echo htmlspecialchars(getSystemSetting('page_courses_banner_badge', 'Smart Academy')); ?></span>
        <h1 class="text-4xl sm:text-6xl font-black font-display tracking-tight uppercase"><?php echo htmlspecialchars(getSystemSetting('page_courses_banner_title', 'Digital Skills & Innovation')); ?></h1>
        <p class="text-slate-300 text-xs sm:text-base max-w-2xl mx-auto font-light leading-relaxed">
            <?php echo htmlspecialchars(getSystemSetting('page_courses_banner_desc', 'Free verified courses and educational pathways created to sensitize Nigerian youths and local representatives on emerging technologies, smart city developments, and AI solutions.')); ?>
        </p>
    </div>
</section>

<!-- Course Listings -->
<section class="py-24 bg-slate-50">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        <div class="max-w-xl text-left space-y-2">
            <span class="text-gold font-bold text-xs uppercase tracking-widest font-display block">Curriculum</span>
            <h2 class="text-3xl font-extrabold text-bushgreen font-display">Available Training Programs</h2>
            <p class="text-slate-500 text-sm font-light leading-relaxed">Unlock leadership capacities, increase tech awareness, and drive digital revolution inside your local ward.</p>
        </div>

        <!-- Course Cards Grid -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
            
            <!-- Course 1 -->
            <div class="bg-white rounded-3xl border border-slate-100 shadow-sm overflow-hidden hover:shadow-lg transition-all duration-300 flex flex-col justify-between hover:border-gold/30">
                <div>
                    <div class="h-48 w-full bg-slate-100 relative">
                        <img src="https://images.unsplash.com/photo-1531482615713-2afd69097998?auto=format&fit=crop&w=800&q=80" alt="Smart Cities Foundation" class="w-full h-full object-cover">
                        <span class="absolute left-4 bottom-4 bg-bushgreen text-white font-bold text-[9px] px-2.5 py-1 rounded uppercase tracking-widest">DSC-101</span>
                    </div>
                    <div class="p-8 space-y-4">
                        <span class="text-[10px] text-gold font-bold uppercase tracking-widest block font-display">4 Weeks &bull; Beginner</span>
                        <h3 class="text-lg font-bold text-slate-800 font-display">Digital Literacy & Smart Cities Foundation</h3>
                        <p class="text-slate-500 text-xs leading-relaxed font-light">
                            Understand smart infrastructure planning, municipal internet grids, database operations, and how technological nodes solve community governance issues.
                        </p>
                    </div>
                </div>
                <div class="p-8 pt-0 border-t border-slate-50 mt-4 flex justify-between items-center text-xs">
                    <span class="font-bold text-slate-400">100% Free / Online</span>
                    <a href="register.php" class="text-bushgreen hover:text-gold font-bold transition flex items-center gap-1">Enroll Free &rarr;</a>
                </div>
            </div>

            <!-- Course 2 -->
            <div class="bg-white rounded-3xl border border-slate-100 shadow-sm overflow-hidden hover:shadow-lg transition-all duration-300 flex flex-col justify-between hover:border-gold/30">
                <div>
                    <div class="h-48 w-full bg-slate-100 relative">
                        <img src="https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?auto=format&fit=crop&w=800&q=80" alt="AI Literacy" class="w-full h-full object-cover">
                        <span class="absolute left-4 bottom-4 bg-bushgreen text-white font-bold text-[9px] px-2.5 py-1 rounded uppercase tracking-widest">AIP-202</span>
                    </div>
                    <div class="p-8 space-y-4">
                        <span class="text-[10px] text-gold font-bold uppercase tracking-widest block font-display">6 Weeks &bull; Intermediate</span>
                        <h3 class="text-lg font-bold text-slate-800 font-display">Artificial Intelligence Literacy & Prompting</h3>
                        <p class="text-slate-500 text-xs leading-relaxed font-light">
                            Learn prompt engineering, neural networks, machine learning principles, and how local trade organizations can utilize AI resources to scale operations.
                        </p>
                    </div>
                </div>
                <div class="p-8 pt-0 border-t border-slate-50 mt-4 flex justify-between items-center text-xs">
                    <span class="font-bold text-slate-400">100% Free / Online</span>
                    <a href="register.php" class="text-bushgreen hover:text-gold font-bold transition flex items-center gap-1">Enroll Free &rarr;</a>
                </div>
            </div>

            <!-- Course 3 -->
            <div class="bg-white rounded-3xl border border-slate-100 shadow-sm overflow-hidden hover:shadow-lg transition-all duration-300 flex flex-col justify-between hover:border-gold/30">
                <div>
                    <div class="h-48 w-full bg-slate-100 relative">
                        <img src="https://images.unsplash.com/photo-1542744094-3a31f103e35f?auto=format&fit=crop&w=800&q=80" alt="Tech Advocacy" class="w-full h-full object-cover">
                        <span class="absolute left-4 bottom-4 bg-bushgreen text-white font-bold text-[9px] px-2.5 py-1 rounded uppercase tracking-widest">GDL-303</span>
                    </div>
                    <div class="p-8 space-y-4">
                        <span class="text-[10px] text-gold font-bold uppercase tracking-widest block font-display">8 Weeks &bull; Advanced</span>
                        <h3 class="text-lg font-bold text-slate-800 font-display">Grassroots Digital Advocacy & Tech Leadership</h3>
                        <p class="text-slate-500 text-xs leading-relaxed font-light">
                            Obtain active training on community mobilization, reporting digital transformation markers, and deploying sensitization portals to local networks.
                        </p>
                    </div>
                </div>
                <div class="p-8 pt-0 border-t border-slate-50 mt-4 flex justify-between items-center text-xs">
                    <span class="font-bold text-slate-400">100% Free / Online</span>
                    <a href="register.php" class="text-bushgreen hover:text-gold font-bold transition flex items-center gap-1">Enroll Free &rarr;</a>
                </div>
            </div>

        </div>
    </div>
</section>

<?php
require_once __DIR__ . '/includes/footer.php';
?>
