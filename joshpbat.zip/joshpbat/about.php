<?php
/**
 * PBAT Smart Nation Initiative - Who We Are
 * Highly polished comprehensive about page containing core missions, organizational charts, and strategic directives.
 */
require_once __DIR__ . '/helpers/seo.php';
SEO::init([
    'title' => 'Who We Are & Dynamic Charter | PBAT Smart Nation Initiative',
    'description' => 'Learn about the structural mandate, vision guidelines, and national coordinator network driving inclusive digital evolution at PBAT Smart Nation Initiative.',
    'keywords' => 'Who We Are, Digital Advocacy Nigeria, Tech Literacy Campaign, Independence Charter Nigeria, PBAT Smart Nation Organization',
    'breadcrumbs' => [
        ['name' => 'Who We Are', 'url' => '/about']
    ]
]);

require_once __DIR__ . '/includes/header.php';
?>

<!-- Sub-Page Hero Banner -->
<section class="relative bg-bushgreen text-white py-20 overflow-hidden border-b-4 border-gold">
    <div class="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-bushgreen-light/70 via-bushgreen to-bushgreen-dark opacity-95"></div>
    <div class="absolute inset-0 bg-[linear-gradient(to_right,#ffffff02_1px,transparent_1px),linear-gradient(to_bottom,#ffffff02_1px,transparent_1px)] bg-[size:3rem_3rem]"></div>
    
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center space-y-4">
        <span class="text-gold font-bold text-xs uppercase tracking-widest font-display block"><?php echo htmlspecialchars(getSystemSetting('page_about_banner_badge', 'Advocacy Identity')); ?></span>
        <h1 class="text-3xl sm:text-5xl font-black font-display tracking-tight uppercase"><?php echo htmlspecialchars(getSystemSetting('page_about_banner_title', 'Who We Are')); ?></h1>
        <p class="text-slate-300 text-xs sm:text-sm max-w-xl mx-auto font-light leading-relaxed">
            <?php echo htmlspecialchars(getSystemSetting('page_about_banner_desc', 'Understanding the structural mandate, vision guidelines, and national coordinator network driving inclusive digital evolution.')); ?>
        </p>
    </div>
</section>

<!-- Vision, Mission & Core Values Section -->
<section class="py-24 bg-white">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
        
        <div class="grid grid-cols-1 md:grid-cols-2 gap-12">
            <!-- Our Vision -->
            <div class="bg-slate-50 p-8 rounded-3xl border border-slate-100 shadow-sm space-y-4 flex flex-col justify-between">
                <div class="space-y-3">
                    <div class="w-12 h-12 rounded-2xl bg-bushgreen/10 flex items-center justify-center text-bushgreen border border-bushgreen/5">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/></svg>
                    </div>
                    <h3 class="text-xl font-bold text-bushgreen font-display"><?php echo htmlspecialchars(getSystemSetting('page_about_vision_title', 'Our Strategic Vision')); ?></h3>
                    <p class="text-slate-600 text-xs leading-relaxed font-light">
                        <?php echo htmlspecialchars(getSystemSetting('page_about_vision_desc', 'To serve as a premier non-governmental technology sensitizer across Nigeria, actively bridging connectivity gaps, fostering data intelligence literacy, and establishing active technology centers within rural local government areas.')); ?>
                    </p>
                </div>
                <div class="text-[10px] text-slate-400 font-semibold tracking-wider uppercase border-t border-slate-200/60 pt-3">PBAT Smart Nation Initiative</div>
            </div>

            <!-- Our Mission -->
            <div class="bg-slate-50 p-8 rounded-3xl border border-slate-100 shadow-sm space-y-4 flex flex-col justify-between">
                <div class="space-y-3">
                    <div class="w-12 h-12 rounded-2xl bg-bushgreen/10 flex items-center justify-center text-bushgreen border border-bushgreen/5">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
                    </div>
                    <h3 class="text-xl font-bold text-bushgreen font-display"><?php echo htmlspecialchars(getSystemSetting('page_about_mission_title', 'Our Core Mission')); ?></h3>
                    <p class="text-slate-600 text-xs leading-relaxed font-light">
                        <?php echo htmlspecialchars(getSystemSetting('page_about_mission_desc', 'We are structured to design regional educational templates, provision certified digital skill paths for youth organizations, and partner with private capital entities to enable robust, inclusive digital transformations.')); ?>
                    </p>
                </div>
                <div class="text-[10px] text-slate-400 font-semibold tracking-wider uppercase border-t border-slate-200/60 pt-3">National Tech Sensitization</div>
            </div>
        </div>

        <!-- Leadership Hierarchy Chart Preview -->
        <div class="space-y-8 pt-8">
            <div class="text-center space-y-2 max-w-xl mx-auto">
                <span class="text-gold font-bold text-xs uppercase tracking-widest font-display block">System Architecture</span>
                <h2 class="text-2xl sm:text-3xl font-extrabold text-bushgreen font-display"><?php echo htmlspecialchars(getSystemSetting('page_about_org_title', 'Organizational Structure')); ?></h2>
                <p class="text-slate-500 text-xs font-light">
                    <?php echo htmlspecialchars(getSystemSetting('page_about_org_desc', 'PBAT Smart Nation operates a disciplined multi-tiered network coordinating digital awareness across geo-political zones.')); ?>
                </p>
            </div>

            <!-- Horizontal Organizational Tiers Layout -->
            <div class="grid grid-cols-1 md:grid-cols-5 gap-4 pt-6">
                <!-- Tier 1 -->
                <div class="bg-slate-50 p-5 rounded-2xl border border-slate-100 text-center space-y-2">
                    <span class="w-8 h-8 rounded-full bg-bushgreen text-gold flex items-center justify-center mx-auto text-xs font-bold font-display">1</span>
                    <h4 class="text-slate-800 font-bold text-xs">Founder Circle</h4>
                    <p class="text-[10px] text-slate-400 leading-relaxed">Top executive strategists setting national policy guidelines.</p>
                </div>
                <!-- Tier 2 -->
                <div class="bg-slate-50 p-5 rounded-2xl border border-slate-100 text-center space-y-2">
                    <span class="w-8 h-8 rounded-full bg-bushgreen text-gold flex items-center justify-center mx-auto text-xs font-bold font-display">2</span>
                    <h4 class="text-slate-800 font-bold text-xs">National Steering</h4>
                    <p class="text-[10px] text-slate-400 leading-relaxed">Executing campaigns and overseeing zonal directories.</p>
                </div>
                <!-- Tier 3 -->
                <div class="bg-slate-50 p-5 rounded-2xl border border-slate-100 text-center space-y-2">
                    <span class="w-8 h-8 rounded-full bg-bushgreen text-gold flex items-center justify-center mx-auto text-xs font-bold font-display">3</span>
                    <h4 class="text-slate-800 font-bold text-xs">Zonal Councils</h4>
                    <p class="text-[10px] text-slate-400 leading-relaxed">Coordinating Southwest, Northcentral, and all zones.</p>
                </div>
                <!-- Tier 4 -->
                <div class="bg-slate-50 p-5 rounded-2xl border border-slate-100 text-center space-y-2">
                    <span class="w-8 h-8 rounded-full bg-bushgreen text-gold flex items-center justify-center mx-auto text-xs font-bold font-display">4</span>
                    <h4 class="text-slate-800 font-bold text-xs">State Chairmen</h4>
                    <p class="text-[10px] text-slate-400 leading-relaxed">Directing state-specific coding academies and centers.</p>
                </div>
                <!-- Tier 5 -->
                <div class="bg-slate-50 p-5 rounded-2xl border border-slate-100 text-center space-y-2">
                    <span class="w-8 h-8 rounded-full bg-bushgreen text-gold flex items-center justify-center mx-auto text-xs font-bold font-display">5</span>
                    <h4 class="text-slate-800 font-bold text-xs">Ambassadors</h4>
                    <p class="text-[10px] text-slate-400 leading-relaxed">Mobilizing grassroots units at ward and LGA levels.</p>
                </div>
            </div>
        </div>

    </div>
</section>

<!-- Vision Section With Banners -->
<section class="py-20 bg-slate-50 border-t border-slate-100">
    <div class="max-w-4xl mx-auto text-center px-4 space-y-6">
        <h2 class="text-3xl font-extrabold text-bushgreen font-display"><?php echo htmlspecialchars(getSystemSetting('page_about_charter_title', 'Our Independence Charter')); ?></h2>
        <p class="text-slate-600 text-sm leading-relaxed font-light">
            <?php echo htmlspecialchars(getSystemSetting('page_about_charter_desc', 'Important Security & Scope Announcement: The PBAT Smart Nation Initiative is a 100% independent, non-governmental public advocacy movement. We function strictly to sensitize citizens on digital policy parameters and empower local youths.')); ?>
        </p>
        <div class="pt-4">
            <a href="register.php" class="px-6 py-3 bg-bushgreen hover:bg-bushgreen-light text-white font-bold text-xs rounded-xl shadow transition">
                Register as Grassroots Ambassador
            </a>
        </div>
    </div>
</section>

<?php
require_once __DIR__ . '/includes/footer.php';
?>
