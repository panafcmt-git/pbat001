<?php
/**
 * PBAT Smart Nation Initiative - Security Audit & Operations Logs
 * Restricted panel capturing and displaying analytical trace histories.
 * Upgraded to a complete interactive User Activity Audit Center with Operator,
 * Action Type, and Search filters.
 */
require_once dirname(__DIR__) . '/helpers/auth.php';
require_once dirname(__DIR__) . '/helpers/common.php';
require_once dirname(__DIR__) . '/config/database.php';

// Route protector - Restrict to Super Admin only
Auth::requireRole(['super_admin'], '../login.php');

$user = Auth::user();
$logs = [];
$users_list = [];
$actions_list = [];

$operator_id = trim($_GET['operator_id'] ?? '');
$action_type = trim($_GET['action_type'] ?? '');
$search = trim($_GET['search'] ?? '');
$error = '';

try {
    $db = Database::connect();
    
    // Fetch distinct operators for filter dropdown
    $users_list = $db->query("SELECT id, name, email FROM `users` ORDER BY name ASC")->fetchAll();
    
    // Fetch distinct actions for filter dropdown
    $actions_list = $db->query("SELECT DISTINCT action FROM `audit_logs` ORDER BY action ASC")->fetchAll(PDO::FETCH_COLUMN);

    // Build dynamic query
    $query = "
        SELECT l.*, u.name as user_name, r.display_name as role_display 
        FROM `audit_logs` l 
        LEFT JOIN `users` u ON l.user_id = u.id 
        LEFT JOIN `roles` r ON u.role_id = r.id 
        WHERE 1=1
    ";
    $params = [];

    if (!empty($operator_id)) {
        $query .= " AND l.user_id = ?";
        $params[] = (int)$operator_id;
    }

    if (!empty($action_type)) {
        $query .= " AND l.action = ?";
        $params[] = $action_type;
    }

    if (!empty($search)) {
        $query .= " AND (l.details LIKE ? OR l.ip_address LIKE ? OR l.action LIKE ? OR u.name LIKE ?)";
        $search_val = "%{$search}%";
        $params[] = $search_val;
        $params[] = $search_val;
        $params[] = $search_val;
        $params[] = $search_val;
    }

    $query .= " ORDER BY l.created_at DESC LIMIT 150";
    
    $stmt = $db->prepare($query);
    $stmt->execute($params);
    $logs = $stmt->fetchAll();

} catch (Exception $e) {
    $error = "Failed to fetch database table diagnostics: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Audit Logs - PBAT Smart Nation</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        bushgreen: {
                            DEFAULT: '#063C1E',
                            light: '#0A4D27',
                            dark: '#03200F',
                        },
                        gold: '#D4AF37'
                    }
                }
            }
        }
    </script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; }
        h1, h2, h3, h4, .font-display { font-family: 'Outfit', sans-serif; }
        [x-cloak] { display: none !important; }
    </style>
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
</head>
<body class="bg-slate-50 text-slate-800 transition-colors duration-200 min-h-screen flex flex-col antialiased"
      x-data="{ darkMode: localStorage.getItem('darkMode') === 'true' }"
      x-init="$watch('darkMode', val => localStorage.setItem('darkMode', val))"
      :class="{ 'dark bg-slate-900 text-slate-100': darkMode }">

    <!-- Header Navbar -->
    <header class="bg-bushgreen text-white border-b-2 border-gold h-20 flex items-center justify-between px-6 shadow-md relative z-30">
        <div class="flex items-center gap-3">
            <a href="dashboard.php" class="py-1.5 px-3 border border-white/20 hover:bg-white/10 text-white rounded-lg text-xs font-bold transition">
                &larr; Back to Dashboard
            </a>
            <div class="w-8 h-8 rounded bg-white/10 flex items-center justify-center border border-white/20 p-1 flex-shrink-0">
                <?php echo getAppLogoHtml('w-full h-full object-contain', 'dashboard'); ?>
            </div>
            <span class="text-white font-extrabold text-sm font-display hidden sm:inline">PBAT SMART NATION INITIATIVE</span>
        </div>
        <div class="flex items-center gap-4 text-xs font-bold text-gold uppercase tracking-wider">
            <button @click="darkMode = !darkMode" class="p-2 rounded-lg border border-gold/45 text-gold hover:bg-gold/10 transition flex items-center justify-center">
                <svg x-show="darkMode" class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364-6.364l-.707.707M6.364 17.636l-.707.707M18.364 17.636l-.707-.707M6.364 6.364l-.707-.707M15 12a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                <svg x-show="!darkMode" class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z"/></svg>
            </button>
            <span>Audit Ledger</span>
        </div>
    </header>

    <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 flex-grow w-full space-y-8">
        
        <div class="space-y-1">
            <h1 class="text-2xl sm:text-3xl font-black text-bushgreen dark:text-gold font-display">User Activity Audit Center</h1>
            <p class="text-slate-500 dark:text-slate-400 text-xs font-light">Trace critical credential assignments, login histories, database modifications, and role updates in real-time.</p>
        </div>

        <?php if (!empty($error)): ?>
            <div class="p-4 bg-red-50 dark:bg-red-500/10 border border-red-200 dark:border-red-500/20 text-red-800 dark:text-red-400 rounded-2xl text-xs font-semibold">
                <?php echo $error; ?>
            </div>
        <?php endif; ?>

        <!-- FILTER CONTROLS -->
        <div class="bg-white dark:bg-slate-800 p-6 rounded-2xl border border-slate-100 dark:border-slate-700 shadow-sm">
            <h3 class="text-slate-800 dark:text-white font-bold text-xs uppercase tracking-wider mb-4 font-display">Filter Activity Logs</h3>
            <form method="GET" action="" class="grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
                
                <div>
                    <label class="block text-slate-500 dark:text-slate-400 text-[10px] font-bold uppercase mb-1.5" for="operator_id">Operator</label>
                    <select name="operator_id" id="operator_id" class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs focus:outline-none focus:border-bushgreen">
                        <option value="">All Operators</option>
                        <?php foreach ($users_list as $op): ?>
                            <option value="<?php echo $op['id']; ?>" <?php echo $operator_id == $op['id'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($op['name']); ?> (<?php echo htmlspecialchars($op['email']); ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div>
                    <label class="block text-slate-500 dark:text-slate-400 text-[10px] font-bold uppercase mb-1.5" for="action_type">Action Category</label>
                    <select name="action_type" id="action_type" class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs focus:outline-none focus:border-bushgreen">
                        <option value="">All Actions</option>
                        <?php foreach ($actions_list as $act): ?>
                            <option value="<?php echo htmlspecialchars($act); ?>" <?php echo $action_type === $act ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($act); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div>
                    <label class="block text-slate-500 dark:text-slate-400 text-[10px] font-bold uppercase mb-1.5" for="search">Keyword Search</label>
                    <input type="text" name="search" id="search" value="<?php echo htmlspecialchars($search); ?>" placeholder="IP, Details, Action..." class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs focus:outline-none focus:border-bushgreen">
                </div>

                <div class="flex gap-2">
                    <button type="submit" class="flex-grow py-2 px-5 bg-bushgreen hover:bg-bushgreen-light text-white text-xs font-bold rounded-xl transition shadow-md">
                        Filter Trail
                    </button>
                    <a href="audit-logs.php" class="py-2 px-4 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-xs font-bold rounded-xl hover:bg-slate-50 dark:hover:bg-slate-900 text-center transition">
                        Reset
                    </a>
                </div>

            </form>
        </div>

        <!-- LOGS LEDGER TABLE -->
        <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm">
            <div class="overflow-x-auto">
                <table class="w-full text-xs text-left text-slate-500 dark:text-slate-400">
                    <thead class="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase border-b border-slate-100 dark:border-slate-700">
                        <tr>
                            <th class="pb-3 w-40">Timestamp</th>
                            <th class="pb-3">Authorized Operator</th>
                            <th class="pb-3">Access Tier</th>
                            <th class="pb-3">Action</th>
                            <th class="pb-3 w-32">IP Address</th>
                            <th class="pb-3 max-w-sm">Operational Details</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-50 dark:divide-slate-700 font-light">
                        <?php if (empty($logs)): ?>
                            <tr>
                                <td colspan="6" class="py-8 text-center text-slate-400 dark:text-slate-500 italic">No audit records found matching the active filters.</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($logs as $log): ?>
                                <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-750/30">
                                    <td class="py-3.5 text-slate-400 dark:text-slate-500 font-semibold font-mono"><?php echo date('Y-m-d H:i:s', strtotime($log['created_at'])); ?></td>
                                    <td class="py-3.5 font-bold text-slate-800 dark:text-slate-200">
                                        <?php if ($log['user_id']): ?>
                                            <a href="user-details.php?id=<?php echo $log['user_id']; ?>" class="hover:text-gold transition">
                                                <?php echo htmlspecialchars($log['user_name'] ?? 'Unknown User'); ?>
                                            </a>
                                        <?php else: ?>
                                            <span class="text-slate-400 italic">System Process</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="py-3.5">
                                        <span class="px-2 py-0.5 rounded bg-bushgreen/10 text-bushgreen dark:bg-gold/10 dark:text-gold text-[8px] font-bold uppercase tracking-wider">
                                            <?php echo htmlspecialchars($log['role_display'] ?? 'System Core'); ?>
                                        </span>
                                    </td>
                                    <td class="py-3.5">
                                        <span class="px-2 py-0.5 rounded-full text-[9px] font-bold uppercase tracking-wide bg-slate-100 text-slate-700 dark:bg-slate-900 dark:text-slate-350 dark:border-slate-750 border border-slate-200">
                                            <?php echo htmlspecialchars($log['action']); ?>
                                        </span>
                                    </td>
                                    <td class="py-3.5 font-mono text-[10px]"><?php echo htmlspecialchars($log['ip_address']); ?></td>
                                    <td class="py-3.5 text-slate-600 dark:text-slate-400 font-semibold leading-normal max-w-sm truncate" title="<?php echo htmlspecialchars($log['details']); ?>">
                                        <?php echo htmlspecialchars($log['details']); ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </main>
</body>
</html>
