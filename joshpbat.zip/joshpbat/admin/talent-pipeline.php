<?php
/**
 * PBAT Smart Nation Initiative - National Talent Pipeline Moderation Console
 * Allows Super Admin to View, Dossier, and Moderate (Shortlist, Approve, Reject) submissions.
 */
require_once dirname(__DIR__) . '/helpers/auth.php';
require_once dirname(__DIR__) . '/helpers/common.php';
require_once dirname(__DIR__) . '/config/database.php';

Auth::requireRole(['super_admin', 'founder_circle'], '../login.php');

$user = Auth::user();
$error = '';
$success = '';

try {
    $db = Database::connect();

    // 1. Process Moderation Action (Post)
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'moderate') {
        if (!Auth::validateCsrf($_POST['csrf_token'] ?? '')) {
            $error = "CSRF Token validation failed.";
        } else {
            $submission_id = (int)$_POST['submission_id'];
            $status = trim($_POST['status'] ?? 'pending');
            $moderation_notes = trim($_POST['moderation_notes'] ?? '');
            
            $valid_statuses = ['pending', 'shortlisted', 'approved', 'rejected'];
            if (!in_array($status, $valid_statuses)) {
                $error = "Invalid moderation status selected.";
            } else {
                // Fetch submission details to get candidate and skill
                $stmt_sub = $db->prepare("SELECT tp.*, u.name, u.email FROM `talent_pipeline` tp JOIN `users` u ON tp.user_id = u.id WHERE tp.id = ? LIMIT 1");
                $stmt_sub->execute([$submission_id]);
                $submission = $stmt_sub->fetch();

                if (!$submission) {
                    $error = "Submissions reference not found.";
                } else {
                    // Update status
                    $stmt_up = $db->prepare("
                        UPDATE `talent_pipeline` 
                        SET `status` = ?, `moderation_notes` = ?, `moderated_by` = ?, `moderated_at` = NOW()
                        WHERE `id` = ?
                    ");
                    $stmt_up->execute([$status, $moderation_notes, $user['id'], $submission_id]);

                    // Log audit trail
                    Auth::logAction($user['id'], 'TALENT_PIPELINE_MODERATE', "Moderated submission ID {$submission_id} (Status: {$status})");

                    // Dispatch notification to user (submitter)
                    $notif_msg = "Your National Talent Pipeline registration for '{$submission['skill']}' has been " . strtoupper($status) . ".";
                    if (!empty($moderation_notes)) {
                        $notif_msg .= " Notes: " . $moderation_notes;
                    }
                    $stmt_n = $db->prepare("INSERT INTO `notifications` (`user_id`, `message`, `type`) VALUES (?, ?, 'general')");
                    $stmt_n->execute([$submission['user_id'], $notif_msg]);

                    // Send email notification
                    $subject = "Talent Pipeline Status Updated - PBAT Smart Nation";
                    $recipient_name = (($submission['registration_type'] ?? 'register_self') === 'register_talent') ? $submission['talent_name'] : $submission['name'];
                    $recipient_email = (($submission['registration_type'] ?? 'register_self') === 'register_talent' && !empty($submission['talent_email'])) ? $submission['talent_email'] : $submission['email'];
                    
                    $msg_html = "
                    <p>Dear <strong>" . htmlspecialchars($recipient_name) . "</strong>,</p>
                    <p>The National Talent Pipeline registration for <strong>" . htmlspecialchars($submission['skill']) . "</strong> has been reviewed by the strategic steering directorate.</p>
                    <p>Status: <strong>" . strtoupper($status) . "</strong></p>
                    <p>Moderator Notes: <em>" . htmlspecialchars($moderation_notes ?: 'No details provided.') . "</em></p>
                    <p>Please check the portal for further updates.</p>
                    ";
                    $mail_body = getEmailTemplate("Talent Pipeline Update", "Talent Directorate Notice", "Hello " . htmlspecialchars($recipient_name), $msg_html, "admin/dashboard.php?tab=talent_pipeline", "View Pipeline");
                    sendMail($recipient_email, $subject, $mail_body);

                    if (($submission['registration_type'] ?? 'register_self') === 'register_talent' && !empty($submission['talent_email'])) {
                        // Also notify the submitter
                        $submitter_subject = "Registered Talent Status Updated - PBAT Smart Nation";
                        $submitter_msg = "
                        <p>Dear <strong>" . htmlspecialchars($submission['name']) . "</strong>,</p>
                        <p>The talent you registered (<strong>" . htmlspecialchars($submission['talent_name']) . "</strong>) for <strong>" . htmlspecialchars($submission['skill']) . "</strong> has been updated.</p>
                        <p>Status: <strong>" . strtoupper($status) . "</strong></p>
                        <p>Moderator Notes: <em>" . htmlspecialchars($moderation_notes ?: 'No details provided.') . "</em></p>
                        ";
                        $submitter_body = getEmailTemplate("Talent Update Notice", "Talent Directorate Notice", "Hello " . htmlspecialchars($submission['name']), $submitter_msg, "admin/dashboard.php?tab=talent_pipeline", "View Pipeline Dashboard");
                        sendMail($submission['email'], $submitter_subject, $submitter_body);
                    }

                    $success = "Submission ID {$submission_id} has been moderated and transitioned to '" . strtoupper($status) . "'!";
                }
            }
        }
    }

    // 2. Fetch all submissions with candidates geopolitics
    $stmt_list = $db->query("
        SELECT tp.*, u.name as candidate_name, u.email as candidate_email, u.phone as candidate_phone, u.avatar, u.role_id, r.display_name as role_name,
               COALESCE(s_amb.name, s_lead.name) as state_name,
               COALESCE(l_amb.name, l_lead.name) as lga_name,
               w_amb.name as ward_name,
               COALESCE(a_amb.impact_score, 0) as impact_score,
               u_mod.name as moderator_name
        FROM `talent_pipeline` tp
        JOIN `users` u ON tp.user_id = u.id
        JOIN `roles` r ON u.role_id = r.id
        LEFT JOIN `ambassadors` a_amb ON u.id = a_amb.user_id
        LEFT JOIN `states` s_amb ON a_amb.state_id = s_amb.id
        LEFT JOIN `lgas` l_amb ON a_amb.lga_id = l_amb.id
        LEFT JOIN `wards` w_amb ON a_amb.ward_id = w_amb.id
        LEFT JOIN `user_leadership` ul ON u.id = ul.user_id
        LEFT JOIN `states` s_lead ON ul.state_id = s_lead.id
        LEFT JOIN `lgas` l_lead ON ul.lga_id = l_lead.id
        LEFT JOIN `users` u_mod ON tp.moderated_by = u_mod.id
        ORDER BY tp.created_at DESC
    ");
    $submissions = $stmt_list->fetchAll();

    // 3. Fetch volunteer preference index for candidates
    $stmt_vols = $db->query("
        SELECT v.*, u.name
        FROM `volunteers` v
        JOIN `users` u ON v.user_id = u.id
    ");
    $raw_vols = $stmt_vols->fetchAll();
    $volunteer_map = [];
    foreach ($raw_vols as $vol) {
        $volunteer_map[$vol['user_id']] = $vol;
    }

} catch (Exception $e) {
    $error = "Talent Pipeline DB Error: " . $e->getMessage();
    $submissions = [];
    $volunteer_map = [];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Talent Pipeline Moderation - PBAT Smart Nation</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        bushgreen: {
                            DEFAULT: '#063C1E',
                            light: '#0A4D27',
                            dark: '#03200F',
                        },
                        gold: '#D4AF37'
                    }
                }
            }
        }
    </script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
    <style>
        [x-cloak] { display: none !important; }
        body { font-family: 'Inter', sans-serif; }
        h1, h2, h3, h4, .font-display { font-family: 'Outfit', sans-serif; }
    </style>
</head>
<body class="bg-slate-50 text-slate-800 transition-colors duration-200 min-h-screen flex flex-col antialiased"
      x-data="{ 
          darkMode: localStorage.getItem('darkMode') === 'true',
          activeTab: 'all',
          selectedSub: null,
          showDossier: false,
          showModerate: false,
          notes: ''
      }"
      x-init="$watch('darkMode', val => localStorage.setItem('darkMode', val))"
      :class="{ 'dark bg-slate-900 text-slate-100': darkMode }">

    <!-- Header Navbar -->
    <header class="bg-bushgreen text-white border-b-2 border-gold h-20 flex items-center justify-between px-6 shadow-md relative z-30">
        <div class="flex items-center gap-3">
            <a href="dashboard.php" class="py-1.5 px-3 border border-white/20 hover:bg-white/10 text-white rounded-lg text-xs font-bold transition">
                &larr; Back to Dashboard
            </a>
            <div class="w-8 h-8 rounded bg-white/10 flex items-center justify-center border border-white/20 p-1 flex-shrink-0">
                <?php echo getAppLogoHtml('w-full h-full object-contain', 'dashboard'); ?>
            </div>
            <span class="text-white font-extrabold text-sm font-display hidden sm:inline">PBAT SMART NATION INITIATIVE</span>
        </div>
        <div class="flex items-center gap-4 text-xs font-bold text-gold uppercase tracking-wider font-display">
            <!-- Dark Mode Toggle -->
            <button @click="darkMode = !darkMode" class="p-2 rounded-lg border border-gold/45 text-gold hover:bg-gold/10 transition flex items-center justify-center">
                <svg x-show="darkMode" class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364-6.364l-.707.707M6.364 17.636l-.707.707M18.364 17.636l-.707-.707M6.364 6.364l-.707-.707M15 12a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                <svg x-show="!darkMode" class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z"/></svg>
            </button>
            <span>Talent Pipeline Hub</span>
        </div>
    </header>

    <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 flex-grow w-full space-y-10">
        
        <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div class="space-y-1">
                <h1 class="text-2xl sm:text-3xl font-black text-bushgreen dark:text-gold font-display uppercase tracking-tight">Talent Pipeline Moderation</h1>
                <p class="text-slate-500 dark:text-slate-400 text-xs font-light">Moderate, review and audit the grassroots IT talent registrations nationwide.</p>
            </div>

            <?php if (!empty($success)): ?>
                <div class="px-4 py-2 bg-emerald-50 border border-emerald-250 text-emerald-800 rounded-xl text-xs font-semibold">
                    <?php echo htmlspecialchars($success); ?>
                </div>
            <?php endif; ?>

            <?php if (!empty($error)): ?>
                <div class="px-4 py-2 bg-red-50 border border-red-205 text-red-800 rounded-xl text-xs font-semibold">
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>
        </div>

        <!-- Tab switches -->
        <div class="flex flex-wrap gap-2 border-b border-slate-200 dark:border-slate-800 pb-2">
            <button @click="activeTab = 'all'" :class="activeTab === 'all' ? 'bg-bushgreen text-white dark:bg-gold dark:text-bushgreen' : 'bg-white dark:bg-slate-800 text-slate-655'" class="px-4 py-1.5 rounded-lg text-xs font-bold transition">All Submissions</button>
            <button @click="activeTab = 'pending'" :class="activeTab === 'pending' ? 'bg-bushgreen text-white dark:bg-gold dark:text-bushgreen' : 'bg-white dark:bg-slate-800 text-slate-655'" class="px-4 py-1.5 rounded-lg text-xs font-bold transition">Pending Review</button>
            <button @click="activeTab = 'shortlisted'" :class="activeTab === 'shortlisted' ? 'bg-bushgreen text-white dark:bg-gold dark:text-bushgreen' : 'bg-white dark:bg-slate-800 text-slate-655'" class="px-4 py-1.5 rounded-lg text-xs font-bold transition">Shortlisted</button>
            <button @click="activeTab = 'approved'" :class="activeTab === 'approved' ? 'bg-bushgreen text-white dark:bg-gold dark:text-bushgreen' : 'bg-white dark:bg-slate-800 text-slate-655'" class="px-4 py-1.5 rounded-lg text-xs font-bold transition">Approved</button>
            <button @click="activeTab = 'rejected'" :class="activeTab === 'rejected' ? 'bg-bushgreen text-white dark:bg-gold dark:text-bushgreen' : 'bg-white dark:bg-slate-800 text-slate-655'" class="px-4 py-1.5 rounded-lg text-xs font-bold transition">Rejected</button>
        </div>

        <!-- List View -->
        <div class="bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 shadow-sm overflow-hidden">
            <div class="overflow-x-auto">
                <table class="w-full text-xs text-left text-slate-500 dark:text-slate-400">
                    <thead class="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider border-b border-slate-100 dark:border-slate-700">
                        <tr>
                            <th class="p-4">Candidate</th>
                            <th class="p-4">Role</th>
                            <th class="p-4">IT Skill</th>
                            <th class="p-4 text-center">Pipeline Mode</th>
                            <th class="p-4">State Assignment</th>
                            <th class="p-4">Status</th>
                            <th class="p-4 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-50 dark:divide-slate-700">
                        <?php if (empty($submissions)): ?>
                            <tr>
                                <td colspan="7" class="p-8 text-center text-slate-400 italic">No registrations submitted yet.</td>
                            </tr>
                        <?php endif; ?>
                        
                        <?php foreach ($submissions as $sub): 
                            $vol_data = isset($volunteer_map[$sub['user_id']]) ? json_encode($volunteer_map[$sub['user_id']]) : 'null';
                        ?>
                            <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-700/50"
                                x-show="activeTab === 'all' || activeTab === '<?php echo $sub['status']; ?>'">
                                <td class="p-4 flex items-center gap-3">
                                    <img src="<?php echo htmlspecialchars(!empty($sub['avatar']) ? '../' . $sub['avatar'] : '../assets/img/default-avatar.png'); ?>" 
                                         class="w-8 h-8 rounded-full object-cover border border-slate-200">
                                    <div>
                                        <?php if (($sub['registration_type'] ?? 'register_self') === 'register_talent'): ?>
                                            <div class="font-bold text-slate-800 dark:text-white"><?php echo htmlspecialchars($sub['talent_name']); ?></div>
                                            <div class="text-[9px] font-mono text-slate-400"><?php echo htmlspecialchars($sub['talent_email'] ?: 'No Email'); ?></div>
                                            <div class="text-[9px] text-slate-400 italic">By: <?php echo htmlspecialchars($sub['candidate_name']); ?></div>
                                        <?php else: ?>
                                            <div class="font-bold text-slate-800 dark:text-white"><?php echo htmlspecialchars($sub['candidate_name']); ?></div>
                                            <div class="text-[9px] font-mono text-slate-400"><?php echo htmlspecialchars($sub['candidate_email']); ?></div>
                                        <?php endif; ?>
                                    </div>
                                </td>
                                <td class="p-4 font-semibold"><?php echo htmlspecialchars($sub['role_name']); ?></td>
                                <td class="p-4 font-bold text-slate-800 dark:text-gold"><?php echo htmlspecialchars($sub['skill']); ?></td>
                                <td class="p-4 text-center">
                                    <span class="px-2 py-0.5 rounded text-[8px] font-bold uppercase tracking-wider <?php echo $sub['role_type'] === 'trainer' ? 'bg-bushgreen text-white' : 'bg-gold/20 text-gold-dark'; ?>">
                                        <?php echo htmlspecialchars($sub['role_type']); ?>
                                    </span>
                                </td>
                                <td class="p-4 font-semibold text-slate-655 dark:text-slate-300"><?php echo htmlspecialchars($sub['state_name'] ?: 'National'); ?> &bull; <span class="text-[10px] text-slate-400"><?php echo htmlspecialchars($sub['lga_name'] ?? 'HQ'); ?></span></td>
                                <td class="p-4">
                                    <span class="px-2.5 py-0.5 rounded-full text-[9px] font-extrabold uppercase tracking-wide
                                        <?php 
                                        if ($sub['status'] === 'approved') echo 'bg-emerald-50 text-emerald-800 border border-emerald-250';
                                        elseif ($sub['status'] === 'shortlisted') echo 'bg-blue-50 text-blue-800 border border-blue-200';
                                        elseif ($sub['status'] === 'rejected') echo 'bg-red-50 text-red-800 border border-red-200';
                                        else echo 'bg-amber-50 text-amber-800 border border-amber-200';
                                        ?>">
                                        <?php echo htmlspecialchars($sub['status']); ?>
                                    </span>
                                </td>
                                <td class="p-4 text-right space-x-1.5 whitespace-nowrap">
                                    <!-- View/Dossier button -->
                                    <button @click="
                                        selectedSub = <?php echo htmlspecialchars(json_encode($sub)); ?>;
                                        selectedSub.volunteer = <?php echo $vol_data; ?>;
                                        showDossier = true;
                                    " class="py-1 px-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 dark:bg-slate-700 dark:text-white dark:hover:bg-slate-600 rounded text-[9px] font-bold transition">
                                        Dossier
                                    </button>
                                    
                                    <!-- Moderate Action button -->
                                    <button @click="
                                        selectedSub = <?php echo htmlspecialchars(json_encode($sub)); ?>;
                                        notes = selectedSub.moderation_notes || '';
                                        showModerate = true;
                                    " class="py-1 px-2.5 bg-bushgreen text-white hover:bg-bushgreen-light rounded text-[9px] font-bold transition">
                                        Moderate
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </main>

    <!-- DOSSIER DIALOG / MODAL (Alpine.js overlay) -->
    <div x-show="showDossier" x-cloak class="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
        <div class="bg-white dark:bg-slate-800 rounded-3xl max-w-2xl w-full border border-slate-100 dark:border-slate-700 shadow-2xl overflow-hidden animate-fade-in" @click.away="showDossier = false">
            
            <div class="bg-bushgreen text-white p-6 border-b-2 border-gold flex justify-between items-center">
                <h3 class="text-base font-black font-display uppercase tracking-wider">Candidate Member Dossier</h3>
                <button @click="showDossier = false" class="text-white hover:text-gold text-lg font-bold">&times;</button>
            </div>

            <div class="p-6 space-y-6 max-h-[75vh] overflow-y-auto" x-if="selectedSub">
                
                <!-- Summary Card -->
                <div class="flex items-center gap-4 p-4 bg-slate-50 dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800">
                    <img :src="selectedSub ? (selectedSub.avatar ? '../' + selectedSub.avatar : '../assets/img/default-avatar.png') : ''" 
                         class="w-16 h-16 rounded-full object-cover border-2 border-gold shadow">
                    <div class="space-y-1">
                        <h4 class="text-base font-black text-slate-800 dark:text-white font-display" x-text="selectedSub ? (selectedSub.registration_type === 'register_talent' ? selectedSub.talent_name : selectedSub.candidate_name) : ''"></h4>
                        <span class="px-2 py-0.5 bg-bushgreen/10 text-bushgreen dark:bg-gold/10 dark:text-gold rounded text-[8px] font-bold uppercase tracking-wider" x-text="selectedSub ? selectedSub.role_name : ''"></span>
                        <div class="text-[10px] text-slate-400 font-mono" x-text="selectedSub ? (selectedSub.registration_type === 'register_talent' ? (selectedSub.talent_email || 'No Email') : selectedSub.candidate_email) : ''"></div>
                        <template x-if="selectedSub && selectedSub.registration_type === 'register_talent'">
                            <div class="text-[9px] text-slate-500 font-light" x-text="'Registered by: ' + selectedSub.candidate_name"></div>
                        </template>
                    </div>
                </div>

                <!-- Geopolitical Scope -->
                <div class="space-y-2">
                    <h5 class="text-[10px] font-bold text-gold uppercase tracking-widest font-display">Geopolitical Coordinates</h5>
                    <div class="grid grid-cols-3 gap-4 text-xs p-3 bg-slate-50 dark:bg-slate-900 rounded-2xl">
                        <div>
                            <span class="text-slate-400 block text-[9px]">State</span>
                            <span class="font-bold text-slate-800 dark:text-white" x-text="selectedSub ? (selectedSub.state_name || 'National') : ''"></span>
                        </div>
                        <div>
                            <span class="text-slate-400 block text-[9px]">LGA</span>
                            <span class="font-bold text-slate-800 dark:text-white" x-text="selectedSub ? (selectedSub.lga_name || 'HQ') : ''"></span>
                        </div>
                        <div>
                            <span class="text-slate-400 block text-[9px]">Ward Unit</span>
                            <span class="font-bold text-slate-800 dark:text-white" x-text="selectedSub ? (selectedSub.ward_name || 'N/A') : ''"></span>
                        </div>
                        <div>
                            <span class="text-slate-400 block text-[9px]">Impact Rating</span>
                            <span class="font-bold text-emerald-600" x-text="selectedSub ? selectedSub.impact_score + ' Points' : '0'"></span>
                        </div>
                    </div>
                </div>

                <!-- Pipeline Submission details -->
                <div class="space-y-2">
                    <h5 class="text-[10px] font-bold text-gold uppercase tracking-widest font-display">Pipeline Submissions Specifics</h5>
                    <div class="space-y-2 p-4 bg-slate-50 dark:bg-slate-900 rounded-2xl">
                        <div class="flex justify-between items-center text-xs">
                            <span class="font-bold text-slate-850 dark:text-white">Registered Skill Category:</span>
                            <span class="font-bold text-bushgreen dark:text-gold" x-text="selectedSub ? selectedSub.skill : ''"></span>
                        </div>
                        <div class="flex justify-between items-center text-xs">
                            <span class="font-bold text-slate-850 dark:text-white">Pipeline Engagement Mode:</span>
                            <span class="px-2 py-0.5 rounded text-[8px] font-bold uppercase" :class="selectedSub && selectedSub.role_type === 'trainer' ? 'bg-bushgreen text-white' : 'bg-gold/20 text-gold-dark'" x-text="selectedSub ? selectedSub.role_type : ''"></span>
                        </div>
                        <div class="flex justify-between items-center text-xs">
                            <span class="font-bold text-slate-850 dark:text-white">Experience Level Claim:</span>
                            <span class="font-semibold text-slate-800 dark:text-white" x-text="selectedSub ? selectedSub.experience_years + ' Years' : '0 Years'"></span>
                        </div>
                        <div class="text-xs space-y-1 pt-2 border-t border-slate-200 dark:border-slate-800">
                            <span class="font-bold text-slate-850 dark:text-white block">Motivation Statement of Intent:</span>
                            <p class="text-slate-500 dark:text-slate-450 leading-relaxed text-justify font-light" x-text="selectedSub ? (selectedSub.additional_notes || 'No notes provided by candidate.') : ''"></p>
                        </div>
                    </div>
                </div>

                <!-- Volunteer Preferences (Joined information) -->
                <div class="space-y-2">
                    <h5 class="text-[10px] font-bold text-gold uppercase tracking-widest font-display">Volunteer Mobilisation Preferences</h5>
                    <div class="p-4 bg-slate-50 dark:bg-slate-900 rounded-2xl space-y-3 text-xs">
                        <template x-if="!selectedSub || !selectedSub.volunteer">
                            <p class="text-slate-400 italic font-light">Candidate has not registered volunteer enlistment coordinates yet.</p>
                        </template>
                        <template x-if="selectedSub && selectedSub.volunteer">
                            <div class="space-y-2">
                                <div class="flex justify-between text-xs">
                                    <span class="font-semibold text-slate-700 dark:text-slate-350">Volunteer Status:</span>
                                    <span class="px-2 py-0.5 rounded text-[9px] font-bold uppercase bg-amber-50 text-amber-800" x-text="selectedSub.volunteer.status"></span>
                                </div>
                                <div class="flex justify-between text-xs">
                                    <span class="font-semibold text-slate-700 dark:text-slate-350">Weekly Availability:</span>
                                    <span class="font-bold text-slate-800 dark:text-white" x-text="selectedSub.volunteer.availability"></span>
                                </div>
                                <div>
                                    <span class="text-slate-400 block text-[9px]">Volunteer Areas of Interest:</span>
                                    <p class="font-mono text-slate-800 dark:text-slate-200 mt-1 text-[9px]" x-text="selectedSub.volunteer.volunteer_areas"></p>
                                </div>
                            </div>
                        </template>
                    </div>
                </div>

            </div>

            <div class="p-6 border-t border-slate-100 dark:border-slate-700 bg-slate-50 dark:bg-slate-900/40 flex justify-end gap-3">
                <button @click="showDossier = false" class="py-2 px-5 bg-slate-200 hover:bg-slate-300 text-slate-700 dark:bg-slate-700 dark:text-white text-xs font-bold rounded-xl transition">
                    Close Dossier
                </button>
                <button @click="
                    showDossier = false;
                    notes = selectedSub.moderation_notes || '';
                    showModerate = true;
                " class="py-2 px-5 bg-bushgreen hover:bg-bushgreen-light text-white text-xs font-bold rounded-xl transition">
                    Proceed to Moderate
                </button>
            </div>

        </div>
    </div>

    <!-- MODERATION DIALOG / MODAL (Alpine.js overlay) -->
    <div x-show="showModerate" x-cloak class="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
        <div class="bg-white dark:bg-slate-800 rounded-3xl max-w-md w-full border border-slate-100 dark:border-slate-700 shadow-2xl overflow-hidden animate-fade-in" @click.away="showModerate = false">
            
            <div class="bg-bushgreen text-white p-5 border-b-2 border-gold flex justify-between items-center">
                <h3 class="text-sm font-black font-display uppercase tracking-wider">Moderate Candidate Skill Submission</h3>
                <button @click="showModerate = false" class="text-white hover:text-gold text-lg font-bold">&times;</button>
            </div>

            <form method="POST" action="" class="p-6 space-y-4" x-if="selectedSub">
                <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                <input type="hidden" name="action" value="moderate">
                <input type="hidden" name="submission_id" :value="selectedSub ? selectedSub.id : 0">

                <div class="p-3 bg-slate-50 dark:bg-slate-900 rounded-xl border border-slate-100 dark:border-slate-800">
                    <span class="text-slate-400 block text-[9px]">Reviewing candidate:</span>
                    <strong class="text-slate-800 dark:text-white text-xs" x-text="selectedSub ? selectedSub.candidate_name : ''"></strong>
                    <span class="text-slate-400 block text-[9px] mt-1">Skill Area:</span>
                    <strong class="text-bushgreen dark:text-gold text-xs" x-text="selectedSub ? selectedSub.skill : ''"></strong>
                </div>

                <div>
                    <label class="block text-slate-655 dark:text-slate-400 text-xs font-semibold mb-1.5" for="m_notes">Moderation Notes / Feedback *</label>
                    <textarea name="moderation_notes" id="m_notes" required rows="4" x-model="notes" placeholder="Write feedback notes explaining your strategic decisions..."
                              class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen dark:text-white leading-relaxed font-light"></textarea>
                </div>

                <div class="space-y-2 pt-2">
                    <label class="block text-slate-655 dark:text-slate-400 text-[10px] font-bold uppercase tracking-wider">Transition State Status:</label>
                    <div class="grid grid-cols-3 gap-2">
                        <button type="submit" name="status" value="shortlisted" class="py-2 bg-blue-600 hover:bg-blue-700 text-white text-[10px] font-bold rounded-lg transition uppercase tracking-wider">
                            Shortlist
                        </button>
                        <button type="submit" name="status" value="approved" class="py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-[10px] font-bold rounded-lg transition uppercase tracking-wider">
                            Approve
                        </button>
                        <button type="submit" name="status" value="rejected" class="py-2 bg-red-650 hover:bg-red-700 text-white text-[10px] font-bold rounded-lg transition uppercase tracking-wider">
                            Reject
                        </button>
                    </div>
                </div>
            </form>
            
            <div class="p-4 bg-slate-50 dark:bg-slate-900/60 border-t border-slate-100 dark:border-slate-800 flex justify-end">
                <button @click="showModerate = false" class="py-1.5 px-4 border border-slate-200 dark:border-slate-700 hover:bg-slate-100 text-[10px] font-bold rounded-lg transition">
                    Cancel
                </button>
            </div>

        </div>
    </div>

</body>
</html>
