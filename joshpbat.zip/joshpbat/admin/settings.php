<?php
/**
 * PBAT Smart Nation Initiative - Website Settings & SMTP Configuration
 * Allows configuring website settings (Branding, SEO keywords, Footer, Contact info) and secure SMTP parameters.
 */
require_once dirname(__DIR__) . '/helpers/auth.php';
require_once dirname(__DIR__) . '/helpers/common.php';
require_once dirname(__DIR__) . '/config/database.php';

Auth::requireRole(['super_admin'], '../login.php');

$user = Auth::user();
$error = '';
$success = '';
$test_success = null;
$test_log = '';

$smtp_config_file = dirname(__DIR__) . '/config/smtp.php';

try {
    $db = Database::connect();

    // 1. Handle Form Actions
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (!Auth::validateCsrf($_POST['csrf_token'] ?? '')) {
            $error = "Security validation token expired.";
        } else {
            $action = $_POST['action'] ?? '';

            // 1.1 SAVE GENERAL SETTINGS
            if ($action === 'save_general') {
                $site_name = trim($_POST['site_name']);
                $contact_email = trim($_POST['contact_email']);
                $contact_phone = trim($_POST['contact_phone']);
                $footer_copyright = trim($_POST['footer_copyright']);
                $logo_url = trim($_POST['logo_url']);
                $logo_size = (int)($_POST['logo_size'] ?? 40);
                $footer_logo_url = trim($_POST['footer_logo_url'] ?? '');
                $footer_logo_size = (int)($_POST['footer_logo_size'] ?? 32);

                // Reset Action Toggles
                if (isset($_POST['reset_logo']) && $_POST['reset_logo'] === 'true') {
                    $logo_url = '';
                }
                if (isset($_POST['reset_footer_logo']) && $_POST['reset_footer_logo'] === 'true') {
                    $footer_logo_url = '';
                }

                // Handle Logo Upload if present
                if (isset($_FILES['logo_upload']) && $_FILES['logo_upload']['error'] === UPLOAD_ERR_OK) {
                    $file = $_FILES['logo_upload'];
                    $file_size = $file['size'];
                    $file_tmp = $file['tmp_name'];
                    $file_name = basename($file['name']);
                    $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

                    $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif', 'svg', 'webp'];
                    if (in_array($file_ext, $allowed_extensions)) {
                        if ($file_size <= 2097152) { // 2MB limit
                            $upload_dir = dirname(__DIR__) . '/uploads/';
                            if (!is_dir($upload_dir)) {
                                mkdir($upload_dir, 0755, true);
                            }
                            $new_file_name = 'logo_' . time() . '.' . $file_ext;
                            $target_file = $upload_dir . $new_file_name;
                            if (move_uploaded_file($file_tmp, $target_file)) {
                                $logo_url = 'uploads/' . $new_file_name;
                            } else {
                                $error = "Failed to write uploaded logo to uploads folder.";
                            }
                        } else {
                            $error = "Logo image size exceeds 2MB limit.";
                        }
                    } else {
                        $error = "Invalid logo file type. Only JPG, PNG, GIF, SVG, and WEBP formats are allowed.";
                    }
                }

                // Handle Footer Logo Upload if present
                if (isset($_FILES['footer_logo_upload']) && $_FILES['footer_logo_upload']['error'] === UPLOAD_ERR_OK) {
                    $file = $_FILES['footer_logo_upload'];
                    $file_size = $file['size'];
                    $file_tmp = $file['tmp_name'];
                    $file_name = basename($file['name']);
                    $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

                    $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif', 'svg', 'webp'];
                    if (in_array($file_ext, $allowed_extensions)) {
                        if ($file_size <= 2097152) { // 2MB limit
                            $upload_dir = dirname(__DIR__) . '/uploads/';
                            if (!is_dir($upload_dir)) {
                                mkdir($upload_dir, 0755, true);
                            }
                            $new_file_name = 'footer_logo_' . time() . '.' . $file_ext;
                            $target_file = $upload_dir . $new_file_name;
                            if (move_uploaded_file($file_tmp, $target_file)) {
                                $footer_logo_url = 'uploads/' . $new_file_name;
                            } else {
                                $error = "Failed to write uploaded footer logo to uploads folder.";
                            }
                        } else {
                            $error = "Footer Logo image size exceeds 2MB limit.";
                        }
                    } else {
                        $error = "Invalid footer logo file type. Only JPG, PNG, GIF, SVG, and WEBP formats are allowed.";
                    }
                }

                if (empty($error)) {
                    $settings = [
                        'site_name' => $site_name,
                        'contact_email' => $contact_email,
                        'contact_phone' => $contact_phone,
                        'footer_copyright' => $footer_copyright,
                        'logo_url' => $logo_url,
                        'logo_size' => $logo_size,
                        'footer_logo_url' => $footer_logo_url,
                        'footer_logo_size' => $footer_logo_size
                    ];

                    $stmt = $db->prepare("INSERT INTO `system_settings` (`setting_key`, `setting_value`) VALUES (?, ?) ON DUPLICATE KEY UPDATE `setting_value` = ?");
                    foreach ($settings as $key => $val) {
                        $stmt->execute([$key, $val, $val]);
                    }

                    Auth::logAction($user['id'], 'SETTINGS_GENERAL_UPDATE', "Updated site general configurations & logo system.");
                    $success = "General website configurations saved successfully!";
                }
            }

            // 1.2 SAVE SMTP CONFIG
            if ($action === 'save_smtp') {
                $smtp_enabled = isset($_POST['smtp_enabled']) ? 'true' : 'false';
                $smtp_host = trim($_POST['smtp_host']);
                $smtp_port = (int)$_POST['smtp_port'];
                $smtp_user = trim($_POST['smtp_user']);
                $smtp_pass = $_POST['smtp_pass'];
                $smtp_encryption = trim($_POST['smtp_encryption']);
                $smtp_from_email = trim($_POST['smtp_from_email']);
                $smtp_from_name = trim($_POST['smtp_from_name']);

                if (empty($smtp_host) || empty($smtp_from_email)) {
                    $error = "SMTP Host and Sender Email are required.";
                } else {
                    $config_content = "<?php\n";
                    $config_content .= "// SMTP Configurations - PBAT Smart Nation\n";
                    $config_content .= "define('SMTP_ENABLED', {$smtp_enabled});\n";
                    $config_content .= "define('SMTP_HOST', '" . addslashes($smtp_host) . "');\n";
                    $config_content .= "define('SMTP_PORT', {$smtp_port});\n";
                    $config_content .= "define('SMTP_USER', '" . addslashes($smtp_user) . "');\n";
                    $config_content .= "define('SMTP_PASS', '" . addslashes($smtp_pass) . "');\n";
                    $config_content .= "define('SMTP_ENCRYPTION', '" . addslashes($smtp_encryption) . "');\n";
                    $config_content .= "define('SMTP_FROM_EMAIL', '" . addslashes($smtp_from_email) . "');\n";
                    $config_content .= "define('SMTP_FROM_NAME', '" . addslashes($smtp_from_name) . "');\n";

                    if (file_put_contents($smtp_config_file, $config_content) === false) {
                        $error = "Failed to write SMTP settings config. Check folder write access.";
                    } else {
                        $success = "SMTP parameters configured successfully!";
                    }
                }
            }

            // 1.2.5 SAVE S3 CONFIG
            if ($action === 'save_s3') {
                $s3_enabled = isset($_POST['s3_enabled']) ? '1' : '0';
                $s3_bucket = trim($_POST['s3_bucket'] ?? '');
                $s3_region = trim($_POST['s3_region'] ?? 'us-east-1');
                $s3_key = trim($_POST['s3_key'] ?? '');
                $s3_secret = trim($_POST['s3_secret'] ?? '');

                $settings_to_save = [
                    's3_enabled' => $s3_enabled,
                    's3_bucket' => $s3_bucket,
                    's3_region' => $s3_region,
                    's3_key' => $s3_key,
                    's3_secret' => $s3_secret
                ];

                $stmt = $db->prepare("INSERT INTO `system_settings` (`setting_key`, `setting_value`) VALUES (?, ?) ON DUPLICATE KEY UPDATE `setting_value` = ?");
                foreach ($settings_to_save as $key => $val) {
                    $stmt->execute([$key, $val, $val]);
                }

                Auth::logAction($user['id'], 'SETTINGS_S3_UPDATE', "Updated Amazon S3 storage parameters.");
                $success = "Amazon S3 Configurations saved successfully!";
                
                // Fetch settings again to refresh active tab variables
                $settings_rows = $db->query("SELECT * FROM `system_settings`")->fetchAll();
                foreach ($settings_rows as $row) {
                    $settings[$row['setting_key']] = $row['setting_value'];
                }
            }

            // 1.3 TEST CONNECTION
            if ($action === 'test_connection') {
                $smtp_host = trim($_POST['smtp_host']);
                $smtp_port = (int)$_POST['smtp_port'];
                $smtp_user = trim($_POST['smtp_user']);
                $smtp_pass = $_POST['smtp_pass'];
                $smtp_encryption = trim($_POST['smtp_encryption']);
                $smtp_from_email = trim($_POST['smtp_from_email']);
                $smtp_from_name = trim($_POST['smtp_from_name']);

                require_once dirname(__DIR__) . '/helpers/smtp.php';
                $mailer = new SMTPMailer($smtp_host, $smtp_port, $smtp_user, $smtp_pass, $smtp_encryption, 5);
                
                $test_body = "<h3>SMTP Diagnostic Connection Handshake Test</h3><p>Secure system email notification tunnels are operating correctly.</p>";
                $test_html = getEmailTemplate("SMTP Handshake Success", "Mail Gateway Test", "Diagnostics Complete", $test_body, "admin/settings.php", "Back to Settings");

                $test_success = $mailer->send($smtp_from_email, $smtp_from_name, $smtp_from_email, "SMTP Connection Test - PBAT Smart Nation", $test_html);
                $test_log = $mailer->getLog();

                if ($test_success) {
                    $success = "SMTP Connection Test Successful! Test alert dispatched to: " . htmlspecialchars($smtp_from_email);
                    Auth::logAction($user['id'], 'SMTP_TEST_SUCCESS', "Successful SMTP connection handshake.");
                } else {
                    $error = "SMTP Connection Handshake Failed. Verify parameters log below.";
                    Auth::logAction($user['id'], 'SMTP_TEST_FAILED', "Failed SMTP socket connection handshake.");
                }
            }
        }
    }

    // 2. Fetch existing general settings
    $settings_rows = $db->query("SELECT * FROM `system_settings`")->fetchAll();
    $settings = [];
    foreach ($settings_rows as $row) {
        $settings[$row['setting_key']] = $row['setting_value'];
    }

} catch (Exception $e) {
    $error = "Settings DB System Error: " . $e->getMessage();
}

// Load SMTP Configs
if (file_exists($smtp_config_file)) {
    require_once $smtp_config_file;
}

$enabled = defined('SMTP_ENABLED') ? SMTP_ENABLED : false;
$host = defined('SMTP_HOST') ? SMTP_HOST : '127.0.0.1';
$port = defined('SMTP_PORT') ? SMTP_PORT : 1025;
$username = defined('SMTP_USER') ? SMTP_USER : '';
$password = defined('SMTP_PASS') ? SMTP_PASS : '';
$encryption = defined('SMTP_ENCRYPTION') ? SMTP_ENCRYPTION : 'none';
$from_email = defined('SMTP_FROM_EMAIL') ? SMTP_FROM_EMAIL : 'notifications@pbat-smartnation.ng';
$from_name = defined('SMTP_FROM_NAME') ? SMTP_FROM_NAME : 'PBAT Smart Nation';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Website Settings Panel - PBAT Smart Nation</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        bushgreen: {
                            DEFAULT: '#063C1E',
                            light: '#0A4D27',
                            dark: '#03200F',
                        },
                        gold: '#D4AF37'
                    }
                }
            }
        }
    </script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        [x-cloak] { display: none !important; }
        body { font-family: 'Inter', sans-serif; }
        h1, h2, h3, h4, .font-display { font-family: 'Outfit', sans-serif; }
    </style>
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
</head>
<body class="bg-slate-50 text-slate-800 transition-colors duration-200 min-h-screen flex flex-col antialiased"
      x-data="{ darkMode: localStorage.getItem('darkMode') === 'true', activeTab: 'general' }"
      x-init="$watch('darkMode', val => localStorage.setItem('darkMode', val))"
      :class="{ 'dark bg-slate-900 text-slate-100': darkMode }">

    <!-- Header Navbar -->
    <header class="bg-bushgreen text-white border-b-2 border-gold h-20 flex items-center justify-between px-6 shadow-md relative z-30">
        <div class="flex items-center gap-3">
            <a href="dashboard.php" class="py-1.5 px-3 border border-white/20 hover:bg-white/10 text-white rounded-lg text-xs font-bold transition">
                &larr; Back to Dashboard
            </a>
            <div class="w-8 h-8 rounded bg-white/10 flex items-center justify-center border border-white/20 p-1 flex-shrink-0">
                <?php echo getAppLogoHtml('w-full h-full object-contain', 'dashboard'); ?>
            </div>
            <span class="text-white font-extrabold text-sm font-display hidden sm:inline">PBAT SMART NATION INITIATIVE</span>
        </div>
        <div class="flex items-center gap-4 text-xs font-bold text-gold uppercase tracking-wider">
            <!-- Dark Mode Toggle -->
            <button @click="darkMode = !darkMode" class="p-2 rounded-lg border border-gold/45 text-gold hover:bg-gold/10 transition flex items-center justify-center">
                <svg x-show="darkMode" class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364-6.364l-.707.707M6.364 17.636l-.707.707M18.364 17.636l-.707-.707M6.364 6.364l-.707-.707M15 12a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                <svg x-show="!darkMode" class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z"/></svg>
            </button>
            <span>System Config Center</span>
        </div>
    </header>

    <main class="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-10 flex-grow w-full space-y-10">
        
        <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div class="space-y-1">
                <h1 class="text-2xl sm:text-3xl font-black text-bushgreen dark:text-gold font-display">System settings Panel</h1>
                <p class="text-slate-500 dark:text-slate-400 text-xs font-light">Branding properties, contact parameters, and custom SMTP configurations.</p>
            </div>
            
            <?php if (!empty($success)): ?>
                <div class="px-4 py-2 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs font-semibold">
                    <?php echo htmlspecialchars($success); ?>
                </div>
            <?php endif; ?>

            <?php if (!empty($error)): ?>
                <div class="px-4 py-2 bg-red-50 border border-red-200 text-red-800 rounded-xl text-xs font-semibold">
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>
        </div>

        <!-- Navigation Tabs -->
        <div class="flex gap-4 border-b border-slate-200 dark:border-slate-700 pb-2">
            <button @click="activeTab = 'general'" :class="activeTab === 'general' ? 'border-b-4 border-gold text-bushgreen dark:text-gold font-bold' : 'text-slate-400'" class="px-4 py-2 text-sm transition">General Website Settings</button>
            <button @click="activeTab = 'smtp'" :class="activeTab === 'smtp' ? 'border-b-4 border-gold text-bushgreen dark:text-gold font-bold' : 'text-slate-400'" class="px-4 py-2 text-sm transition">SMTP Gateway Config</button>
            <button @click="activeTab = 's3'" :class="activeTab === 's3' ? 'border-b-4 border-gold text-bushgreen dark:text-gold font-bold' : 'text-slate-400'" class="px-4 py-2 text-sm transition">Amazon S3 Storage Config</button>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            
            <!-- GENERAL SETTINGS TAB -->
            <div class="lg:col-span-8 bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6" x-show="activeTab === 'general'">
                <div class="pb-3 border-b border-slate-100 dark:border-slate-700">
                    <h3 class="text-slate-800 dark:text-slate-200 font-bold text-sm">Site Branding Details</h3>
                </div>

                <form method="POST" action="" enctype="multipart/form-data" class="space-y-6">
                    <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                    <input type="hidden" name="action" value="save_general">

                    <!-- Logo System Management Row -->
                    <div class="grid grid-cols-1 md:grid-cols-12 gap-6 p-5 bg-slate-50 dark:bg-slate-900/50 rounded-2xl border border-slate-100 dark:border-slate-750">
                        <div class="md:col-span-4 flex flex-col items-center justify-center text-center space-y-2 border-r border-slate-200/50 dark:border-slate-700/50 pr-4">
                            <span class="text-slate-400 text-[10px] font-bold uppercase tracking-wider block">Current Brand Logo</span>
                            <div class="w-24 h-24 bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 flex items-center justify-center p-3 shadow-inner overflow-hidden">
                                <?php if (!empty($settings['logo_url'])): ?>
                                    <img src="../<?php echo htmlspecialchars($settings['logo_url']); ?>" alt="App Logo" class="max-w-full max-h-full object-contain">
                                <?php else: ?>
                                    <div class="text-slate-300 dark:text-slate-650 text-center">
                                        <svg class="w-10 h-10 mx-auto mb-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
                                        <span class="text-[9px] uppercase tracking-wide font-bold">Default SVG</span>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <?php if (!empty($settings['logo_url'])): ?>
                                <button type="submit" name="reset_logo" value="true" class="py-1 px-3 bg-red-50 hover:bg-red-100 text-red-650 rounded-lg text-[10px] font-bold transition flex items-center gap-1">
                                    Reset Logo
                                </button>
                            <?php endif; ?>
                        </div>
                        <div class="md:col-span-8 space-y-4">
                            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                                <div>
                                    <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="site_name">Site Name *</label>
                                    <input type="text" name="site_name" required value="<?php echo htmlspecialchars($settings['site_name'] ?? 'PBAT Smart Nation Initiative'); ?>"
                                           class="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                                </div>
                                <div>
                                    <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="logo_url">Custom Logo URL / Path</label>
                                    <input type="text" name="logo_url" id="logo_url_input" value="<?php echo htmlspecialchars($settings['logo_url'] ?? ''); ?>" placeholder="uploads/logo_xxx.png"
                                           class="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-mono">
                                </div>
                                <div>
                                    <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="logo_size">Logo Height (px) *</label>
                                    <input type="number" name="logo_size" required min="20" max="200" value="<?php echo htmlspecialchars($settings['logo_size'] ?? '40'); ?>"
                                           class="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-mono">
                                </div>
                            </div>

                            <div>
                                <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1.5">Upload New Logo Image</label>
                                <div class="flex items-center justify-center w-full">
                                    <label class="flex flex-col items-center justify-center w-full h-24 border-2 border-slate-200 border-dashed rounded-xl cursor-pointer bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-750 transition duration-300 border-slate-200 dark:border-slate-700">
                                        <div class="flex flex-col items-center justify-center pt-3 pb-3">
                                            <svg class="w-6 h-6 mb-1 text-slate-400 dark:text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"/></svg>
                                            <p class="mb-1 text-[11px] text-slate-500 dark:text-slate-400"><span class="font-bold">Click to upload</span> logo image</p>
                                            <p class="text-[9px] text-slate-400 dark:text-slate-500 font-light">SVG, PNG, JPG, or WEBP (Max 2MB)</p>
                                        </div>
                                        <input type="file" name="logo_upload" accept="image/*" class="hidden" onchange="document.getElementById('logo_url_input').value = 'uploads/' + this.files[0].name;" />
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Footer Logo System Management Row -->
                    <div class="grid grid-cols-1 md:grid-cols-12 gap-6 p-5 bg-slate-50 dark:bg-slate-900/50 rounded-2xl border border-slate-100 dark:border-slate-750">
                        <div class="md:col-span-4 flex flex-col items-center justify-center text-center space-y-2 border-r border-slate-200/50 dark:border-slate-700/50 pr-4">
                            <span class="text-slate-400 text-[10px] font-bold uppercase tracking-wider block">Current Footer Logo</span>
                            <div class="w-24 h-24 bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 flex items-center justify-center p-3 shadow-inner overflow-hidden">
                                <?php if (!empty($settings['footer_logo_url'])): ?>
                                    <img src="../<?php echo htmlspecialchars($settings['footer_logo_url']); ?>" alt="Footer Logo" class="max-w-full max-h-full object-contain">
                                <?php else: ?>
                                    <div class="text-slate-300 dark:text-slate-650 text-center">
                                        <svg class="w-10 h-10 mx-auto mb-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
                                        <span class="text-[9px] uppercase tracking-wide font-bold">Default SVG</span>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <?php if (!empty($settings['footer_logo_url'])): ?>
                                <button type="submit" name="reset_footer_logo" value="true" class="py-1 px-3 bg-red-50 hover:bg-red-100 text-red-650 rounded-lg text-[10px] font-bold transition flex items-center gap-1">
                                    Reset Footer Logo
                                </button>
                            <?php endif; ?>
                        </div>
                        <div class="md:col-span-8 space-y-4">
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div>
                                    <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="footer_logo_url">Custom Footer Logo URL / Path</label>
                                    <input type="text" name="footer_logo_url" id="footer_logo_url_input" value="<?php echo htmlspecialchars($settings['footer_logo_url'] ?? ''); ?>" placeholder="uploads/footer_logo_xxx.png"
                                           class="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-mono">
                                </div>
                                <div>
                                    <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="footer_logo_size">Footer Logo Height (px) *</label>
                                    <input type="number" name="footer_logo_size" required min="10" max="150" value="<?php echo htmlspecialchars($settings['footer_logo_size'] ?? '32'); ?>"
                                           class="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-mono">
                                </div>
                            </div>

                            <div>
                                <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1.5">Upload New Footer Logo Image</label>
                                <div class="flex items-center justify-center w-full">
                                    <label class="flex flex-col items-center justify-center w-full h-24 border-2 border-slate-200 border-dashed rounded-xl cursor-pointer bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-750 transition duration-300 border-slate-200 dark:border-slate-700">
                                        <div class="flex flex-col items-center justify-center pt-3 pb-3">
                                            <svg class="w-6 h-6 mb-1 text-slate-400 dark:text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"/></svg>
                                            <p class="mb-1 text-[11px] text-slate-500 dark:text-slate-400"><span class="font-bold">Click to upload</span> footer logo</p>
                                            <p class="text-[9px] text-slate-400 dark:text-slate-500 font-light">SVG, PNG, JPG, or WEBP (Max 2MB)</p>
                                        </div>
                                        <input type="file" name="footer_logo_upload" accept="image/*" class="hidden" onchange="document.getElementById('footer_logo_url_input').value = 'uploads/' + this.files[0].name;" />
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="contact_email">Support Contact Email</label>
                            <input type="email" name="contact_email" value="<?php echo htmlspecialchars($settings['contact_email'] ?? 'info@pbat-smartnation.ng'); ?>"
                                   class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none font-mono">
                        </div>
                        <div>
                            <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="contact_phone">Support Contact Phone</label>
                            <input type="text" name="contact_phone" value="<?php echo htmlspecialchars($settings['contact_phone'] ?? '+2348030000001'); ?>"
                                   class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none font-mono">
                        </div>
                    </div>

                    <div>
                        <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="footer_copyright">Footer Copyright Info *</label>
                        <input type="text" name="footer_copyright" required value="<?php echo htmlspecialchars($settings['footer_copyright'] ?? '&copy; 2026 PBAT Smart Nation.'); ?>"
                               class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none">
                    </div>

                    <button type="submit" class="py-2.5 px-6 bg-bushgreen hover:bg-bushgreen-light text-white text-xs font-bold rounded-lg transition shadow-md">
                        Save General Settings
                    </button>
                </form>
            </div>

            <!-- SMTP SETTINGS TAB -->
            <div class="lg:col-span-12 grid grid-cols-1 lg:grid-cols-12 gap-8 items-start w-full" x-show="activeTab === 'smtp'">
                <form method="POST" action="" class="lg:col-span-7 bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
                    <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                    <input type="hidden" name="action" id="smtp_action" value="save_smtp">

                    <div class="flex justify-between items-center pb-4 border-b border-slate-100 dark:border-slate-700">
                        <div>
                            <h3 class="text-slate-800 dark:text-slate-200 font-bold text-sm">SMTP Gateway Credentials</h3>
                        </div>
                        <label class="relative inline-flex items-center cursor-pointer select-none">
                            <input type="checkbox" name="smtp_enabled" value="1" class="sr-only peer" <?php echo $enabled ? 'checked' : ''; ?>>
                            <div class="w-11 h-6 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-bushgreen"></div>
                            <span class="ml-2.5 text-xs font-semibold text-slate-700 dark:text-slate-300">Enable SMTP</span>
                        </label>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div class="md:col-span-2">
                            <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="smtp_host">SMTP Server Host *</label>
                            <input type="text" name="smtp_host" required value="<?php echo htmlspecialchars($host); ?>"
                                   class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none">
                        </div>
                        <div>
                            <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="smtp_port">SMTP Port *</label>
                            <input type="number" name="smtp_port" required value="<?php echo htmlspecialchars($port); ?>"
                                   class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none font-mono">
                        </div>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="smtp_user">SMTP Username</label>
                            <input type="text" name="smtp_user" value="<?php echo htmlspecialchars($username); ?>"
                                   class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none font-mono">
                        </div>
                        <div>
                            <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="smtp_pass">SMTP Password</label>
                            <input type="password" name="smtp_pass" value="<?php echo htmlspecialchars($password); ?>"
                                   class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none">
                        </div>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div>
                            <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="smtp_encryption">Encryption</label>
                            <select name="smtp_encryption" class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none">
                                <option value="none" <?php echo $encryption === 'none' ? 'selected' : ''; ?>>None</option>
                                <option value="tls" <?php echo $encryption === 'tls' ? 'selected' : ''; ?>>STARTTLS</option>
                                <option value="ssl" <?php echo $encryption === 'ssl' ? 'selected' : ''; ?>>SSL (465)</option>
                            </select>
                        </div>
                        <div>
                            <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="smtp_from_email">Sender Email *</label>
                            <input type="email" name="smtp_from_email" required value="<?php echo htmlspecialchars($from_email); ?>"
                                   class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none font-mono">
                        </div>
                        <div>
                            <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="smtp_from_name">Sender Label *</label>
                            <input type="text" name="smtp_from_name" required value="<?php echo htmlspecialchars($from_name); ?>"
                                   class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none">
                        </div>
                    </div>

                    <div class="pt-4 border-t border-slate-100 dark:border-slate-700 flex flex-col sm:flex-row gap-4">
                        <button type="submit" onclick="document.getElementById('smtp_action').value = 'save_smtp';" 
                                class="flex-grow py-2.5 bg-bushgreen hover:bg-bushgreen-light text-white text-xs font-bold rounded-lg transition shadow-md">
                            Save SMTP Credentials
                        </button>
                        
                        <button type="submit" onclick="document.getElementById('smtp_action').value = 'test_connection';" 
                                class="py-2.5 px-6 border border-slate-200 dark:border-slate-700 hover:border-gold hover:text-gold text-slate-700 dark:text-slate-300 text-xs font-bold rounded-lg transition">
                            Test SMTP Handshake
                        </button>
                    </div>
                </form>

                <!-- Handshake Diagnostic Logs -->
                <div class="lg:col-span-5 bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-4">
                    <h3 class="text-slate-800 dark:text-slate-200 font-bold text-sm">Diagnostic Handshake log</h3>
                    <div class="p-4 bg-slate-900 border border-slate-800 rounded-xl font-mono text-[10px] text-emerald-450 overflow-x-auto min-h-[220px] max-h-[300px]">
                        <?php if (!empty($test_log)): ?>
                            <pre class="whitespace-pre-wrap leading-relaxed"><?php echo htmlspecialchars($test_log); ?></pre>
                        <?php else: ?>
                            <div class="text-slate-500 italic text-center py-10">Run connection test to stream logs...</div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- S3 SETTINGS TAB -->
            <div class="lg:col-span-12 grid grid-cols-1 lg:grid-cols-12 gap-8 items-start w-full" x-show="activeTab === 's3'">
                <form method="POST" action="" class="lg:col-span-7 bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
                    <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                    <input type="hidden" name="action" value="save_s3">

                    <div class="flex justify-between items-center pb-4 border-b border-slate-100 dark:border-slate-700">
                        <div>
                            <h3 class="text-slate-800 dark:text-slate-200 font-bold text-sm">Amazon S3 Settings</h3>
                        </div>
                        <label class="relative inline-flex items-center cursor-pointer select-none">
                            <input type="checkbox" name="s3_enabled" value="1" class="sr-only peer" <?php echo ($settings['s3_enabled'] ?? '0') == '1' ? 'checked' : ''; ?>>
                            <div class="w-11 h-6 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-bushgreen"></div>
                            <span class="ml-2.5 text-xs font-semibold text-slate-700 dark:text-slate-300">Enable S3 Storage</span>
                        </label>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="s3_bucket">S3 Bucket Name *</label>
                            <input type="text" name="s3_bucket" value="<?php echo htmlspecialchars($settings['s3_bucket'] ?? ''); ?>"
                                   class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none">
                        </div>
                        <div>
                            <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="s3_region">S3 Region *</label>
                            <input type="text" name="s3_region" value="<?php echo htmlspecialchars($settings['s3_region'] ?? 'us-east-1'); ?>"
                                   class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none font-mono">
                        </div>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="s3_key">AWS Access Key ID *</label>
                            <input type="text" name="s3_key" value="<?php echo htmlspecialchars($settings['s3_key'] ?? ''); ?>"
                                   class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none font-mono">
                        </div>
                        <div>
                            <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="s3_secret">AWS Secret Access Key *</label>
                            <input type="password" name="s3_secret" value="<?php echo htmlspecialchars($settings['s3_secret'] ?? ''); ?>"
                                   class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none">
                        </div>
                    </div>

                    <div class="pt-4 border-t border-slate-100 dark:border-slate-700">
                        <button type="submit" class="w-full py-2.5 bg-bushgreen hover:bg-bushgreen-light text-white text-xs font-bold rounded-lg transition shadow-md">
                            Save S3 Configurations
                        </button>
                    </div>
                </form>
            </div>

        </div>

    </main>
</body>
</html>
