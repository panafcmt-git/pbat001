<?php
/**
 * PBAT Smart Nation Initiative - System Update Center
 * Allows Super Admin to upload system update ZIP archives, perform file backups,
 * overwrite system files, and run database schema updates.
 */
require_once dirname(__DIR__) . '/helpers/auth.php';
require_once dirname(__DIR__) . '/helpers/common.php';
require_once dirname(__DIR__) . '/config/database.php';

Auth::requireRole(['super_admin'], '../login.php');

$user = Auth::user();
$error = '';
$success = '';
$update_logs = [];

// Storage & Directory checks
$root_dir = dirname(__DIR__);
$is_writable = is_writable($root_dir);
$zip_enabled = class_exists('ZipArchive');

$protected_update_paths = [
    'config/',
    'database/',
    'backups/',
    'uploads/',
    'temp_extract/',
    'temp_verify/',
    'temp_zip_dir/',
];

function isProtectedUpdatePath(string $path): bool {
    global $protected_update_paths;

    $normalized = str_replace('\\', '/', ltrim($path, './'));
    foreach ($protected_update_paths as $protected) {
        if ($normalized === $protected || strpos($normalized, $protected) === 0) {
            return true;
        }
    }

    return false;
}

function isSafeMigrationFile(string $path): bool {
    $normalized = str_replace('\\', '/', ltrim($path, './'));

    return $normalized === 'update.sql'
        || $normalized === 'migrate.php'
        || strpos($normalized, 'database/') === 0;
}

// Get current system version
$current_version = '1.0.0';
try {
    $db = Database::connect();
    $stmt = $db->prepare("SELECT `setting_value` FROM `system_settings` WHERE `setting_key` = 'system_version' LIMIT 1");
    $stmt->execute();
    $db_version = $stmt->fetchColumn();
    if ($db_version) {
        $current_version = $db_version;
    }
} catch (Exception $e) {
    $error = "Database warning: " . $e->getMessage();
}

// Handle Revert to Backup
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'revert_backup') {
    if (!Auth::validateCsrf($_POST['csrf_token'] ?? '')) {
        $error = "CSRF Token validation failed.";
        $update_logs[] = "[ERROR] CSRF Token verification failed.";
    } elseif (!$is_writable) {
        $error = "The application root directory is not writable.";
        $update_logs[] = "[ERROR] Root folder permissions are too strict. Write access denied.";
    } else {
        $backup_folder = trim($_POST['backup_folder'] ?? '');
        // Validate folder name to prevent directory traversal
        if (empty($backup_folder) || !preg_match('/^backup_[a-zA-Z0-9_]+$/', $backup_folder)) {
            $error = "Invalid backup folder name.";
            $update_logs[] = "[ERROR] Invalid backup folder target.";
        } else {
            $backup_src = $root_dir . '/backups/' . $backup_folder;
            if (!is_dir($backup_src)) {
                $error = "The selected backup directory does not exist.";
                $update_logs[] = "[ERROR] Backup directory not found.";
            } else {
                $update_logs[] = "[INFO] Initiating system rollback to: '{$backup_folder}'...";
                
                // Recursive helper to restore files
                $restore_fn = function ($src, $dst) use (&$restore_fn, &$update_logs) {
                    $dir = opendir($src);
                    @mkdir($dst);
                    while (false !== ($file = readdir($dir))) {
                        if (($file != '.') && ($file != '..')) {
                            if (is_dir($src . '/' . $file)) {
                                $restore_fn($src . '/' . $file, $dst . '/' . $file);
                            } else {
                                if (copy($src . '/' . $file, $dst . '/' . $file)) {
                                    $update_logs[] = "[RESTORE] Restored file: " . str_replace(dirname(dirname(__DIR__)), '', $dst . '/' . $file);
                                }
                            }
                        }
                    }
                    closedir($dir);
                };
                
                try {
                    $restore_fn($backup_src, $root_dir);
                    $update_logs[] = "[SUCCESS] System rollback completed successfully.";
                    Auth::logAction($user['id'], 'SYSTEM_REVERT_BACKUP', "Reverted system files to backup: {$backup_folder}");
                    $success = "System successfully reverted to backup: " . htmlspecialchars($backup_folder);
                } catch (Exception $ex) {
                    $error = "Rollback failed: " . $ex->getMessage();
                    $update_logs[] = "[ERROR] Rollback process encountered an error: " . $ex->getMessage();
                }
            }
        }
    }
}

// Handle Update Package Upload
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'run_update') {
    if (!Auth::validateCsrf($_POST['csrf_token'] ?? '')) {
        $error = "CSRF Token validation failed.";
        $update_logs[] = "[ERROR] CSRF Token verification failed.";
    } elseif (!$zip_enabled) {
        $error = "ZipArchive PHP extension is not enabled on this server.";
        $update_logs[] = "[ERROR] ZipArchive PHP extension is missing. Cannot extract updates.";
    } elseif (!$is_writable) {
        $error = "The application root directory is not writable.";
        $update_logs[] = "[ERROR] Root folder permissions are too strict. Write access denied.";
    } elseif (!isset($_FILES['update_package']) || $_FILES['update_package']['error'] !== UPLOAD_ERR_OK) {
        $upload_err = $_FILES['update_package']['error'] ?? UPLOAD_ERR_NO_FILE;
        $error = "Failed to upload file package. Error code: " . $upload_err;
        $update_logs[] = "[ERROR] Update package file upload failed (Code: {$upload_err}).";
    } else {
        $file = $_FILES['update_package'];
        $file_name = basename($file['name']);
        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
        
        if ($file_ext !== 'zip') {
            $error = "Invalid package file extension. Only .zip updates are supported.";
            $update_logs[] = "[ERROR] Invalid package format. Expected ZIP archive, got '.{$file_ext}'.";
        } else {
            $uploaded_zip = $file['tmp_name'];
            $update_logs[] = "[INFO] Starting system update with package: '{$file_name}' (" . round($file['size'] / 1024, 1) . " KB)";
            
            $zip = new ZipArchive();
            if ($zip->open($uploaded_zip) !== true) {
                $error = "Failed to open ZIP archive.";
                $update_logs[] = "[ERROR] ZIP archive is corrupt or could not be opened.";
            } else {
                // 1. Look for manifest file
                $manifest_index = $zip->locateName('manifest.json');
                $update_json_index = $zip->locateName('update.json');
                $manifest_name = ($manifest_index !== false) ? 'manifest.json' : (($update_json_index !== false) ? 'update.json' : '');
                
                $manifest = null;
                if ($manifest_name) {
                    $manifest_content = $zip->getFromName($manifest_name);
                    $manifest = json_decode($manifest_content, true);
                }
                
                if (!$manifest) {
                    $update_logs[] = "[WARNING] No manifest.json or update.json manifest found in zip. Proceeding with basic extraction.";
                    $new_version = '1.0.0_patched_' . time();
                    $update_desc = 'Manual ZIP code patch';
                } else {
                    $new_version = $manifest['version'] ?? '1.0.0_patched';
                    $update_desc = $manifest['description'] ?? 'System patch update';
                    $update_logs[] = "[INFO] Manifest verified. Update Package Version: {$new_version} ({$update_desc})";
                }
                
                // 2. Create selective file backup of files about to be overwritten
                $backup_folder_name = 'backup_' . date('Ymd_His');
                $backup_path = $root_dir . '/backups/' . $backup_folder_name . '/';
                $update_logs[] = "[INFO] Creating selective file backup of files to be updated in 'backups/{$backup_folder_name}'...";
                
                $backup_count = 0;
                if (!is_dir($backup_path)) {
                    mkdir($backup_path, 0755, true);
                }
                
                for ($i = 0; $i < $zip->numFiles; $i++) {
                    $filename = $zip->getNameIndex($i);
                    // Skip folders/directories
                    if (substr($filename, -1) === '/') {
                        continue;
                    }
                    
                    // Do not backup manifest.json or update.json, and never touch protected directories.
                    if ($filename === 'manifest.json' || $filename === 'update.json' || isProtectedUpdatePath($filename)) {
                        continue;
                    }
                    
                    $target_file = $root_dir . '/' . $filename;
                    if (file_exists($target_file)) {
                        $backup_file_path = $backup_path . $filename;
                        $backup_file_dir = dirname($backup_file_path);
                        if (!is_dir($backup_file_dir)) {
                            mkdir($backup_file_dir, 0755, true);
                        }
                        if (copy($target_file, $backup_file_path)) {
                            $backup_count++;
                        }
                    }
                }
                $update_logs[] = "[SUCCESS] Backup finished. Protected {$backup_count} existing files before overwriting.";
                
                // 3. Extract only safe, frontend/code files to root. Protected database/config folders are skipped.
                $extract_files = [];
                for ($i = 0; $i < $zip->numFiles; $i++) {
                    $entry = $zip->getNameIndex($i);
                    if (substr($entry, -1) === '/') {
                        continue;
                    }

                    if ($entry === 'manifest.json' || $entry === 'update.json' || isProtectedUpdatePath($entry)) {
                        if (isProtectedUpdatePath($entry)) {
                            $update_logs[] = "[SKIP] Protected path omitted from update: {$entry}";
                        }
                        continue;
                    }

                    $extract_files[] = $entry;
                }

                $update_logs[] = "[INFO] Extracting " . count($extract_files) . " safe update files to the application root...";
                $extract_status = !empty($extract_files) ? $zip->extractTo($root_dir, $extract_files) : true;
                $zip->close();
                
                if (!$extract_status) {
                    $error = "Failed to extract package files. Check directory permissions.";
                    $update_logs[] = "[ERROR] Extraction failed. Some system files could not be overwritten.";
                } else {
                    $update_logs[] = "[SUCCESS] Extracted update files successfully.";
                    
                    // 4. Run database migrations if present
                    // Try looking for manifest settings or convention files
                    $sql_file = $manifest['migration_sql'] ?? 'update.sql';
                    $php_file = $manifest['migration_php'] ?? 'migrate.php';

                    $safe_sql = isSafeMigrationFile($sql_file);
                    $safe_php = isSafeMigrationFile($php_file);
                    
                    $full_sql_path = $root_dir . '/' . $sql_file;
                    $full_php_path = $root_dir . '/' . $php_file;
                    
                    // Run SQL commands only when the manifest points to safe, non-destructive migration files.
                    if ($safe_sql && file_exists($full_sql_path)) {
                        $update_logs[] = "[INFO] Found safe database schema migration file: '{$sql_file}'. Running SQL queries...";
                        try {
                            $sql_queries = file_get_contents($full_sql_path);
                            // Run multi queries using PDO
                            if (!empty(trim($sql_queries))) {
                                $db->exec($sql_queries);
                                $update_logs[] = "[SUCCESS] Database schema aligned successfully.";
                            }
                            // Clean up update.sql
                            @unlink($full_sql_path);
                            $update_logs[] = "[INFO] Deleted SQL migration file '{$sql_file}' from root folder.";
                        } catch (Exception $e) {
                            $update_logs[] = "[ERROR] SQL migration failed: " . $e->getMessage();
                        }
                    }
                    
                    // Run PHP migrations only when the manifest points to a safe migration file.
                    if ($safe_php && file_exists($full_php_path)) {
                        $update_logs[] = "[INFO] Found safe PHP migration execution script: '{$php_file}'. Running PHP code...";
                        try {
                            include $full_php_path;
                            $update_logs[] = "[SUCCESS] PHP migration script executed successfully.";
                            // Clean up migrate.php
                            @unlink($full_php_path);
                            $update_logs[] = "[INFO] Deleted PHP migration file '{$php_file}' from root folder.";
                        } catch (Exception $e) {
                            $update_logs[] = "[ERROR] PHP migration script failed: " . $e->getMessage();
                        }
                    }
                    
                    // 5. Update settings table
                    try {
                        $stmt = $db->prepare("INSERT INTO `system_settings` (`setting_key`, `setting_value`) VALUES ('system_version', ?) ON DUPLICATE KEY UPDATE `setting_value` = ?");
                        $stmt->execute([$new_version, $new_version]);
                        $current_version = $new_version;
                        $update_logs[] = "[INFO] Updated system version key in database to version: '{$new_version}'.";
                        
                        Auth::logAction($user['id'], 'SYSTEM_UPGRADE_SUCCESS', "Upgraded system to version {$new_version} via ZIP uploader.");
                    } catch (Exception $e) {
                        $update_logs[] = "[WARNING] Failed to update system version in settings table: " . $e->getMessage();
                    }
                    
                    $success = "System upgraded to version {$new_version} successfully!";
                    $update_logs[] = "[SUCCESS] System upgrade finished. Ready to accept traffic.";
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>System Update Center - PBAT Smart Nation</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        bushgreen: {
                            DEFAULT: '#063C1E',
                            light: '#0A4D27',
                            dark: '#03200F',
                        },
                        gold: '#D4AF37'
                    }
                }
            }
        }
    </script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Outfit', sans-serif; }
    </style>
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
</head>
<body class="bg-slate-50 min-h-screen flex flex-col antialiased">

    <!-- Header Navbar -->
    <header class="bg-bushgreen text-white border-b-2 border-gold h-20 flex items-center justify-between px-6 shadow-md relative z-30">
        <div class="flex items-center gap-3">
            <a href="maintenance.php" class="py-1.5 px-3 border border-white/20 hover:bg-white/10 text-white rounded-lg text-xs font-bold transition">
                &larr; Back to Diagnostics
            </a>
            <div class="w-8 h-8 rounded bg-white/10 flex items-center justify-center border border-white/20 p-1 flex-shrink-0">
                <?php echo getAppLogoHtml('w-full h-full object-contain', 'dashboard'); ?>
            </div>
            <span class="text-white font-extrabold text-sm font-display hidden sm:inline">PBAT SMART NATION INITIATIVE</span>
        </div>
        <div class="flex items-center gap-3 text-xs font-bold text-gold uppercase tracking-wider">
            System Upgrade Tool
        </div>
    </header>

    <main class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-10 flex-grow w-full space-y-8" x-data="{ uploading: false }">
        
        <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div class="space-y-1">
                <h1 class="text-2xl sm:text-3xl font-black text-bushgreen font-display">System Update Center</h1>
                <p class="text-slate-500 text-xs font-light">Industry-standard ZIP package manager. Upload updates, back up replaced source code, and run SQL migrations.</p>
            </div>
            <div class="flex items-center gap-3 bg-white border border-slate-200 px-4 py-2 rounded-xl shadow-sm text-xs font-semibold text-slate-700">
                <span>Current Version:</span>
                <span class="px-2.5 py-1 bg-bushgreen text-white rounded-lg font-mono font-bold"><?php echo htmlspecialchars($current_version); ?></span>
            </div>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            
            <!-- PACKAGE UPLOADER FORM (Col 7) -->
            <div class="lg:col-span-7 space-y-6">
                
                <!-- Server Diagnostics Panel -->
                <div class="bg-white rounded-2xl border border-slate-100 p-6 shadow-sm space-y-4">
                    <span class="text-xs font-bold text-bushgreen block uppercase tracking-wider">Update Pre-Checks & Specs</span>
                    
                    <div class="grid grid-cols-2 md:grid-cols-3 gap-3 text-xs">
                        <div class="p-3 bg-slate-50 border rounded-xl <?php echo $zip_enabled ? 'border-emerald-100 text-emerald-800 bg-emerald-50/20' : 'border-red-100 text-red-800 bg-red-50/20'; ?>">
                            <span class="block text-[10px] text-slate-400 font-bold uppercase tracking-wider mb-1">PHP Zip Extension</span>
                            <span class="font-bold"><?php echo $zip_enabled ? 'Available' : 'Missing'; ?></span>
                        </div>
                        <div class="p-3 bg-slate-50 border rounded-xl <?php echo $is_writable ? 'border-emerald-100 text-emerald-800 bg-emerald-50/20' : 'border-red-100 text-red-800 bg-red-50/20'; ?>">
                            <span class="block text-[10px] text-slate-400 font-bold uppercase tracking-wider mb-1">Root Write Status</span>
                            <span class="font-bold"><?php echo $is_writable ? 'Writable' : 'Locked'; ?></span>
                        </div>
                        <div class="p-3 bg-slate-50 border border-slate-100 rounded-xl">
                            <span class="block text-[10px] text-slate-400 font-bold uppercase tracking-wider mb-1">Upload Max Size</span>
                            <span class="font-bold text-slate-800"><?php echo ini_get('upload_max_filesize'); ?></span>
                        </div>
                    </div>
                </div>

                <!-- ZIP Upload Form -->
                <div class="bg-white rounded-2xl border border-slate-100 p-6 shadow-sm">
                    <form method="POST" action="" enctype="multipart/form-data" class="space-y-6" @submit="uploading = true">
                        <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                        <input type="hidden" name="action" value="run_update">

                        <div class="space-y-2">
                            <label class="block text-slate-700 font-bold text-sm">Upload ZIP Update Package</label>
                            <p class="text-[10px] text-slate-400 leading-normal">
                                Select the ZIP update file. The file must contain a `manifest.json` file inside the root of the archive to be verified. The updater now skips protected `config/`, `database/`, `backups/`, and upload folders, so database files are not overwritten by the ZIP.
                            </p>
                        </div>

                        <!-- Drag and Drop Mock Interface -->
                        <div class="flex items-center justify-center w-full">
                            <label class="flex flex-col items-center justify-center w-full h-36 border-2 border-slate-200 border-dashed rounded-xl cursor-pointer bg-slate-50 hover:bg-slate-100/70 border-slate-200 transition">
                                <div class="flex flex-col items-center justify-center pt-5 pb-6 text-center px-4">
                                    <svg class="w-8 h-8 mb-2 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"/></svg>
                                    <p class="mb-1 text-xs text-slate-500"><span class="font-bold">Click to select update package</span></p>
                                    <p class="text-[10px] text-slate-400 font-light">Only ZIP file archives are accepted (Max size: <?php echo ini_get('upload_max_filesize'); ?>)</p>
                                </div>
                                <input type="file" name="update_package" accept=".zip" class="hidden" required onchange="document.getElementById('selected_file_label').innerText = 'Selected: ' + this.files[0].name;" />
                            </label>
                        </div>
                        <div id="selected_file_label" class="text-xs text-bushgreen font-mono font-semibold text-center italic"></div>

                        <!-- Upgrade Warnings Alert -->
                        <div class="p-3.5 bg-amber-50 border-l-4 border-amber-500 text-amber-800 rounded-r-xl text-xs space-y-1">
                            <span class="font-bold block uppercase tracking-wider">Warning & Safety Notice</span>
                            <span class="font-light leading-normal block">This update path is restricted to frontend/code files and safe migrations only. Protected directories such as `config/`, `database/`, `backups/`, and `uploads/` are not overwritten, and your existing database content is not replaced by the ZIP itself.</span>
                        </div>

                        <!-- Submit Button / Loader -->
                        <div class="flex justify-end pt-4 border-t border-slate-100">
                            <button type="submit" :disabled="uploading" class="py-2.5 px-6 bg-bushgreen hover:bg-emerald-800 text-white text-xs font-bold rounded-lg transition shadow-md flex items-center gap-2">
                                <span x-show="!uploading">Process System Update</span>
                                <span x-show="uploading" class="flex items-center gap-2">
                                    <svg class="animate-spin h-4 w-4 text-white" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>
                                    Uploading & Processing Update...
                                </span>
                            </button>
                        </div>
                    </form>
                </div>

                <!-- Revert to Past Update / Backup Form -->
                <div class="bg-white rounded-2xl border border-slate-100 p-6 shadow-sm mt-6">
                    <form method="POST" action="" class="space-y-4">
                        <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                        <input type="hidden" name="action" value="revert_backup">

                        <div class="space-y-1">
                            <label class="block text-slate-700 font-bold text-sm">Revert to Previous Version</label>
                            <p class="text-[10px] text-slate-400 leading-normal">
                                Select a backup restore point from the dropdown below to revert the code changes of a recent update.
                            </p>
                        </div>

                        <div>
                            <label class="block text-slate-600 text-xs font-semibold mb-1" for="backup_folder">Select Past Restore Point *</label>
                            <select name="backup_folder" id="backup_folder" required class="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                                <option value="">-- Choose Backup Restore Point --</option>
                                <?php 
                                $backups_dir = $root_dir . '/backups';
                                $past_backups = [];
                                if (is_dir($backups_dir)) {
                                    $dirs = scandir($backups_dir);
                                    foreach ($dirs as $dir) {
                                        if ($dir !== '.' && $dir !== '..' && is_dir($backups_dir . '/' . $dir) && (strpos($dir, 'backup_') === 0)) {
                                            $past_backups[] = $dir;
                                        }
                                    }
                                    rsort($past_backups);
                                }
                                ?>
                                <?php if (empty($past_backups)): ?>
                                    <option value="" disabled>No past backups found</option>
                                <?php else: ?>
                                    <?php foreach ($past_backups as $bk): ?>
                                        <option value="<?php echo htmlspecialchars($bk); ?>">
                                            <?php 
                                            // Format folder name for readability e.g., backup_20260606_135203 -> 2026-06-06 13:52:03
                                            $formatted_name = $bk;
                                            if (preg_match('/backup_(?:test_)?(\d{4})(\d{2})(\d{2})_(\d{2})(\d{2})(\d{2})/', $bk, $matches)) {
                                                $formatted_name = "Backup created on {$matches[1]}-{$matches[2]}-{$matches[3]} @ {$matches[4]}:{$matches[5]}:{$matches[6]}";
                                            }
                                            echo htmlspecialchars($formatted_name . " (" . $bk . ")"); 
                                            ?>
                                        </option>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </select>
                        </div>

                        <div class="flex justify-end pt-2 border-t border-slate-100">
                            <button type="submit" class="py-2.5 px-6 bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold rounded-lg transition shadow-md" onclick="return confirm('Are you sure you want to rollback the application files to the selected backup point?');">
                                Rollback System Files
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- DIAGNOSTIC CONSOLE & DETAILS (Col 5) -->
            <div class="lg:col-span-5 space-y-6">
                
                <!-- Status Notifications -->
                <?php if (!empty($success)): ?>
                    <div class="p-4 bg-emerald-50 border-l-4 border-emerald-500 rounded-r-2xl text-emerald-800 flex items-start gap-2.5 shadow-sm">
                        <svg class="w-5 h-5 text-emerald-500 mt-0.5 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/></svg>
                        <div class="space-y-0.5">
                            <span class="text-xs font-bold block">Upgrade Successful!</span>
                            <span class="text-[11px] leading-relaxed font-light block"><?php echo htmlspecialchars($success); ?></span>
                        </div>
                    </div>
                <?php endif; ?>
                <?php if (!empty($error)): ?>
                    <div class="p-4 bg-red-50 border-l-4 border-red-500 rounded-r-2xl text-red-800 flex items-start gap-2.5 shadow-sm">
                        <svg class="w-5 h-5 text-red-500 mt-0.5 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clip-rule="evenodd"/></svg>
                        <div class="space-y-0.5">
                            <span class="text-xs font-bold block">Upgrade Failed</span>
                            <span class="text-[11px] leading-relaxed font-light block"><?php echo htmlspecialchars($error); ?></span>
                        </div>
                    </div>
                <?php endif; ?>

                <!-- Log Console Box -->
                <div class="bg-slate-900 border border-slate-950 rounded-2xl p-5 shadow-lg space-y-4">
                    <div class="flex justify-between items-center border-b border-slate-800 pb-2">
                        <span class="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Update Console Logs</span>
                        <span class="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
                    </div>

                    <div class="h-80 overflow-y-auto text-[11px] font-mono text-slate-300 space-y-1.5 leading-normal pr-2">
                        <?php if (empty($update_logs)): ?>
                            <div class="text-slate-500 italic">Console idle. Upload a ZIP package to see live logs output...</div>
                        <?php else: ?>
                            <?php foreach ($update_logs as $log): ?>
                                <?php 
                                $color_class = 'text-slate-300';
                                if (strpos($log, '[ERROR]') !== false) {
                                    $color_class = 'text-red-400 font-bold';
                                } elseif (strpos($log, '[SUCCESS]') !== false) {
                                    $color_class = 'text-emerald-400 font-bold';
                                } elseif (strpos($log, '[WARNING]') !== false) {
                                    $color_class = 'text-amber-400';
                                }
                                ?>
                                <div class="<?php echo $color_class; ?>"><?php echo htmlspecialchars($log); ?></div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Package Manifest Example Info Card -->
                <div class="bg-white rounded-2xl border border-slate-100 p-6 shadow-sm space-y-3">
                    <span class="text-xs font-bold text-slate-800 block">Required Package Structure</span>
                    <p class="text-[10px] text-slate-500 leading-normal">
                        ZIP packages should include a manifest file in the root containing details like this:
                    </p>
                    <pre class="bg-slate-950 text-slate-300 p-3 rounded-xl text-[9px] font-mono leading-relaxed overflow-x-auto">
{
  "version": "1.1.0",
  "description": "Fix bug and align database",
  "migration_sql": "update.sql",
  "migration_php": "migrate.php"
}</pre>
                </div>

            </div>

        </div>

    </main>
</body>
</html>
