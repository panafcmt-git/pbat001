<?php
/**
 * Admin Overall Control Dashboard (Role 1)
 * Full operational control, database diagnostics, user directories, and system security.
 */
if (!defined('DB_HOST')) {
    exit('Access Denied');
}
?>
<!-- Admin Content -->
<div class="space-y-8">
    <div class="bg-gradient-to-r from-bushgreen to-bushgreen-light text-white p-8 rounded-3xl shadow-xl relative overflow-hidden border border-gold/30">
        <div class="absolute inset-0 bg-cover bg-center mix-blend-overlay opacity-10 bg-[url('https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=600&q=80')]"></div>
        <div class="relative z-10 space-y-3">
            <span class="px-2.5 py-1 bg-gold/20 text-gold rounded-full text-[9px] font-bold uppercase tracking-widest leading-none font-display">System Administrator</span>
            <h2 class="text-2xl sm:text-3xl font-black font-display leading-tight text-white">Overall Control Command</h2>
            <p class="text-slate-300 text-xs font-light max-w-xl">
                Configure global settings, provision and authorize role assignments, and supervise operations logs.
            </p>
        </div>
    </div>

    <!-- Analytics grid -->
    <div class="grid grid-cols-1 sm:grid-cols-4 gap-6">
        <div class="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm flex items-center justify-between">
            <div class="space-y-1">
                <span class="text-slate-400 text-[10px] font-bold uppercase tracking-wider block">Total Members</span>
                <div class="text-3xl font-black text-bushgreen font-display"><?php echo number_format($total_ambassadors); ?></div>
                <span class="text-[9px] text-slate-400 font-light block">Verified nationwide</span>
            </div>
            <div class="w-12 h-12 rounded-xl bg-bushgreen/5 flex items-center justify-center text-bushgreen"><svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"/></svg></div>
        </div>
        <div class="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm flex items-center justify-between">
            <div class="space-y-1">
                <span class="text-slate-400 text-[10px] font-bold uppercase tracking-wider block">Town Halls & Conferences</span>
                <div class="text-3xl font-black text-bushgreen font-display"><?php echo $total_events; ?></div>
                <span class="text-[9px] text-slate-400 font-light block">Dispatched dates</span>
            </div>
            <div class="w-12 h-12 rounded-xl bg-bushgreen/5 flex items-center justify-center text-bushgreen"><svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2-2v12a2 2 0 002 2z"/></svg></div>
        </div>
        <div class="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm flex items-center justify-between">
            <div class="space-y-1">
                <span class="text-slate-400 text-[10px] font-bold uppercase tracking-wider block">Field briefings</span>
                <div class="text-3xl font-black text-bushgreen font-display"><?php echo $total_reports; ?></div>
                <span class="text-[9px] text-slate-400 font-light block">LGA briefs catalogued</span>
            </div>
            <div class="w-12 h-12 rounded-xl bg-bushgreen/5 flex items-center justify-center text-bushgreen"><svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg></div>
        </div>
        <div class="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm flex items-center justify-between">
            <div class="space-y-1">
                <span class="text-slate-400 text-[10px] font-bold uppercase tracking-wider block">National score</span>
                <div class="text-3xl font-black text-bushgreen font-display"><?php echo number_format($total_ambassadors * 25); ?></div>
                <span class="text-[9px] text-emerald-600 font-bold bg-emerald-50 px-2 py-0.5 rounded">High Reach</span>
            </div>
            <div class="w-12 h-12 rounded-xl bg-bushgreen/5 flex items-center justify-center text-bushgreen"><svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg></div>
        </div>
    </div>

    <!-- Administrative lists and tools -->
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        <!-- Graph Left -->
        <div class="lg:col-span-2 bg-white rounded-3xl border border-slate-100 p-6 shadow-sm space-y-6">
            <div class="flex justify-between items-center border-b border-slate-100 pb-4">
                <h3 class="text-slate-800 font-bold text-sm font-display">System Access Log Metrics</h3>
                <span class="text-[9px] bg-bushgreen text-white font-bold px-2 py-0.5 rounded">Admin Command</span>
            </div>
            <div class="h-64 relative">
                <canvas id="stateAdvocacyChart"></canvas>
            </div>
        </div>

        <!-- Quick actions -->
        <div class="bg-white rounded-3xl border border-slate-100 p-6 shadow-sm space-y-4">
            <h3 class="text-slate-800 font-bold text-sm font-display border-b border-slate-100 pb-3">Admin Quick Keys</h3>
            
            <div class="space-y-3">
                <a href="users.php" class="block p-3 rounded-xl border border-slate-100 hover:border-gold/30 hover:bg-slate-50 transition flex items-center justify-between text-xs">
                    <span class="font-bold text-slate-700">Appoint & Manage Coordinators</span>
                    <svg class="w-4 h-4 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/></svg>
                </a>
                <a href="blog.php" class="block p-3 rounded-xl border border-slate-100 hover:border-gold/30 hover:bg-slate-50 transition flex items-center justify-between text-xs">
                    <span class="font-bold text-slate-700">News, Updates & Policy Drafts</span>
                    <svg class="w-4 h-4 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/></svg>
                </a>
                <a href="maintenance.php" class="block p-3 rounded-xl border border-slate-100 hover:border-gold/30 hover:bg-slate-50 transition flex items-center justify-between text-xs">
                    <span class="font-bold text-slate-700">System Maintenance & Diagnostics</span>
                    <svg class="w-4 h-4 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/></svg>
                </a>
                <a href="audit-logs.php" class="block p-3 rounded-xl border border-slate-100 hover:border-gold/30 hover:bg-slate-50 transition flex items-center justify-between text-xs">
                    <span class="font-bold text-slate-700">Browse Operations Log Ledger</span>
                    <svg class="w-4 h-4 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/></svg>
                </a>
                <a href="events.php" class="block p-3 rounded-xl border border-slate-100 hover:border-gold/30 hover:bg-slate-50 transition flex items-center justify-between text-xs">
                    <span class="font-bold text-slate-700">Upcoming Town Halls & Conferences</span>
                    <svg class="w-4 h-4 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/></svg>
                </a>
                <a href="tv.php" class="block p-3 rounded-xl border border-slate-100 hover:border-gold/30 hover:bg-slate-50 transition flex items-center justify-between text-xs">
                    <span class="font-bold text-slate-700">Scheduled TV Broadcasts & Episodes</span>
                    <svg class="w-4 h-4 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/></svg>
                </a>
            </div>
        </div>

    </div>
</div>
