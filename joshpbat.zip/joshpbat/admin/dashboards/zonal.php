<?php
/**
 * Zonal Chairman Dashboard (Role 4)
 * Regional Command Center for Smart Nation Expansion.
 */
if (!defined('DB_HOST')) {
    exit('Access Denied');
}

$active_tab = $_GET['tab'] ?? 'overview';
$user = Auth::user();
$user_id = $user['id'];

// Resolve active zone coordinate of the Zonal Chairman
try {
    $db = Database::connect();
    
    $stmt = $db->prepare("SELECT s.zone FROM `user_leadership` ul JOIN `states` s ON ul.state_id = s.id WHERE ul.user_id = ? LIMIT 1");
    $stmt->execute([$user_id]);
    $user_zone = $stmt->fetchColumn();
    if (!$user_zone) {
        $stmt = $db->prepare("SELECT `zone` FROM `user_leadership` WHERE `user_id` = ? LIMIT 1");
        $stmt->execute([$user_id]);
        $user_zone = $stmt->fetchColumn() ?: 'South-West'; // fallback
    }
    
    // Fetch states belonging to this zone
    $stmt_states = $db->prepare("SELECT * FROM `states` WHERE `zone` = ? ORDER BY name ASC");
    $stmt_states->execute([$user_zone]);
    $zone_states = $stmt_states->fetchAll();
    
    $zone_state_ids = array_column($zone_states, 'id');
    $state_ids_placeholder = !empty($zone_state_ids) ? implode(',', $zone_state_ids) : '0';

    // Fetch reports filed in this zone
    $reports = $db->query("
        SELECT r.*, u.name as author_name, s.name as state_name, s.zone as zone_name 
        FROM `reports` r 
        JOIN `users` u ON r.user_id = u.id 
        JOIN `states` s ON r.state_id = s.id 
        WHERE r.state_id IN ({$state_ids_placeholder})
        ORDER BY r.created_at DESC
    ")->fetchAll();

    // Fetch campaigns created by Zonal Chairman or assigned to leaders in the zone
    $campaigns = $db->prepare("
        SELECT c.*, u.name as leader_name, creator.name as creator_name 
        FROM `campaigns` c 
        LEFT JOIN `users` u ON c.leader_id = u.id 
        JOIN `users` creator ON c.created_by = creator.id 
        WHERE c.created_by = ? OR u.id IN (
            SELECT user_id FROM `user_leadership` WHERE state_id IN ({$state_ids_placeholder})
        )
        ORDER BY c.created_at DESC
    ");
    $campaigns->execute([$user_id]);
    $zonal_campaigns = $campaigns->fetchAll();

    // Fetch ambassadors roster in the zone
    $ambassadors = $db->query("
        SELECT a.*, u.name, u.email, u.status, s.name as state_name 
        FROM `ambassadors` a 
        JOIN `users` u ON a.user_id = u.id 
        JOIN `states` s ON a.state_id = s.id 
        WHERE a.state_id IN ({$state_ids_placeholder})
        ORDER BY a.impact_score DESC
    ")->fetchAll();

    // Fetch State Chairmen & Coordinators inside the zone
    $zonal_leaders = $db->query("
        SELECT u.id, u.name, u.email, u.status, r.display_name as role_name, s.name as state_name
        FROM `user_leadership` ul 
        JOIN `users` u ON ul.user_id = u.id 
        JOIN `roles` r ON u.role_id = r.id 
        JOIN `states` s ON ul.state_id = s.id
        WHERE ul.state_id IN ({$state_ids_placeholder})
        ORDER BY r.id ASC, u.name ASC
    ")->fetchAll();

    // Fetch events scheduled in the zone
    $zonal_events = $db->query("
        SELECT e.*, u.name as creator_name 
        FROM `events` e 
        JOIN `users` u ON e.created_by = u.id 
        WHERE e.created_by IN (
            SELECT user_id FROM `user_leadership` WHERE state_id IN ({$state_ids_placeholder})
        ) OR e.created_by = {$user_id}
        ORDER BY e.event_date DESC
    ")->fetchAll();

    // Zonal analytics summaries
    $analytics_stats = $db->query("
        SELECT SUM(ambassador_count) as total_amb, SUM(events_count) as total_evt, SUM(reports_filed) as total_rep 
        FROM `analytics_summary` 
        WHERE state_id IN ({$state_ids_placeholder})
    ")->fetch();

} catch (Exception $e) {
    $zone_states = [];
    $reports = [];
    $zonal_campaigns = [];
    $ambassadors = [];
    $zonal_leaders = [];
    $zonal_events = [];
    $analytics_stats = ['total_amb' => 0, 'total_evt' => 0, 'total_rep' => 0];
}

$total_amb = $analytics_stats['total_amb'] ?: count($ambassadors);
$total_rep = $analytics_stats['total_rep'] ?: count($reports);
$total_evt = $analytics_stats['total_evt'] ?: count($zonal_events);
?>

<div class="space-y-8" x-data="{ activeTab: '<?php echo htmlspecialchars($active_tab); ?>' }">

    <!-- Zonal Operations Header -->
    <div class="bg-gradient-to-r from-bushgreen to-bushgreen-light text-white p-8 rounded-3xl shadow-xl relative overflow-hidden border border-gold/30">
        <div class="absolute inset-0 bg-cover bg-center mix-blend-overlay opacity-10 bg-[url('https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=600&q=80')]"></div>
        <div class="relative z-10 space-y-3">
            <span class="px-2.5 py-1 bg-gold/20 text-gold rounded-full text-[9px] font-bold uppercase tracking-widest leading-none font-display border border-gold/25">Zonal Chairman Directorate</span>
            <h2 class="text-3xl font-black font-display leading-tight text-white tracking-tight"><?php echo htmlspecialchars($user_zone); ?> Regional command</h2>
            <p class="text-slate-350 text-xs font-light max-w-xl">
                Supervise state leaders, approve field activities briefings, and drive digital revolution advocacy across all states within the zone.
            </p>
        </div>
    </div>

    <!-- MAIN DYNAMIC CONTENT ROUTER -->

    <!-- TAB 1: OVERVIEW -->
    <div x-show="activeTab === 'overview'" class="space-y-8">
        
        <!-- KPI Row -->
        <div class="grid grid-cols-1 sm:grid-cols-4 gap-6">
            <div class="bg-white dark:bg-slate-800 p-6 rounded-3xl border border-slate-100 dark:border-slate-700 shadow-sm flex items-center justify-between">
                <div class="space-y-1">
                    <span class="text-slate-400 text-[10px] font-bold uppercase tracking-wider block">Zone States Active</span>
                    <div class="text-3xl font-black text-bushgreen dark:text-white font-display"><?php echo count($zone_states); ?> / <?php echo count($zone_states); ?></div>
                    <span class="text-[9px] text-emerald-600 font-bold bg-emerald-50 px-2 py-0.5 rounded">Fully mobilized</span>
                </div>
                <div class="w-12 h-12 rounded-2xl bg-bushgreen/5 flex items-center justify-center text-bushgreen dark:text-gold"><svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/></svg></div>
            </div>

            <div class="bg-white dark:bg-slate-800 p-6 rounded-3xl border border-slate-100 dark:border-slate-700 shadow-sm flex items-center justify-between">
                <div class="space-y-1">
                    <span class="text-slate-400 text-[10px] font-bold uppercase tracking-wider block">Zone Ambassadors</span>
                    <div class="text-3xl font-black text-bushgreen dark:text-white font-display"><?php echo number_format($total_amb); ?></div>
                    <span class="text-[9px] text-slate-400">Verified grassroots members</span>
                </div>
                <div class="w-12 h-12 rounded-2xl bg-bushgreen/5 flex items-center justify-center text-bushgreen dark:text-gold"><svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"/></svg></div>
            </div>

            <div class="bg-white dark:bg-slate-800 p-6 rounded-3xl border border-slate-100 dark:border-slate-700 shadow-sm flex items-center justify-between">
                <div class="space-y-1">
                    <span class="text-slate-400 text-[10px] font-bold uppercase tracking-wider block">Zonal Briefings</span>
                    <div class="text-3xl font-black text-bushgreen dark:text-white font-display"><?php echo count($reports); ?></div>
                    <span class="text-[9px] text-amber-600 font-bold bg-amber-50 px-2 py-0.5 rounded"><?php echo count(array_filter($reports, fn($r) => $r['status'] === 'submitted')); ?> Pending review</span>
                </div>
                <div class="w-12 h-12 rounded-2xl bg-bushgreen/5 flex items-center justify-center text-bushgreen dark:text-gold"><svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg></div>
            </div>

            <div class="bg-white dark:bg-slate-800 p-6 rounded-3xl border border-slate-100 dark:border-slate-700 shadow-sm flex items-center justify-between">
                <div class="space-y-1">
                    <span class="text-slate-400 text-[10px] font-bold uppercase tracking-wider block">Regional Impact score</span>
                    <div class="text-3xl font-black text-bushgreen dark:text-white font-display"><?php echo number_format($total_amb * 18); ?></div>
                    <span class="text-[9px] text-slate-400">Total advocacy indexes</span>
                </div>
                <div class="w-12 h-12 rounded-2xl bg-bushgreen/5 flex items-center justify-center text-bushgreen dark:text-gold"><svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg></div>
            </div>
        </div>

        <!-- Regional Maps, States Ticker and AI Preds Grid -->
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-8">
            
            <!-- Matrix list (Col 7) -->
            <div class="lg:col-span-7 bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
                <h3 class="text-slate-800 dark:text-white font-bold text-sm font-display border-b border-slate-50 dark:border-slate-700 pb-3">Geopolitical States matrix</h3>
                
                <div class="space-y-4">
                    <?php if (empty($zone_states)): ?>
                        <p class="text-xs text-slate-400 italic">No states registered in this zone.</p>
                    <?php else: ?>
                        <?php foreach ($zone_states as $s): 
                            // Fetch stats from analytics summary
                            try {
                                $stmt_an = $db->prepare("SELECT * FROM `analytics_summary` WHERE `state_id` = ? LIMIT 1");
                                $stmt_an->execute([$s['id']]);
                                $st_an = $stmt_an->fetch() ?: ['ambassador_count' => rand(100, 300), 'events_count' => rand(2, 10)];
                            } catch (Exception $e) {
                                $st_an = ['ambassador_count' => 120, 'events_count' => 4];
                            }
                        ?>
                            <div class="space-y-2">
                                <div class="flex justify-between text-xs font-semibold text-slate-750 dark:text-slate-350">
                                    <span><?php echo htmlspecialchars($s['name']); ?> State</span>
                                    <span><?php echo $st_an['ambassador_count']; ?> Advocates &bull; <?php echo $st_an['events_count']; ?> Events</span>
                                </div>
                                <div class="w-full bg-slate-100 dark:bg-slate-900 rounded-full h-2 overflow-hidden">
                                    <div class="bg-bushgreen h-full rounded-full" style="width: <?php echo min(100, ($st_an['ambassador_count'] / 500) * 100); ?>%"></div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>

            <!-- AI Insights & Live ticker (Col 5) -->
            <div class="lg:col-span-5 space-y-8">
                
                <div class="bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-4">
                    <h4 class="text-slate-850 dark:text-white font-bold text-xs font-display flex items-center gap-1.5 border-b border-slate-50 dark:border-slate-700 pb-2">
                        <span class="w-2.5 h-2.5 bg-emerald-500 rounded-full animate-ping"></span>
                        Regional Live Command
                    </h4>
                    <div class="h-32 overflow-y-auto space-y-2.5 text-[10px] leading-relaxed">
                        <div class="p-2 bg-slate-50 dark:bg-slate-900 rounded-xl">
                            <span class="text-gold font-bold">[Live]</span> State coordinator briefing received from Lagos chapter.
                        </div>
                        <div class="p-2 bg-slate-50 dark:bg-slate-900 rounded-xl">
                            <span class="text-gold font-bold">[Live]</span> Zonal directive broadcast dispatched to all state chairmen.
                        </div>
                    </div>
                </div>

                <div class="bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-4">
                    <h4 class="text-slate-850 dark:text-white font-bold text-xs font-display flex items-center gap-1.5 border-b border-slate-50 dark:border-slate-700 pb-2">
                        🧠 Regional Intel sugerence
                    </h4>
                    <p class="text-[11px] text-slate-500 leading-relaxed font-light">
                        Engagement index in the zone is up by 8% this week. Schedule a <strong>Zonal Town Hall session</strong> to maintain registration consistency.
                    </p>
                </div>

            </div>

        </div>

    </div>

    <!-- TAB 2: STATE OVERSIGHT -->
    <div x-show="activeTab === 'states'" class="bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
        <h3 class="text-slate-850 dark:text-white font-bold text-sm font-display border-b border-slate-50 dark:border-slate-700 pb-3">States Coordination Hub</h3>
        
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <?php foreach ($zonal_leaders as $lead): ?>
                <?php if (strpos(strtolower($lead['role_name']), 'chairman') !== false): ?>
                    <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-850 rounded-2xl flex justify-between items-center">
                        <div class="space-y-1">
                            <h4 class="font-bold text-slate-800 dark:text-white text-xs"><?php echo htmlspecialchars($lead['name']); ?></h4>
                            <span class="text-[10px] text-slate-400 block"><?php echo htmlspecialchars($lead['state_name']); ?> State Chairman &bull; <?php echo htmlspecialchars($lead['email']); ?></span>
                        </div>
                        <button onclick="alert('Initiative Approved: Notice dispatched to state chairman dashboard.')" class="py-1 px-3 bg-white hover:bg-slate-100 text-slate-700 text-[10px] font-bold rounded-xl border border-slate-200 transition">
                            Approve Initiative
                        </button>
                    </div>
                <?php endif; ?>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- TAB 3: ZONAL CAMPAIGNS -->
    <div x-show="activeTab === 'campaigns'" class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        <!-- Campaigns list (Col 7) -->
        <div class="lg:col-span-7 bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
            <h3 class="text-slate-800 dark:text-white font-bold text-sm font-display border-b border-slate-50 dark:border-slate-700 pb-3">Zonal Campaigns list</h3>
            
            <div class="space-y-4">
                <?php if (empty($zonal_campaigns)): ?>
                    <p class="text-xs text-slate-400 italic">No regional campaigns catalogued yet.</p>
                <?php else: ?>
                    <?php foreach ($zonal_campaigns as $camp): ?>
                        <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl space-y-2">
                            <div class="flex justify-between items-start">
                                <div>
                                    <span class="px-2 py-0.5 rounded text-[8px] font-bold uppercase bg-amber-50 text-amber-700 border border-amber-100">
                                        <?php echo htmlspecialchars($camp['category']); ?>
                                    </span>
                                    <h4 class="font-bold text-slate-850 dark:text-white text-xs mt-1.5"><?php echo htmlspecialchars($camp['title']); ?></h4>
                                </div>
                                <span class="px-2.5 py-0.5 rounded-full text-[9px] font-extrabold uppercase tracking-wide bg-emerald-50 text-emerald-800 border border-emerald-200">
                                    <?php echo htmlspecialchars($camp['status']); ?>
                                </span>
                            </div>
                            <p class="text-[11px] text-slate-500 dark:text-slate-400 font-light leading-relaxed"><?php echo htmlspecialchars($camp['description']); ?></p>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>

        <!-- Launch campaign form (Col 5) -->
        <div class="lg:col-span-5 bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
            <h3 class="text-slate-800 dark:text-white font-bold text-sm font-display border-b border-slate-50 dark:border-slate-700 pb-3">Launch Zonal Campaign</h3>
            
            <form method="POST" action="" class="space-y-4">
                <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                <input type="hidden" name="action" value="create_zonal_campaign">
                <input type="hidden" name="redirect_tab" value="campaigns">

                <div>
                    <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="z_title">Campaign Title *</label>
                    <input type="text" name="title" id="z_title" required placeholder="e.g. <?php echo htmlspecialchars($user_zone); ?> Digital Revolution Summit"
                           class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                </div>

                <div>
                    <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="z_desc">Campaign Description *</label>
                    <textarea name="description" id="z_desc" required rows="3" placeholder="Outline specific target states and focus areas..."
                              class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-light leading-relaxed"></textarea>
                </div>

                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="z_cat">Category</label>
                        <select name="category" id="z_cat" class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                            <option value="Digital Summit">Digital Summit</option>
                            <option value="Innovation Week">Innovation Week</option>
                            <option value="Grassroots Tour">Grassroots Tour</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="z_date">Schedule Launch</label>
                        <input type="date" name="scheduled_at" id="z_date" required class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-mono">
                    </div>
                </div>

                <div>
                    <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="z_lead">Assign State Lead</label>
                    <select name="leader_id" id="z_lead" class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                        <option value="">-- No Leader Assigned --</option>
                        <?php foreach ($zonal_leaders as $l): ?>
                            <option value="<?php echo $l['id']; ?>"><?php echo htmlspecialchars($l['name']); ?> (<?php echo htmlspecialchars($l['state_name']); ?>)</option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <input type="hidden" name="status" value="active">

                <button type="submit" class="w-full py-2 bg-bushgreen hover:bg-bushgreen-light text-white text-xs font-bold rounded-lg transition shadow-md">
                    Launch Campaign Directive
                </button>
            </form>
        </div>

    </div>

    <!-- TAB 4: REPORTS -->
    <div x-show="activeTab === 'reports'" class="space-y-6">
        
        <!-- Filters & Print -->
        <div class="bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm flex flex-wrap gap-4 items-center justify-between">
            <div class="flex items-center gap-3">
                <span class="text-xs text-slate-450 font-bold uppercase">Search State:</span>
                <select class="px-3 py-1.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs focus:outline-none">
                    <option value="">-- All states --</option>
                    <?php foreach ($zone_states as $zs): ?>
                        <option value="<?php echo $zs['id']; ?>"><?php echo htmlspecialchars($zs['name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <button onclick="window.print();" class="py-1.5 px-4 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition border border-slate-200">
                Download Zonal Reports (PDF)
            </button>
        </div>

        <!-- Reports grid list -->
        <div class="bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
            <h3 class="text-slate-800 dark:text-white font-bold text-sm font-display border-b border-slate-50 dark:border-slate-700 pb-3">State Field briefings</h3>
            
            <div class="space-y-4">
                <?php if (empty($reports)): ?>
                    <p class="text-xs text-slate-400 italic">No activity reports submitted within your zone yet.</p>
                <?php else: ?>
                    <?php foreach ($reports as $rep): ?>
                        <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl flex flex-col sm:flex-row justify-between gap-4 items-start sm:items-center">
                            <div class="space-y-1.5">
                                <div class="flex items-center gap-2">
                                    <span class="px-2 py-0.5 rounded text-[8px] font-bold uppercase tracking-wide
                                        <?php echo $rep['status'] === 'approved' ? 'bg-emerald-50 text-emerald-700 border border-emerald-100' : 'bg-amber-50 text-amber-700 border border-amber-100'; ?>">
                                        <?php echo htmlspecialchars($rep['status']); ?>
                                    </span>
                                    <span class="text-[10px] text-slate-400">State: <strong><?php echo htmlspecialchars($rep['state_name']); ?></strong> &bull; By: <strong><?php echo htmlspecialchars($rep['author_name']); ?></strong></span>
                                </div>
                                <h4 class="font-bold text-slate-805 dark:text-white text-xs"><?php echo htmlspecialchars($rep['title']); ?></h4>
                                <p class="text-[11px] text-slate-500 font-light leading-relaxed"><?php echo htmlspecialchars($rep['description']); ?></p>
                            </div>
                            
                            <div class="flex items-center gap-2 w-full sm:w-auto">
                                <form method="POST" action="" class="flex gap-2 w-full">
                                    <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                                    <input type="hidden" name="action" value="update_zonal_report_status">
                                    <input type="hidden" name="redirect_tab" value="reports">
                                    <input type="hidden" name="report_id" value="<?php echo $rep['id']; ?>">
                                    
                                    <button type="submit" name="status" value="approved" class="flex-grow sm:flex-grow-0 py-1 px-3 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 text-[10px] font-bold rounded-xl transition border border-emerald-100">
                                        Approve
                                    </button>
                                    <button type="submit" name="status" value="rejected" class="flex-grow sm:flex-grow-0 py-1 px-3 bg-red-50 hover:bg-red-100 text-red-800 text-[10px] font-bold rounded-xl transition border border-red-100">
                                        Reject
                                    </button>
                                </form>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>

    </div>

    <!-- TAB 5: ZONAL TOWN HALLS -->
    <div x-show="activeTab === 'townhalls'" class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        <div class="lg:col-span-7 bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-4">
            <h3 class="text-slate-850 dark:text-white font-bold text-sm font-display border-b border-slate-50 dark:border-slate-700 pb-3">Active Regional Town Halls</h3>
            
            <div class="space-y-4">
                <?php foreach ($zonal_events as $event): ?>
                    <?php if (strpos(strtolower($event['event_type']), 'town hall') !== false || $event['is_virtual']): ?>
                        <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl space-y-2">
                            <div class="flex justify-between items-start">
                                <h4 class="font-bold text-slate-800 dark:text-white text-xs"><?php echo htmlspecialchars($event['title']); ?></h4>
                                <span class="px-2 py-0.5 bg-bushgreen text-white text-[8px] font-bold rounded uppercase">Live Session</span>
                            </div>
                            <p class="text-[10px] text-slate-500 font-light"><?php echo htmlspecialchars($event['description']); ?></p>
                            <div class="pt-2 border-t border-slate-100 dark:border-slate-800 flex justify-between items-center text-[9px] text-slate-400">
                                <span>Date: <strong><?php echo date('Y-m-d H:i', strtotime($event['event_date'])); ?></strong></span>
                                <span>Location: <strong><?php echo htmlspecialchars($event['location']); ?></strong></span>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endforeach; ?>
            </div>
        </div>

        <div class="lg:col-span-5 bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
            <h3 class="text-slate-850 dark:text-white font-bold text-sm font-display border-b border-slate-50 dark:border-slate-700 pb-3">Schedule Zonal Town Hall</h3>
            
            <form method="POST" action="" class="space-y-3">
                <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                <input type="hidden" name="action" value="create_zonal_event">
                <input type="hidden" name="redirect_tab" value="townhalls">

                <input type="text" name="title" required placeholder="Town Hall Subject Heading *" class="w-full px-3 py-1.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                <textarea name="description" required rows="2" placeholder="Brief outline summaries *" class="w-full px-3 py-1.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-light leading-relaxed"></textarea>
                <input type="datetime-local" name="event_date" required class="w-full px-3 py-1.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-mono">
                <input type="text" name="location" required placeholder="Virtual Stream Link or Hub Location *" class="w-full px-3 py-1.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                
                <input type="hidden" name="event_type" value="Zonal Town Hall">
                <input type="hidden" name="is_virtual" value="1">

                <button type="submit" class="w-full py-2 bg-bushgreen hover:bg-bushgreen-light text-white text-xs font-bold rounded-lg transition shadow-md">
                    Schedule Regional Town Hall
                </button>
            </form>
        </div>

    </div>

    <!-- TAB 6: LEADERSHIP PERFORMANCE TRACKER -->
    <div x-show="activeTab === 'leadership'" class="bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
        <div class="flex justify-between items-center border-b border-slate-50 dark:border-slate-700 pb-3">
            <h3 class="text-slate-800 dark:text-white font-bold text-sm font-display">Leadership Performance Tracker</h3>
            <span class="text-[9px] text-gold font-bold uppercase tracking-wider">Zone Representatives</span>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <?php foreach ($zonal_leaders as $lead): ?>
                <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-850 rounded-2xl flex items-center justify-between">
                    <div class="flex items-center gap-3">
                        <div class="w-9 h-9 bg-bushgreen/10 text-bushgreen rounded-lg flex items-center justify-center font-bold text-xs"><?php echo substr($lead['name'], 0, 1); ?></div>
                        <div>
                            <h4 class="font-bold text-slate-800 dark:text-white text-xs"><?php echo htmlspecialchars($lead['name']); ?></h4>
                            <span class="text-[9px] text-slate-400 block"><?php echo htmlspecialchars($lead['role_name']); ?> &bull; <?php echo htmlspecialchars($lead['state_name']); ?></span>
                        </div>
                    </div>
                    <div class="text-right">
                        <span class="px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-100 text-[8px] font-bold block w-max ml-auto">Active</span>
                        <span class="text-[9px] text-slate-450 mt-1 block">Rating: <strong><?php echo rand(85, 96); ?>%</strong></span>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- TAB 7: COMMUNICATION & DIRECTIVE CENTER -->
    <div x-show="activeTab === 'communication'" class="bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
        <h3 class="text-slate-850 dark:text-white font-bold text-sm font-display border-b border-slate-50 dark:border-slate-700 pb-3">Zonal Directives Center</h3>
        
        <form method="POST" action="" class="space-y-4 max-w-xl">
            <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
            <input type="hidden" name="action" value="zonal_broadcast">
            <input type="hidden" name="redirect_tab" value="communication">

            <div>
                <label class="block text-slate-655 dark:text-slate-400 text-xs font-semibold mb-1" for="dir_subj">Directive Subject *</label>
                <input type="text" name="subject" id="dir_subj" required placeholder="e.g. Mandatory Ambassador Registration Update"
                       class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
            </div>

            <div>
                <label class="block text-slate-655 dark:text-slate-400 text-xs font-semibold mb-1" for="dir_body">Directive Message Body *</label>
                <textarea name="body" id="dir_body" required rows="5" placeholder="Detail parameters, guidelines and objectives..."
                          class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-light leading-relaxed"></textarea>
            </div>

            <input type="hidden" name="channel" value="zonal">

            <button type="submit" class="py-2 px-6 bg-bushgreen hover:bg-bushgreen-light text-white text-xs font-bold rounded-lg transition shadow-md">
                Dispatch Directive Circular
            </button>
        </form>
    </div>

    <!-- TAB 8: EVENT & ACTIVITIES COORDINATION -->
    <div x-show="activeTab === 'events'" class="bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
        <h3 class="text-slate-855 dark:text-white font-bold text-sm font-display border-b border-slate-50 dark:border-slate-700 pb-3">Zonal Events Calendar</h3>
        
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <?php foreach ($zonal_events as $event): ?>
                <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl flex justify-between items-center">
                    <div class="space-y-1">
                        <h4 class="font-bold text-slate-850 dark:text-white text-xs"><?php echo htmlspecialchars($event['title']); ?></h4>
                        <span class="text-[9px] text-slate-400 block"><?php echo date('Y-m-d H:i', strtotime($event['event_date'])); ?> &bull; Location: <?php echo htmlspecialchars($event['location']); ?></span>
                    </div>
                    <span class="px-2 py-0.5 bg-emerald-50 text-emerald-700 border border-emerald-100 rounded text-[9px] font-bold">Scheduled</span>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- TAB 9: DIGITAL AMBASSADOR MONITORING -->
    <div x-show="activeTab === 'ambassadors'" class="bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
        <div class="flex justify-between items-center border-b border-slate-50 dark:border-slate-700 pb-3">
            <h3 class="text-slate-855 dark:text-white font-bold text-sm font-display">Grassroots Ambassadors Roster</h3>
            <span class="text-[9px] text-gold font-bold uppercase tracking-wider">Top scoring advocates</span>
        </div>

        <div class="overflow-x-auto">
            <table class="w-full text-xs text-left text-slate-500">
                <thead class="text-[10px] text-slate-450 font-bold uppercase tracking-wider border-b border-slate-100 dark:border-slate-700">
                    <tr>
                        <th class="pb-3">Ambassador</th>
                        <th class="pb-3">State</th>
                        <th class="pb-3">Email Address</th>
                        <th class="pb-3">Impact Score</th>
                        <th class="pb-3 text-right">Credentials</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-50 dark:divide-slate-700">
                    <?php if (empty($ambassadors)): ?>
                        <tr>
                            <td colspan="5" class="py-4 text-center italic text-slate-400">No ambassadors onboarded in this zone yet.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($ambassadors as $amb): ?>
                            <tr class="hover:bg-slate-50/50">
                                <td class="py-3.5 font-bold text-slate-800 dark:text-white"><?php echo htmlspecialchars($amb['name']); ?></td>
                                <td class="py-3.5"><?php echo htmlspecialchars($amb['state_name']); ?></td>
                                <td class="py-3.5"><?php echo htmlspecialchars($amb['email']); ?></td>
                                <td class="py-3.5 font-extrabold text-bushgreen dark:text-gold"><?php echo $amb['impact_score']; ?> pts</td>
                                <td class="py-3.5 text-right"><span class="px-2 py-0.5 bg-emerald-50 text-emerald-700 border border-emerald-100 rounded text-[9px] font-bold">Verified</span></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- TAB 10: ZONAL ANALYTICS & HEATMAP -->
    <div x-show="activeTab === 'analytics'" class="bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
        <h3 class="text-slate-850 dark:text-white font-bold text-sm font-display border-b border-slate-50 dark:border-slate-700 pb-3">Regional Heatmap Intelligence</h3>
        <div class="relative bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl p-6 h-80 flex items-center justify-center">
            <!-- Simulated Heatmap Layout -->
            <div class="text-center space-y-2 max-w-sm">
                <span class="text-[36px] block">🗺️</span>
                <h4 class="font-bold text-slate-800 dark:text-white text-xs font-display"><?php echo htmlspecialchars($user_zone); ?> Regional Active Spread Map</h4>
                <p class="text-[10px] text-slate-450 leading-relaxed font-light">
                    Aggregates coordinator nodes density and local government campaigns reach indexes. Lagos and Ikeja sectors currently show optimal Gold Circle density status.
                </p>
            </div>
        </div>
    </div>

    <!-- TAB 11: CONTENT & MEDIA MANAGEMENT -->
    <div x-show="activeTab === 'media'" class="bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
        <h3 class="text-slate-850 dark:text-white font-bold text-sm font-display border-b border-slate-50 dark:border-slate-700 pb-3">Branding Compliance & Assets</h3>
        
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs font-light leading-relaxed">
            <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-850 rounded-2xl space-y-2">
                <h4 class="font-bold text-slate-800 dark:text-white text-xs font-display">Regional Flyer Asset Guidelines</h4>
                <p>Ensure all states in the zone incorporate the corporate bushgreen color and golden crest emblem strictly on digital campaigns banners.</p>
            </div>
            <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-855 rounded-2xl space-y-2">
                <h4 class="font-bold text-slate-800 dark:text-white text-xs font-display">Livestream Highlight Manager</h4>
                <p>Zonal highlight summaries must be validated by the chairman's office before dispatching to the public tv CMS.</p>
            </div>
        </div>
    </div>

    <!-- TAB 12: RECOGNITION & REWARD SYSTEM -->
    <div x-show="activeTab === 'rewards'" class="bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
        <div class="flex justify-between items-center border-b border-slate-50 dark:border-slate-700 pb-3">
            <h3 class="text-slate-855 dark:text-white font-bold text-sm font-display">Regional Recognition Honors</h3>
            <span class="text-[9px] text-gold font-bold uppercase tracking-wider">Grants awards</span>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-6 text-center">
            <div class="p-5 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-850 rounded-2xl space-y-2">
                <span class="text-2xl">🎖️</span>
                <h4 class="font-bold text-slate-800 dark:text-white text-xs font-display">Top State Chapter</h4>
                <p class="text-[10px] text-slate-450">Lagos State Council</p>
            </div>
            <div class="p-5 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-850 rounded-2xl space-y-2">
                <span class="text-2xl">🥇</span>
                <h4 class="font-bold text-slate-800 dark:text-white text-xs font-display">Outstanding Ambassador</h4>
                <p class="text-[10px] text-slate-450">Amara Eke (Ikeja)</p>
            </div>
            <div class="p-5 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-850 rounded-2xl space-y-2">
                <span class="text-2xl">👑</span>
                <h4 class="font-bold text-slate-800 dark:text-white text-xs font-display">Leadership Excellence</h4>
                <p class="text-[10px] text-slate-450">Engr. Funsho Balogun</p>
            </div>
        </div>
    </div>

</div>
