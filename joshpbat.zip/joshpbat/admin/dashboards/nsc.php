<?php
/**
 * National Steering Council Operations Headquarters (Role 3)
 * Master operational, policy execution, and campaign coordination room.
 */
if (!defined('DB_HOST')) {
    exit('Access Denied');
}

$active_tab = $_GET['tab'] ?? 'overview';
$user = Auth::user();

try {
    $db = Database::connect();
    
    // Fetch campaigns
    $campaigns = $db->query("
        SELECT c.*, u.name as leader_name, creator.name as creator_name 
        FROM `campaigns` c 
        LEFT JOIN `users` u ON c.leader_id = u.id 
        JOIN `users` creator ON c.created_by = creator.id 
        ORDER BY c.created_at DESC
    ")->fetchAll();

    // Fetch reports
    $reports = $db->query("
        SELECT r.*, u.name as author_name, s.name as state_name, s.zone as zone_name 
        FROM `reports` r 
        JOIN `users` u ON r.user_id = u.id 
        JOIN `states` s ON r.state_id = s.id 
        ORDER BY r.created_at DESC
    ")->fetchAll();

    // Fetch coordinators & chairmen
    $leaders = $db->query("
        SELECT u.id, u.name, u.email, u.status, r.display_name as role_name 
        FROM `users` u 
        JOIN `roles` r ON u.role_id = r.id 
        WHERE r.name IN ('zonal_chairman', 'state_chairman', 'coordinator') 
        ORDER BY r.id ASC, u.name ASC
    ")->fetchAll();

    // Fetch NSC Tasks
    $tasks = $db->query("
        SELECT t.*, u.name as creator_name 
        FROM `nsc_tasks` t 
        JOIN `users` u ON t.created_by = u.id 
        ORDER BY t.created_at DESC
    ")->fetchAll();

    // Fetch NSC Polls
    $polls = $db->query("
        SELECT p.*, u.name as creator_name 
        FROM `nsc_polls` p 
        JOIN `users` u ON p.created_by = u.id 
        ORDER BY p.created_at DESC
    ")->fetchAll();

    // Fetch states list
    $states_list = $db->query("SELECT id, name, zone FROM `states` ORDER BY name ASC")->fetchAll();

} catch (Exception $e) {
    $campaigns = [];
    $reports = [];
    $leaders = [];
    $tasks = [];
    $polls = [];
    $states_list = [];
}
?>

<div class="space-y-8" x-data="{ activeTab: '<?php echo htmlspecialchars($active_tab); ?>' }">

    <!-- Operational Header Hero -->
    <div class="bg-gradient-to-r from-bushgreen to-bushgreen-light text-white p-8 rounded-3xl shadow-xl relative overflow-hidden border border-gold/30">
        <div class="absolute inset-0 bg-cover bg-center mix-blend-overlay opacity-10 bg-[url('https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=600&q=80')]"></div>
        <div class="absolute -right-16 -top-16 w-48 h-48 bg-gold/10 rounded-full blur-2xl"></div>
        <div class="relative z-10 space-y-3">
            <span class="px-2.5 py-1 bg-gold/20 text-gold rounded-full text-[9px] font-bold uppercase tracking-widest leading-none font-display border border-gold/20">National Steering Council</span>
            <h2 class="text-3xl font-black font-display leading-none text-white tracking-tight">National Operations Headquarters</h2>
            <p class="text-slate-300 text-xs font-light max-w-2xl leading-relaxed">
                Transforming the vision of the Smart Nation Movement into coordinated campaigns, state policy implementations, and measurable grassroots impact.
            </p>
        </div>
    </div>

    <!-- MAIN DYNAMIC CONTENT ROUTER -->

    <!-- TAB 1: OVERVIEW -->
    <div x-show="activeTab === 'overview'" class="space-y-8">
        
        <!-- KPI Cards -->
        <div class="grid grid-cols-1 sm:grid-cols-4 gap-6">
            <div class="bg-white dark:bg-slate-800 p-6 rounded-3xl border border-slate-100 dark:border-slate-700 shadow-sm flex items-center justify-between transition-all hover:shadow-md">
                <div class="space-y-1">
                    <span class="text-slate-400 text-[10px] font-bold uppercase tracking-wider block">Total Active States</span>
                    <div class="text-3xl font-black text-bushgreen dark:text-white font-display">6 / 6</div>
                    <span class="text-[9px] text-emerald-600 font-bold bg-emerald-50 px-2 py-0.5 rounded">All zones mobilized</span>
                </div>
                <div class="w-12 h-12 rounded-2xl bg-bushgreen/5 flex items-center justify-center text-bushgreen dark:text-gold"><svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/></svg></div>
            </div>
            
            <div class="bg-white dark:bg-slate-800 p-6 rounded-3xl border border-slate-100 dark:border-slate-700 shadow-sm flex items-center justify-between transition-all hover:shadow-md">
                <div class="space-y-1">
                    <span class="text-slate-400 text-[10px] font-bold uppercase tracking-wider block">Campaigns Active</span>
                    <div class="text-3xl font-black text-bushgreen dark:text-white font-display"><?php echo count($campaigns); ?></div>
                    <span class="text-[9px] text-slate-500">Scheduled directives</span>
                </div>
                <div class="w-12 h-12 rounded-2xl bg-bushgreen/5 flex items-center justify-center text-bushgreen dark:text-gold"><svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5.882V19.24a1.76 1.76 0 01-3.417.592l-2.147-6.15M18 13a3 3 0 100-6M5.436 13.683A4.001 4.001 0 017 6h1.832c4.1 0 7.625-1.234 9.168-3v14c-1.543-1.766-5.067-3-9.168-3H7a3.988 3.988 0 01-1.564-.317z"/></svg></div>
            </div>

            <div class="bg-white dark:bg-slate-800 p-6 rounded-3xl border border-slate-100 dark:border-slate-700 shadow-sm flex items-center justify-between transition-all hover:shadow-md">
                <div class="space-y-1">
                    <span class="text-slate-400 text-[10px] font-bold uppercase tracking-wider block">Submitted Briefings</span>
                    <div class="text-3xl font-black text-bushgreen dark:text-white font-display"><?php echo count($reports); ?></div>
                    <span class="text-[9px] text-amber-600 font-bold bg-amber-50 px-2 py-0.5 rounded"><?php echo count(array_filter($reports, fn($r) => $r['status'] === 'submitted')); ?> Pending review</span>
                </div>
                <div class="w-12 h-12 rounded-2xl bg-bushgreen/5 flex items-center justify-center text-bushgreen dark:text-gold"><svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg></div>
            </div>

            <div class="bg-white dark:bg-slate-800 p-6 rounded-3xl border border-slate-100 dark:border-slate-700 shadow-sm flex items-center justify-between transition-all hover:shadow-md">
                <div class="space-y-1">
                    <span class="text-slate-400 text-[10px] font-bold uppercase tracking-wider block">TV Live Audience</span>
                    <div class="text-3xl font-black text-bushgreen dark:text-white font-display">1,824</div>
                    <span class="text-[9px] text-red-600 font-bold bg-red-50 px-2 py-0.5 rounded flex items-center gap-1 w-max animate-pulse">
                        <span class="w-1.5 h-1.5 bg-red-600 rounded-full"></span> Live
                    </span>
                </div>
                <div class="w-12 h-12 rounded-2xl bg-bushgreen/5 flex items-center justify-center text-bushgreen dark:text-gold"><svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z"/></svg></div>
            </div>
        </div>

        <!-- Heatmap, Analytics & AI Engine Grid -->
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-8">
            
            <!-- Heatmap Map (Col 7) -->
            <div class="lg:col-span-7 bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
                <div class="flex justify-between items-center border-b border-slate-50 dark:border-slate-700 pb-3">
                    <h3 class="text-slate-800 dark:text-white font-bold text-sm font-display">National Engagement Heatmap</h3>
                    <span class="text-[10px] font-bold text-gold uppercase tracking-widest">Active state spread</span>
                </div>
                <div class="relative bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl p-4 flex items-center justify-center h-80 overflow-hidden">
                    <!-- Nigeria Map SVG Overlay mockup -->
                    <svg class="w-full h-full text-slate-300 dark:text-slate-700" viewBox="0 0 500 350" fill="none">
                        <path d="M50 150 C80 90, 160 50, 220 70 C280 90, 360 80, 420 110 C480 140, 470 200, 440 260 C410 320, 320 330, 260 310 C200 290, 140 330, 80 290 C20 250, 20 210, 50 150 Z" fill="currentColor" opacity="0.15" stroke="currentColor" stroke-width="2"/>
                        <!-- Interactive Pulsing Hub points -->
                        <g class="cursor-pointer" onclick="alert('Lagos Zone: 480 Ambassadors Active, 14 Events Completed.')">
                            <circle cx="160" cy="270" r="14" fill="#063C1E" opacity="0.3" class="animate-ping"/>
                            <circle cx="160" cy="270" r="8" fill="#D4AF37" stroke="#fff" stroke-width="2"/>
                            <text x="180" y="275" fill="#063C1E" class="text-[9px] font-bold fill-current dark:fill-white font-display">Lagos (High)</text>
                        </g>
                        <g class="cursor-pointer" onclick="alert('FCT Zone: 220 Ambassadors Active, 8 Events Completed.')">
                            <circle cx="250" cy="160" r="12" fill="#063C1E" opacity="0.3" class="animate-ping"/>
                            <circle cx="250" cy="160" r="7" fill="#D4AF37" stroke="#fff" stroke-width="2"/>
                            <text x="265" y="165" fill="#063C1E" class="text-[9px] font-bold fill-current dark:fill-white font-display">FCT (Medium)</text>
                        </g>
                        <g class="cursor-pointer" onclick="alert('Kano Zone: 390 Ambassadors Active, 6 Events Completed.')">
                            <circle cx="240" cy="80" r="14" fill="#063C1E" opacity="0.3" class="animate-ping"/>
                            <circle cx="240" cy="80" r="8" fill="#D4AF37" stroke="#fff" stroke-width="2"/>
                            <text x="255" y="85" fill="#063C1E" class="text-[9px] font-bold fill-current dark:fill-white font-display">Kano (High)</text>
                        </g>
                        <g class="cursor-pointer" onclick="alert('Rivers Zone: 310 Ambassadors Active, 11 Events Completed.')">
                            <circle cx="220" cy="290" r="12" fill="#063C1E" opacity="0.3" class="animate-ping"/>
                            <circle cx="220" cy="290" r="7" fill="#D4AF37" stroke="#fff" stroke-width="2"/>
                            <text x="240" y="295" fill="#063C1E" class="text-[9px] font-bold fill-current dark:fill-white font-display">Rivers (Medium)</text>
                        </g>
                    </svg>
                    <div class="absolute bottom-4 left-4 bg-white/95 dark:bg-slate-800/95 border border-slate-100 dark:border-slate-700 p-2.5 rounded-xl text-[9px] shadow-md space-y-1">
                        <div class="font-bold text-slate-800 dark:text-white uppercase tracking-wider">Advocacy Spread</div>
                        <div class="flex items-center gap-1.5"><span class="w-2.5 h-2.5 bg-gold rounded-full"></span> Gold Circle: High density</div>
                        <div class="flex items-center gap-1.5"><span class="w-2.5 h-2.5 bg-bushgreen rounded-full"></span> Green Circle: Active hub</div>
                    </div>
                </div>
            </div>

            <!-- AI Engine & Live Command Ticker (Col 5) -->
            <div class="lg:col-span-5 space-y-8">
                
                <!-- AI Engine Insights -->
                <div class="bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-4">
                    <div class="flex items-center gap-2 border-b border-slate-50 dark:border-slate-700 pb-3">
                        <div class="w-8 h-8 rounded-lg bg-gold/10 text-gold flex items-center justify-center font-bold">🧠</div>
                        <div>
                            <h4 class="text-slate-800 dark:text-white font-bold text-xs font-display">AI Operational Intel</h4>
                            <span class="text-[9px] text-slate-400 font-light">Growth forecasting & trend analytics</span>
                        </div>
                    </div>
                    
                    <div class="space-y-3 text-xs">
                        <div class="p-3 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-xl space-y-1.5">
                            <div class="flex justify-between items-center text-[10px] text-slate-400 font-bold uppercase">
                                <span>National Sentiment Index</span>
                                <span class="text-emerald-600 font-extrabold">84% Positive</span>
                            </div>
                            <div class="w-full bg-slate-200 dark:bg-slate-800 h-1.5 rounded-full overflow-hidden">
                                <div class="bg-emerald-600 h-full w-[84%]"></div>
                            </div>
                        </div>

                        <div class="p-3 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-xl space-y-1">
                            <span class="text-[9px] text-gold font-bold uppercase tracking-wider block">Predictive Suggestion</span>
                            <p class="text-[11px] text-slate-500 leading-relaxed font-light">
                                Youth registration counts in North-West show a 14% forecast bump. Allocate <strong>Smart Nation Campus Tour</strong> activities to Kano hubs to optimize coverage.
                            </p>
                        </div>
                    </div>
                </div>

                <!-- Live Ticker Feed -->
                <div class="bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-4">
                    <div class="flex justify-between items-center border-b border-slate-50 dark:border-slate-700 pb-3">
                        <h4 class="text-slate-800 dark:text-white font-bold text-xs font-display flex items-center gap-1.5">
                            <span class="w-2.5 h-2.5 bg-emerald-500 rounded-full animate-ping"></span>
                            Live Command Feed
                        </h4>
                        <span class="text-[9px] text-slate-400 font-mono uppercase">Real-Time Logs</span>
                    </div>

                    <div class="h-44 overflow-y-auto space-y-3 pr-2 scrollbar-thin">
                        <div class="p-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-xl text-[10px] leading-relaxed flex gap-2">
                            <span class="text-gold font-bold">[11:24]</span>
                            <span class="text-slate-600 dark:text-slate-400">Ambassador <strong>Amara Eke</strong> logged check-in at Ikeja Hub, scoring +5 points.</span>
                        </div>
                        <div class="p-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-xl text-[10px] leading-relaxed flex gap-2">
                            <span class="text-gold font-bold">[10:45]</span>
                            <span class="text-slate-600 dark:text-slate-400">Zonal Chairman <strong>Adebayo Adeola</strong> dispatched North-Central regional brief.</span>
                        </div>
                        <div class="p-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-xl text-[10px] leading-relaxed flex gap-2">
                            <span class="text-gold font-bold">[09:12]</span>
                            <span class="text-slate-600 dark:text-slate-400">State report submitted from <strong>Enugu</strong> state coordinator node.</span>
                        </div>
                    </div>
                </div>

            </div>

        </div>

        <!-- National Scoreboard -->
        <div class="bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-4">
            <h3 class="text-slate-800 dark:text-white font-bold text-sm font-display border-b border-slate-50 dark:border-slate-700 pb-3">National Smart Nation Scoreboard</h3>
            <div class="overflow-x-auto">
                <table class="w-full text-xs text-left text-slate-500">
                    <thead class="text-[10px] text-slate-400 font-bold uppercase tracking-wider border-b border-slate-100 dark:border-slate-700">
                        <tr>
                            <th class="pb-3">Rank</th>
                            <th class="pb-3">Geopolitical Zone</th>
                            <th class="pb-3">Ambassadors mobilized</th>
                            <th class="pb-3">Briefings Filed</th>
                            <th class="pb-3">TV Events Host</th>
                            <th class="pb-3 text-right">Impact Index</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-50 dark:divide-slate-700">
                        <tr class="hover:bg-slate-50/50">
                            <td class="py-3.5 font-bold text-gold">#1</td>
                            <td class="py-3.5 font-bold text-slate-850 dark:text-white">South West</td>
                            <td class="py-3.5">480</td>
                            <td class="py-3.5">38</td>
                            <td class="py-3.5">14</td>
                            <td class="py-3.5 text-right font-extrabold text-bushgreen dark:text-gold">9,200 pts</td>
                        </tr>
                        <tr class="hover:bg-slate-50/50">
                            <td class="py-3.5 font-bold text-slate-400">#2</td>
                            <td class="py-3.5 font-bold text-slate-850 dark:text-white">North West</td>
                            <td class="py-3.5">390</td>
                            <td class="py-3.5">31</td>
                            <td class="py-3.5">6</td>
                            <td class="py-3.5 text-right font-extrabold text-slate-600">7,800 pts</td>
                        </tr>
                        <tr class="hover:bg-slate-50/50">
                            <td class="py-3.5 font-bold text-slate-400">#3</td>
                            <td class="py-3.5 font-bold text-slate-850 dark:text-white">South South</td>
                            <td class="py-3.5">310</td>
                            <td class="py-3.5">25</td>
                            <td class="py-3.5">11</td>
                            <td class="py-3.5 text-right font-extrabold text-slate-600">6,100 pts</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>

    </div>

    <!-- TAB 2: CAMPAIGNS -->
    <div x-show="activeTab === 'campaigns'" class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        <!-- Campaigns list (Col 7) -->
        <div class="lg:col-span-7 bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
            <h3 class="text-slate-800 dark:text-white font-bold text-sm font-display border-b border-slate-50 dark:border-slate-700 pb-3">Active National Campaigns</h3>
            
            <div class="space-y-4">
                <?php if (empty($campaigns)): ?>
                    <p class="text-xs text-slate-400 italic">No campaigns catalogued yet.</p>
                <?php else: ?>
                    <?php foreach ($campaigns as $camp): ?>
                        <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl space-y-3">
                            <div class="flex justify-between items-start">
                                <div>
                                    <span class="px-2 py-0.5 rounded text-[8px] font-bold uppercase bg-amber-50 text-amber-700 border border-amber-100">
                                        <?php echo htmlspecialchars($camp['category']); ?>
                                    </span>
                                    <h4 class="font-bold text-slate-850 dark:text-white text-xs mt-1.5"><?php echo htmlspecialchars($camp['title']); ?></h4>
                                </div>
                                <span class="px-2.5 py-0.5 rounded-full text-[9px] font-extrabold uppercase tracking-wide
                                    <?php echo $camp['status'] === 'active' ? 'bg-emerald-50 text-emerald-800 border border-emerald-200' : 'bg-slate-100 text-slate-500 border border-slate-200'; ?>">
                                    <?php echo htmlspecialchars($camp['status']); ?>
                                </span>
                            </div>
                            <p class="text-[11px] text-slate-500 dark:text-slate-400 font-light leading-relaxed"><?php echo htmlspecialchars($camp['description']); ?></p>
                            
                            <div class="pt-2 border-t border-slate-100 dark:border-slate-800 flex justify-between items-center text-[10px] text-slate-400">
                                <span>Leader: <strong><?php echo htmlspecialchars($camp['leader_name'] ?? 'Unassigned'); ?></strong></span>
                                <span>Target: <strong><?php echo $camp['scheduled_at'] ? date('M d, Y', strtotime($camp['scheduled_at'])) : 'Immediate'; ?></strong></span>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>

        <!-- Schedule Campaign Form (Col 5) -->
        <div class="lg:col-span-5 bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
            <h3 class="text-slate-800 dark:text-white font-bold text-sm font-display border-b border-slate-50 dark:border-slate-700 pb-3">Create National Campaign</h3>
            
            <form method="POST" action="" class="space-y-4">
                <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                <input type="hidden" name="action" value="nsc_create_campaign">
                <input type="hidden" name="redirect_tab" value="campaigns">

                <div>
                    <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="camp_title">Campaign Title *</label>
                    <input type="text" name="title" id="camp_title" required placeholder="e.g. National AI Awareness Campaign"
                           class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                </div>

                <div>
                    <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="camp_desc">Operational Description *</label>
                    <textarea name="description" id="camp_desc" required rows="3" placeholder="Outline objectives, scopes, and target demographics..."
                              class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-light leading-relaxed"></textarea>
                </div>

                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="camp_cat">Category</label>
                        <select name="category" id="camp_cat" class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                            <option value="Digital Revolution">Digital Revolution</option>
                            <option value="AI Awareness">AI Awareness</option>
                            <option value="Campus Tour">Campus Tour</option>
                            <option value="Town Hall Series">Town Hall Series</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="camp_date">Schedule Launch</label>
                        <input type="date" name="scheduled_at" id="camp_date" required class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-mono">
                    </div>
                </div>

                <div>
                    <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="camp_lead">Assign Leadership Authority</label>
                    <select name="leader_id" id="camp_lead" class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                        <option value="">-- No Leader Assigned --</option>
                        <?php foreach ($leaders as $l): ?>
                            <option value="<?php echo $l['id']; ?>"><?php echo htmlspecialchars($l['name']); ?> (<?php echo htmlspecialchars($l['role_name']); ?>)</option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div>
                    <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="camp_status">Publish Status</label>
                    <select name="status" id="camp_status" class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                        <option value="active">Active (Deploy online)</option>
                        <option value="scheduled">Scheduled (Future queue)</option>
                        <option value="draft">Draft (Saved local)</option>
                    </select>
                </div>

                <button type="submit" class="w-full py-2.5 bg-bushgreen hover:bg-bushgreen-light text-white text-xs font-bold rounded-lg transition shadow-md shadow-bushgreen/10">
                    Deploy National Campaign
                </button>
            </form>
        </div>

    </div>

    <!-- TAB 3: ZONAL COORDINATION -->
    <div x-show="activeTab === 'zonal'" class="space-y-8">
        
        <!-- Comparison Grid -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <?php 
            $zones_names = ['North Central', 'North East', 'North West', 'South West', 'South South', 'South East'];
            foreach ($zones_names as $idx => $zn): 
                $border_colors = ['border-l-gold', 'border-l-emerald-600', 'border-l-blue-600', 'border-l-amber-600', 'border-l-indigo-600', 'border-l-purple-600'];
                $class = $border_colors[$idx % count($border_colors)];
            ?>
                <div class="bg-white dark:bg-slate-800 rounded-2xl p-6 border border-slate-100 dark:border-slate-700 border-l-4 <?php echo $class; ?> shadow-sm space-y-4">
                    <h4 class="font-bold text-slate-850 dark:text-white font-display text-sm"><?php echo $zn; ?> Zone</h4>
                    <div class="grid grid-cols-2 gap-4 text-xs">
                        <div class="p-2 bg-slate-50 dark:bg-slate-900 rounded-lg">
                            <span class="text-slate-400 text-[9px] uppercase tracking-wider block">Ambassadors</span>
                            <span class="font-extrabold text-slate-800 dark:text-white"><?php echo rand(120, 500); ?> Active</span>
                        </div>
                        <div class="p-2 bg-slate-50 dark:bg-slate-900 rounded-lg">
                            <span class="text-slate-400 text-[9px] uppercase tracking-wider block">Directives</span>
                            <span class="font-extrabold text-slate-800 dark:text-white"><?php echo rand(4, 15); ?> Assigned</span>
                        </div>
                    </div>
                    <div class="pt-2 border-t border-slate-100 dark:border-slate-850 flex justify-between items-center text-[10px] text-slate-400">
                        <span>Zonal Hub Status</span>
                        <span class="px-2 py-0.2 rounded bg-emerald-50 text-emerald-700 border border-emerald-100 text-[8px] font-bold uppercase tracking-wider">Operational</span>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <!-- Task Assigner & Deadlines -->
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            
            <!-- Tasks list (Col 7) -->
            <div class="lg:col-span-7 bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
                <h3 class="text-slate-800 dark:text-white font-bold text-sm font-display border-b border-slate-50 dark:border-slate-700 pb-3">Assigned Operational Objectives</h3>
                
                <div class="space-y-4">
                    <?php if (empty($tasks)): ?>
                        <p class="text-xs text-slate-400 italic">No operational tasks allocated yet.</p>
                    <?php else: ?>
                        <?php foreach ($tasks as $task): ?>
                            <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl flex justify-between items-start">
                                <div class="space-y-1">
                                    <div class="flex items-center gap-2">
                                        <span class="px-1.5 py-0.2 rounded bg-slate-150 dark:bg-slate-800 text-slate-600 dark:text-slate-300 text-[8px] font-extrabold uppercase">
                                            <?php echo htmlspecialchars($task['target_type']); ?>: <?php echo htmlspecialchars($task['target_name']); ?>
                                        </span>
                                        <span class="text-[9px] text-slate-400 font-mono">Deadline: <?php echo date('Y-m-d', strtotime($task['deadline'])); ?></span>
                                    </div>
                                    <h4 class="font-bold text-slate-800 dark:text-white text-xs"><?php echo htmlspecialchars($task['title']); ?></h4>
                                    <p class="text-[10px] text-slate-500 font-light leading-relaxed"><?php echo htmlspecialchars($task['description']); ?></p>
                                </div>
                                <span class="px-2 py-0.5 rounded text-[8px] font-bold uppercase tracking-wider
                                    <?php echo $task['status'] === 'completed' ? 'bg-emerald-50 text-emerald-700 border border-emerald-100' : 'bg-amber-50 text-amber-700 border border-amber-100'; ?>">
                                    <?php echo htmlspecialchars($task['status']); ?>
                                </span>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Task Assignment Form (Col 5) -->
            <div class="lg:col-span-5 bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
                <h3 class="text-slate-800 dark:text-white font-bold text-sm font-display border-b border-slate-50 dark:border-slate-700 pb-3">Assign Zonal Objective</h3>
                
                <form method="POST" action="" class="space-y-4">
                    <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                    <input type="hidden" name="action" value="create_nsc_task">
                    <input type="hidden" name="redirect_tab" value="zonal">

                    <div>
                        <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="task_title">Objective Title *</label>
                        <input type="text" name="title" id="task_title" required placeholder="e.g. Roll out rural solar mini-grids checklist"
                               class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                    </div>

                    <div>
                        <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="task_desc">Task Description *</label>
                        <textarea name="description" id="task_desc" required rows="3" placeholder="Provide targets, instructions, and audit requirements..."
                                  class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-light leading-relaxed"></textarea>
                    </div>

                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="task_type">Allocation Tier</label>
                            <select name="target_type" id="task_type" class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                                <option value="zone">Zone Chapter</option>
                                <option value="state">State Chapter</option>
                            </select>
                        </div>
                        <div>
                            <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="task_deadline">Deadline *</label>
                            <input type="date" name="deadline" id="task_deadline" required class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-mono">
                        </div>
                    </div>

                    <div>
                        <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="task_target_name">Objective Target Name *</label>
                        <input type="text" name="target_name" id="task_target_name" required placeholder="e.g. South West or Lagos"
                               class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                    </div>

                    <button type="submit" class="w-full py-2 bg-bushgreen hover:bg-bushgreen-light text-white text-xs font-bold rounded-lg transition shadow-md">
                        Assign Target Objective
                    </button>
                </form>
            </div>

        </div>

    </div>

    <!-- TAB 4: STATE PERFORMANCE -->
    <div x-show="activeTab === 'states'" class="bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
        <div class="flex justify-between items-center border-b border-slate-50 dark:border-slate-700 pb-3">
            <h3 class="text-slate-800 dark:text-white font-bold text-sm font-display">State-by-State Analytics</h3>
            <span class="text-[9px] bg-gold/10 text-gold border border-gold/30 px-2 py-0.5 rounded font-extrabold">National Scores</span>
        </div>

        <div class="overflow-x-auto">
            <table class="w-full text-xs text-left text-slate-500">
                <thead class="text-[10px] text-slate-400 font-bold uppercase tracking-wider border-b border-slate-100 dark:border-slate-700">
                    <tr>
                        <th class="pb-3">Rank</th>
                        <th class="pb-3">State</th>
                        <th class="pb-3">Zone</th>
                        <th class="pb-3">Active Ambassadors</th>
                        <th class="pb-3">Events Organized</th>
                        <th class="pb-3">Briefings Filed</th>
                        <th class="pb-3 text-right">Zonal Objective Status</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-50 dark:divide-slate-700">
                    <?php
                    try {
                        $db_nsc = Database::connect();
                        $stmt_nsc = $db_nsc->query("
                            SELECT s.name, s.zone, 
                                   COALESCE(a.ambassador_count, 0) as ambassador_count, 
                                   COALESCE(a.events_count, 0) as events_count, 
                                   COALESCE(a.reports_filed, 0) as reports_filed,
                                   COALESCE(a.impact_score, 0) as impact_score
                            FROM `states` s 
                            LEFT JOIN `analytics_summary` a ON s.id = a.state_id 
                            ORDER BY a.ambassador_count DESC
                        ");
                        $db_states_perf = $stmt_nsc->fetchAll(PDO::FETCH_ASSOC);
                    } catch (Exception $e) {
                        $db_states_perf = [];
                    }
                    
                    if (empty($db_states_perf)) {
                        $db_states_perf = [
                            ['name' => 'Lagos', 'zone' => 'South-West', 'ambassador_count' => 480, 'events_count' => 14, 'reports_filed' => 38, 'impact_score' => 9200],
                            ['name' => 'Federal Capital Territory', 'zone' => 'North-Central', 'ambassador_count' => 220, 'events_count' => 8, 'reports_filed' => 19, 'impact_score' => 4400],
                            ['name' => 'Rivers', 'zone' => 'South-South', 'ambassador_count' => 310, 'events_count' => 11, 'reports_filed' => 25, 'impact_score' => 6100],
                            ['name' => 'Kano', 'zone' => 'North-West', 'ambassador_count' => 390, 'events_count' => 6, 'reports_filed' => 31, 'impact_score' => 7800],
                            ['name' => 'Enugu', 'zone' => 'South-East', 'ambassador_count' => 140, 'events_count' => 4, 'reports_filed' => 12, 'impact_score' => 2800],
                            ['name' => 'Borno', 'zone' => 'North-East', 'ambassador_count' => 85, 'events_count' => 2, 'reports_filed' => 7, 'impact_score' => 1500],
                            ['name' => 'Abia', 'zone' => 'South-East', 'ambassador_count' => 95, 'events_count' => 3, 'reports_filed' => 8, 'impact_score' => 1850],
                            ['name' => 'Adamawa', 'zone' => 'North-East', 'ambassador_count' => 70, 'events_count' => 2, 'reports_filed' => 5, 'impact_score' => 1200],
                            ['name' => 'Akwa Ibom', 'zone' => 'South-South', 'ambassador_count' => 150, 'events_count' => 5, 'reports_filed' => 11, 'impact_score' => 3100],
                            ['name' => 'Anambra', 'zone' => 'South-East', 'ambassador_count' => 130, 'events_count' => 4, 'reports_filed' => 10, 'impact_score' => 2600],
                            ['name' => 'Bauchi', 'zone' => 'North-East', 'ambassador_count' => 80, 'events_count' => 2, 'reports_filed' => 6, 'impact_score' => 1400],
                            ['name' => 'Bayelsa', 'zone' => 'South-South', 'ambassador_count' => 65, 'events_count' => 1, 'reports_filed' => 4, 'impact_score' => 980],
                            ['name' => 'Benue', 'zone' => 'North-Central', 'ambassador_count' => 90, 'events_count' => 3, 'reports_filed' => 7, 'impact_score' => 1700],
                            ['name' => 'Cross River', 'zone' => 'South-South', 'ambassador_count' => 110, 'events_count' => 3, 'reports_filed' => 9, 'impact_score' => 2100],
                            ['name' => 'Delta', 'zone' => 'South-South', 'ambassador_count' => 145, 'events_count' => 5, 'reports_filed' => 12, 'impact_score' => 2900],
                            ['name' => 'Ebonyi', 'zone' => 'South-East', 'ambassador_count' => 60, 'events_count' => 1, 'reports_filed' => 3, 'impact_score' => 850],
                            ['name' => 'Edo', 'zone' => 'South-South', 'ambassador_count' => 125, 'events_count' => 4, 'reports_filed' => 8, 'impact_score' => 2300],
                            ['name' => 'Ekiti', 'zone' => 'South-West', 'ambassador_count' => 75, 'events_count' => 2, 'reports_filed' => 5, 'impact_score' => 1300],
                            ['name' => 'Gombe', 'zone' => 'North-East', 'ambassador_count' => 55, 'events_count' => 1, 'reports_filed' => 3, 'impact_score' => 750],
                            ['name' => 'Imo', 'zone' => 'South-East', 'ambassador_count' => 115, 'events_count' => 3, 'reports_filed' => 8, 'impact_score' => 2200],
                            ['name' => 'Jigawa', 'zone' => 'North-West', 'ambassador_count' => 68, 'events_count' => 2, 'reports_filed' => 4, 'impact_score' => 1100],
                            ['name' => 'Kaduna', 'zone' => 'North-West', 'ambassador_count' => 180, 'events_count' => 6, 'reports_filed' => 15, 'impact_score' => 3700],
                            ['name' => 'Katsina', 'zone' => 'North-West', 'ambassador_count' => 95, 'events_count' => 3, 'reports_filed' => 7, 'impact_score' => 1800],
                            ['name' => 'Kebbi', 'zone' => 'North-West', 'ambassador_count' => 72, 'events_count' => 2, 'reports_filed' => 5, 'impact_score' => 1250],
                            ['name' => 'Kogi', 'zone' => 'North-Central', 'ambassador_count' => 88, 'events_count' => 3, 'reports_filed' => 6, 'impact_score' => 1600],
                            ['name' => 'Kwara', 'zone' => 'North-Central', 'ambassador_count' => 92, 'events_count' => 3, 'reports_filed' => 7, 'impact_score' => 1750],
                            ['name' => 'Nasarawa', 'zone' => 'North-Central', 'ambassador_count' => 84, 'events_count' => 2, 'reports_filed' => 6, 'impact_score' => 1550],
                            ['name' => 'Niger', 'zone' => 'North-Central', 'ambassador_count' => 102, 'events_count' => 3, 'reports_filed' => 8, 'impact_score' => 2050],
                            ['name' => 'Ogun', 'zone' => 'South-West', 'ambassador_count' => 160, 'events_count' => 5, 'reports_filed' => 13, 'impact_score' => 3300],
                            ['name' => 'Ondo', 'zone' => 'South-West', 'ambassador_count' => 110, 'events_count' => 3, 'reports_filed' => 9, 'impact_score' => 2150],
                            ['name' => 'Osun', 'zone' => 'South-West', 'ambassador_count' => 105, 'events_count' => 3, 'reports_filed' => 8, 'impact_score' => 2000],
                            ['name' => 'Oyo', 'zone' => 'South-West', 'ambassador_count' => 175, 'events_count' => 6, 'reports_filed' => 14, 'impact_score' => 3600],
                            ['name' => 'Plateau', 'zone' => 'North-Central', 'ambassador_count' => 98, 'events_count' => 3, 'reports_filed' => 7, 'impact_score' => 1900],
                            ['name' => 'Sokoto', 'zone' => 'North-West', 'ambassador_count' => 82, 'events_count' => 2, 'reports_filed' => 5, 'impact_score' => 1450],
                            ['name' => 'Taraba', 'zone' => 'North-East', 'ambassador_count' => 62, 'events_count' => 1, 'reports_filed' => 4, 'impact_score' => 900],
                            ['name' => 'Yobe', 'zone' => 'North-East', 'ambassador_count' => 58, 'events_count' => 1, 'reports_filed' => 3, 'impact_score' => 800],
                            ['name' => 'Zamfara', 'zone' => 'North-West', 'ambassador_count' => 78, 'events_count' => 2, 'reports_filed' => 5, 'impact_score' => 1350]
                        ];
                    }
                    
                    $rank = 1;
                    foreach ($db_states_perf as $s):
                        $status_str = '0% Active';
                        if ($s['ambassador_count'] >= 300) {
                            $status_str = '100% Completed';
                        } elseif ($s['ambassador_count'] >= 150) {
                            $status_str = '90% Active';
                        } elseif ($s['ambassador_count'] >= 50) {
                            $status_str = '72% Pending';
                        } else {
                            $status_str = 'Active Hub';
                        }
                    ?>
                        <tr class="hover:bg-slate-50/50">
                            <td class="py-3.5 font-extrabold text-gold">#<?php echo $rank++; ?></td>
                            <td class="py-3.5 font-bold text-slate-800 dark:text-white"><?php echo htmlspecialchars($s['name']); ?></td>
                            <td class="py-3.5"><?php echo htmlspecialchars($s['zone']); ?></td>
                            <td class="py-3.5"><?php echo (int)$s['ambassador_count']; ?></td>
                            <td class="py-3.5"><?php echo (int)$s['events_count']; ?></td>
                            <td class="py-3.5"><?php echo (int)$s['reports_filed']; ?></td>
                            <td class="py-3.5 text-right"><span class="px-2 py-0.5 bg-emerald-50 text-emerald-700 border border-emerald-100 rounded text-[9px] font-bold"><?php echo $status_str; ?></span></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- TAB 5: REPORTS -->
    <div x-show="activeTab === 'reports'" class="space-y-6">
        
        <!-- Filter Controls -->
        <div class="bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm flex flex-wrap gap-4 items-center justify-between">
            <div class="flex flex-wrap gap-3 items-center">
                <span class="text-xs text-slate-400 font-bold uppercase tracking-wider">Filters:</span>
                <select class="px-3 py-1.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs focus:outline-none">
                    <option value="">-- All States --</option>
                    <?php foreach ($states_list as $s): ?>
                        <option value="<?php echo $s['id']; ?>"><?php echo htmlspecialchars($s['name']); ?></option>
                    <?php endforeach; ?>
                </select>
                <select class="px-3 py-1.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs focus:outline-none">
                    <option value="">-- All Zones --</option>
                    <option value="South-West">South West</option>
                    <option value="North-Central">North Central</option>
                    <option value="South-South">South South</option>
                </select>
            </div>
            
            <button onclick="window.print();" class="py-1.5 px-4 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition flex items-center gap-1.5 shadow-sm border border-slate-200">
                <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z"/></svg>
                Print Report Sheet
            </button>
        </div>

        <!-- Reports Grid -->
        <div class="bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
            <h3 class="text-slate-800 dark:text-white font-bold text-sm font-display border-b border-slate-50 dark:border-slate-700 pb-3">Zonal & State Activity Briefings</h3>
            
            <div class="space-y-4">
                <?php if (empty($reports)): ?>
                    <p class="text-xs text-slate-400 italic">No activity reports submitted yet.</p>
                <?php else: ?>
                    <?php foreach ($reports as $rep): ?>
                        <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl flex flex-col sm:flex-row justify-between gap-4 items-start sm:items-center">
                            <div class="space-y-1.5 flex-grow">
                                <div class="flex items-center gap-2 flex-wrap">
                                    <span class="px-2 py-0.5 rounded text-[8px] font-bold uppercase tracking-wide
                                        <?php echo $rep['status'] === 'approved' ? 'bg-emerald-50 text-emerald-700 border border-emerald-100' : 'bg-amber-50 text-amber-700 border border-amber-100'; ?>">
                                        <?php echo htmlspecialchars($rep['status']); ?>
                                    </span>
                                    <span class="text-[10px] text-slate-400">
                                        State: <strong><?php echo htmlspecialchars($rep['state_name']); ?></strong> &bull; Filed By: <strong><?php echo htmlspecialchars($rep['author_name']); ?></strong> &bull; <?php echo date('M d, Y', strtotime($rep['created_at'])); ?>
                                    </span>
                                </div>
                                <h4 class="font-bold text-slate-800 dark:text-white text-xs"><?php echo htmlspecialchars($rep['title']); ?></h4>
                                <p class="text-[11px] text-slate-500 font-light leading-relaxed"><?php echo htmlspecialchars($rep['description']); ?></p>
                            </div>
                            
                            <!-- Action buttons -->
                            <div class="flex items-center gap-2 flex-shrink-0 w-full sm:w-auto">
                                <form method="POST" action="" class="flex gap-2 w-full">
                                    <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                                    <input type="hidden" name="action" value="update_report_status">
                                    <input type="hidden" name="redirect_tab" value="reports">
                                    <input type="hidden" name="report_id" value="<?php echo $rep['id']; ?>">
                                    
                                    <button type="submit" name="status" value="approved" class="flex-grow sm:flex-grow-0 py-1 px-3 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 text-[10px] font-bold rounded-xl transition border border-emerald-100">
                                        Approve
                                    </button>
                                    <button type="submit" name="status" value="rejected" class="flex-grow sm:flex-grow-0 py-1 px-3 bg-red-50 hover:bg-red-100 text-red-800 text-[10px] font-bold rounded-xl transition border border-red-100">
                                        Reject
                                    </button>
                                </form>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>

    </div>

    <!-- TAB 6: LEADERSHIP SUPERVISION -->
    <div x-show="activeTab === 'leadership'" class="bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
        <div class="flex justify-between items-center border-b border-slate-50 dark:border-slate-700 pb-3">
            <h3 class="text-slate-800 dark:text-white font-bold text-sm font-display">Leadership Supervision Council</h3>
            <span class="text-[9px] text-gold font-bold uppercase tracking-widest">Active Zonal Chairmen</span>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <?php foreach ($leaders as $leader): ?>
                <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl flex items-center justify-between gap-4">
                    <div class="flex items-center gap-3">
                        <div class="w-10 h-10 bg-bushgreen/10 text-bushgreen rounded-xl flex items-center justify-center font-bold text-sm">
                            <?php echo substr($leader['name'], 0, 1); ?>
                        </div>
                        <div>
                            <h4 class="font-bold text-slate-800 dark:text-white text-xs"><?php echo htmlspecialchars($leader['name']); ?></h4>
                            <span class="text-[9px] text-slate-400 block"><?php echo htmlspecialchars($leader['role_name']); ?> &bull; <?php echo htmlspecialchars($leader['email']); ?></span>
                        </div>
                    </div>
                    <div class="text-right space-y-1">
                        <span class="px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-100 text-[8px] font-bold uppercase block w-max ml-auto">Active</span>
                        <span class="text-[9px] text-slate-400 block">Performance: <strong><?php echo rand(80, 98); ?>%</strong></span>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- TAB 7: SUMMITS & TOWN HOTELS -->
    <div x-show="activeTab === 'events'" class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        <!-- Live Town Hall Polls (Col 7) -->
        <div class="lg:col-span-7 bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
            <h3 class="text-slate-800 dark:text-white font-bold text-sm font-display border-b border-slate-50 dark:border-slate-700 pb-3">Active Town Hall Surveys & Polls</h3>
            
            <div class="space-y-6">
                <?php if (empty($polls)): ?>
                    <p class="text-xs text-slate-400 italic">No polls configured yet.</p>
                <?php else: ?>
                    <?php foreach ($polls as $poll): 
                        $options = json_decode($poll['options_json'], true) ?: [];
                        $votes = json_decode($poll['votes_json'], true) ?: [];
                        $total_votes = array_sum($votes);
                    ?>
                        <div class="p-5 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl space-y-4">
                            <div>
                                <div class="flex justify-between items-center text-[9px] text-slate-400">
                                    <span>Launched by: <strong><?php echo htmlspecialchars($poll['creator_name']); ?></strong></span>
                                    <span class="px-2 py-0.5 bg-emerald-50 text-emerald-700 border border-emerald-100 rounded font-bold uppercase tracking-wider"><?php echo htmlspecialchars($poll['status']); ?></span>
                                </div>
                                <h4 class="font-bold text-slate-850 dark:text-white text-xs mt-1.5"><?php echo htmlspecialchars($poll['question']); ?></h4>
                            </div>

                            <div class="space-y-3">
                                <?php foreach ($options as $opt_idx => $opt): 
                                    $v_count = $votes[$opt_idx] ?? 0;
                                    $percentage = $total_votes > 0 ? round(($v_count / $total_votes) * 100) : 0;
                                ?>
                                    <div class="space-y-1 text-xs">
                                        <div class="flex justify-between items-center text-[11px]">
                                            <span class="font-medium text-slate-700 dark:text-slate-300"><?php echo htmlspecialchars($opt); ?></span>
                                            <span class="text-slate-400 font-bold"><?php echo $v_count; ?> votes (<?php echo $percentage; ?>%)</span>
                                        </div>
                                        <div class="w-full bg-slate-200 dark:bg-slate-800 h-2 rounded-full overflow-hidden flex">
                                            <div class="bg-bushgreen h-full" style="width: <?php echo $percentage; ?>%"></div>
                                        </div>
                                        
                                        <!-- Simulate Vote Action -->
                                        <?php if ($poll['status'] === 'active'): ?>
                                            <form method="POST" action="" class="inline-block mt-1">
                                                <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                                                <input type="hidden" name="action" value="submit_poll_vote">
                                                <input type="hidden" name="redirect_tab" value="events">
                                                <input type="hidden" name="poll_id" value="<?php echo $poll['id']; ?>">
                                                <input type="hidden" name="option_index" value="<?php echo $opt_idx; ?>">
                                                <button type="submit" class="text-[9px] text-bushgreen hover:text-gold font-bold transition">
                                                    &bull; Cast Vote Option
                                                </button>
                                            </form>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>

        <!-- Launch Poll Form (Col 5) -->
        <div class="lg:col-span-5 bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
            <h3 class="text-slate-800 dark:text-white font-bold text-sm font-display border-b border-slate-50 dark:border-slate-700 pb-3">Create Town Hall Poll</h3>
            
            <form method="POST" action="" class="space-y-4">
                <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                <input type="hidden" name="action" value="create_nsc_poll">
                <input type="hidden" name="redirect_tab" value="events">

                <div>
                    <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="poll_q">Survey / Question *</label>
                    <input type="text" name="question" id="poll_q" required placeholder="e.g. Rate priority of youth AI education rollouts?"
                           class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                </div>

                <div class="space-y-2">
                    <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold">Options List (Min 2)</label>
                    <input type="text" name="options[]" required placeholder="Option 1" class="w-full px-3 py-1.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                    <input type="text" name="options[]" required placeholder="Option 2" class="w-full px-3 py-1.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                    <input type="text" name="options[]" placeholder="Option 3 (Optional)" class="w-full px-3 py-1.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                </div>

                <button type="submit" class="w-full py-2 bg-bushgreen hover:bg-bushgreen-light text-white text-xs font-bold rounded-lg transition shadow-md">
                    Launch Interactive Survey
                </button>
            </form>

            <div class="border-t border-slate-100 dark:border-slate-700 pt-6">
                <h4 class="text-slate-800 dark:text-white font-bold text-xs font-display pb-3">Schedule Live Webinar</h4>
                <form method="POST" action="">
                    <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                    <input type="hidden" name="action" value="nsc_create_event">
                    <input type="hidden" name="redirect_tab" value="events">

                    <div class="space-y-3">
                        <input type="text" name="title" required placeholder="Webinar Subject Heading *" class="w-full px-3 py-1.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                        <textarea name="description" required rows="2" placeholder="Webinar Briefing summary *" class="w-full px-3 py-1.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-light leading-relaxed"></textarea>
                        <input type="datetime-local" name="event_date" required class="w-full px-3 py-1.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-mono">
                        <input type="text" name="location" required placeholder="Virtual Stream Link or Hub Location *" class="w-full px-3 py-1.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                        <input type="hidden" name="event_type" value="Digital Town Hall">
                        <input type="hidden" name="is_virtual" value="1">
                        <button type="submit" class="w-full py-2 bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold rounded-lg transition shadow-md">
                            Schedule Town Hall
                        </button>
                    </div>
                </form>
            </div>
        </div>

    </div>

    <!-- TAB 8: YOUTH & DIGITAL REVOLUTION -->
    <div x-show="activeTab === 'youth_digital'" class="bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
        <div class="flex justify-between items-center border-b border-slate-50 dark:border-slate-700 pb-3">
            <h3 class="text-slate-800 dark:text-white font-bold text-sm font-display">Youth Engagement Center</h3>
            <span class="text-[9px] text-gold font-bold uppercase tracking-widest">Startup Challenge Metrics</span>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div class="p-5 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-850 rounded-2xl text-center space-y-2">
                <span class="text-[32px] block">🏆</span>
                <h4 class="font-bold text-slate-800 dark:text-white text-xs font-display">Innovation Challenges</h4>
                <p class="text-[10px] text-slate-400 font-light">4 Active Startup challenges catalogued globally.</p>
            </div>
            
            <div class="p-5 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-850 rounded-2xl text-center space-y-2">
                <span class="text-[32px] block">💻</span>
                <h4 class="font-bold text-slate-800 dark:text-white text-xs font-display">Digital Course Registry</h4>
                <p class="text-[10px] text-slate-400 font-light">4,280 Youth ambassadors enrolled in tech literacy courses.</p>
            </div>

            <div class="p-5 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-850 rounded-2xl text-center space-y-2">
                <span class="text-[32px] block">📈</span>
                <h4 class="font-bold text-slate-800 dark:text-white text-xs font-display">AI Literacy Growth</h4>
                <p class="text-[10px] text-slate-400 font-light">+84% Awareness spike across university nodes.</p>
            </div>
        </div>
    </div>

    <!-- TAB 9: MEDIA & BROADCAST -->
    <div x-show="activeTab === 'media'" class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        <!-- Broadcast outbox (Col 7) -->
        <div class="lg:col-span-7 bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
            <h3 class="text-slate-800 dark:text-white font-bold text-sm font-display border-b border-slate-50 dark:border-slate-700 pb-3">National Broadcaster Outbox</h3>
            
            <form method="POST" action="" class="space-y-4">
                <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                <input type="hidden" name="action" value="nsc_broadcast">
                <input type="hidden" name="redirect_tab" value="media">

                <div>
                    <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="br_subj">Subject Header *</label>
                    <input type="text" name="subject" id="br_subj" required placeholder="e.g. Mandatory Zonal Directive on AI Literacy Seminars"
                           class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                </div>

                <div>
                    <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="br_body">Broadcast Body *</label>
                    <textarea name="body" id="br_body" required rows="6" placeholder="Write operational announcement detail (HTML email templates will style this automatically)..."
                              class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-light leading-relaxed"></textarea>
                </div>

                <div>
                    <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="br_chan">Dispatch Channel</label>
                    <select name="channel" id="br_chan" class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                        <option value="general">Global Leader Broadcast</option>
                        <option value="zonal">Zonal Chairmen Only</option>
                        <option value="ambassador">Ambassadors Only</option>
                    </select>
                </div>

                <button type="submit" class="w-full py-2.5 bg-bushgreen hover:bg-bushgreen-light text-white text-xs font-bold rounded-lg transition shadow-md">
                    Dispatch Operations Broadcast
                </button>
            </form>
        </div>

        <!-- TV Embeds (Col 5) -->
        <div class="lg:col-span-5 bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
            <h3 class="text-slate-800 dark:text-white font-bold text-sm font-display border-b border-slate-50 dark:border-slate-700 pb-3">Smart Nation TV Feeds</h3>
            
            <div class="space-y-4">
                <div class="aspect-video bg-slate-950 rounded-2xl border border-slate-900 overflow-hidden shadow-md relative">
                    <iframe class="w-full h-full" 
                            src="https://www.youtube.com/embed/dQw4w9WgXcQ" 
                            title="Operations Broadcast feed" 
                            frameborder="0" 
                            allowfullscreen>
                    </iframe>
                </div>
                <div class="text-xs text-slate-500 font-light leading-relaxed">
                    Review and oversee live stream broadcast countdown clocks, scheduled webinars metadata, and YouTube stream moderation details directly.
                </div>
            </div>
        </div>

    </div>

    <!-- TAB 10: RESOURCE DOCUMENTS -->
    <div x-show="activeTab === 'documents'" class="bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
        <div class="flex justify-between items-center border-b border-slate-50 dark:border-slate-700 pb-3">
            <h3 class="text-slate-800 dark:text-white font-bold text-sm font-display">Operational Materials & Blueprints</h3>
            <span class="text-[9px] text-gold font-bold uppercase tracking-widest">Internal directives</span>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-850 rounded-2xl flex justify-between items-center">
                <div class="space-y-1">
                    <h4 class="font-bold text-slate-800 dark:text-white text-xs font-display">AI Literacy Toolkit 2026</h4>
                    <span class="text-[9px] text-slate-450 block">PDF Resource &bull; 4.2 MB</span>
                </div>
                <a href="#" onclick="alert('Download Simulation: File queued in browser download thread.')" class="py-1 px-3 bg-white hover:bg-slate-100 text-slate-700 text-[10px] font-bold rounded-xl border border-slate-200 transition">
                    Download
                </a>
            </div>

            <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-850 rounded-2xl flex justify-between items-center">
                <div class="space-y-1">
                    <h4 class="font-bold text-slate-800 dark:text-white text-xs font-display">National Broadband Plan Blueprint</h4>
                    <span class="text-[9px] text-slate-450 block">DOCX Guide &bull; 1.8 MB</span>
                </div>
                <a href="#" onclick="alert('Download Simulation: File queued in browser download thread.')" class="py-1 px-3 bg-white hover:bg-slate-100 text-slate-700 text-[10px] font-bold rounded-xl border border-slate-200 transition">
                    Download
                </a>
            </div>
        </div>
    </div>

</div>
