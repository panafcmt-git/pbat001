<?php
/**
 * Founder Circle Command Portal (Role 2)
 * Executive strategic national oversight, vision roadmap planning, and leadership controls.
 */
if (!defined('DB_HOST')) {
    exit('Access Denied');
}

$active_tab = $_GET['tab'] ?? 'overview';

// Helper to query lists from new Founder Circle tables
try {
    $db = Database::connect();
    
    // Fetch visions
    $visions = $db->query("SELECT v.*, u.name as author_name FROM `founder_visions` v JOIN `users` u ON v.created_by = u.id ORDER BY v.created_at DESC")->fetchAll();
    
    // Fetch partnerships
    $partnerships = $db->query("SELECT * FROM `founder_partnerships` ORDER BY created_at DESC")->fetchAll();
    
    // Fetch thinktank ideas
    $thinktank = $db->query("SELECT t.*, u.name as author_name FROM `founder_thinktank` t JOIN `users` u ON t.user_id = u.id ORDER BY t.created_at DESC")->fetchAll();
    
    // Fetch awards
    $awards = $db->query("SELECT a.*, u1.name as recipient_name, u2.name as granter_name FROM `founder_awards` a JOIN `users` u1 ON a.recipient_id = u1.id JOIN `users` u2 ON a.granted_by = u2.id ORDER BY a.granted_at DESC")->fetchAll();
    
    // Fetch expansion
    $expansion = $db->query("SELECT ex.*, s.name as state_name, u.name as head_name FROM `founder_expansion` ex JOIN `states` s ON ex.state_id = s.id LEFT JOIN `users` u ON ex.regional_head_id = u.id ORDER BY ex.target_date ASC")->fetchAll();
    
    // Fetch executive notes
    $notes = $db->prepare("SELECT n.*, u.name as author_name FROM `founder_notes` n JOIN `users` u ON n.created_by = u.id WHERE n.created_by = ? ORDER BY n.created_at DESC");
    $notes->execute([$user_id]);
    $notes_list = $notes->fetchAll();
    
    // Fetch campaigns for oversight
    $campaigns = $db->query("SELECT c.*, u.name as leader_name, ca.reach_count, ca.engagement_rate FROM `campaigns` c LEFT JOIN `users` u ON c.leader_id = u.id LEFT JOIN `campaign_analytics` ca ON c.id = ca.campaign_id ORDER BY c.scheduled_at ASC")->fetchAll();
    
    // Fetch leaders for dropdowns / approvals (role_id 3, 4, 5, 6)
    $leaders = $db->query("SELECT id, name, email, status, role_id FROM `users` WHERE `role_id` BETWEEN 3 AND 6 ORDER BY name ASC")->fetchAll();
    
    // Fetch ambassadors for award assignments
    $ambassadors_list = $db->query("SELECT u.id, u.name FROM `users` u WHERE u.role_id = 7 ORDER BY u.name ASC")->fetchAll();

    // Fetch upcoming events for Town Halls
    $events = $db->query("SELECT e.*, u.name as author_name FROM `events` e JOIN `users` u ON e.created_by = u.id ORDER BY e.event_date ASC")->fetchAll();
    
    // Fetch livestreams
    $livestreams = $db->query("SELECT l.*, u.name as author_name FROM `livestreams` l JOIN `users` u ON l.created_by = u.id ORDER BY l.scheduled_at ASC")->fetchAll();

    // Calculate dynamic stats
    $total_sponsors = count($partnerships);
    $total_funding = array_sum(array_column($partnerships, 'sponsor_amount'));
    $total_notes = count($notes_list);

} catch (Exception $e) {
    $visions = [];
    $partnerships = [];
    $thinktank = [];
    $awards = [];
    $expansion = [];
    $notes_list = [];
    $campaigns = [];
    $leaders = [];
    $ambassadors_list = [];
    $events = [];
    $livestreams = [];
    $total_sponsors = 0;
    $total_funding = 0.0;
    $total_notes = 0;
}
?>

<!-- Executive Strategic Command Wrapper -->
<div class="space-y-8" x-data="{ currentTab: '<?php echo htmlspecialchars($active_tab); ?>' }">

    <!-- CURVED VISIONARY GLOW BANNER -->
    <div class="bg-gradient-to-r from-bushgreen-dark via-bushgreen to-bushgreen-light text-white p-8 rounded-3xl shadow-xl relative overflow-hidden border-2 border-gold/30">
        <div class="absolute inset-0 bg-cover bg-center mix-blend-overlay opacity-15 bg-[url('https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=800&q=80')]"></div>
        <div class="relative z-10 flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
            <div class="space-y-3">
                <span class="px-2.5 py-1 bg-gold/25 text-gold border border-gold/35 rounded-full text-[9px] font-black uppercase tracking-widest leading-none font-display inline-block animate-pulse">
                    🎖 Verified Founder Hub
                </span>
                <h2 class="text-2xl sm:text-3xl font-black font-display leading-tight text-white tracking-tight">National Directorate & Sovereign Council</h2>
                <p class="text-slate-350 text-xs font-light max-w-xl leading-relaxed">
                    Welcome, Founder. Oversee strategic campaigns, recommend leadership tiers, draft tech policy directions, and inspect real-time digital impact maps.
                </p>
            </div>
            <!-- Dynamic Mini Quick Stats -->
            <div class="flex gap-4">
                <div class="px-4 py-2.5 bg-white/5 border border-white/10 rounded-2xl backdrop-blur text-center min-w-[100px]">
                    <div class="text-lg font-black text-gold font-mono"><?php echo count($campaigns); ?></div>
                    <div class="text-[8px] uppercase tracking-wider text-slate-400 font-bold">Campaigns</div>
                </div>
                <div class="px-4 py-2.5 bg-white/5 border border-white/10 rounded-2xl backdrop-blur text-center min-w-[100px]">
                    <div class="text-lg font-black text-gold font-mono">₦<?php echo number_format($total_funding / 1000000, 1); ?>M</div>
                    <div class="text-[8px] uppercase tracking-wider text-slate-400 font-bold">Donor Funds</div>
                </div>
            </div>
        </div>
    </div>

    <!-- 1️⃣ TAB CONTENT: STRATEGIC OVERVIEW -->
    <div class="space-y-8" x-show="currentTab === 'overview'">
        <!-- Analytics summary tiles -->
        <div class="grid grid-cols-1 sm:grid-cols-4 gap-6">
            <div class="bg-white dark:bg-slate-800 p-6 rounded-2xl border border-slate-100 dark:border-slate-700 shadow-sm flex items-center justify-between transition hover:shadow-md">
                <div class="space-y-1">
                    <span class="text-slate-400 dark:text-slate-500 text-[10px] font-bold uppercase tracking-wider block">National Reach</span>
                    <div class="text-3xl font-black text-bushgreen dark:text-gold font-display"><?php echo number_format($total_ambassadors); ?></div>
                    <span class="text-[9px] text-emerald-600 font-bold bg-emerald-50 dark:bg-emerald-950/20 px-2 py-0.5 rounded">Active Chapters</span>
                </div>
                <div class="w-12 h-12 rounded-xl bg-bushgreen/5 dark:bg-gold/5 flex items-center justify-center text-bushgreen dark:text-gold"><svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"/></svg></div>
            </div>
            <div class="bg-white dark:bg-slate-800 p-6 rounded-2xl border border-slate-100 dark:border-slate-700 shadow-sm flex items-center justify-between transition hover:shadow-md">
                <div class="space-y-1">
                    <span class="text-slate-400 dark:text-slate-500 text-[10px] font-bold uppercase tracking-wider block">Smart Nation TV</span>
                    <div class="text-3xl font-black text-bushgreen dark:text-gold font-display"><?php echo count($livestreams); ?></div>
                    <span class="text-[9px] text-slate-400 dark:text-slate-500 font-light block">Scheduled broadcasts</span>
                </div>
                <div class="w-12 h-12 rounded-xl bg-bushgreen/5 dark:bg-gold/5 flex items-center justify-center text-bushgreen dark:text-gold"><svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 4v16M17 4v16M3 8h4m10 0h4M3 12h18M3 16h4m10 0h4M4 20h16a1 1 0 001-1V5a1 1 0 00-1-1H4a1 1 0 00-1 1v14a1 1 0 001 1z"/></svg></div>
            </div>
            <div class="bg-white dark:bg-slate-800 p-6 rounded-2xl border border-slate-100 dark:border-slate-700 shadow-sm flex items-center justify-between transition hover:shadow-md">
                <div class="space-y-1">
                    <span class="text-slate-400 dark:text-slate-500 text-[10px] font-bold uppercase tracking-wider block">Summit Briefings</span>
                    <div class="text-3xl font-black text-bushgreen dark:text-gold font-display"><?php echo count($events); ?></div>
                    <span class="text-[9px] text-slate-400 dark:text-slate-500 font-light block">Total town halls</span>
                </div>
                <div class="w-12 h-12 rounded-xl bg-bushgreen/5 dark:bg-gold/5 flex items-center justify-center text-bushgreen dark:text-gold"><svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2-2v12a2 2 0 002 2z"/></svg></div>
            </div>
            <div class="bg-white dark:bg-slate-800 p-6 rounded-2xl border border-slate-100 dark:border-slate-700 shadow-sm flex items-center justify-between transition hover:shadow-md">
                <div class="space-y-1">
                    <span class="text-slate-400 dark:text-slate-500 text-[10px] font-bold uppercase tracking-wider block">Strategic Partners</span>
                    <div class="text-3xl font-black text-bushgreen dark:text-gold font-display"><?php echo $total_sponsors; ?></div>
                    <span class="text-[9px] text-emerald-600 font-bold bg-emerald-50 dark:bg-emerald-950/20 px-2 py-0.5 rounded">Active Collaborators</span>
                </div>
                <div class="w-12 h-12 rounded-xl bg-bushgreen/5 dark:bg-gold/5 flex items-center justify-center text-bushgreen dark:text-gold"><svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 11c0 3.517-1.009 6.799-2.753 9.571m-3.44-2.04l.054-.09A13.916 13.916 0 009 11.571V11a4 4 0 00-8 0v.571c0 2.232-.693 4.316-1.879 6.037M12 11c0 3.517 1.009 6.799 2.753 9.571m3.44-2.04l-.054-.09A13.916 13.916 0 0015 11.571V11a4 4 0 018 0v.571c0 2.232.693 4.316 1.879 6.037M12 7a4 4 0 11-8 0 4 4 0 018 0zm8 0a4 4 0 11-8 0 4 4 0 018 0z"/></svg></div>
            </div>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-12 gap-8">
            <!-- 🌍 Interactive Zonal Checklists (Heatmap equivalent) -->
            <div class="lg:col-span-8 bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
                <div>
                    <h3 class="text-slate-800 dark:text-slate-200 font-bold text-sm tracking-wide font-display uppercase">National Digital Impact Map</h3>
                    <p class="text-[10px] text-slate-450">Grassroots ambassador distribution index and regional engagement metrics.</p>
                </div>
                <!-- Interactive Map UI (Stylized Vector Checklist Grid) -->
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <?php foreach ($state_data as $sd): 
                        $reach_color = $sd['ambassador_count'] >= 300 ? 'text-gold bg-gold/10 border-gold/30' : 'text-bushgreen bg-bushgreen/5 border-bushgreen/20 dark:text-emerald-400 dark:bg-emerald-950/20';
                        $level_label = $sd['ambassador_count'] >= 300 ? 'High Reach Tier' : 'Medium Reach Tier';
                    ?>
                        <div class="p-4 rounded-xl border border-slate-100 dark:border-slate-700 flex flex-col gap-2">
                            <div class="flex justify-between items-center">
                                <span class="font-bold text-xs text-slate-800 dark:text-slate-200"><?php echo htmlspecialchars($sd['name']); ?> State</span>
                                <span class="px-2 py-0.5 border rounded-full text-[8px] font-bold uppercase <?php echo $reach_color; ?>">
                                    <?php echo $level_label; ?>
                                </span>
                            </div>
                            <div class="grid grid-cols-3 gap-2 text-center pt-1">
                                <div class="p-2 bg-slate-50 dark:bg-slate-900 rounded-lg">
                                    <div class="text-xs font-black text-bushgreen dark:text-gold"><?php echo $sd['ambassador_count']; ?></div>
                                    <div class="text-[7px] text-slate-400 uppercase tracking-widest font-bold">Ambassadors</div>
                                </div>
                                <div class="p-2 bg-slate-50 dark:bg-slate-900 rounded-lg">
                                    <div class="text-xs font-black text-bushgreen dark:text-gold"><?php echo $sd['reports_filed']; ?></div>
                                    <div class="text-[7px] text-slate-400 uppercase tracking-widest font-bold">Reports</div>
                                </div>
                                <div class="p-2 bg-slate-50 dark:bg-slate-900 rounded-lg">
                                    <div class="text-xs font-black text-bushgreen dark:text-gold"><?php echo $sd['events_count']; ?></div>
                                    <div class="text-[7px] text-slate-400 uppercase tracking-widest font-bold">Webinars</div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- 🧠 Smart Insights Engine (AI-predictions) -->
            <div class="lg:col-span-4 space-y-6">
                <div class="bg-gradient-to-br from-bushgreen-dark to-slate-900 text-white rounded-3xl border border-gold/30 p-6 shadow-sm space-y-4">
                    <div class="flex items-center gap-2">
                        <span class="p-1.5 bg-gold/15 border border-gold/30 text-gold rounded-lg">
                            <svg class="w-4 h-4 animate-pulse" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
                        </span>
                        <h3 class="font-bold text-sm font-display tracking-wide uppercase text-gold">Smart Insights Engine</h3>
                    </div>
                    <p class="text-[10px] text-slate-400 font-light leading-relaxed">
                        Machine Learning algorithms analyze live participation vectors and local activity logs.
                    </p>
                    <div class="space-y-3.5 text-xs">
                        <div class="p-3 bg-white/5 border border-white/10 rounded-xl space-y-1">
                            <span class="text-[8px] font-bold uppercase tracking-wider text-slate-400">Enrollment Forecast</span>
                            <div class="font-bold text-white text-xs">Growth predicted: <span class="text-emerald-400 font-mono font-black">+24% Zonal Expansion</span></div>
                        </div>
                        <div class="p-3 bg-white/5 border border-white/10 rounded-xl space-y-1">
                            <span class="text-[8px] font-bold uppercase tracking-wider text-slate-400">Public Sentiment Index</span>
                            <div class="font-bold text-white text-xs">Strong Alignment (<span class="text-gold font-mono font-black">88% positive index</span>)</div>
                        </div>
                        <div class="p-3 bg-white/5 border border-white/10 rounded-xl space-y-1">
                            <span class="text-[8px] font-bold uppercase tracking-wider text-slate-400">Recommended Action</span>
                            <div class="font-light text-slate-300 text-[11px] leading-relaxed">Deploy youth coding hubs in Kano and Borno states next month.</div>
                        </div>
                    </div>
                </div>

                <!-- 📡 Live Strategic Ticker / Feed -->
                <div class="bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-4">
                    <h3 class="text-slate-800 dark:text-slate-200 font-bold text-sm tracking-wide font-display">Live Command Feed</h3>
                    <div class="space-y-3 max-h-[220px] overflow-y-auto pr-1">
                        <div class="p-2.5 bg-slate-50 dark:bg-slate-900 rounded-xl border border-slate-100 dark:border-slate-800 text-[11px] flex flex-col gap-1">
                            <span class="text-[8px] font-bold text-slate-400 block">SYSTEM ACT</span>
                            <p class="text-slate-700 dark:text-slate-350 font-light">Microsoft Africa partnerships credentials established.</p>
                        </div>
                        <div class="p-2.5 bg-slate-50 dark:bg-slate-900 rounded-xl border border-slate-100 dark:border-slate-800 text-[11px] flex flex-col gap-1">
                            <span class="text-[8px] font-bold text-slate-400 block">REPORT FILED</span>
                            <p class="text-slate-700 dark:text-slate-350 font-light">LGA Broadband proposal submitted by state director.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- 2️⃣ TAB CONTENT: CAMPAIGN OVERSIGHT -->
    <div class="space-y-8" x-show="currentTab === 'campaigns'">
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            <div class="lg:col-span-8 bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
                <h3 class="text-slate-800 dark:text-slate-200 font-bold text-sm tracking-wide font-display">Strategic Campaigns Review</h3>
                <div class="space-y-4">
                    <?php if (empty($campaigns)): ?>
                        <p class="text-slate-400 italic text-xs text-center py-6">No scheduled campaigns found.</p>
                    <?php endif; ?>
                    <?php foreach ($campaigns as $camp): ?>
                        <div class="p-4 rounded-xl border border-slate-100 dark:border-slate-700 flex flex-col gap-3">
                            <div class="flex justify-between items-start">
                                <div>
                                    <h4 class="font-bold text-slate-800 dark:text-slate-200 text-xs sm:text-sm"><?php echo htmlspecialchars($camp['title']); ?></h4>
                                    <span class="text-[9px] text-slate-400">Category: <strong class="font-semibold text-slate-600 dark:text-slate-400"><?php echo htmlspecialchars($camp['category']); ?></strong> &bull; Launched: <?php echo date('Y-m-d H:i', strtotime($camp['scheduled_at'])); ?></span>
                                </div>
                                <span class="px-2.5 py-0.5 rounded text-[8px] font-bold uppercase tracking-wide
                                    <?php echo $camp['status'] === 'active' ? 'bg-emerald-50 text-emerald-700 border border-emerald-100' : ($camp['status'] === 'completed' ? 'bg-blue-50 text-blue-700 border border-blue-100' : 'bg-slate-100 text-slate-650 border border-slate-200'); ?>">
                                    <?php echo htmlspecialchars($camp['status']); ?>
                                </span>
                            </div>
                            <p class="text-slate-500 dark:text-slate-400 text-xs font-light leading-relaxed"><?php echo htmlspecialchars($camp['description']); ?></p>
                            
                            <!-- Control Workflow -->
                            <form method="POST" action="" class="flex items-center gap-2 pt-2 border-t border-slate-100 dark:border-slate-700">
                                <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                                <input type="hidden" name="action" value="founder_approve_campaign">
                                <input type="hidden" name="camp_id" value="<?php echo $camp['id']; ?>">
                                <input type="hidden" name="redirect_tab" value="campaigns">
                                
                                <span class="text-[9px] font-bold text-slate-400 uppercase mr-auto">Strategic Action:</span>
                                <?php if ($camp['status'] === 'draft'): ?>
                                    <button type="submit" name="status" value="scheduled" class="py-1 px-3 bg-bushgreen hover:bg-bushgreen-light text-white text-[9px] font-bold rounded uppercase">Approve & Schedule</button>
                                <?php endif; ?>
                                <?php if ($camp['status'] === 'scheduled'): ?>
                                    <button type="submit" name="status" value="active" class="py-1 px-3 bg-emerald-600 hover:bg-emerald-700 text-white text-[9px] font-bold rounded uppercase">Go Live</button>
                                <?php endif; ?>
                                <?php if ($camp['status'] === 'active'): ?>
                                    <button type="submit" name="status" value="completed" class="py-1 px-3 bg-slate-800 hover:bg-slate-900 text-white text-[9px] font-bold rounded uppercase">Mark Completed</button>
                                <?php endif; ?>
                            </form>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Create Strategic Campaign -->
            <div class="lg:col-span-4 bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
                <div>
                    <h3 class="text-slate-800 dark:text-slate-200 font-bold text-sm tracking-wide">Launch Strategic Campaign</h3>
                    <p class="text-[10px] text-slate-400">Deploy high-level movement structures.</p>
                </div>
                <form method="POST" action="" class="space-y-4">
                    <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                    <input type="hidden" name="action" value="founder_create_campaign">
                    <input type="hidden" name="redirect_tab" value="campaigns">

                    <div>
                        <label class="block text-slate-655 dark:text-slate-400 text-xs font-semibold mb-1" for="camp_title">Campaign Title *</label>
                        <input type="text" name="title" id="camp_title" required placeholder="e.g. AI Awareness Summit Week"
                               class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                    </div>
                    <div>
                        <label class="block text-slate-655 dark:text-slate-400 text-xs font-semibold mb-1" for="camp_category">Category *</label>
                        <input type="text" name="category" id="camp_category" required placeholder="e.g. AI Advocacy"
                               class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                    </div>
                    <div>
                        <label class="block text-slate-655 dark:text-slate-400 text-xs font-semibold mb-1" for="camp_leader">Campaign Lead Director</label>
                        <select name="leader_id" id="camp_leader" class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                            <option value="">-- No Leader Assigned --</option>
                            <?php foreach ($leaders as $l): ?>
                                <option value="<?php echo $l['id']; ?>"><?php echo htmlspecialchars($l['name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="block text-slate-655 dark:text-slate-400 text-xs font-semibold mb-1" for="camp_date">Launch Date *</label>
                            <input type="datetime-local" name="scheduled_at" id="camp_date" required class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                        </div>
                        <div>
                            <label class="block text-slate-655 dark:text-slate-400 text-xs font-semibold mb-1" for="camp_status">Initial Status</label>
                            <select name="status" id="camp_status" class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                                <option value="draft">Draft</option>
                                <option value="scheduled">Scheduled</option>
                                <option value="active">Active</option>
                            </select>
                        </div>
                    </div>
                    <div>
                        <label class="block text-slate-655 dark:text-slate-400 text-xs font-semibold mb-1" for="camp_desc">Brief Objectives *</label>
                        <textarea name="description" id="camp_desc" required rows="4" placeholder="Objectives, scope, and key performance guidelines..."
                                  class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen"></textarea>
                    </div>
                    <button type="submit" class="w-full py-2 bg-bushgreen hover:bg-bushgreen-light text-white text-xs font-bold rounded-lg transition shadow-md">
                        Deploy Campaign
                    </button>
                </form>
            </div>
        </div>
    </div>

    <!-- 3️⃣ TAB CONTENT: VISION & POLICY -->
    <div class="space-y-8" x-show="currentTab === 'policy'">
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            <div class="lg:col-span-8 bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
                <h3 class="text-slate-800 dark:text-slate-200 font-bold text-sm tracking-wide font-display">Published Vision & Strategy Statements</h3>
                <div class="space-y-4">
                    <?php if (empty($visions)): ?>
                        <p class="text-slate-400 italic text-xs text-center py-6">No policy statements found.</p>
                    <?php endif; ?>
                    <?php foreach ($visions as $v): ?>
                        <div class="p-5 rounded-xl border border-slate-100 dark:border-slate-700 space-y-3 leading-relaxed">
                            <div class="flex justify-between items-start">
                                <h4 class="font-bold text-slate-850 dark:text-slate-200 text-sm"><?php echo htmlspecialchars($v['title']); ?></h4>
                                <span class="px-2.5 py-0.5 rounded-full bg-gold/15 text-gold text-[8px] font-bold uppercase tracking-wider">
                                    <?php echo str_replace('_', ' ', $v['category']); ?>
                                </span>
                            </div>
                            <p class="text-slate-500 dark:text-slate-400 text-xs font-light"><?php echo nl2br(htmlspecialchars($v['content'])); ?></p>
                            <div class="text-[9px] text-slate-400 border-t border-slate-50 dark:border-slate-700/50 pt-2 flex justify-between">
                                <span>Published By: <strong><?php echo htmlspecialchars($v['author_name']); ?></strong></span>
                                <span>Date: <?php echo date('Y-m-d H:i', strtotime($v['created_at'])); ?></span>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Publish Statement -->
            <div class="lg:col-span-4 bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
                <div>
                    <h3 class="text-slate-800 dark:text-slate-200 font-bold text-sm tracking-wide">Publish Vision & Policy Statement</h3>
                    <p class="text-[10px] text-slate-400">Issue roadmaps, goals, or innovation agendas.</p>
                </div>
                <form method="POST" action="" class="space-y-4">
                    <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                    <input type="hidden" name="action" value="create_vision">
                    <input type="hidden" name="redirect_tab" value="policy">

                    <div>
                        <label class="block text-slate-655 dark:text-slate-400 text-xs font-semibold mb-1" for="v_title">Statement Title *</label>
                        <input type="text" name="title" id="v_title" required placeholder="e.g. Digital Inclusion Goals 2027"
                               class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                    </div>
                    <div>
                        <label class="block text-slate-655 dark:text-slate-400 text-xs font-semibold mb-1" for="v_category">Policy Category *</label>
                        <select name="category" id="v_category" required class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                            <option value="roadmap">Digital Roadmap</option>
                            <option value="advocacy_direction">Advocacy Direction</option>
                            <option value="goals_management">Goals Management</option>
                            <option value="innovation_agenda">Innovation Agenda</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-slate-655 dark:text-slate-400 text-xs font-semibold mb-1" for="v_content">Policy Body Content *</label>
                        <textarea name="content" id="v_content" required rows="6" placeholder="Write policy, guidelines, directives, or tech infrastructure allocations..."
                                  class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-light leading-relaxed"></textarea>
                    </div>
                    <button type="submit" class="w-full py-2 bg-bushgreen hover:bg-bushgreen-light text-white text-xs font-bold rounded-lg transition shadow-md">
                        Publish Vision
                    </button>
                </form>
            </div>
        </div>
    </div>

    <!-- 4️⃣ TAB CONTENT: LEADERSHIP OVERSIGHT -->
    <div class="space-y-8" x-show="currentTab === 'leadership'">
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            <div class="lg:col-span-8 bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
                <h3 class="text-slate-800 dark:text-slate-200 font-bold text-sm tracking-wide font-display">National Leadership & Zonal Coordinator Directory</h3>
                
                <div class="overflow-x-auto">
                    <table class="w-full text-xs text-left text-slate-500">
                        <thead class="text-[10px] text-slate-400 font-bold uppercase border-b border-slate-100 dark:border-slate-700">
                            <tr>
                                <th class="pb-3">Name</th>
                                <th class="pb-3">Role Tier</th>
                                <th class="pb-3">Email Address</th>
                                <th class="pb-3">Status</th>
                                <th class="pb-3 text-right">Access Controls</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-50 dark:divide-slate-700/50">
                            <?php foreach ($leaders as $l): ?>
                                <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-700/50">
                                    <td class="py-3 font-semibold text-slate-800 dark:text-slate-200 flex items-center gap-1">
                                        <?php echo htmlspecialchars($l['name']); ?>
                                        <?php if ($l['role_id'] == 2): ?>
                                            <span class="text-[8px] bg-gold/20 text-gold border border-gold/30 px-1 rounded">🎖 Founder</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="py-3 text-[10px] font-bold text-slate-600 dark:text-slate-450 uppercase"><?php echo str_replace('_', ' ', Auth::getRoleNameById($l['role_id'])); ?></td>
                                    <td class="py-3 font-mono"><?php echo htmlspecialchars($l['email']); ?></td>
                                    <td class="py-3">
                                        <span class="px-2 py-0.5 rounded text-[8px] font-bold uppercase
                                            <?php echo $l['status'] === 'active' ? 'bg-emerald-50 text-emerald-700 border border-emerald-100' : 'bg-red-50 text-red-700 border border-red-100'; ?>">
                                            <?php echo htmlspecialchars($l['status']); ?>
                                        </span>
                                    </td>
                                    <td class="py-3 text-right">
                                        <form method="POST" action="" class="inline-block">
                                            <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                                            <input type="hidden" name="action" value="founder_approve_leadership">
                                            <input type="hidden" name="leadership_id" value="<?php echo $l['id']; ?>">
                                            <input type="hidden" name="redirect_tab" value="leadership">

                                            <?php if ($l['status'] === 'active'): ?>
                                                <button type="submit" name="status_act" value="suspended" class="py-1 px-2.5 bg-red-50 hover:bg-red-100 text-red-655 rounded text-[9px] font-bold transition">Suspend</button>
                                            <?php else: ?>
                                                <button type="submit" name="status_act" value="active" class="py-1 px-2.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 rounded text-[9px] font-bold transition">Verify</button>
                                            <?php endif; ?>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Strategic Honors List -->
                <div class="border-t border-slate-100 dark:border-slate-700 pt-6 space-y-4">
                    <h3 class="text-slate-800 dark:text-slate-200 font-bold text-sm tracking-wide">Granted National Honors & Recognition Awards</h3>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <?php foreach ($awards as $a): ?>
                            <div class="p-3 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-xl space-y-2">
                                <div class="flex justify-between items-center text-[10px]">
                                    <span class="font-bold text-bushgreen dark:text-gold"><?php echo htmlspecialchars($a['award_title']); ?></span>
                                    <span class="px-2 py-0.5 rounded-full bg-gold/15 text-gold font-bold uppercase text-[7px]">
                                        <?php echo str_replace('_', ' ', $a['award_type']); ?>
                                    </span>
                                </div>
                                <p class="text-[11px] text-slate-500 dark:text-slate-400 font-light"><?php echo htmlspecialchars($a['description']); ?></p>
                                <div class="text-[8px] text-slate-400 flex justify-between">
                                    <span>Recipient: <strong><?php echo htmlspecialchars($a['recipient_name']); ?></strong></span>
                                    <span>Granted: <?php echo date('Y-m-d', strtotime($a['granted_at'])); ?></span>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>

            <!-- Issue Awards & Honors -->
            <div class="lg:col-span-4 bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
                <div>
                    <h3 class="text-slate-800 dark:text-slate-200 font-bold text-sm tracking-wide">Grant Strategic Honor / Award</h3>
                    <p class="text-[10px] text-slate-400">Recognize outstanding ambassadors or coordinators.</p>
                </div>
                <form method="POST" action="" class="space-y-4">
                    <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                    <input type="hidden" name="action" value="create_award">
                    <input type="hidden" name="redirect_tab" value="leadership">

                    <div>
                        <label class="block text-slate-655 dark:text-slate-400 text-xs font-semibold mb-1" for="award_rec">Recipient Ambassador *</label>
                        <select name="recipient_id" id="award_rec" required class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                            <option value="">-- Choose Recipient --</option>
                            <?php foreach ($ambassadors_list as $amb): ?>
                                <option value="<?php echo $amb['id']; ?>"><?php echo htmlspecialchars($amb['name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div>
                        <label class="block text-slate-655 dark:text-slate-400 text-xs font-semibold mb-1" for="award_title">Award Title *</label>
                        <input type="text" name="award_title" id="award_title" required placeholder="e.g. Outstanding Digital Innovator"
                               class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                    </div>
                    <div>
                        <label class="block text-slate-655 dark:text-slate-400 text-xs font-semibold mb-1" for="award_type">Honor Category *</label>
                        <select name="award_type" id="award_type" required class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                            <option value="outstanding_ambassador">Outstanding Ambassador Award</option>
                            <option value="leadership_recognition">Leadership Recognition</option>
                            <option value="innovation_award">Innovation & Technology Award</option>
                            <option value="champion">Digital Revolution Champion</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-slate-655 dark:text-slate-400 text-xs font-semibold mb-1" for="award_desc">Award Citation Description *</label>
                        <textarea name="description" id="award_desc" required rows="4" placeholder="Write citation highlighting impact, local state mobilization results..."
                                  class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-light"></textarea>
                    </div>
                    <button type="submit" class="w-full py-2 bg-bushgreen hover:bg-bushgreen-light text-white text-xs font-bold rounded-lg transition shadow-md">
                        Grant Honor Award
                    </button>
                </form>
            </div>
        </div>
    </div>

    <!-- 5️⃣ TAB CONTENT: PARTNERSHIPS -->
    <div class="space-y-8" x-show="currentTab === 'partnerships'">
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            <div class="lg:col-span-8 bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
                <h3 class="text-slate-800 dark:text-slate-200 font-bold text-sm tracking-wide font-display">Partnerships & Technology Collaborations</h3>
                
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <?php if (empty($partnerships)): ?>
                        <p class="text-slate-400 italic text-xs text-center py-6 col-span-2">No registered partnerships.</p>
                    <?php endif; ?>
                    <?php foreach ($partnerships as $p): ?>
                        <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-xl space-y-3">
                            <div class="flex justify-between items-center text-xs">
                                <span class="font-bold text-slate-800 dark:text-slate-200"><?php echo htmlspecialchars($p['name']); ?></span>
                                <span class="px-2 py-0.5 rounded bg-bushgreen/10 text-bushgreen dark:text-emerald-400 font-bold uppercase text-[7px]">
                                    <?php echo str_replace('_', ' ', $p['type']); ?>
                                </span>
                            </div>
                            <p class="text-[11px] text-slate-500 dark:text-slate-400 font-light leading-relaxed"><?php echo htmlspecialchars($p['description']); ?></p>
                            <div class="text-[9px] text-slate-400 space-y-1.5 border-t border-slate-200 dark:border-slate-800 pt-2">
                                <div class="flex justify-between">
                                    <span>Contact: <strong><?php echo htmlspecialchars($p['contact_name']); ?></strong> (<?php echo htmlspecialchars($p['contact_email']); ?>)</span>
                                </div>
                                <div class="flex justify-between font-semibold">
                                    <span>Sponsorship Funding:</span>
                                    <span class="text-gold font-mono">₦<?php echo number_format($p['sponsor_amount'], 2); ?></span>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Create Partnership -->
            <div class="lg:col-span-4 bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
                <div>
                    <h3 class="text-slate-800 dark:text-slate-200 font-bold text-sm tracking-wide">Register New Collaborator</h3>
                    <p class="text-[10px] text-slate-400">Map NGOs, companies, and donors.</p>
                </div>
                <form method="POST" action="" class="space-y-4">
                    <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                    <input type="hidden" name="action" value="create_partnership">
                    <input type="hidden" name="redirect_tab" value="partnerships">

                    <div>
                        <label class="block text-slate-655 dark:text-slate-400 text-xs font-semibold mb-1" for="p_name">Partner / Sponsor Name *</label>
                        <input type="text" name="name" id="p_name" required placeholder="e.g. Google Developer Group Africa"
                               class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                    </div>
                    <div>
                        <label class="block text-slate-655 dark:text-slate-400 text-xs font-semibold mb-1" for="p_type">Partner Category *</label>
                        <select name="type" id="p_type" required class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                            <option value="tech_company">Technology Enterprise</option>
                            <option value="ngo">Non-Governmental Org (NGO)</option>
                            <option value="youth_org">Youth Advocacy Coalition</option>
                            <option value="educational_inst">Educational Institution / Research Center</option>
                        </select>
                    </div>
                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="block text-slate-655 dark:text-slate-400 text-xs font-semibold mb-1" for="p_contact">Contact Name</label>
                            <input type="text" name="contact_name" id="p_contact" placeholder="Liaison Name"
                                   class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                        </div>
                        <div>
                            <label class="block text-slate-655 dark:text-slate-400 text-xs font-semibold mb-1" for="p_email">Contact Email</label>
                            <input type="email" name="contact_email" id="p_email" placeholder="liaison@domain.com"
                                   class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-mono">
                        </div>
                    </div>
                    <div>
                        <label class="block text-slate-655 dark:text-slate-400 text-xs font-semibold mb-1" for="p_funding">Sponsorship Capital Allocation (₦)</label>
                        <input type="number" step="1000" name="sponsor_amount" id="p_funding" placeholder="0"
                               class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-mono">
                    </div>
                    <div>
                        <label class="block text-slate-655 dark:text-slate-400 text-xs font-semibold mb-1" for="p_desc">Collaboration Description *</label>
                        <textarea name="description" id="p_desc" required rows="3" placeholder="Sponsorship objectives, targeted local hubs support program..."
                                  class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-light"></textarea>
                    </div>
                    <button type="submit" class="w-full py-2 bg-bushgreen hover:bg-bushgreen-light text-white text-xs font-bold rounded-lg transition shadow-md">
                        Register Partnership
                    </button>
                </form>
            </div>
        </div>
    </div>

    <!-- 6️⃣ TAB CONTENT: THINK-TANK -->
    <div class="space-y-8" x-show="currentTab === 'thinktank'">
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            <div class="lg:col-span-8 bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
                <h3 class="text-slate-800 dark:text-slate-200 font-bold text-sm tracking-wide font-display">Smart Nation Think-Tank Roster</h3>
                <div class="space-y-4">
                    <?php if (empty($thinktank)): ?>
                        <p class="text-slate-400 italic text-xs text-center py-6">No discussions active.</p>
                    <?php endif; ?>
                    <?php foreach ($thinktank as $item): ?>
                        <div class="p-4 rounded-xl border border-slate-100 dark:border-slate-700 space-y-3 leading-relaxed">
                            <div class="flex justify-between items-center text-xs">
                                <h4 class="font-bold text-slate-800 dark:text-slate-200"><?php echo htmlspecialchars($item['title']); ?></h4>
                                <span class="px-2 py-0.5 rounded-full bg-bushgreen/5 text-bushgreen dark:text-gold text-[7px] font-bold uppercase">
                                    <?php echo str_replace('_', ' ', $item['category']); ?>
                                </span>
                            </div>
                            <p class="text-slate-500 dark:text-slate-400 text-xs font-light"><?php echo nl2br(htmlspecialchars($item['content'])); ?></p>
                            <div class="text-[9px] text-slate-400 pt-2 border-t border-slate-100 dark:border-slate-700 flex justify-between items-center">
                                <span>Submitted By: <strong><?php echo htmlspecialchars($item['author_name']); ?></strong></span>
                                <span class="flex items-center gap-1">
                                    <svg class="w-3.5 h-3.5 text-gold" fill="currentColor" viewBox="0 0 20 20"><path d="M2 10.5a1.5 1.5 0 113 0v6a1.5 1.5 0 01-3 0v-6zM6 10.333v5.43a2 2 0 001.106 1.79l.05.025A4 4 0 008.943 18h5.416a2 2 0 001.962-1.608l1.2-6A2 2 0 0015.56 8H12V4a2 2 0 00-2-2 1 1 0 00-1 1v.667a4 4 0 01-.8 2.4L6.8 7.933a4 4 0 00-.8 2.4z"/></svg>
                                    <?php echo $item['upvotes']; ?> strategic upvotes
                                </span>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Submit Idea -->
            <div class="lg:col-span-4 bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
                <div>
                    <h3 class="text-slate-800 dark:text-slate-200 font-bold text-sm tracking-wide">Submit Idea / Policy Discussion</h3>
                    <p class="text-[10px] text-slate-400">Initiate brainstorming sessions.</p>
                </div>
                <form method="POST" action="" class="space-y-4">
                    <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                    <input type="hidden" name="action" value="create_thinktank">
                    <input type="hidden" name="redirect_tab" value="thinktank">

                    <div>
                        <label class="block text-slate-655 dark:text-slate-400 text-xs font-semibold mb-1" for="tt_title">Discussion Topic Title *</label>
                        <input type="text" name="title" id="tt_title" required placeholder="e.g. Mandatory AI Coding curricula in local schools"
                               class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                    </div>
                    <div>
                        <label class="block text-slate-655 dark:text-slate-400 text-xs font-semibold mb-1" for="tt_cat">Discussion Category *</label>
                        <select name="category" id="tt_cat" required class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                            <option value="digital_strategy">National Digital Strategy</option>
                            <option value="tech_policy">Technology Policy discussions</option>
                            <option value="brainstorming">Future Nigeria Brainstorming</option>
                            <option value="ai_insights">AI & Innovation Insights</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-slate-655 dark:text-slate-400 text-xs font-semibold mb-1" for="tt_content">Detailed Strategy / Idea Details *</label>
                        <textarea name="content" id="tt_content" required rows="6" placeholder="Provide background analysis, implementation blueprints, or policy recommendation outlines..."
                                  class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-light"></textarea>
                    </div>
                    <button type="submit" class="w-full py-2 bg-bushgreen hover:bg-bushgreen-light text-white text-xs font-bold rounded-lg transition shadow-md">
                        Submit Think-Tank Idea
                    </button>
                </form>
            </div>
        </div>
    </div>

    <!-- 7️⃣ TAB CONTENT: STRATEGIC COMMS -->
    <div class="space-y-8" x-show="currentTab === 'communications'">
        <div class="max-w-2xl mx-auto bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-8 shadow-sm space-y-6">
            <div class="text-center space-y-2 pb-4 border-b border-slate-100 dark:border-slate-700">
                <span class="text-[9px] bg-gold/15 text-gold border border-gold/30 px-2 py-0.5 rounded font-bold uppercase tracking-wider">Executive Dispatch Center</span>
                <h3 class="text-slate-800 dark:text-slate-200 font-bold text-lg font-display">National Communications Broadcaster</h3>
                <p class="text-[11px] text-slate-550 leading-relaxed font-light">
                    Dispatch Founder Circulars, strategic instructions, or public statements directly to the email outboxes of all active coordinators and ambassadors nationwide.
                </p>
            </div>
            <form method="POST" action="" class="space-y-4">
                <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                <input type="hidden" name="action" value="create_broadcast">
                <input type="hidden" name="redirect_tab" value="communications">

                <div>
                    <label class="block text-slate-700 dark:text-slate-400 text-xs font-semibold mb-1" for="comm_subject">Strategic Subject Line *</label>
                    <input type="text" name="subject" id="comm_subject" required placeholder="e.g. Zonal Directives for Q3 Digital Inclusion Hubs"
                           class="w-full px-3 py-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs focus:outline-none focus:border-bushgreen">
                </div>
                <div>
                    <label class="block text-slate-700 dark:text-slate-400 text-xs font-semibold mb-1" for="comm_channel">Circular Broadcast Channel *</label>
                    <select name="channel" id="comm_channel" required class="w-full px-3 py-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs focus:outline-none focus:border-bushgreen">
                        <option value="founder_circular">Founder's Executive Circular</option>
                        <option value="announcement">Strategic Announcement</option>
                        <option value="public_statement">Official Public Statement</option>
                        <option value="leadership_directive">Leadership Directive</option>
                    </select>
                </div>
                <div>
                    <label class="block text-slate-700 dark:text-slate-400 text-xs font-semibold mb-1" for="comm_body">Directive Content (HTML / Plain text) *</label>
                    <textarea name="body" id="comm_body" required rows="8" placeholder="Dear Ambassadors & Directors, ... Define tactical tasks, updates, webinar agendas..."
                              class="w-full px-3 py-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs focus:outline-none focus:border-bushgreen font-light leading-relaxed"></textarea>
                </div>
                <button type="submit" class="w-full py-3 bg-bushgreen hover:bg-bushgreen-light text-white font-bold rounded-xl text-xs shadow-md tracking-wider transition uppercase">
                    Dispatch National Circular Broadcast
                </button>
            </form>
        </div>
    </div>

    <!-- 8️⃣ TAB CONTENT: MEDIA & TV OVERSIGHT -->
    <div class="space-y-8" x-show="currentTab === 'media'">
        <div class="bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
            <div>
                <h3 class="text-slate-800 dark:text-slate-200 font-bold text-sm tracking-wide font-display uppercase">Smart Nation TV Oversight & Livestream Management</h3>
                <p class="text-[10px] text-slate-400">Schedule streaming events, verify Twitch/YouTube endpoints, and monitor broadcast performance indicators.</p>
            </div>
            
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <?php if (empty($livestreams)): ?>
                    <p class="text-slate-400 italic text-xs text-center py-6 col-span-2">No active broadcasts scheduled.</p>
                <?php endif; ?>
                <?php foreach ($livestreams as $ls): ?>
                    <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-xl space-y-3 flex flex-col justify-between">
                        <div>
                            <div class="flex justify-between items-start">
                                <h4 class="font-bold text-xs text-slate-800 dark:text-slate-200"><?php echo htmlspecialchars($ls['title']); ?></h4>
                                <span class="px-2 py-0.5 rounded text-[8px] font-bold uppercase tracking-wide bg-gold/15 text-gold border border-gold/30">
                                    <?php echo htmlspecialchars($ls['status']); ?>
                                </span>
                            </div>
                            <p class="text-[11px] text-slate-500 dark:text-slate-400 font-light pt-1.5"><?php echo htmlspecialchars($ls['description']); ?></p>
                        </div>
                        <div class="text-[9px] text-slate-400 border-t border-slate-200 dark:border-slate-800 pt-2 flex flex-col gap-1">
                            <div>Stream URL: <strong class="font-mono"><?php echo htmlspecialchars($ls['stream_url']); ?></strong></div>
                            <div class="flex justify-between">
                                <span>Scheduled: <?php echo date('Y-m-d H:i', strtotime($ls['scheduled_at'])); ?></span>
                                <span>Duration: <?php echo $ls['duration']; ?> mins</span>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <!-- 9️⃣ TAB CONTENT: TOWN HALLS & SUMMITS -->
    <div class="space-y-8" x-show="currentTab === 'townhalls'">
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            <div class="lg:col-span-8 bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
                <h3 class="text-slate-800 dark:text-slate-200 font-bold text-sm tracking-wide font-display">National Summits & Interactive Town Halls</h3>
                
                <div class="space-y-4">
                    <?php if (empty($events)): ?>
                        <p class="text-slate-400 italic text-xs text-center py-6">No scheduled town halls found.</p>
                    <?php endif; ?>
                    <?php foreach ($events as $ev): ?>
                        <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-xl space-y-2 leading-relaxed">
                            <div class="flex justify-between items-start text-xs">
                                <h4 class="font-bold text-slate-800 dark:text-slate-200"><?php echo htmlspecialchars($ev['title']); ?></h4>
                                <span class="px-2.5 py-0.5 rounded bg-bushgreen/10 text-bushgreen dark:bg-emerald-950 dark:text-emerald-350 font-bold uppercase text-[7px]">
                                    <?php echo htmlspecialchars($ev['event_type']); ?>
                                </span>
                            </div>
                            <p class="text-[11px] text-slate-500 dark:text-slate-400 font-light"><?php echo htmlspecialchars($ev['description']); ?></p>
                            <div class="text-[9px] text-slate-400 space-y-1 pt-2 border-t border-slate-200 dark:border-slate-800 font-mono">
                                <div>Location: <?php echo htmlspecialchars($ev['location']); ?></div>
                                <div class="flex justify-between">
                                    <span>Date: <?php echo date('Y-m-d H:i', strtotime($ev['event_date'])); ?></span>
                                    <span>Virtual: <?php echo $ev['is_virtual'] ? 'Yes' : 'No'; ?></span>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Schedule Summit/Townhall -->
            <div class="lg:col-span-4 bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
                <div>
                    <h3 class="text-slate-800 dark:text-slate-200 font-bold text-sm tracking-wide">Schedule National Town Hall</h3>
                    <p class="text-[10px] text-slate-400">Deploy high-level summit registrations.</p>
                </div>
                <form method="POST" action="" class="space-y-4">
                    <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                    <input type="hidden" name="action" value="founder_schedule_townhall">
                    <input type="hidden" name="redirect_tab" value="townhalls">

                    <div>
                        <label class="block text-slate-655 dark:text-slate-400 text-xs font-semibold mb-1" for="ev_title">Summit / Event Title *</label>
                        <input type="text" name="title" id="ev_title" required placeholder="e.g. Zonal Digital Revolution Forum"
                               class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                    </div>
                    <div>
                        <label class="block text-slate-655 dark:text-slate-400 text-xs font-semibold mb-1" for="ev_type">Event Type *</label>
                        <input type="text" name="event_type" id="ev_type" required placeholder="e.g. Summit"
                               class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                    </div>
                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="block text-slate-655 dark:text-slate-400 text-xs font-semibold mb-1" for="ev_date">Event Date *</label>
                            <input type="datetime-local" name="event_date" id="ev_date" required class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                        </div>
                        <div class="flex items-center pt-5 pl-2">
                            <label class="relative inline-flex items-center cursor-pointer select-none">
                                <input type="checkbox" name="is_virtual" value="1" class="sr-only peer" checked>
                                <div class="w-9 h-5 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-bushgreen"></div>
                                <span class="ml-2 text-xs text-slate-700 dark:text-slate-305">Is Virtual</span>
                            </label>
                        </div>
                    </div>
                    <div>
                        <label class="block text-slate-655 dark:text-slate-400 text-xs font-semibold mb-1" for="ev_loc">Location / Venue *</label>
                        <input type="text" name="location" id="ev_loc" required placeholder="e.g. YouTube Live & Zoom"
                               class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                    </div>
                    <div>
                        <label class="block text-slate-655 dark:text-slate-400 text-xs font-semibold mb-1" for="ev_url">Stream Broadcast URL (if virtual)</label>
                        <input type="url" name="stream_url" id="ev_url" placeholder="https://youtube.com/embed/..."
                               class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-mono">
                    </div>
                    <div>
                        <label class="block text-slate-655 dark:text-slate-400 text-xs font-semibold mb-1" for="ev_desc">Program Description *</label>
                        <textarea name="description" id="ev_desc" required rows="3" placeholder="Outline agenda items, virtual link directives, and speaking credentials..."
                                  class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-light"></textarea>
                    </div>
                    <button type="submit" class="w-full py-2 bg-bushgreen hover:bg-bushgreen-light text-white text-xs font-bold rounded-lg transition shadow-md">
                        Schedule Summit Program
                    </button>
                </form>
            </div>
        </div>
    </div>

    <!-- 🔟 TAB CONTENT: EXECUTIVE PORTAL -->
    <div class="space-y-8" x-show="currentTab === 'executive'">
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            <div class="lg:col-span-8 bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
                <h3 class="text-slate-800 dark:text-slate-200 font-bold text-sm tracking-wide font-display">Confidential Executive Notes & Strategy Papers</h3>
                <div class="space-y-4">
                    <?php if (empty($notes_list)): ?>
                        <p class="text-slate-400 italic text-xs text-center py-6">No confidential strategy files registered.</p>
                    <?php endif; ?>
                    <?php foreach ($notes_list as $n): ?>
                        <div class="p-4 bg-slate-900 border border-slate-800 text-slate-300 rounded-xl space-y-3 leading-relaxed">
                            <div class="flex justify-between items-center text-xs">
                                <h4 class="font-bold text-gold font-mono"><?php echo htmlspecialchars($n['title']); ?></h4>
                                <span class="px-2.5 py-0.5 rounded-full bg-red-950/20 text-red-400 border border-red-900/30 text-[8px] font-bold uppercase tracking-wider font-mono">
                                    Confidential
                                </span>
                            </div>
                            <p class="text-slate-400 text-xs font-mono font-light whitespace-pre-wrap leading-relaxed"><?php echo htmlspecialchars($n['content']); ?></p>
                            <div class="text-[8px] text-slate-500 pt-2 border-t border-slate-800 flex justify-between font-mono">
                                <span>Author: <?php echo htmlspecialchars($n['author_name']); ?></span>
                                <span>Date: <?php echo date('Y-m-d H:i', strtotime($n['created_at'])); ?></span>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Create note -->
            <div class="lg:col-span-4 bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
                <div>
                    <h3 class="text-slate-800 dark:text-slate-200 font-bold text-sm tracking-wide">Write Private Planning Note</h3>
                    <p class="text-[10px] text-slate-400">Save confidential executive parameters.</p>
                </div>
                <form method="POST" action="" class="space-y-4">
                    <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                    <input type="hidden" name="action" value="create_note">
                    <input type="hidden" name="redirect_tab" value="executive">

                    <div>
                        <label class="block text-slate-655 dark:text-slate-400 text-xs font-semibold mb-1" for="n_title">Note Title *</label>
                        <input type="text" name="title" id="n_title" required placeholder="e.g. Zonal Restructure Memo"
                               class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                    </div>
                    <div>
                        <label class="block text-slate-655 dark:text-slate-400 text-xs font-semibold mb-1" for="n_content">Confidential Body *</label>
                        <textarea name="content" id="n_content" required rows="6" placeholder="Confidential details, budget coordinates, structural appointments targets..."
                                  class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-mono font-light"></textarea>
                    </div>
                    <div class="flex items-center pl-1">
                        <label class="relative inline-flex items-center cursor-pointer select-none">
                            <input type="checkbox" name="is_confidential" value="1" class="sr-only peer" checked>
                            <div class="w-9 h-5 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-red-600"></div>
                            <span class="ml-2 text-xs text-slate-700 dark:text-slate-305 font-bold text-red-655">Enforce Encryption / Lock Note</span>
                        </label>
                    </div>
                    <button type="submit" class="w-full py-2 bg-bushgreen hover:bg-bushgreen-light text-white text-xs font-bold rounded-lg transition shadow-md">
                        Save Confidential Memo
                    </button>
                </form>
            </div>
        </div>
    </div>

    <!-- 1️⃣1️⃣ TAB CONTENT: FUTURE VISUALIZATION -->
    <div class="space-y-8" x-show="currentTab === 'visualization'" x-data="{ slide: 1 }">
        <div class="max-w-4xl mx-auto bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-8 shadow-sm space-y-6">
            <div class="flex justify-between items-center border-b border-slate-100 dark:border-slate-700 pb-4">
                <div>
                    <h3 class="text-slate-800 dark:text-slate-200 font-bold text-sm tracking-wide font-display uppercase">Future Nigeria Visualization Center</h3>
                    <p class="text-[10px] text-slate-400">Interactive visionary slides modeling smart city integrations and technology nodes.</p>
                </div>
                <div class="flex gap-2">
                    <button @click="slide = slide === 1 ? 3 : slide - 1" class="p-2 border border-slate-200 dark:border-slate-700 hover:border-gold hover:text-gold text-slate-600 dark:text-slate-400 rounded-lg text-xs transition">&larr; Prev</button>
                    <button @click="slide = slide === 3 ? 1 : slide + 1" class="p-2 border border-slate-200 dark:border-slate-700 hover:border-gold hover:text-gold text-slate-600 dark:text-slate-400 rounded-lg text-xs transition">Next &rarr;</button>
                </div>
            </div>

            <!-- Slides carousel -->
            <div class="rounded-2xl overflow-hidden relative border border-slate-200 dark:border-slate-700 h-96">
                <!-- Slide 1 -->
                <div x-show="slide === 1" class="absolute inset-0 bg-cover bg-center flex flex-col justify-end p-8 text-white" style="background-image: linear-gradient(to top, rgba(0,0,0,0.85), rgba(0,0,0,0)), url('https://images.unsplash.com/photo-1542831371-29b0f74f9713?auto=format&fit=crop&w=1200&q=80')">
                    <div class="space-y-2 max-w-xl">
                        <span class="text-gold font-bold text-[9px] uppercase tracking-wider block">Concept Node 1</span>
                        <h4 class="font-bold text-lg font-display">Geopolitical Fiber Mesh Grids</h4>
                        <p class="text-[11px] text-slate-300 font-light leading-relaxed">
                            A model showing physical interconnectivity blueprints running across all Nigerian geopolitical zones. Connecting the grassroots hubs with unified metadata routes.
                        </p>
                    </div>
                </div>
                <!-- Slide 2 -->
                <div x-show="slide === 2" class="absolute inset-0 bg-cover bg-center flex flex-col justify-end p-8 text-white" style="background-image: linear-gradient(to top, rgba(0,0,0,0.85), rgba(0,0,0,0)), url('https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=1200&q=80')" style="display: none;">
                    <div class="space-y-2 max-w-xl">
                        <span class="text-gold font-bold text-[9px] uppercase tracking-wider block">Concept Node 2</span>
                        <h4 class="font-bold text-lg font-display">Municipal Smart Hub Workspaces</h4>
                        <p class="text-[11px] text-slate-300 font-light leading-relaxed">
                            Blueprints for building standardized tech inclusion nodes in rural LGAs, including solar grids, satellite terminals, and coding seminar spaces.
                        </p>
                    </div>
                </div>
                <!-- Slide 3 -->
                <div x-show="slide === 3" class="absolute inset-0 bg-cover bg-center flex flex-col justify-end p-8 text-white" style="background-image: linear-gradient(to top, rgba(0,0,0,0.85), rgba(0,0,0,0)), url('https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=1200&q=80')" style="display: none;">
                    <div class="space-y-2 max-w-xl">
                        <span class="text-gold font-bold text-[9px] uppercase tracking-wider block">Concept Node 3</span>
                        <h4 class="font-bold text-lg font-display">Local Cloud Sovereign Database</h4>
                        <p class="text-[11px] text-slate-300 font-light leading-relaxed">
                            Sovereign datacenters modeling secure identity verifications for local cooperative integrations.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- 1️⃣2️⃣ TAB CONTENT: FUTURE EXPANSION -->
    <div class="space-y-8" x-show="currentTab === 'expansion'">
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            <div class="lg:col-span-8 bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
                <h3 class="text-slate-800 dark:text-slate-200 font-bold text-sm tracking-wide font-display">Regional Expansion Rollout Strategy</h3>
                
                <div class="space-y-4">
                    <?php if (empty($expansion)): ?>
                        <p class="text-slate-400 italic text-xs text-center py-6">No active rollout plans found.</p>
                    <?php endif; ?>
                    <?php foreach ($expansion as $ex): ?>
                        <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-xl space-y-2 leading-relaxed">
                            <div class="flex justify-between items-center text-xs">
                                <h4 class="font-bold text-slate-800 dark:text-slate-200"><?php echo htmlspecialchars($ex['state_name']); ?> State Chapter</h4>
                                <span class="px-2.5 py-0.5 rounded text-[8px] font-bold uppercase tracking-wide bg-gold/15 text-gold border border-gold/30">
                                    <?php echo htmlspecialchars($ex['status']); ?>
                                </span>
                            </div>
                            <div class="text-[9px] text-slate-400 space-y-1.5 pt-2 font-mono">
                                <div>Target Expansion Launch: <?php echo date('Y-m-d', strtotime($ex['target_date'])); ?></div>
                                <div>Zonal Director Appointed: <strong><?php echo htmlspecialchars($ex['head_name'] ?: 'None Assigned'); ?></strong></div>
                                <div class="flex justify-between font-bold">
                                    <span>Funding Capital Allocated:</span>
                                    <span>₦<?php echo number_format($ex['funding_allocated'], 2); ?></span>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Create Expansion Plan -->
            <div class="lg:col-span-4 bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
                <div>
                    <h3 class="text-slate-800 dark:text-slate-200 font-bold text-sm tracking-wide">Schedule Zonal State Rollout</h3>
                    <p class="text-[10px] text-slate-400">Map rollouts to states.</p>
                </div>
                <form method="POST" action="" class="space-y-4">
                    <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                    <input type="hidden" name="action" value="create_expansion">
                    <input type="hidden" name="redirect_tab" value="expansion">

                    <div>
                        <label class="block text-slate-655 dark:text-slate-400 text-xs font-semibold mb-1" for="ex_state">Target State *</label>
                        <select name="state_id" id="ex_state" required class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                            <option value="">-- Choose State --</option>
                            <?php 
                            // Query states list
                            try {
                                $states = $db->query("SELECT id, name FROM states ORDER BY name ASC")->fetchAll();
                                foreach ($states as $s) {
                                    echo '<option value="' . $s['id'] . '">' . htmlspecialchars($s['name']) . '</option>';
                                }
                            } catch (Exception $e) {}
                            ?>
                        </select>
                    </div>
                    <div>
                        <label class="block text-slate-655 dark:text-slate-400 text-xs font-semibold mb-1" for="ex_head">Zonal / State Executive Head</label>
                        <select name="regional_head_id" id="ex_head" class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                            <option value="">-- No Leader Assigned --</option>
                            <?php foreach ($leaders as $l): ?>
                                <option value="<?php echo $l['id']; ?>"><?php echo htmlspecialchars($l['name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div>
                        <label class="block text-slate-655 dark:text-slate-400 text-xs font-semibold mb-1" for="ex_date">Launch Target Date *</label>
                        <input type="date" name="target_date" id="ex_date" required class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-mono">
                    </div>
                    <div>
                        <label class="block text-slate-655 dark:text-slate-400 text-xs font-semibold mb-1" for="ex_fund">Capital Allocation Funding (₦) *</label>
                        <input type="number" step="1000" name="funding_allocated" id="ex_fund" required placeholder="0"
                               class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-mono">
                    </div>
                    <button type="submit" class="w-full py-2 bg-bushgreen hover:bg-bushgreen-light text-white text-xs font-bold rounded-lg transition shadow-md">
                        Deploy Expansion Plan
                    </button>
                </form>
            </div>
        </div>
    </div>

</div>
