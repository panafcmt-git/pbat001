<?php
/**
 * State Chairman Dashboard (Role 5)
 * The Smart Nation State Command Center
 */
if (!defined('DB_HOST')) {
    exit('Access Denied');
}

$active_tab = $_GET['tab'] ?? 'overview';
$user = Auth::user();
$user_id = $user['id'];

// Resolve active state coordinate of the State Chairman
try {
    $db = Database::connect();
    
    $stmt = $db->prepare("SELECT state_id FROM `user_leadership` WHERE user_id = ? LIMIT 1");
    $stmt->execute([$user_id]);
    $state_id = $stmt->fetchColumn() ?: 1; // Default to Lagos (1) if not found
    
    // Get state details
    $stmt_state = $db->prepare("SELECT * FROM `states` WHERE id = ? LIMIT 1");
    $stmt_state->execute([$state_id]);
    $state_info = $stmt_state->fetch();
    $state_name = $state_info['name'] ?? 'Lagos';
    $state_zone = $state_info['zone'] ?? 'South-West';
    
    // Get all LGAs in this state
    $stmt_lgas = $db->prepare("SELECT * FROM `lgas` WHERE state_id = ? ORDER BY name ASC");
    $stmt_lgas->execute([$state_id]);
    $state_lgas = $stmt_lgas->fetchAll();
    
    $lga_ids = array_column($state_lgas, 'id');
    $lga_ids_placeholder = !empty($lga_ids) ? implode(',', $lga_ids) : '0';
    
    // Fetch LGA coordinators in this state
    $stmt_coordinators = $db->prepare("
        SELECT u.id, u.name, u.email, u.status, ul.lga_id, l.name as lga_name,
               (SELECT COUNT(*) FROM `ambassadors` WHERE lga_id = ul.lga_id) as ambassador_count,
               (SELECT COUNT(*) FROM `reports` WHERE user_id = u.id) as reports_count
        FROM `users` u
        JOIN `user_leadership` ul ON u.id = ul.user_id
        LEFT JOIN `lgas` l ON ul.lga_id = l.id
        WHERE ul.state_id = ? AND u.role_id = 6
        ORDER BY l.name ASC
    ");
    $stmt_coordinators->execute([$state_id]);
    $coordinators = $stmt_coordinators->fetchAll();
    
    // Fetch reports filed in this state
    $stmt_reports = $db->prepare("
        SELECT r.*, u.name as author_name, l.name as lga_name
        FROM `reports` r
        JOIN `users` u ON r.user_id = u.id
        LEFT JOIN `user_leadership` ul ON u.id = ul.user_id
        LEFT JOIN `lgas` l ON ul.lga_id = l.id
        WHERE r.state_id = ?
        ORDER BY r.created_at DESC
    ");
    $stmt_reports->execute([$state_id]);
    $reports = $stmt_reports->fetchAll();
    
    // Fetch campaigns created by State Chairman or assigned to coordinators/ambassadors in the state
    $stmt_campaigns = $db->prepare("
        SELECT c.*, u.name as leader_name, creator.name as creator_name
        FROM `campaigns` c
        LEFT JOIN `users` u ON c.leader_id = u.id
        JOIN `users` creator ON c.created_by = creator.id
        WHERE c.created_by = ? OR c.leader_id IN (
            SELECT user_id FROM `user_leadership` WHERE state_id = ?
        ) OR c.leader_id IN (
            SELECT user_id FROM `ambassadors` WHERE state_id = ?
        )
        ORDER BY c.created_at DESC
    ");
    $stmt_campaigns->execute([$user_id, $state_id, $state_id]);
    $state_campaigns = $stmt_campaigns->fetchAll();
    
    // Fetch ambassadors in the state
    $stmt_ambassadors = $db->prepare("
        SELECT a.*, u.name, u.email, u.status, l.name as lga_name
        FROM `ambassadors` a
        JOIN `users` u ON a.user_id = u.id
        LEFT JOIN `lgas` l ON a.lga_id = l.id
        WHERE a.state_id = ?
        ORDER BY a.impact_score DESC
    ");
    $stmt_ambassadors->execute([$state_id]);
    $ambassadors = $stmt_ambassadors->fetchAll();
    
    // Fetch events scheduled in the state
    $stmt_events = $db->prepare("
        SELECT e.*, u.name as creator_name
        FROM `events` e
        JOIN `users` u ON e.created_by = u.id
        WHERE e.created_by = ? OR e.created_by IN (
            SELECT user_id FROM `user_leadership` WHERE state_id = ?
        ) OR e.location LIKE ?
        ORDER BY e.event_date DESC
    ");
    $stmt_events->execute([$user_id, $state_id, '%' . $state_name . '%']);
    $state_events = $stmt_events->fetchAll();
    
    // Fetch polls
    $stmt_polls = $db->prepare("SELECT * FROM `nsc_polls` ORDER BY created_at DESC");
    $stmt_polls->execute();
    $state_polls = $stmt_polls->fetchAll();
    
    // Fetch state analytics summary
    $stmt_stats = $db->prepare("
        SELECT SUM(ambassador_count) as total_amb, SUM(events_count) as total_evt, SUM(reports_filed) as total_rep
        FROM `analytics_summary`
        WHERE state_id = ?
    ");
    $stmt_stats->execute([$state_id]);
    $analytics_stats = $stmt_stats->fetch();
    
} catch (Exception $e) {
    $state_lgas = [];
    $coordinators = [];
    $reports = [];
    $state_campaigns = [];
    $ambassadors = [];
    $state_events = [];
    $state_polls = [];
    $analytics_stats = ['total_amb' => 0, 'total_evt' => 0, 'total_rep' => 0];
}

$total_amb = $analytics_stats['total_amb'] ?: count($ambassadors);
$total_rep = $analytics_stats['total_rep'] ?: count($reports);
$total_evt = $analytics_stats['total_evt'] ?: count($state_events);
?>

<div class="space-y-8" x-data="{ activeTab: '<?php echo htmlspecialchars($active_tab); ?>' }">

    <!-- State Command Header -->
    <div class="bg-gradient-to-r from-bushgreen to-bushgreen-light text-white p-8 rounded-3xl shadow-xl relative overflow-hidden border border-gold/30">
        <div class="absolute inset-0 bg-cover bg-center mix-blend-overlay opacity-10 bg-[url('https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=600&q=80')]"></div>
        <div class="relative z-10 space-y-3">
            <span class="px-2.5 py-1 bg-gold/20 text-gold rounded-full text-[9px] font-bold uppercase tracking-widest leading-none font-display border border-gold/25">State Command Center</span>
            <h2 class="text-3xl font-black font-display leading-tight text-white tracking-tight"><?php echo htmlspecialchars($state_name); ?> State Chapter</h2>
            <p class="text-slate-300 text-xs font-light max-w-xl">
                Coordinate Local Government chapters, direct digital campaigns, approve field briefings, and drive community engagement across all administrative wards.
            </p>
        </div>
    </div>

    <!-- TAB 1: OVERVIEW -->
    <div x-show="activeTab === 'overview'" class="space-y-8">
        
        <!-- KPI Row -->
        <div class="grid grid-cols-1 sm:grid-cols-4 gap-6">
            <div class="bg-white dark:bg-slate-800 p-6 rounded-3xl border border-slate-100 dark:border-slate-700 shadow-sm flex items-center justify-between">
                <div class="space-y-1">
                    <span class="text-slate-400 text-[10px] font-bold uppercase tracking-wider block">Active Local Govs</span>
                    <div class="text-3xl font-black text-bushgreen dark:text-white font-display"><?php echo count($coordinators); ?> / <?php echo count($state_lgas); ?></div>
                    <span class="text-[9px] text-emerald-600 font-bold bg-emerald-50 px-2 py-0.5 rounded">Chapters active</span>
                </div>
                <div class="w-12 h-12 rounded-2xl bg-bushgreen/5 flex items-center justify-center text-bushgreen dark:text-gold"><svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/></svg></div>
            </div>

            <div class="bg-white dark:bg-slate-800 p-6 rounded-3xl border border-slate-100 dark:border-slate-700 shadow-sm flex items-center justify-between">
                <div class="space-y-1">
                    <span class="text-slate-400 text-[10px] font-bold uppercase tracking-wider block">Grassroots Ambassadors</span>
                    <div class="text-3xl font-black text-bushgreen dark:text-white font-display"><?php echo number_format($total_amb); ?></div>
                    <span class="text-[9px] text-slate-400">Mobilized on the ground</span>
                </div>
                <div class="w-12 h-12 rounded-2xl bg-bushgreen/5 flex items-center justify-center text-bushgreen dark:text-gold"><svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"/></svg></div>
            </div>

            <div class="bg-white dark:bg-slate-800 p-6 rounded-3xl border border-slate-100 dark:border-slate-700 shadow-sm flex items-center justify-between">
                <div class="space-y-1">
                    <span class="text-slate-400 text-[10px] font-bold uppercase tracking-wider block">Briefings filed</span>
                    <div class="text-3xl font-black text-bushgreen dark:text-white font-display"><?php echo count($reports); ?></div>
                    <span class="text-[9px] text-amber-600 font-bold bg-amber-50 px-2 py-0.5 rounded"><?php echo count(array_filter($reports, fn($r) => $r['status'] === 'submitted')); ?> Pending review</span>
                </div>
                <div class="w-12 h-12 rounded-2xl bg-bushgreen/5 flex items-center justify-center text-bushgreen dark:text-gold"><svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg></div>
            </div>

            <div class="bg-white dark:bg-slate-800 p-6 rounded-3xl border border-slate-100 dark:border-slate-700 shadow-sm flex items-center justify-between">
                <div class="space-y-1">
                    <span class="text-slate-400 text-[10px] font-bold uppercase tracking-wider block">State Engagement index</span>
                    <div class="text-3xl font-black text-bushgreen dark:text-white font-display"><?php echo number_format(($total_amb * 25) + ($total_evt * 50)); ?></div>
                    <span class="text-[9px] text-slate-400">Total index index points</span>
                </div>
                <div class="w-12 h-12 rounded-2xl bg-bushgreen/5 flex items-center justify-center text-bushgreen dark:text-gold"><svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg></div>
            </div>
        </div>

        <!-- Grid of LGA details and tickers -->
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-8">
            
            <!-- LGA mobilized progress -->
            <div class="lg:col-span-7 bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
                <h3 class="text-slate-800 dark:text-white font-bold text-sm font-display border-b border-slate-50 dark:border-slate-700 pb-3">Local Government mobilizations</h3>
                
                <div class="space-y-4 max-h-[350px] overflow-y-auto pr-2">
                    <?php if (empty($state_lgas)): ?>
                        <p class="text-xs text-slate-400 italic">No Local Government areas seeded.</p>
                    <?php else: ?>
                        <?php foreach ($state_lgas as $lga): 
                            // Check if this LGA has a coordinator
                            $has_coord = false;
                            $coord_name = 'Vacant';
                            foreach ($coordinators as $c) {
                                if ($c['lga_id'] == $lga['id']) {
                                    $has_coord = true;
                                    $coord_name = $c['name'];
                                    break;
                                }
                            }
                            // Count ambassadors in this LGA
                            $amb_count = 0;
                            foreach ($ambassadors as $a) {
                                if ($a['lga_id'] == $lga['id']) {
                                    $amb_count++;
                                }
                            }
                            $mobilization_pct = min(100, ($amb_count / 10) * 100);
                        ?>
                            <div class="space-y-2">
                                <div class="flex justify-between text-xs font-semibold text-slate-700 dark:text-slate-350">
                                    <span class="flex items-center gap-1.5">
                                        <span class="w-1.5 h-1.5 rounded-full <?php echo $has_coord ? 'bg-emerald-500' : 'bg-rose-400'; ?>"></span>
                                        <?php echo htmlspecialchars($lga['name']); ?> LGA
                                    </span>
                                    <span class="text-[10px] text-slate-400">Coord: <?php echo htmlspecialchars($coord_name); ?> | <?php echo $amb_count; ?> Ambassadors</span>
                                </div>
                                <div class="w-full bg-slate-100 dark:bg-slate-900 rounded-full h-2 overflow-hidden">
                                    <div class="h-full rounded-full <?php echo $has_coord ? 'bg-bushgreen dark:bg-gold' : 'bg-slate-300 dark:bg-slate-700'; ?>" style="width: <?php echo max(5, $mobilization_pct); ?>%"></div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>

            <!-- AI suggestions and command feed -->
            <div class="lg:col-span-5 space-y-8">
                
                <div class="bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-4">
                    <h4 class="text-slate-850 dark:text-white font-bold text-xs font-display flex items-center gap-1.5 border-b border-slate-50 dark:border-slate-700 pb-2">
                        <span class="w-2.5 h-2.5 bg-emerald-500 rounded-full animate-ping"></span>
                        State Command feed
                    </h4>
                    <div class="h-32 overflow-y-auto space-y-2.5 text-[10px] leading-relaxed">
                        <div class="p-2 bg-slate-50 dark:bg-slate-900 rounded-xl">
                            <span class="text-gold font-bold">[Live]</span> LGA Coordinator briefing received for Ikeja.
                        </div>
                        <div class="p-2 bg-slate-50 dark:bg-slate-900 rounded-xl">
                            <span class="text-gold font-bold">[Live]</span> Ambassador Tunde Coker completed digital ID check-in.
                        </div>
                        <div class="p-2 bg-slate-50 dark:bg-slate-900 rounded-xl">
                            <span class="text-gold font-bold">[Live]</span> Directive circular dispatched to all coordinator chapters.
                        </div>
                    </div>
                </div>

                <div class="bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-4">
                    <h4 class="text-slate-855 dark:text-white font-bold text-xs font-display flex items-center gap-1.5 border-b border-slate-50 dark:border-slate-700 pb-2">
                        🧠 Command Intel Suggestions
                    </h4>
                    <p class="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed font-light">
                        Engagement level in <strong>Ikeja</strong> is optimal. Focus resources on mobilising coordinators in vacant regions to raise overall state registration indexes by 15%.
                    </p>
                </div>

            </div>
        </div>
    </div>

    <!-- TAB 2: LOCAL GOVERNMENT MANAGEMENT -->
    <div x-show="activeTab === 'lgas'" class="bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
        <div class="flex justify-between items-center border-b border-slate-50 dark:border-slate-700 pb-3">
            <h3 class="text-slate-850 dark:text-white font-bold text-sm font-display">LGA Coordinators Management</h3>
            <button onclick="alert('Nomination request has been logged. It will be sent to the Zonal Chairman for endorsement.')" class="py-1.5 px-3 bg-bushgreen hover:bg-bushgreen-light text-white text-xs font-bold rounded-xl transition shadow">
                Nominate Coordinator
            </button>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <?php if (empty($coordinators)): ?>
                <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-850 rounded-2xl text-center col-span-2 py-8 space-y-2">
                    <span class="text-3xl">👥</span>
                    <h4 class="font-bold text-slate-700 dark:text-white text-xs">No active coordinators found</h4>
                    <p class="text-[10px] text-slate-400 max-w-sm mx-auto">Use the Nominate Coordinator button to recommend representatives for Local Government chapters.</p>
                </div>
            <?php else: ?>
                <?php foreach ($coordinators as $c): ?>
                    <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-850 rounded-2xl flex justify-between items-center">
                        <div class="space-y-1">
                            <h4 class="font-bold text-slate-800 dark:text-white text-xs"><?php echo htmlspecialchars($c['name']); ?></h4>
                            <span class="text-[10px] text-slate-450 dark:text-slate-400 block">
                                LGA: <strong><?php echo htmlspecialchars($c['lga_name']); ?></strong> &bull; <?php echo htmlspecialchars($c['email']); ?>
                            </span>
                            <span class="text-[9px] text-slate-400 block">
                                Mobilized: <strong><?php echo $c['ambassador_count']; ?></strong> Ambassadors &bull; Briefings Filed: <strong><?php echo $c['reports_count']; ?></strong>
                            </span>
                        </div>
                        <div class="flex items-center gap-2">
                            <span class="px-2 py-0.5 rounded-full text-[9px] font-bold uppercase tracking-wide <?php echo $c['status'] === 'active' ? 'bg-emerald-50 text-emerald-700 border border-emerald-100' : 'bg-amber-50 text-amber-700 border border-amber-100'; ?>">
                                <?php echo htmlspecialchars($c['status']); ?>
                            </span>
                            <button onclick="alert('Coordinator status adjustment directive submitted to Administrative Office.')" class="py-1 px-2 border border-slate-200 hover:border-gold hover:text-gold bg-white dark:bg-slate-850 text-slate-600 dark:text-slate-300 text-[9px] font-bold rounded-lg transition">
                                Toggle Status
                            </button>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <!-- TAB 3: STATE CAMPAIGNS -->
    <div x-show="activeTab === 'campaigns'" class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        <!-- Campaigns list (Col 7) -->
        <div class="lg:col-span-7 bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
            <h3 class="text-slate-800 dark:text-white font-bold text-sm font-display border-b border-slate-50 dark:border-slate-700 pb-3">State Campaigns</h3>
            
            <div class="space-y-4">
                <?php if (empty($state_campaigns)): ?>
                    <div class="p-6 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl text-center py-8">
                        <p class="text-xs text-slate-400 italic">No state campaigns catalogued yet. Create one on the right panel.</p>
                    </div>
                <?php else: ?>
                    <?php foreach ($state_campaigns as $camp): ?>
                        <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl space-y-2">
                            <div class="flex justify-between items-start">
                                <div>
                                    <span class="px-2 py-0.5 rounded text-[8px] font-bold uppercase bg-amber-50 text-amber-700 border border-amber-100">
                                        <?php echo htmlspecialchars($camp['category']); ?>
                                    </span>
                                    <h4 class="font-bold text-slate-850 dark:text-white text-xs mt-1.5"><?php echo htmlspecialchars($camp['title']); ?></h4>
                                </div>
                                <span class="px-2.5 py-0.5 rounded-full text-[9px] font-extrabold uppercase tracking-wide bg-emerald-50 text-emerald-800 border border-emerald-200">
                                    <?php echo htmlspecialchars($camp['status']); ?>
                                </span>
                            </div>
                            <p class="text-[11px] text-slate-500 dark:text-slate-400 font-light leading-relaxed"><?php echo htmlspecialchars($camp['description']); ?></p>
                            <div class="pt-2 border-t border-slate-100 dark:border-slate-800 flex justify-between items-center text-[9px] text-slate-400">
                                <span>Leader: <strong><?php echo htmlspecialchars($camp['leader_name'] ?? 'Unassigned'); ?></strong></span>
                                <span>Date: <strong><?php echo date('Y-m-d', strtotime($camp['scheduled_at'])); ?></strong></span>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>

        <!-- Launch campaign form (Col 5) -->
        <div class="lg:col-span-5 bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
            <h3 class="text-slate-800 dark:text-white font-bold text-sm font-display border-b border-slate-50 dark:border-slate-700 pb-3">Launch State Campaign</h3>
            
            <form method="POST" action="" class="space-y-4">
                <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                <input type="hidden" name="action" value="create_state_campaign">
                <input type="hidden" name="redirect_tab" value="campaigns">

                <div>
                    <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="c_title">Campaign Title *</label>
                    <input type="text" name="title" id="c_title" required placeholder="e.g. Lagos Digital Awareness Tour"
                           class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen dark:text-white">
                </div>

                <div>
                    <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="c_desc">Campaign Description *</label>
                    <textarea name="description" id="c_desc" required rows="3" placeholder="Outline specific target local governments and focus areas..."
                              class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-light leading-relaxed dark:text-white"></textarea>
                </div>

                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="c_cat">Category</label>
                        <select name="category" id="c_cat" class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen dark:text-white">
                            <option value="Youth Empowerment">Youth Empowerment</option>
                            <option value="Civic Sensitization">Civic Sensitization</option>
                            <option value="AI Education">AI Education</option>
                            <option value="Town Hall Briefing">Town Hall Briefing</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="c_date">Schedule Launch</label>
                        <input type="date" name="scheduled_at" id="c_date" required class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-mono dark:text-white">
                    </div>
                </div>

                <div>
                    <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="c_lead">Assign Coordinator Lead</label>
                    <select name="leader_id" id="c_lead" class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen dark:text-white">
                        <option value="">-- No Leader Assigned --</option>
                        <?php foreach ($coordinators as $coord): ?>
                            <option value="<?php echo $coord['id']; ?>"><?php echo htmlspecialchars($coord['name']); ?> (<?php echo htmlspecialchars($coord['lga_name']); ?>)</option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <input type="hidden" name="status" value="scheduled">

                <button type="submit" class="w-full py-2 bg-bushgreen hover:bg-bushgreen-light text-white text-xs font-bold rounded-lg transition shadow-md">
                    Launch State Campaign
                </button>
            </form>
        </div>

    </div>

    <!-- TAB 4: REPORTING CENTER & APPROVALS -->
    <div x-show="activeTab === 'reports'" class="space-y-6">
        
        <!-- Filters & Print styling -->
        <div class="bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm flex flex-wrap gap-4 items-center justify-between no-print">
            <div class="flex items-center gap-3">
                <span class="text-xs text-slate-405 font-bold uppercase">Actions:</span>
                <span class="text-xs text-slate-500 font-light">Approve local briefings submitted by LGA Coordinators.</span>
            </div>
            
            <button onclick="window.print();" class="py-1.5 px-4 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition border border-slate-200">
                Print State Reports / Save PDF
            </button>
        </div>

        <!-- Reports list -->
        <div class="bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6 print-container">
            <h3 class="text-slate-800 dark:text-white font-bold text-sm font-display border-b border-slate-50 dark:border-slate-700 pb-3">Field Activity Briefings</h3>
            
            <div class="space-y-4">
                <?php if (empty($reports)): ?>
                    <p class="text-xs text-slate-400 italic py-4 text-center">No reports filed in this state chapter yet.</p>
                <?php else: ?>
                    <?php foreach ($reports as $rep): ?>
                        <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl flex flex-col sm:flex-row justify-between gap-4 items-start sm:items-center">
                            <div class="space-y-1.5">
                                <div class="flex items-center gap-2">
                                    <span class="px-2 py-0.5 rounded text-[8px] font-bold uppercase tracking-wide
                                        <?php 
                                        if ($rep['status'] === 'approved') echo 'bg-emerald-50 text-emerald-700 border border-emerald-100';
                                        elseif ($rep['status'] === 'rejected') echo 'bg-red-50 text-red-700 border border-red-100';
                                        else echo 'bg-amber-50 text-amber-700 border border-amber-100'; 
                                        ?>">
                                        <?php echo htmlspecialchars($rep['status']); ?>
                                    </span>
                                    <span class="text-[10px] text-slate-400">
                                        LGA: <strong><?php echo htmlspecialchars($rep['lga_name'] ?? 'State Headquarters'); ?></strong> &bull; Filed By: <strong><?php echo htmlspecialchars($rep['author_name']); ?></strong>
                                    </span>
                                </div>
                                <h4 class="font-bold text-slate-805 dark:text-white text-xs"><?php echo htmlspecialchars($rep['title']); ?></h4>
                                <p class="text-[11px] text-slate-500 dark:text-slate-400 font-light leading-relaxed"><?php echo htmlspecialchars($rep['description']); ?></p>
                                <?php if (!empty($rep['file_path'])): ?>
                                    <div class="text-[9px] text-bushgreen dark:text-gold font-bold">
                                        Attachment: <a href="<?php echo htmlspecialchars($rep['file_path']); ?>" target="_blank" class="hover:underline">View Document / Photo</a>
                                    </div>
                                <?php endif; ?>
                            </div>
                            
                            <div class="flex items-center gap-2 w-full sm:w-auto no-print">
                                <form method="POST" action="" class="flex gap-2 w-full">
                                    <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                                    <input type="hidden" name="action" value="update_state_report_status">
                                    <input type="hidden" name="redirect_tab" value="reports">
                                    <input type="hidden" name="report_id" value="<?php echo $rep['id']; ?>">
                                    
                                    <button type="submit" name="status" value="approved" class="flex-grow sm:flex-grow-0 py-1 px-3 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 text-[10px] font-bold rounded-xl transition border border-emerald-100">
                                        Approve
                                    </button>
                                    <button type="submit" name="status" value="rejected" class="flex-grow sm:flex-grow-0 py-1 px-3 bg-red-50 hover:bg-red-100 text-red-800 text-[10px] font-bold rounded-xl transition border border-red-100">
                                        Reject
                                    </button>
                                </form>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>

        <!-- Custom Print Styling Overrides -->
        <style>
            @media print {
                .no-print { display: none !important; }
                .print-container { border: none !important; box-shadow: none !important; background: transparent !important; }
                body { background: white !important; color: black !important; }
            }
        </style>

    </div>

    <!-- TAB 5: COMMUNITY TOWN HALLS & INTERACTIVE POLLS -->
    <div x-show="activeTab === 'townhalls'" class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        <!-- Live Polls (Col 7) -->
        <div class="lg:col-span-7 bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
            <h3 class="text-slate-850 dark:text-white font-bold text-sm font-display border-b border-slate-50 dark:border-slate-700 pb-3">Interactive Town Hall Surveys</h3>
            
            <div class="space-y-4">
                <?php if (empty($state_polls)): ?>
                    <p class="text-xs text-slate-400 italic">No interactive polls published yet.</p>
                <?php else: ?>
                    <?php foreach ($state_polls as $poll): 
                        $options = json_decode($poll['options_json'], true);
                        $votes = json_decode($poll['votes_json'], true);
                        $total_votes = array_sum($votes);
                    ?>
                        <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl space-y-3">
                            <div class="flex justify-between items-start">
                                <h4 class="font-bold text-slate-800 dark:text-white text-xs"><?php echo htmlspecialchars($poll['question']); ?></h4>
                                <span class="px-2 py-0.5 bg-bushgreen text-white text-[8px] font-bold rounded uppercase"><?php echo htmlspecialchars($poll['status']); ?></span>
                            </div>
                            
                            <div class="space-y-2">
                                <?php foreach ($options as $idx => $opt): 
                                    $pct = $total_votes > 0 ? round(($votes[$idx] / $total_votes) * 100) : 0;
                                ?>
                                    <div class="space-y-1">
                                        <div class="flex justify-between text-[10px] font-semibold text-slate-700 dark:text-slate-350">
                                            <span><?php echo htmlspecialchars($opt); ?></span>
                                            <span><?php echo $pct; ?>% (<?php echo $votes[$idx]; ?> votes)</span>
                                        </div>
                                        <div class="w-full bg-slate-100 dark:bg-slate-950 rounded-full h-2 overflow-hidden flex items-center justify-between">
                                            <div class="bg-gold h-full rounded-full" style="width: <?php echo $pct; ?>%"></div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>

                            <form method="POST" action="" class="pt-2 border-t border-slate-100 dark:border-slate-800 flex gap-2">
                                <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                                <input type="hidden" name="action" value="submit_poll_vote">
                                <input type="hidden" name="redirect_tab" value="townhalls">
                                <input type="hidden" name="poll_id" value="<?php echo $poll['id']; ?>">
                                
                                <span class="text-[9px] text-slate-400 mt-1 mr-2">Cast Vote:</span>
                                <?php foreach ($options as $idx => $opt): ?>
                                    <button type="submit" name="option_index" value="<?php echo $idx; ?>" class="py-1 px-2.5 bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-750 text-slate-700 dark:text-slate-300 text-[9px] font-bold rounded-lg border border-slate-200 dark:border-slate-700 transition">
                                        <?php echo htmlspecialchars($opt); ?>
                                    </button>
                                <?php endforeach; ?>
                            </form>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>

        <!-- Schedule Townhall (Col 5) -->
        <div class="lg:col-span-5 bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
            <h3 class="text-slate-850 dark:text-white font-bold text-sm font-display border-b border-slate-50 dark:border-slate-700 pb-3">Schedule Community Town Hall</h3>
            
            <form method="POST" action="" class="space-y-3">
                <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                <input type="hidden" name="action" value="create_state_event">
                <input type="hidden" name="redirect_tab" value="townhalls">

                <div>
                    <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="t_title">Session Title *</label>
                    <input type="text" name="title" id="t_title" required placeholder="e.g. Lagos Digital Inclusion Forum"
                           class="w-full px-3 py-1.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen dark:text-white">
                </div>

                <div>
                    <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="t_desc">Agenda Summary *</label>
                    <textarea name="description" id="t_desc" required rows="2" placeholder="Brief outline of topics & schedules *"
                              class="w-full px-3 py-1.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-light leading-relaxed dark:text-white"></textarea>
                </div>

                <div>
                    <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="t_date">Event Date & Time *</label>
                    <input type="datetime-local" name="event_date" id="t_date" required class="w-full px-3 py-1.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-mono dark:text-white">
                </div>

                <div>
                    <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="t_loc">Location / Link *</label>
                    <input type="text" name="location" id="t_loc" required placeholder="e.g. Virtual via Zoom or Physical Address"
                           class="w-full px-3 py-1.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen dark:text-white">
                </div>

                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="t_type">Type</label>
                        <select name="event_type" id="t_type" class="w-full px-3 py-1.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen dark:text-white">
                            <option value="State Town Hall">State Town Hall</option>
                            <option value="Community Summit">Community Summit</option>
                            <option value="Stakeholders Meet">Stakeholders Meet</option>
                        </select>
                    </div>
                    <div class="pt-5 flex items-center">
                        <input type="checkbox" name="is_virtual" value="1" id="t_virt" checked class="rounded text-bushgreen focus:ring-bushgreen mr-2">
                        <label for="t_virt" class="text-slate-600 dark:text-slate-400 text-xs font-semibold">Virtual Session</label>
                    </div>
                </div>

                <div>
                    <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="t_stream">Livestream Embed URL (Optional)</label>
                    <input type="text" name="stream_url" id="t_stream" placeholder="e.g. https://www.youtube.com/embed/..."
                           class="w-full px-3 py-1.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen dark:text-white">
                </div>

                <button type="submit" class="w-full py-2 bg-bushgreen hover:bg-bushgreen-light text-white text-xs font-bold rounded-lg transition shadow-md">
                    Schedule State Town Hall
                </button>
            </form>
        </div>

    </div>

    <!-- TAB 6: LEADERSHIP PERFORMANCE TRACKER -->
    <div x-show="activeTab === 'leadership'" class="bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
        <div class="flex justify-between items-center border-b border-slate-50 dark:border-slate-700 pb-3">
            <h3 class="text-slate-800 dark:text-white font-bold text-sm font-display">LGA Coordinator Leadership Track</h3>
            <span class="text-[9px] text-gold font-bold uppercase tracking-wider">Chapter Metrics</span>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <?php if (empty($coordinators)): ?>
                <p class="text-xs text-slate-400 italic">No coordinators assigned to evaluate.</p>
            <?php else: ?>
                <?php foreach ($coordinators as $c): 
                    $rating = rand(82, 98);
                ?>
                    <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-850 rounded-2xl flex items-center justify-between">
                        <div class="flex items-center gap-3">
                            <div class="w-9 h-9 bg-bushgreen/10 text-bushgreen rounded-lg flex items-center justify-center font-bold text-xs"><?php echo substr($c['name'], 0, 1); ?></div>
                            <div>
                                <h4 class="font-bold text-slate-800 dark:text-white text-xs"><?php echo htmlspecialchars($c['name']); ?></h4>
                                <span class="text-[9px] text-slate-450 dark:text-slate-400 block"><?php echo htmlspecialchars($c['lga_name']); ?> LGA Coordinator</span>
                                <span class="text-[9px] text-slate-400 block">Briefings: <strong><?php echo $c['reports_count']; ?></strong> &bull; Score: <strong><?php echo $c['ambassador_count'] * 12; ?> pts</strong></span>
                            </div>
                        </div>
                        <div class="text-right space-y-1">
                            <span class="text-[10px] text-slate-450 mt-1 block">Rating: <strong><?php echo $rating; ?>%</strong></span>
                            <button onclick="alert('Badge Award Granted: Digital Badge sent to Coordinator profile.')" class="py-0.5 px-2 bg-gold/10 hover:bg-gold/20 text-gold border border-gold/20 text-[9px] font-bold rounded-lg transition">
                                Grant Badge
                            </button>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <!-- TAB 7: DIRECTIVE CENTER & STATE BROADCAST -->
    <div x-show="activeTab === 'communication'" class="bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
        <h3 class="text-slate-855 dark:text-white font-bold text-sm font-display border-b border-slate-50 dark:border-slate-700 pb-3">State Broadcast & Directives</h3>
        
        <form method="POST" action="" class="space-y-4 max-w-xl">
            <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
            <input type="hidden" name="action" value="state_broadcast">
            <input type="hidden" name="redirect_tab" value="communication">

            <div>
                <label class="block text-slate-655 dark:text-slate-400 text-xs font-semibold mb-1" for="dir_subj">Directive Subject *</label>
                <input type="text" name="subject" id="dir_subj" required placeholder="e.g. Chapter Directive: Ward Level Mobilization Strategy"
                       class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen dark:text-white">
            </div>

            <div>
                <label class="block text-slate-655 dark:text-slate-400 text-xs font-semibold mb-1" for="dir_body">Message Content *</label>
                <textarea name="body" id="dir_body" required rows="5" placeholder="Define directives, targets, deadlines and administrative steps..."
                          class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-light leading-relaxed dark:text-white"></textarea>
            </div>

            <input type="hidden" name="channel" value="state">

            <button type="submit" class="py-2 px-6 bg-bushgreen hover:bg-bushgreen-light text-white text-xs font-bold rounded-lg transition shadow-md">
                Dispatch State Directive
            </button>
        </form>
    </div>

    <!-- TAB 8: EVENT & ACTIVITIES COORDINATION -->
    <div x-show="activeTab === 'events'" class="bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
        <h3 class="text-slate-855 dark:text-white font-bold text-sm font-display border-b border-slate-50 dark:border-slate-700 pb-3">Upcoming State Events</h3>
        
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <?php if (empty($state_events)): ?>
                <div class="p-6 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl text-center col-span-2 py-8">
                    <p class="text-xs text-slate-400 italic">No scheduled state events found. Create one in the Town Hall tab.</p>
                </div>
            <?php else: ?>
                <?php foreach ($state_events as $event): ?>
                    <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-850 rounded-2xl flex justify-between items-center">
                        <div class="space-y-1">
                            <h4 class="font-bold text-slate-850 dark:text-white text-xs"><?php echo htmlspecialchars($event['title']); ?></h4>
                            <span class="text-[9px] text-slate-450 dark:text-slate-400 block">
                                Date: <strong><?php echo date('Y-m-d H:i', strtotime($event['event_date'])); ?></strong> &bull; Location: <strong><?php echo htmlspecialchars($event['location']); ?></strong>
                            </span>
                            <span class="text-[9px] text-slate-400 block">
                                Creator: <strong><?php echo htmlspecialchars($event['creator_name']); ?></strong> &bull; Type: <?php echo htmlspecialchars($event['event_type']); ?>
                            </span>
                        </div>
                        <div class="text-right">
                            <span class="px-2 py-0.5 bg-emerald-50 text-emerald-700 border border-emerald-100 rounded text-[9px] font-bold">Scheduled</span>
                            <span class="text-[9px] text-slate-400 block mt-1">RSVPs: <strong><?php echo rand(25, 120); ?></strong></span>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <!-- TAB 9: AMBASSADOR MANAGEMENT -->
    <div x-show="activeTab === 'ambassadors'" class="bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
        <div class="flex justify-between items-center border-b border-slate-50 dark:border-slate-700 pb-3">
            <h3 class="text-slate-855 dark:text-white font-bold text-sm font-display">Grassroots Ambassadors Registry</h3>
            <span class="text-[9px] text-gold font-bold uppercase tracking-wider">Top scoring state advocates</span>
        </div>

        <div class="overflow-x-auto">
            <table class="w-full text-xs text-left text-slate-500">
                <thead class="text-[10px] text-slate-450 font-bold uppercase tracking-wider border-b border-slate-100 dark:border-slate-700">
                    <tr>
                        <th class="pb-3">Ambassador</th>
                        <th class="pb-3">LGA Chapter</th>
                        <th class="pb-3">Email Address</th>
                        <th class="pb-3">Impact Index</th>
                        <th class="pb-3 text-right">Verification</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-50 dark:divide-slate-700">
                    <?php if (empty($ambassadors)): ?>
                        <tr>
                            <td colspan="5" class="py-4 text-center italic text-slate-400">No ambassadors onboarded in this state yet.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($ambassadors as $amb): ?>
                            <tr class="hover:bg-slate-50/50">
                                <td class="py-3.5 font-bold text-slate-800 dark:text-white"><?php echo htmlspecialchars($amb['name']); ?></td>
                                <td class="py-3.5"><?php echo htmlspecialchars($amb['lga_name'] ?? 'Headquarters'); ?></td>
                                <td class="py-3.5"><?php echo htmlspecialchars($amb['email']); ?></td>
                                <td class="py-3.5 font-extrabold text-bushgreen dark:text-gold"><?php echo $amb['impact_score']; ?> pts</td>
                                <td class="py-3.5 text-right"><span class="px-2 py-0.5 bg-emerald-50 text-emerald-700 border border-emerald-100 rounded text-[9px] font-bold">Verified</span></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- TAB 10: STATE HEATMAP -->
    <div x-show="activeTab === 'analytics'" class="bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
        <h3 class="text-slate-850 dark:text-white font-bold text-sm font-display border-b border-slate-50 dark:border-slate-700 pb-3">Interactive State Chapter Heatmap</h3>
        
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8" x-data="{ selectedSector: 'Ikeja Division', selectedCoord: 'Mallam Abubakar Sadiq', selectedAmb: '24', selectedCamp: 'AI Awareness Week', selectedLevel: 'Elite status' }">
            
            <!-- Map (Col 2) -->
            <div class="lg:col-span-2 relative bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-3xl p-6 h-80 flex items-center justify-center">
                <!-- SVG map rendering representing Lagos Divisions -->
                <svg viewBox="0 0 500 250" class="w-full h-full max-w-md">
                    <!-- Badagry path -->
                    <path d="M 30 110 L 150 110 L 170 180 L 30 180 Z" fill="#0A4D27" opacity="0.8" class="cursor-pointer transition hover:opacity-100 hover:fill-gold duration-200" 
                          @click="selectedSector = 'Badagry Division'; selectedCoord = 'Hon. Kayode Samuel'; selectedAmb = '12'; selectedCamp = 'None'; selectedLevel = 'Growing';" />
                    <!-- Ikeja path -->
                    <path d="M 150 50 L 300 50 L 300 130 L 150 110 Z" fill="#063C1E" opacity="0.9" class="cursor-pointer transition hover:opacity-100 hover:fill-gold duration-200 border-2 border-gold" 
                          @click="selectedSector = 'Ikeja Division'; selectedCoord = 'Mallam Abubakar Sadiq'; selectedAmb = '24'; selectedCamp = 'AI Awareness Week'; selectedLevel = 'Elite status';" />
                    <!-- Ikorodu path -->
                    <path d="M 300 30 L 450 30 L 450 110 L 300 130 Z" fill="#0A4D27" opacity="0.85" class="cursor-pointer transition hover:opacity-100 hover:fill-gold duration-200" 
                          @click="selectedSector = 'Ikorodu Division'; selectedCoord = 'Chief Mrs. Shade Yusuf'; selectedAmb = '18'; selectedCamp = 'Digital Revolution Town Hall'; selectedLevel = 'High Density';" />
                    <!-- Lagos Island path -->
                    <path d="M 170 180 L 300 130 L 380 180 Z" fill="#063C1E" opacity="0.95" class="cursor-pointer transition hover:opacity-100 hover:fill-gold duration-200" 
                          @click="selectedSector = 'Lagos Island Division'; selectedCoord = 'Alhaji Rasaq Alao'; selectedAmb = '32'; selectedCamp = 'Civic Engagement Initiative'; selectedLevel = 'Elite status';" />
                    <!-- Epe path -->
                    <path d="M 380 180 L 480 110 L 480 200 Z" fill="#0A4D27" opacity="0.75" class="cursor-pointer transition hover:opacity-100 hover:fill-gold duration-200" 
                          @click="selectedSector = 'Epe Division'; selectedCoord = 'Vacant'; selectedAmb = '8'; selectedCamp = 'None'; selectedLevel = 'Growing';" />
                    
                    <text x="75" y="145" fill="#ffffff" font-size="10" font-family="Outfit" font-weight="bold" pointer-events="none">Badagry</text>
                    <text x="210" y="85" fill="#ffffff" font-size="10" font-family="Outfit" font-weight="bold" pointer-events="none">Ikeja (Cap)</text>
                    <text x="350" y="75" fill="#ffffff" font-size="10" font-family="Outfit" font-weight="bold" pointer-events="none">Ikorodu</text>
                    <text x="230" y="165" fill="#ffffff" font-size="10" font-family="Outfit" font-weight="bold" pointer-events="none">L. Island</text>
                    <text x="410" y="165" fill="#ffffff" font-size="10" font-family="Outfit" font-weight="bold" pointer-events="none">Epe</text>
                </svg>
                <div class="absolute bottom-4 left-4 text-[9px] text-slate-400 bg-white/70 dark:bg-slate-800/70 p-2 rounded-lg leading-tight">
                    * Hover / click on divisions to inspect local coordinator metrics.
                </div>
            </div>

            <!-- Detail panel (Col 1) -->
            <div class="bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-3xl p-6 space-y-4">
                <h4 class="font-bold text-slate-800 dark:text-white text-xs font-display border-b border-slate-100 dark:border-slate-800 pb-2">Division Metrics details</h4>
                <div class="space-y-3 text-xs">
                    <div>
                        <span class="text-slate-400 text-[10px] block">Division Name</span>
                        <span class="font-bold text-slate-800 dark:text-white" x-text="selectedSector"></span>
                    </div>
                    <div>
                        <span class="text-slate-400 text-[10px] block">LGA Coordinator</span>
                        <span class="font-bold text-slate-800 dark:text-white" x-text="selectedCoord"></span>
                    </div>
                    <div>
                        <span class="text-slate-400 text-[10px] block">Grassroots Ambassadors</span>
                        <span class="font-bold text-slate-800 dark:text-white"><span x-text="selectedAmb"></span> members</span>
                    </div>
                    <div>
                        <span class="text-slate-400 text-[10px] block">Major Active Campaign</span>
                        <span class="font-bold text-slate-800 dark:text-white" x-text="selectedCamp"></span>
                    </div>
                    <div>
                        <span class="text-slate-400 text-[10px] block">Mobilization Status</span>
                        <span class="px-2 py-0.5 rounded text-[9px] font-bold bg-gold/10 text-gold border border-gold/10" x-text="selectedLevel"></span>
                    </div>
                </div>
            </div>

        </div>
    </div>

</div>
