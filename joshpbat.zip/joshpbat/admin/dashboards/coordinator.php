<?php
/**
 * LGA Coordinator Dashboard (Role 6)
 * Grassroots Digital Mobilization Command Center
 */
if (!defined('DB_HOST')) {
    exit('Access Denied');
}

$active_tab = $_GET['tab'] ?? 'overview';
$user = Auth::user();
$user_id = $user['id'];

try {
    $db = Database::connect();
    
    // Resolve coordinator's active state and LGA coordinates
    $stmt = $db->prepare("SELECT state_id, lga_id FROM `user_leadership` WHERE user_id = ? LIMIT 1");
    $stmt->execute([$user_id]);
    $lead_info = $stmt->fetch();
    $state_id = $lead_info['state_id'] ?? 1;
    $lga_id = $lead_info['lga_id'] ?? 1;
    
    // Get state details
    $stmt_state = $db->prepare("SELECT name FROM `states` WHERE id = ? LIMIT 1");
    $stmt_state->execute([$state_id]);
    $state_name = $stmt_state->fetchColumn() ?: 'Lagos';
    
    // Get LGA details
    $stmt_lga = $db->prepare("SELECT name FROM `lgas` WHERE id = ? LIMIT 1");
    $stmt_lga->execute([$lga_id]);
    $lga_name = $stmt_lga->fetchColumn() ?: 'Ikeja';
    
    // Fetch Wards in this LGA
    $stmt_wards = $db->prepare("SELECT * FROM `wards` WHERE lga_id = ? ORDER BY name ASC");
    $stmt_wards->execute([$lga_id]);
    $lga_wards = $stmt_wards->fetchAll();
    
    // Fetch active ambassadors in this LGA
    $stmt_ambassadors = $db->prepare("
        SELECT a.*, u.name, u.email, u.status, w.name as ward_name
        FROM `ambassadors` a
        JOIN `users` u ON a.user_id = u.id
        LEFT JOIN `wards` w ON a.ward_id = w.id
        WHERE a.lga_id = ?
        ORDER BY a.impact_score DESC
    ");
    $stmt_ambassadors->execute([$lga_id]);
    $ambassadors = $stmt_ambassadors->fetchAll();
    
    // Fetch campaigns in this LGA or created by this coordinator
    $stmt_campaigns = $db->prepare("
        SELECT c.*, u.name as leader_name, creator.name as creator_name
        FROM `campaigns` c
        LEFT JOIN `users` u ON c.leader_id = u.id
        JOIN `users` creator ON c.created_by = creator.id
        WHERE c.created_by = ? OR c.leader_id IN (
            SELECT user_id FROM `ambassadors` WHERE lga_id = ?
        )
        ORDER BY c.created_at DESC
    ");
    $stmt_campaigns->execute([$user_id, $lga_id]);
    $campaigns = $stmt_campaigns->fetchAll();
    
    // Fetch local events scheduled by this coordinator
    $stmt_events = $db->prepare("
        SELECT e.*, u.name as creator_name
        FROM `events` e
        JOIN `users` u ON e.created_by = u.id
        WHERE e.created_by = ? OR e.location LIKE ?
        ORDER BY e.event_date DESC
    ");
    $stmt_events->execute([$user_id, '%' . $lga_name . '%']);
    $events = $stmt_events->fetchAll();
    
    // Fetch reports submitted by this coordinator
    $stmt_reports = $db->prepare("
        SELECT r.*, u.name as author_name
        FROM `reports` r
        JOIN `users` u ON r.user_id = u.id
        WHERE r.user_id = ?
        ORDER BY r.created_at DESC
    ");
    $stmt_reports->execute([$user_id]);
    $reports = $stmt_reports->fetchAll();

    // Fetch talent pipeline registrations for current user
    $stmt_tp = $db->prepare("SELECT * FROM `talent_pipeline` WHERE `user_id` = ? ORDER BY `created_at` DESC");
    $stmt_tp->execute([$user_id]);
    $talent_submissions = $stmt_tp->fetchAll();

    // Fetch volunteer profile for current user
    $stmt_vol = $db->prepare("SELECT * FROM `volunteers` WHERE `user_id` = ? LIMIT 1");
    $stmt_vol->execute([$user_id]);
    $volunteer_profile = $stmt_vol->fetch() ?: null;
    
} catch (Exception $e) {
    $lga_wards = [];
    $ambassadors = [];
    $campaigns = [];
    $events = [];
    $reports = [];
    $talent_submissions = [];
    $volunteer_profile = null;
}

$total_amb = count($ambassadors);
$total_camps = count($campaigns);
$total_evts = count($events);
$total_score = array_sum(array_column($ambassadors, 'impact_score'));
?>

<div class="space-y-8" x-data="{ activeTab: '<?php echo htmlspecialchars($active_tab); ?>' }">

    <!-- Coordinator Header -->
    <div class="bg-gradient-to-r from-bushgreen to-bushgreen-light text-white p-8 rounded-3xl shadow-xl relative overflow-hidden border border-gold/30">
        <div class="absolute inset-0 bg-cover bg-center mix-blend-overlay opacity-10 bg-[url('https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=600&q=80')]"></div>
        <div class="relative z-10 space-y-3">
            <span class="px-2.5 py-1 bg-gold/20 text-gold rounded-full text-[9px] font-bold uppercase tracking-widest leading-none font-display border border-gold/25">LGA Coordinator Desk</span>
            <h2 class="text-3xl font-black font-display leading-tight text-white tracking-tight"><?php echo htmlspecialchars($lga_name); ?> Command Center</h2>
            <p class="text-slate-355 text-xs font-light max-w-xl">
                Mobilize local wards, track grassroots tech campaigns, register ambassadors, schedule town halls, and consolidate community briefs inside <?php echo htmlspecialchars($state_name); ?> State.
            </p>
        </div>
    </div>

    <!-- MAIN DYNAMIC CONTENT ROUTER -->

    <!-- TAB 1: OVERVIEW -->
    <div x-show="activeTab === 'overview'" class="space-y-8">
        
        <!-- KPI Row -->
        <div class="grid grid-cols-1 sm:grid-cols-4 gap-6">
            <div class="bg-white dark:bg-slate-800 p-6 rounded-3xl border border-slate-100 dark:border-slate-700 shadow-sm flex items-center justify-between">
                <div class="space-y-1">
                    <span class="text-slate-400 text-[10px] font-bold uppercase tracking-wider block">Wards Seeded</span>
                    <div class="text-3xl font-black text-bushgreen dark:text-white font-display"><?php echo count($lga_wards); ?> Wards</div>
                    <span class="text-[9px] text-emerald-600 font-bold bg-emerald-50 px-2 py-0.5 rounded">Grassroots Units</span>
                </div>
                <div class="w-12 h-12 rounded-2xl bg-bushgreen/5 flex items-center justify-center text-bushgreen dark:text-gold"><svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/></svg></div>
            </div>

            <div class="bg-white dark:bg-slate-800 p-6 rounded-3xl border border-slate-100 dark:border-slate-700 shadow-sm flex items-center justify-between">
                <div class="space-y-1">
                    <span class="text-slate-400 text-[10px] font-bold uppercase tracking-wider block">LGA Ambassadors</span>
                    <div class="text-3xl font-black text-bushgreen dark:text-white font-display"><?php echo number_format($total_amb); ?></div>
                    <span class="text-[9px] text-slate-400">Verified advocates</span>
                </div>
                <div class="w-12 h-12 rounded-2xl bg-bushgreen/5 flex items-center justify-center text-bushgreen dark:text-gold"><svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"/></svg></div>
            </div>

            <div class="bg-white dark:bg-slate-800 p-6 rounded-3xl border border-slate-100 dark:border-slate-700 shadow-sm flex items-center justify-between">
                <div class="space-y-1">
                    <span class="text-slate-400 text-[10px] font-bold uppercase tracking-wider block">Local Campaigns</span>
                    <div class="text-3xl font-black text-bushgreen dark:text-white font-display"><?php echo $total_camps; ?></div>
                    <span class="text-[9px] text-amber-600 font-bold bg-amber-50 px-2 py-0.5 rounded">Active initiatives</span>
                </div>
                <div class="w-12 h-12 rounded-2xl bg-bushgreen/5 flex items-center justify-center text-bushgreen dark:text-gold"><svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg></div>
            </div>

            <div class="bg-white dark:bg-slate-800 p-6 rounded-3xl border border-slate-100 dark:border-slate-700 shadow-sm flex items-center justify-between">
                <div class="space-y-1">
                    <span class="text-slate-400 text-[10px] font-bold uppercase tracking-wider block">LGA Impact Score</span>
                    <div class="text-3xl font-black text-bushgreen dark:text-white font-display"><?php echo number_format($total_score); ?></div>
                    <span class="text-[9px] text-slate-400">Advocacy index points</span>
                </div>
                <div class="w-12 h-12 rounded-2xl bg-bushgreen/5 flex items-center justify-center text-bushgreen dark:text-gold"><svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg></div>
            </div>
        </div>

        <!-- Grid of Wards density and Command feed -->
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-8">
            
            <!-- Wards list -->
            <div class="lg:col-span-7 bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
                <h3 class="text-slate-800 dark:text-white font-bold text-sm font-display border-b border-slate-50 dark:border-slate-700 pb-3">Ward chapter mobilizations</h3>
                
                <div class="space-y-4 max-h-[350px] overflow-y-auto pr-2">
                    <?php if (empty($lga_wards)): ?>
                        <p class="text-xs text-slate-400 italic">No administrative wards seeded.</p>
                    <?php else: ?>
                        <?php foreach ($lga_wards as $ward): 
                            // Count ambassadors in this ward
                            $w_amb_count = 0;
                            foreach ($ambassadors as $a) {
                                if ($a['ward_id'] == $ward['id']) {
                                    $w_amb_count++;
                                }
                            }
                            $ward_pct = min(100, ($w_amb_count / 5) * 100);
                        ?>
                            <div class="space-y-2">
                                <div class="flex justify-between text-xs font-semibold text-slate-700 dark:text-slate-350">
                                    <span class="flex items-center gap-1.5">
                                        <span class="w-1.5 h-1.5 rounded-full bg-bushgreen dark:bg-gold"></span>
                                        <?php echo htmlspecialchars($ward['name']); ?>
                                    </span>
                                    <span class="text-[10px] text-slate-400"><?php echo $w_amb_count; ?> Ambassadors / 5 target</span>
                                </div>
                                <div class="w-full bg-slate-100 dark:bg-slate-900 rounded-full h-2 overflow-hidden">
                                    <div class="bg-bushgreen dark:bg-gold h-full rounded-full" style="width: <?php echo max(5, $ward_pct); ?>%"></div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Command Live Ticker -->
            <div class="lg:col-span-5 space-y-8">
                
                <div class="bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-4">
                    <h4 class="text-slate-850 dark:text-white font-bold text-xs font-display flex items-center gap-1.5 border-b border-slate-50 dark:border-slate-700 pb-2">
                        <span class="w-2.5 h-2.5 bg-emerald-500 rounded-full animate-ping"></span>
                        LGA Command feed
                    </h4>
                    <div class="h-32 overflow-y-auto space-y-2.5 text-[10px] leading-relaxed">
                        <div class="p-2 bg-slate-50 dark:bg-slate-900 rounded-xl">
                            <span class="text-gold font-bold">[Live]</span> Grassroots Ambassador profile registered for Ikeja Ward Unit.
                        </div>
                        <div class="p-2 bg-slate-50 dark:bg-slate-900 rounded-xl">
                            <span class="text-gold font-bold">[Live]</span> Local campaign outreach scheduled for Friday morning.
                        </div>
                        <div class="p-2 bg-slate-50 dark:bg-slate-900 rounded-xl">
                            <span class="text-gold font-bold">[Live]</span> Briefing summary filed and dispatched to State Chairman.
                        </div>
                    </div>
                </div>

                <div class="bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-4">
                    <h4 class="text-slate-855 dark:text-white font-bold text-xs font-display flex items-center gap-1.5 border-b border-slate-50 dark:border-slate-700 pb-2">
                        🧠 Mobilization Intelligence
                    </h4>
                    <p class="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed font-light">
                        Ward registration averages are growing at 12% weekly. Focus on setting up a <strong>Youth Tech Sensitization program</strong> to capitalize on local digital interest.
                    </p>
                </div>

            </div>
        </div>
    </div>

    <!-- TAB 2: GRASSROOTS AMBASSADOR MANAGEMENT -->
    <div x-show="activeTab === 'ambassadors'" class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        <!-- Roster (Col 7) -->
        <div class="lg:col-span-7 bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
            <div class="flex justify-between items-center border-b border-slate-50 dark:border-slate-700 pb-3">
                <h3 class="text-slate-800 dark:text-white font-bold text-sm font-display">Grassroots Ambassadors Roster</h3>
                <span class="text-[9px] text-gold font-bold uppercase tracking-wider">Top scoring advocates</span>
            </div>

            <div class="overflow-x-auto">
                <table class="w-full text-xs text-left text-slate-500">
                    <thead class="text-[10px] text-slate-450 font-bold uppercase tracking-wider border-b border-slate-100 dark:border-slate-700">
                        <tr>
                            <th class="pb-3">Ambassador</th>
                            <th class="pb-3">Ward Chapter</th>
                            <th class="pb-3">Email</th>
                            <th class="pb-3">Score</th>
                            <th class="pb-3 text-right">Digital ID</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-50 dark:divide-slate-700">
                        <?php if (empty($ambassadors)): ?>
                            <tr>
                                <td colspan="5" class="py-4 text-center italic text-slate-400">No ambassadors onboarded in this LGA yet.</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($ambassadors as $amb): ?>
                                <tr class="hover:bg-slate-50/50">
                                    <td class="py-3.5 font-bold text-slate-800 dark:text-white"><?php echo htmlspecialchars($amb['name']); ?></td>
                                    <td class="py-3.5"><?php echo htmlspecialchars($amb['ward_name'] ?? 'Headquarters'); ?></td>
                                    <td class="py-3.5"><?php echo htmlspecialchars($amb['email']); ?></td>
                                    <td class="py-3.5 font-extrabold text-bushgreen dark:text-gold"><?php echo $amb['impact_score']; ?> pts</td>
                                    <td class="py-3.5 text-right">
                                        <a href="id-card.php?uuid=<?php echo urlencode($amb['uuid']); ?>" target="_blank" class="py-0.5 px-2 bg-emerald-50 text-emerald-700 border border-emerald-100 rounded text-[9px] font-bold hover:bg-emerald-100 transition">
                                            View ID Card
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Registration form (Col 5) -->
        <div class="lg:col-span-5 bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
            <h3 class="text-slate-800 dark:text-white font-bold text-sm font-display border-b border-slate-50 dark:border-slate-700 pb-3">Register Ambassador</h3>
            
            <form method="POST" action="" class="space-y-4">
                <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                <input type="hidden" name="action" value="register_lga_ambassador">
                <input type="hidden" name="redirect_tab" value="ambassadors">

                <div>
                    <label class="block text-slate-655 dark:text-slate-400 text-xs font-semibold mb-1" for="a_name">Full Name *</label>
                    <input type="text" name="name" id="a_name" required placeholder="e.g. Amara Eke"
                           class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen dark:text-white">
                </div>

                <div>
                    <label class="block text-slate-655 dark:text-slate-400 text-xs font-semibold mb-1" for="a_email">Email Address *</label>
                    <input type="email" name="email" id="a_email" required placeholder="e.g. ambassador@pbat-smartnation.ng"
                           class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen dark:text-white">
                </div>

                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-slate-655 dark:text-slate-400 text-xs font-semibold mb-1" for="a_phone">Phone Number</label>
                        <input type="text" name="phone" id="a_phone" placeholder="080..."
                               class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen dark:text-white">
                    </div>
                    <div>
                        <label class="block text-slate-655 dark:text-slate-400 text-xs font-semibold mb-1" for="a_ward">Select Ward *</label>
                        <select name="ward_id" id="a_ward" required class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen dark:text-white">
                            <?php foreach ($lga_wards as $ward): ?>
                                <option value="<?php echo $ward['id']; ?>"><?php echo htmlspecialchars($ward['name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <div>
                    <label class="block text-slate-655 dark:text-slate-400 text-xs font-semibold mb-1" for="a_pass">Password *</label>
                    <input type="password" name="password" id="a_pass" required value="password123"
                           class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen dark:text-white">
                </div>

                <button type="submit" class="w-full py-2 bg-bushgreen hover:bg-bushgreen-light text-white text-xs font-bold rounded-lg transition shadow-md">
                    Register & Verify Ambassador
                </button>
            </form>
        </div>

    </div>

    <!-- TAB 3: COMMUNITY CAMPAIGN MANAGEMENT -->
    <div x-show="activeTab === 'campaigns'" class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        <!-- Campaigns list (Col 7) -->
        <div class="lg:col-span-7 bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
            <h3 class="text-slate-800 dark:text-white font-bold text-sm font-display border-b border-slate-50 dark:border-slate-700 pb-3">Local Outreach Campaigns</h3>
            
            <div class="space-y-4">
                <?php if (empty($campaigns)): ?>
                    <p class="text-xs text-slate-400 italic py-4 text-center">No community campaigns launched yet. Create one using the right panel form.</p>
                <?php else: ?>
                    <?php foreach ($campaigns as $camp): ?>
                        <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl space-y-2">
                            <div class="flex justify-between items-start">
                                <div>
                                    <span class="px-2 py-0.5 rounded text-[8px] font-bold uppercase bg-amber-50 text-amber-700 border border-amber-100">
                                        <?php echo htmlspecialchars($camp['category']); ?>
                                    </span>
                                    <h4 class="font-bold text-slate-850 dark:text-white text-xs mt-1.5"><?php echo htmlspecialchars($camp['title']); ?></h4>
                                </div>
                                <span class="px-2.5 py-0.5 rounded-full text-[9px] font-extrabold uppercase tracking-wide bg-emerald-50 text-emerald-800 border border-emerald-200">
                                    <?php echo htmlspecialchars($camp['status']); ?>
                                </span>
                            </div>
                            <p class="text-[11px] text-slate-500 dark:text-slate-400 font-light leading-relaxed"><?php echo htmlspecialchars($camp['description']); ?></p>
                            <div class="pt-2 border-t border-slate-100 dark:border-slate-800 flex justify-between items-center text-[9px] text-slate-400">
                                <span>Leader: <strong><?php echo htmlspecialchars($camp['leader_name'] ?? 'Grassroots Chapter'); ?></strong></span>
                                <span>Launch: <strong><?php echo date('Y-m-d', strtotime($camp['scheduled_at'])); ?></strong></span>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>

        <!-- Launch campaign form (Col 5) -->
        <div class="lg:col-span-5 bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
            <h3 class="text-slate-800 dark:text-white font-bold text-sm font-display border-b border-slate-50 dark:border-slate-700 pb-3">Launch Local Campaign</h3>
            
            <form method="POST" action="" class="space-y-4">
                <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                <input type="hidden" name="action" value="create_lga_campaign">
                <input type="hidden" name="redirect_tab" value="campaigns">

                <div>
                    <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="lc_title">Campaign Title *</label>
                    <input type="text" name="title" id="lc_title" required placeholder="e.g. Ikeja Youth Digital Awareness Drive"
                           class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen dark:text-white">
                </div>

                <div>
                    <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="lc_desc">Campaign Description *</label>
                    <textarea name="description" id="lc_desc" required rows="3" placeholder="Outline specific target wards and local communities..."
                              class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-light leading-relaxed dark:text-white"></textarea>
                </div>

                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="lc_cat">Category</label>
                        <select name="category" id="lc_cat" class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen dark:text-white">
                            <option value="Youth Digital Awareness">Youth Digital Awareness</option>
                            <option value="Community Outreach">Community Outreach</option>
                            <option value="AI Literacy Campaign">AI Literacy Campaign</option>
                            <option value="Tech Empowerment">Tech Empowerment</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="lc_date">Launch Date</label>
                        <input type="date" name="scheduled_at" id="lc_date" required class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-mono dark:text-white">
                    </div>
                </div>

                <input type="hidden" name="status" value="active">

                <button type="submit" class="w-full py-2 bg-bushgreen hover:bg-bushgreen-light text-white text-xs font-bold rounded-lg transition shadow-md">
                    Launch Campaign Outreach
                </button>
            </form>
        </div>

    </div>

    <!-- TAB 4: EVENT & TOWN HALL MANAGEMENT -->
    <div x-show="activeTab === 'events'" class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        <!-- Local events list -->
        <div class="lg:col-span-7 bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-4">
            <h3 class="text-slate-850 dark:text-white font-bold text-sm font-display border-b border-slate-50 dark:border-slate-700 pb-3">Scheduled Local Events</h3>
            
            <div class="space-y-4">
                <?php if (empty($events)): ?>
                    <p class="text-xs text-slate-400 italic py-4 text-center">No local community events scheduled.</p>
                <?php else: ?>
                    <?php foreach ($events as $event): ?>
                        <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl space-y-2">
                            <div class="flex justify-between items-start">
                                <h4 class="font-bold text-slate-800 dark:text-white text-xs"><?php echo htmlspecialchars($event['title']); ?></h4>
                                <span class="px-2 py-0.5 bg-bushgreen text-white text-[8px] font-bold rounded uppercase">Local event</span>
                            </div>
                            <p class="text-[10px] text-slate-550 dark:text-slate-400 font-light"><?php echo htmlspecialchars($event['description']); ?></p>
                            <div class="pt-2 border-t border-slate-100 dark:border-slate-800 flex justify-between items-center text-[9px] text-slate-400">
                                <span>Date: <strong><?php echo date('Y-m-d H:i', strtotime($event['event_date'])); ?></strong></span>
                                <span>Location: <strong><?php echo htmlspecialchars($event['location']); ?></strong></span>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>

        <!-- Schedule form -->
        <div class="lg:col-span-5 bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
            <h3 class="text-slate-855 dark:text-white font-bold text-sm font-display border-b border-slate-50 dark:border-slate-700 pb-3">Schedule Community Town Hall</h3>
            
            <form method="POST" action="" class="space-y-3">
                <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                <input type="hidden" name="action" value="create_lga_event">
                <input type="hidden" name="redirect_tab" value="events">

                <input type="text" name="title" required placeholder="Event / Town Hall Subject Heading *" class="w-full px-3 py-1.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen dark:text-white">
                <textarea name="description" required rows="2" placeholder="Agenda outline / summaries *" class="w-full px-3 py-1.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-light leading-relaxed dark:text-white"></textarea>
                <input type="datetime-local" name="event_date" required class="w-full px-3 py-1.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-mono dark:text-white">
                <input type="text" name="location" required placeholder="e.g. Municipal Hall or Zoom Link *" class="w-full px-3 py-1.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen dark:text-white">
                
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <select name="event_type" class="w-full px-3 py-1.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen dark:text-white">
                            <option value="Community Town Hall">Community Town Hall</option>
                            <option value="LGA Outreach">LGA Outreach</option>
                            <option value="Youth Assembly">Youth Assembly</option>
                        </select>
                    </div>
                    <div class="pt-1.5 flex items-center">
                        <input type="checkbox" name="is_virtual" value="1" id="e_virt" class="rounded text-bushgreen focus:ring-bushgreen mr-2">
                        <label for="e_virt" class="text-slate-600 dark:text-slate-400 text-xs font-semibold">Virtual</label>
                    </div>
                </div>

                <input type="text" name="stream_url" placeholder="Optional YouTube / Twitch embed URL" class="w-full px-3 py-1.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen dark:text-white">

                <button type="submit" class="w-full py-2 bg-bushgreen hover:bg-bushgreen-light text-white text-xs font-bold rounded-lg transition shadow-md">
                    Schedule Event Outreach
                </button>
            </form>
        </div>

    </div>

    <!-- TAB 5: ACTIVITY REPORTING SYSTEM -->
    <div x-show="activeTab === 'reports'" class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        <!-- Reports submitted history (Col 7) -->
        <div class="lg:col-span-7 bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
            <div class="flex justify-between items-center border-b border-slate-50 dark:border-slate-700 pb-3">
                <h3 class="text-slate-800 dark:text-white font-bold text-sm font-display">Submitted Activity Briefs</h3>
                <button onclick="window.print();" class="py-1 px-3 bg-slate-100 hover:bg-slate-200 text-slate-700 text-[10px] font-bold rounded-xl transition border border-slate-200">
                    Download PDF Reports
                </button>
            </div>

            <div class="space-y-4">
                <?php if (empty($reports)): ?>
                    <p class="text-xs text-slate-400 italic py-4 text-center">No reports filed by your command office yet.</p>
                <?php else: ?>
                    <?php foreach ($reports as $rep): ?>
                        <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl space-y-2">
                            <div class="flex justify-between items-center">
                                <h4 class="font-bold text-slate-850 dark:text-white text-xs"><?php echo htmlspecialchars($rep['title']); ?></h4>
                                <span class="px-2 py-0.5 rounded text-[8px] font-bold uppercase tracking-wide
                                    <?php 
                                    if ($rep['status'] === 'approved') echo 'bg-emerald-50 text-emerald-700 border border-emerald-100';
                                    elseif ($rep['status'] === 'rejected') echo 'bg-red-50 text-red-700 border border-red-100';
                                    else echo 'bg-amber-50 text-amber-700 border border-amber-100'; 
                                    ?>">
                                    <?php echo htmlspecialchars($rep['status']); ?>
                                </span>
                            </div>
                            <p class="text-[11px] text-slate-500 dark:text-slate-400 font-light leading-relaxed"><?php echo htmlspecialchars($rep['description']); ?></p>
                            <?php if (!empty($rep['file_path'])): ?>
                                <div class="text-[9px] text-bushgreen dark:text-gold font-bold">
                                    Attachment: <a href="<?php echo htmlspecialchars($rep['file_path']); ?>" target="_blank" class="hover:underline">View Document</a>
                                </div>
                            <?php endif; ?>
                            <div class="text-[9px] text-slate-400 block pt-1.5 border-t border-slate-100 dark:border-slate-800/50">
                                Submitted on: <strong><?php echo date('Y-m-d H:i', strtotime($rep['created_at'])); ?></strong>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>

        <!-- Submit report form (Col 5) -->
        <div class="lg:col-span-5 bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
            <h3 class="text-slate-800 dark:text-white font-bold text-sm font-display border-b border-slate-50 dark:border-slate-700 pb-3">File Activity Briefing</h3>
            
            <form method="POST" action="" enctype="multipart/form-data" class="space-y-4">
                <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                <input type="hidden" name="action" value="submit_lga_report">
                <input type="hidden" name="redirect_tab" value="reports">

                <div>
                    <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="r_title">Report Title *</label>
                    <input type="text" name="title" id="r_title" required placeholder="e.g. Weekly Mobilization Briefing"
                           class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen dark:text-white">
                </div>

                <div>
                    <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="r_desc">Report Content & Summary *</label>
                    <textarea name="description" id="r_desc" required rows="4" placeholder="Detail parameters, guidelines and local achievements..."
                              class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-light leading-relaxed dark:text-white"></textarea>
                </div>

                <div>
                    <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="r_cat">Category</label>
                    <select name="category" id="r_cat" class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen dark:text-white">
                        <option value="Weekly Update">Weekly Update</option>
                        <option value="Event Briefing">Event Briefing</option>
                        <option value="Youth Opportunity Log">Youth Opportunity Log</option>
                        <option value="Compliance Audit">Compliance Audit</option>
                    </select>
                </div>

                <div>
                    <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="r_file">Media Attachment (PDF / JPG / PNG)</label>
                    <input type="file" name="attachment_file" id="r_file" class="w-full text-xs text-slate-500 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg p-2 focus:outline-none">
                </div>

                <button type="submit" class="w-full py-2 bg-bushgreen hover:bg-bushgreen-light text-white text-xs font-bold rounded-lg transition shadow-md">
                    Submit Field Report
                </button>
            </form>
        </div>

    </div>

    <!-- TAB 6: COMMUNITY ENGAGEMENT CENTER -->
    <div x-show="activeTab === 'engagement'" class="bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
        <h3 class="text-slate-850 dark:text-white font-bold text-sm font-display border-b border-slate-50 dark:border-slate-700 pb-3">Public Opinion & Surveys</h3>
        
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <!-- Surveys/Feedback -->
            <div class="space-y-4">
                <h4 class="font-bold text-slate-700 dark:text-slate-300 text-xs font-display">Local Feedback Log</h4>
                <div class="p-3 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-xl space-y-1">
                    <div class="flex justify-between text-[9px] text-slate-400">
                        <span>Submitted by: <strong>Adebayo T.</strong></span>
                        <span>Ward 2</span>
                    </div>
                    <p class="text-xs font-light text-slate-750 dark:text-slate-300">"We need more digital skills workshops at the youth center."</p>
                </div>
                <div class="p-3 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-xl space-y-1">
                    <div class="flex justify-between text-[9px] text-slate-400">
                        <span>Submitted by: <strong>Grace O.</strong></span>
                        <span>Ward 1</span>
                    </div>
                    <p class="text-xs font-light text-slate-750 dark:text-slate-300">"Campaign coverage is great, but we need printed brochures for elders."</p>
                </div>
            </div>

            <!-- Opinion Polls -->
            <div class="space-y-4">
                <h4 class="font-bold text-slate-700 dark:text-slate-300 text-xs font-display">Log Community Sugerence</h4>
                <form onsubmit="event.preventDefault(); alert('Suggestion catalogued and updated on engagement index.'); this.reset();" class="space-y-3">
                    <input type="text" required placeholder="Citizen Name *" class="w-full px-3 py-1.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen dark:text-white">
                    <textarea required placeholder="Outline citizen concern or suggestion details..." class="w-full px-3 py-1.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-light dark:text-white" rows="3"></textarea>
                    <button type="submit" class="py-1.5 px-4 bg-bushgreen text-white text-xs font-bold rounded-lg transition shadow">
                        Log Sugerence
                    </button>
                </form>
            </div>
        </div>
    </div>

    <!-- TAB 7: COMMUNICATION & ANNOUNCEMENT CENTER -->
    <div x-show="activeTab === 'comms'" class="bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
        <h3 class="text-slate-855 dark:text-white font-bold text-sm font-display border-b border-slate-50 dark:border-slate-700 pb-3">Local Directives & Bulletins</h3>
        
        <form method="POST" action="" class="space-y-4 max-w-xl">
            <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
            <input type="hidden" name="action" value="lga_broadcast">
            <input type="hidden" name="redirect_tab" value="comms">

            <div>
                <label class="block text-slate-655 dark:text-slate-400 text-xs font-semibold mb-1" for="comms_subj">Directive Subject *</label>
                <input type="text" name="subject" id="comms_subj" required placeholder="e.g. Ward Mobilization Guidelines for Weekend Drive"
                       class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen dark:text-white">
            </div>

            <div>
                <label class="block text-slate-655 dark:text-slate-400 text-xs font-semibold mb-1" for="comms_body">Directive Message *</label>
                <textarea name="body" id="comms_body" required rows="5" placeholder="Outline specific mobilization targets, location coordinate guidelines, and contact logistics..."
                          class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-light leading-relaxed dark:text-white"></textarea>
            </div>

            <input type="hidden" name="channel" value="local">

            <button type="submit" class="py-2 px-6 bg-bushgreen hover:bg-bushgreen-light text-white text-xs font-bold rounded-lg transition shadow-md">
                Dispatch Local Circular
            </button>
        </form>
    </div>

    <!-- TAB 8: DIGITAL ID & QR VERIFICATION SYSTEM -->
    <div x-show="activeTab === 'verify_qr'" class="bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
        <h3 class="text-slate-850 dark:text-white font-bold text-sm font-display border-b border-slate-50 dark:border-slate-700 pb-3">Grassroots Credentials Verification</h3>
        
        <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
            <!-- Manual UUID Form -->
            <div class="space-y-4">
                <h4 class="font-bold text-slate-700 dark:text-slate-350 text-xs font-display">Manual ID Checker</h4>
                <form onsubmit="event.preventDefault(); alert('Credential Verified: Ambassador profile is certified & active.');" class="space-y-3">
                    <input type="text" required placeholder="Enter Ambassador UUID/Email *" class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen dark:text-white font-mono">
                    <button type="submit" class="w-full py-2 bg-bushgreen text-white text-xs font-bold rounded-lg transition shadow">
                        Perform Identity Audit
                    </button>
                </form>
            </div>

            <!-- Attendance checkin logs -->
            <div class="bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-3xl p-6 space-y-3">
                <h4 class="font-bold text-slate-850 dark:text-white text-xs font-display">Local Attendance Check-in Logs</h4>
                <div class="h-32 overflow-y-auto space-y-2 text-[10px]">
                    <div class="p-2 bg-white dark:bg-slate-850 border border-slate-100 dark:border-slate-700 rounded-lg">
                        Ambassador <strong>Amara Eke</strong> checked-in at LGA Town Hall. <span class="text-slate-400 block">[10 minutes ago]</span>
                    </div>
                    <div class="p-2 bg-white dark:bg-slate-850 border border-slate-100 dark:border-slate-700 rounded-lg">
                        Ambassador <strong>Tunde Coker</strong> checked-in at Ikeja Ward meeting. <span class="text-slate-400 block">[1 hour ago]</span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- TAB 9: LOCAL ANALYTICS & HEATMAP CENTER -->
    <div x-show="activeTab === 'analytics'" class="bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
        <h3 class="text-slate-850 dark:text-white font-bold text-sm font-display border-b border-slate-50 dark:border-slate-700 pb-3">LGA Chapter Heatmap</h3>
        
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8" x-data="{ selectedWard: 'Ward 01 (Central)', selectedDensity: 'High Density (8 advocates)', selectedActiveCamp: 'AI Awareness week', selectedPerformanceIndex: 'Elite chapter status' }">
            <!-- Simulated Heatmap Layout -->
            <div class="lg:col-span-2 relative bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-3xl p-6 h-80 flex items-center justify-center">
                <!-- SVG map rendering representing LGA Wards -->
                <svg viewBox="0 0 400 200" class="w-full h-full max-w-sm">
                    <!-- Ward 1 -->
                    <circle cx="100" cy="100" r="40" fill="#063C1E" opacity="0.9" class="cursor-pointer transition hover:fill-gold duration-200"
                            @click="selectedWard = 'Ward 01 (Central)'; selectedDensity = 'High Density (8 advocates)'; selectedActiveCamp = 'AI Awareness week'; selectedPerformanceIndex = 'Elite chapter status';" />
                    <!-- Ward 2 -->
                    <circle cx="200" cy="70" r="30" fill="#0A4D27" opacity="0.8" class="cursor-pointer transition hover:fill-gold duration-200"
                            @click="selectedWard = 'Ward 02 (North)'; selectedDensity = 'Medium Density (4 advocates)'; selectedActiveCamp = 'Youth Digital awareness'; selectedPerformanceIndex = 'Optimal performance';" />
                    <!-- Ward 3 -->
                    <circle cx="300" cy="130" r="35" fill="#0A4D27" opacity="0.75" class="cursor-pointer transition hover:fill-gold duration-200"
                            @click="selectedWard = 'Ward 03 (East)'; selectedDensity = 'Medium Density (5 advocates)'; selectedActiveCamp = 'Digital Town Hall'; selectedPerformanceIndex = 'Optimal performance';" />
                    <!-- Ward 4 -->
                    <circle cx="150" cy="150" r="25" fill="#0A4D27" opacity="0.6" class="cursor-pointer transition hover:fill-gold duration-200"
                            @click="selectedWard = 'Ward 04 (South)'; selectedDensity = 'Growing Density (2 advocates)'; selectedActiveCamp = 'None'; selectedPerformanceIndex = 'Initial seeding phase';" />
                    
                    <text x="75" y="105" fill="#ffffff" font-size="8" font-family="Outfit" font-weight="bold" pointer-events="none">Ward 1</text>
                    <text x="180" y="75" fill="#ffffff" font-size="8" font-family="Outfit" font-weight="bold" pointer-events="none">Ward 2</text>
                    <text x="280" y="135" fill="#ffffff" font-size="8" font-family="Outfit" font-weight="bold" pointer-events="none">Ward 3</text>
                    <text x="135" y="155" fill="#ffffff" font-size="8" font-family="Outfit" font-weight="bold" pointer-events="none">Ward 4</text>
                </svg>
                <div class="absolute bottom-4 left-4 text-[9px] text-slate-400 bg-white/70 dark:bg-slate-800/70 p-2 rounded-lg leading-tight">
                    * Click on ward bubbles to inspect specific coordinate metrics.
                </div>
            </div>

            <!-- Detail panel -->
            <div class="bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-3xl p-6 space-y-4">
                <h4 class="font-bold text-slate-800 dark:text-white text-xs font-display border-b border-slate-100 dark:border-slate-800 pb-2">Ward Metrics</h4>
                <div class="space-y-3 text-xs">
                    <div>
                        <span class="text-slate-400 text-[10px] block">Ward Name</span>
                        <span class="font-bold text-slate-800 dark:text-white" x-text="selectedWard"></span>
                    </div>
                    <div>
                        <span class="text-slate-400 text-[10px] block">Ambassador Concentration</span>
                        <span class="font-bold text-slate-800 dark:text-white" x-text="selectedDensity"></span>
                    </div>
                    <div>
                        <span class="text-slate-400 text-[10px] block">Active Outreach Initiative</span>
                        <span class="font-bold text-slate-800 dark:text-white" x-text="selectedActiveCamp"></span>
                    </div>
                    <div>
                        <span class="text-slate-400 text-[10px] block">Performance Status</span>
                        <span class="px-2 py-0.5 rounded text-[9px] font-bold bg-gold/10 text-gold border border-gold/10" x-text="selectedPerformanceIndex"></span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- TAB 10: YOUTH EMPOWERMENT & INNOVATION HUB -->
    <div x-show="activeTab === 'youth_hub'" class="bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
        <h3 class="text-slate-850 dark:text-white font-bold text-sm font-display border-b border-slate-50 dark:border-slate-700 pb-3">Youth Innovation Hub</h3>
        
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            <!-- Opportunities Roster (Col 7) -->
            <div class="lg:col-span-7 space-y-4">
                <h4 class="font-bold text-slate-700 dark:text-slate-350 text-xs font-display">Active Digital Skill Programs</h4>
                <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-850 rounded-2xl space-y-2">
                    <div class="flex justify-between items-center">
                        <h4 class="font-bold text-slate-800 dark:text-white text-xs">Google AI Literacy Challenge</h4>
                        <span class="px-2 py-0.5 bg-gold/10 text-gold border border-gold/15 rounded text-[8px] font-bold">15 Open Seats</span>
                    </div>
                    <p class="text-[10px] text-slate-500 dark:text-slate-400 leading-relaxed font-light">
                        Provides introductory machine learning certification vouchers to active local ward youths.
                    </p>
                </div>
                <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-850 rounded-2xl space-y-2">
                    <div class="flex justify-between items-center">
                        <h4 class="font-bold text-slate-800 dark:text-white text-xs">Smart Nation Innovation Summit</h4>
                        <span class="px-2 py-0.5 bg-emerald-50 text-emerald-700 border border-emerald-100 rounded text-[8px] font-bold">Endorsement Open</span>
                    </div>
                    <p class="text-[10px] text-slate-500 dark:text-slate-400 leading-relaxed font-light">
                        Local civic hackathon focusing on e-governance tooling mockups for youth groups.
                    </p>
                </div>
            </div>

            <!-- Skills Registration Form (Col 5) -->
            <div class="lg:col-span-5 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-3xl p-6 space-y-4">
                <h4 class="font-bold text-slate-850 dark:text-white text-xs font-display border-b border-slate-100 dark:border-slate-800 pb-2">Talent Skills Registry</h4>
                
                <form onsubmit="event.preventDefault(); alert('Youth registered for Skills Opportunity Program successfully!'); this.reset();" class="space-y-3">
                    <div>
                        <label class="block text-slate-600 dark:text-slate-400 text-[10px] font-bold uppercase mb-1">Candidate Name *</label>
                        <input type="text" required placeholder="e.g. John Doe" class="w-full px-3 py-2 bg-white dark:bg-slate-850 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen dark:text-white">
                    </div>
                    <div>
                        <label class="block text-slate-600 dark:text-slate-400 text-[10px] font-bold uppercase mb-1">Email Address *</label>
                        <input type="email" required placeholder="e.g. candidate@gmail.com" class="w-full px-3 py-2 bg-white dark:bg-slate-850 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen dark:text-white font-mono">
                    </div>
                    <div>
                        <label class="block text-slate-600 dark:text-slate-400 text-[10px] font-bold uppercase mb-1">Skill Course of Interest *</label>
                        <select required class="w-full px-3 py-2 bg-white dark:bg-slate-850 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen dark:text-white">
                            <option value="AI Tools & Prompting">AI Tools & Prompting</option>
                            <option value="Introduction to Coding">Introduction to Coding</option>
                            <option value="Data Analytics Basics">Data Analytics Basics</option>
                            <option value="Digital Marketing Strategies">Digital Marketing Strategies</option>
                        </select>
                    </div>
                    <button type="submit" class="w-full py-2 bg-bushgreen text-white text-xs font-bold rounded-lg transition shadow">
                        Onboard to Skills Challenge
                    </button>
                </form>
            </div>
        </div>
    </div>

    <!-- TAB 13: NATIONAL TALENT PIPELINE REGISTRATION -->
    <div x-show="activeTab === 'talent_pipeline'" class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        <!-- Registration Form (Col 5) -->
        <div class="lg:col-span-5 bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
            <div class="border-b border-slate-50 dark:border-slate-700 pb-3">
                <h3 class="text-slate-850 dark:text-white font-bold text-sm font-display">National Talent Pipeline Registration</h3>
                <p class="text-[10px] text-slate-400">Join the national initiative to train others or get trained in high-demand IT fields.</p>
            </div>

            <form method="POST" action="" class="space-y-4">
                <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                <input type="hidden" name="action" value="submit_talent_pipeline">
                <input type="hidden" name="redirect_tab" value="talent_pipeline">

                <div>
                    <label class="block text-slate-655 dark:text-slate-400 text-xs font-semibold mb-1">I want to register as a: *</label>
                    <div class="grid grid-cols-2 gap-4">
                        <label class="flex items-center gap-2 p-3 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl cursor-pointer">
                            <input type="radio" name="role_type" value="trainer" required class="text-bushgreen focus:ring-bushgreen">
                            <span class="text-xs font-bold text-slate-700 dark:text-slate-300">Trainer</span>
                        </label>
                        <label class="flex items-center gap-2 p-3 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl cursor-pointer">
                            <input type="radio" name="role_type" value="trainee" required checked class="text-bushgreen focus:ring-bushgreen">
                            <span class="text-xs font-bold text-slate-700 dark:text-slate-300">Trainee</span>
                        </label>
                    </div>
                </div>

                <div>
                    <label class="block text-slate-655 dark:text-slate-400 text-xs font-semibold mb-1" for="tp_skill_c">Select IT Skill *</label>
                    <select name="skill" id="tp_skill_c" required class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen dark:text-white font-semibold">
                        <option value="Software Engineering & Web Development">Software Engineering & Web Development</option>
                        <option value="Mobile App Development (Flutter/React Native)">Mobile App Development (Flutter/React Native)</option>
                        <option value="Cloud Computing (AWS/GCP/Azure)">Cloud Computing (AWS/GCP/Azure)</option>
                        <option value="Cyber Security & Ethical Hacking">Cyber Security & Ethical Hacking</option>
                        <option value="Artificial Intelligence & Machine Learning">Artificial Intelligence & Machine Learning</option>
                        <option value="Data Science & Advanced Analytics">Data Science & Advanced Analytics</option>
                        <option value="UI/UX Design & Product Design">UI/UX Design & Product Design</option>
                        <option value="Product Management & Agile Methodologies">Product Management & Agile Methodologies</option>
                        <option value="Blockchain & Web3 Technologies">Blockchain & Web3 Technologies</option>
                        <option value="DevOps & Site Reliability Engineering (SRE)">DevOps & Site Reliability Engineering (SRE)</option>
                    </select>
                </div>

                <div>
                    <label class="block text-slate-655 dark:text-slate-400 text-xs font-semibold mb-1" for="tp_exp_c">Years of Experience in this Area</label>
                    <input type="number" name="experience_years" id="tp_exp_c" min="0" max="40" value="0"
                           class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen dark:text-white">
                </div>

                <div>
                    <label class="block text-slate-655 dark:text-slate-400 text-xs font-semibold mb-1" for="tp_notes_c">Statement of Intent & Additional Details</label>
                    <textarea name="additional_notes" id="tp_notes_c" rows="4" placeholder="Briefly describe your motivation, background, or training facilities/interest..."
                              class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-light leading-relaxed dark:text-white"></textarea>
                </div>

                <button type="submit" class="w-full py-2 bg-bushgreen hover:bg-bushgreen-light text-white text-xs font-bold rounded-lg transition shadow-md">
                    Submit Registration
                </button>
            </form>
        </div>

        <!-- History & Status (Col 7) -->
        <div class="lg:col-span-7 bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
            <h3 class="text-slate-800 dark:text-white font-bold text-sm font-display border-b border-slate-50 dark:border-slate-700 pb-3">My Talent Pipeline Submissions</h3>

            <div class="space-y-4">
                <?php if (empty($talent_submissions)): ?>
                    <p class="text-xs text-slate-400 italic py-8 text-center">You have not submitted any pipeline registrations yet.</p>
                <?php else: ?>
                    <?php foreach ($talent_submissions as $sub): ?>
                        <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-150 dark:border-slate-800 rounded-2xl space-y-3">
                            <div class="flex justify-between items-start">
                                <div>
                                    <span class="px-2 py-0.5 rounded text-[8px] font-bold uppercase tracking-widest <?php echo $sub['role_type'] === 'trainer' ? 'bg-bushgreen text-white' : 'bg-gold/20 text-gold-dark'; ?>">
                                        <?php echo htmlspecialchars($sub['role_type']); ?>
                                    </span>
                                    <h4 class="font-bold text-slate-850 dark:text-white text-xs mt-1.5"><?php echo htmlspecialchars($sub['skill']); ?></h4>
                                </div>
                                <span class="px-2.5 py-0.5 rounded-full text-[9px] font-extrabold uppercase tracking-wide
                                    <?php 
                                    if ($sub['status'] === 'approved') echo 'bg-emerald-50 text-emerald-800 border border-emerald-250';
                                    elseif ($sub['status'] === 'shortlisted') echo 'bg-blue-50 text-blue-800 border border-blue-200';
                                    elseif ($sub['status'] === 'rejected') echo 'bg-red-50 text-red-800 border border-red-200';
                                    else echo 'bg-amber-50 text-amber-800 border border-amber-200';
                                    ?>">
                                    <?php echo htmlspecialchars($sub['status']); ?>
                                </span>
                            </div>

                            <div class="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed font-light space-y-1.5">
                                <p><span class="font-semibold text-slate-700 dark:text-slate-300">Experience:</span> <?php echo $sub['experience_years']; ?> Years</p>
                                <?php if (!empty($sub['additional_notes'])): ?>
                                    <p><span class="font-semibold text-slate-700 dark:text-slate-300">Notes:</span> <?php echo htmlspecialchars($sub['additional_notes']); ?></p>
                                <?php endif; ?>
                            </div>

                            <?php if (!empty($sub['moderation_notes'])): ?>
                                <div class="p-3 bg-white dark:bg-slate-950 rounded-xl border border-slate-100 dark:border-slate-900 text-[10px] space-y-1">
                                    <span class="font-bold text-gold uppercase tracking-wider block text-[8px]">Moderator Decision Feedback:</span>
                                    <p class="text-slate-655 dark:text-slate-400 italic">"<?php echo htmlspecialchars($sub['moderation_notes']); ?>"</p>
                                </div>
                            <?php endif; ?>

                            <div class="text-[9px] text-slate-400 pt-2 border-t border-slate-100 dark:border-slate-800/40">
                                Submitted on: <strong><?php echo date('Y-m-d H:i', strtotime($sub['created_at'])); ?></strong>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>

    </div>

    <!-- TAB 14: MOBILISATION & VOLUNTEERS SYSTEM -->
    <div x-show="activeTab === 'volunteers'" class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        <!-- Volunteer Enlistment Form (Col 6) -->
        <div class="lg:col-span-6 bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
            <div class="border-b border-slate-50 dark:border-slate-700 pb-3">
                <h3 class="text-slate-855 dark:text-white font-bold text-sm font-display">Volunteer Mobilisation Enlistment</h3>
                <p class="text-[10px] text-slate-400">Configure your volunteering availability, preferences, and mobilization skills.</p>
            </div>

            <form method="POST" action="" class="space-y-4">
                <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                <input type="hidden" name="action" value="submit_volunteer_profile">
                <input type="hidden" name="redirect_tab" value="volunteers">

                <div>
                    <label class="block text-slate-655 dark:text-slate-400 text-xs font-semibold mb-2">Select Areas of Volunteering Interest: *</label>
                    <div class="space-y-2">
                        <?php 
                        $vol_areas = [
                            'Outreach'      => 'Community Mobilisation & Grassroots Outreach',
                            'Mentoring'     => 'Technical Training & IT Mentorship',
                            'Logistics'     => 'Event Management & Logistics Setup',
                            'Media'         => 'Publicity, Media & Content Writing',
                            'IT_Setup'      => 'Systems Support & Hardware Installation',
                            'Onboarding'    => 'Onboarding & Registration Assistance',
                            'Monitoring'    => 'Monitoring, Evaluation & Impact Reporting'
                        ];
                        
                        $selected_areas = [];
                        if ($volunteer_profile && !empty($volunteer_profile['volunteer_areas'])) {
                            $selected_areas = json_decode($volunteer_profile['volunteer_areas'], true) ?: [];
                        }

                        foreach ($vol_areas as $key => $label):
                            $checked = in_array($key, $selected_areas) ? 'checked' : '';
                        ?>
                            <label class="flex items-start gap-2.5 p-2 bg-slate-55 dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-xl cursor-pointer font-semibold">
                                <input type="checkbox" name="volunteer_areas[]" value="<?php echo $key; ?>" <?php echo $checked; ?> class="rounded text-bushgreen focus:ring-bushgreen w-4 h-4 mt-0.5">
                                <span class="text-xs text-slate-705 dark:text-slate-300 font-medium"><?php echo $label; ?></span>
                            </label>
                        <?php endforeach; ?>
                    </div>
                </div>

                <div>
                    <label class="block text-slate-655 dark:text-slate-400 text-xs font-semibold mb-1" for="v_availability_c">Weekly Availability *</label>
                    <select name="availability" id="v_availability_c" required class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen dark:text-white">
                        <option value="Weekends Only" <?php echo ($volunteer_profile && $volunteer_profile['availability'] === 'Weekends Only') ? 'selected' : ''; ?>>Weekends Only</option>
                        <option value="Weekdays Only" <?php echo ($volunteer_profile && $volunteer_profile['availability'] === 'Weekdays Only') ? 'selected' : ''; ?>>Weekdays Only</option>
                        <option value="Flexible (Weekdays & Weekends)" <?php echo ($volunteer_profile && $volunteer_profile['availability'] === 'Flexible (Weekdays & Weekends)') ? 'selected' : ''; ?>>Flexible (Weekdays & Weekends)</option>
                        <option value="Full-Time Active Deployment" <?php echo ($volunteer_profile && $volunteer_profile['availability'] === 'Full-Time Active Deployment') ? 'selected' : ''; ?>>Full-Time Active Deployment</option>
                    </select>
                </div>

                <div>
                    <label class="block text-slate-655 dark:text-slate-400 text-xs font-semibold mb-1" for="v_exp_c">Past Mobilisation or Voluntary Experience</label>
                    <textarea name="experience" id="v_exp_c" rows="3" placeholder="Briefly describe any past experience in community programs or training mobilization..."
                              class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-light leading-relaxed dark:text-white"><?php echo $volunteer_profile ? htmlspecialchars($volunteer_profile['experience']) : ''; ?></textarea>
                </div>

                <button type="submit" class="w-full py-2 bg-bushgreen hover:bg-bushgreen-light text-white text-xs font-bold rounded-lg transition shadow-md">
                    <?php echo $volunteer_profile ? 'Update Enlistment Profile' : 'Enlist as Volunteer'; ?>
                </button>
            </form>
        </div>

        <!-- Status Panel (Col 6) -->
        <div class="lg:col-span-6 space-y-6">
            <div class="bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
                <h3 class="text-slate-800 dark:text-white font-bold text-sm font-display border-b border-slate-50 dark:border-slate-700 pb-3">Enlistment Status</h3>

                <?php if (!$volunteer_profile): ?>
                    <div class="p-8 text-center text-slate-400 italic text-xs space-y-3">
                        <p>You have not enlisted in the Mobilisation & Volunteers register yet.</p>
                        <p class="text-[10px] text-slate-500 font-light">Complete the preferences form on the left to activate your volunteer coordinate.</p>
                    </div>
                <?php else: ?>
                    <div class="space-y-4">
                        <div class="flex justify-between items-center p-4 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl">
                            <span class="text-xs font-bold text-slate-700 dark:text-slate-300">Volunteer Verification Status</span>
                            <span class="px-2.5 py-0.5 rounded-full text-[9px] font-extrabold uppercase tracking-wide
                                <?php 
                                if ($volunteer_profile['status'] === 'approved') echo 'bg-emerald-50 text-emerald-800 border border-emerald-250';
                                elseif ($volunteer_profile['status'] === 'rejected') echo 'bg-red-50 text-red-800 border border-red-200';
                                else echo 'bg-amber-50 text-amber-800 border border-amber-200';
                                ?>">
                                <?php echo htmlspecialchars($volunteer_profile['status']); ?>
                            </span>
                        </div>

                        <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl space-y-3 text-xs">
                            <h4 class="font-bold text-slate-800 dark:text-white text-xs font-display">My Registered Preferences</h4>
                            
                            <div class="space-y-2">
                                <div>
                                    <span class="text-slate-400 block text-[10px] font-semibold">Active Availability</span>
                                    <span class="font-bold text-slate-800 dark:text-white"><?php echo htmlspecialchars($volunteer_profile['availability']); ?></span>
                                </div>
                                <div>
                                    <span class="text-slate-400 block text-[10px] font-semibold">Enlisted Volunteer Roles</span>
                                    <div class="flex flex-wrap gap-1.5 mt-1">
                                        <?php 
                                        foreach ($selected_areas as $area_key) {
                                            $name = $vol_areas[$area_key] ?? $area_key;
                                            echo '<span class="px-2 py-0.5 bg-bushgreen/10 text-bushgreen dark:bg-gold/10 dark:text-gold rounded text-[9px] font-semibold">' . htmlspecialchars($name) . '</span>';
                                        }
                                        ?>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="text-[9px] text-slate-400 text-center pt-2 font-mono">
                            Last Updated: <?php echo date('Y-m-d H:i', strtotime($volunteer_profile['updated_at'])); ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
            
            <div class="bg-gradient-to-r from-bushgreen to-bushgreen-light text-white p-6 rounded-3xl shadow-md space-y-3">
                <h4 class="font-bold text-xs uppercase tracking-wider font-display text-gold">Volunteer Mobilization Code of Conduct</h4>
                <p class="text-[10px] leading-relaxed font-light text-slate-350">
                    PBAT volunteers must operate with maximum transparency, assist citizens professionally, and align coordinates with LGA chapter circular rules. Unauthorized mobilization is strictly prohibited.
                </p>
            </div>
        </div>

    </div>

</div>
