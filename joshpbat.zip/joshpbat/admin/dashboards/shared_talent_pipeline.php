<?php
/**
 * Shared National Talent Pipeline Tab View
 * Included dynamically by dashboard.php for all user tiers.
 */
if (!defined('DB_HOST')) {
    exit('Access Denied');
}
?>
<div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start animate-fade-in" x-data="{ regType: 'register_self' }">
    
    <!-- Registration Form (Col 5) -->
    <div class="lg:col-span-5 bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
        <div class="border-b border-slate-50 dark:border-slate-700 pb-3">
            <h3 class="text-slate-850 dark:text-white font-bold text-sm font-display flex items-center gap-2">
                <span class="w-1.5 h-6 bg-gold rounded-full"></span>
                National Talent Pipeline Registration
            </h3>
            <p class="text-[10px] text-slate-400">Join the national initiative to train others, get trained, or register a community member.</p>
        </div>

        <form method="POST" action="" class="space-y-4">
            <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
            <input type="hidden" name="action" value="submit_talent_pipeline">
            <input type="hidden" name="redirect_tab" value="talent_pipeline">

            <!-- Registration Type Selection -->
            <div>
                <label class="block text-slate-655 dark:text-slate-400 text-xs font-semibold mb-1.5">Registration Option: *</label>
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <label class="flex items-center gap-2.5 p-3 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl cursor-pointer hover:border-gold/50 transition-colors">
                        <input type="radio" name="registration_type" value="register_self" x-model="regType" required class="text-bushgreen focus:ring-bushgreen">
                        <div class="flex flex-col">
                            <span class="text-xs font-bold text-slate-850 dark:text-white">Register My Skill</span>
                            <span class="text-[9px] text-slate-400">Register yourself</span>
                        </div>
                    </label>
                    <label class="flex items-center gap-2.5 p-3 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl cursor-pointer hover:border-gold/50 transition-colors">
                        <input type="radio" name="registration_type" value="register_talent" x-model="regType" required class="text-bushgreen focus:ring-bushgreen">
                        <div class="flex flex-col">
                            <span class="text-xs font-bold text-slate-850 dark:text-white">Register A Talent</span>
                            <span class="text-[9px] text-slate-400">Register someone else</span>
                        </div>
                    </label>
                </div>
            </div>

            <!-- Third-Party Talent Fields (shown only if register_talent) -->
            <div x-show="regType === 'register_talent'" x-transition class="space-y-4 p-4 bg-slate-50 dark:bg-slate-900/50 border border-slate-100 dark:border-slate-800 rounded-2xl">
                <h4 class="text-[10px] font-bold text-gold uppercase tracking-wider font-display">Talent's Contact Details</h4>
                <div>
                    <label class="block text-slate-600 dark:text-slate-400 text-[10px] font-bold uppercase tracking-wider mb-1" for="tp_talent_name">Talent Full Name *</label>
                    <input type="text" name="talent_name" id="tp_talent_name" placeholder="e.g. Jane Doe" :required="regType === 'register_talent'"
                           class="w-full px-3 py-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen dark:text-white">
                </div>
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                        <label class="block text-slate-600 dark:text-slate-400 text-[10px] font-bold uppercase tracking-wider mb-1" for="tp_talent_email">Talent Email Address</label>
                        <input type="email" name="talent_email" id="tp_talent_email" placeholder="jane@example.com"
                               class="w-full px-3 py-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen dark:text-white">
                    </div>
                    <div>
                        <label class="block text-slate-600 dark:text-slate-400 text-[10px] font-bold uppercase tracking-wider mb-1" for="tp_talent_phone">Talent Phone Number</label>
                        <input type="text" name="talent_phone" id="tp_talent_phone" placeholder="+234..."
                               class="w-full px-3 py-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen dark:text-white">
                    </div>
                </div>
            </div>

            <!-- Role Type (Trainer vs Trainee) -->
            <div>
                <label class="block text-slate-655 dark:text-slate-400 text-xs font-semibold mb-1">Engagement Role: *</label>
                <div class="grid grid-cols-2 gap-4">
                    <label class="flex items-center gap-2 p-3 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl cursor-pointer hover:border-gold/50 transition-colors">
                        <input type="radio" name="role_type" value="trainer" required class="text-bushgreen focus:ring-bushgreen">
                        <span class="text-xs font-bold text-slate-700 dark:text-slate-300">Trainer / Mentor</span>
                    </label>
                    <label class="flex items-center gap-2 p-3 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl cursor-pointer hover:border-gold/50 transition-colors">
                        <input type="radio" name="role_type" value="trainee" required checked class="text-bushgreen focus:ring-bushgreen">
                        <span class="text-xs font-bold text-slate-700 dark:text-slate-300">Trainee / Learner</span>
                    </label>
                </div>
            </div>

            <!-- Skill Selector -->
            <div>
                <label class="block text-slate-655 dark:text-slate-400 text-xs font-semibold mb-1" for="tp_skill">Select IT Skill *</label>
                <select name="skill" id="tp_skill" required class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen dark:text-white font-semibold">
                    <option value="Software Engineering & Web Development">Software Engineering & Web Development</option>
                    <option value="Mobile App Development (Flutter/React Native)">Mobile App Development (Flutter/React Native)</option>
                    <option value="Cloud Computing (AWS/GCP/Azure)">Cloud Computing (AWS/GCP/Azure)</option>
                    <option value="Cyber Security & Ethical Hacking">Cyber Security & Ethical Hacking</option>
                    <option value="Artificial Intelligence & Machine Learning">Artificial Intelligence & Machine Learning</option>
                    <option value="Data Science & Advanced Analytics">Data Science & Advanced Analytics</option>
                    <option value="UI/UX Design & Product Design">UI/UX Design & Product Design</option>
                    <option value="Product Management & Agile Methodologies">Product Management & Agile Methodologies</option>
                    <option value="Blockchain & Web3 Technologies">Blockchain & Web3 Technologies</option>
                    <option value="DevOps & Site Reliability Engineering (SRE)">DevOps & Site Reliability Engineering (SRE)</option>
                </select>
            </div>

            <!-- Experience Years -->
            <div>
                <label class="block text-slate-655 dark:text-slate-400 text-xs font-semibold mb-1" for="tp_exp">Years of Experience in this Area</label>
                <input type="number" name="experience_years" id="tp_exp" min="0" max="40" value="0"
                       class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen dark:text-white">
            </div>

            <!-- Statement of Intent -->
            <div>
                <label class="block text-slate-655 dark:text-slate-400 text-xs font-semibold mb-1" for="tp_notes">Statement of Intent & Additional Details</label>
                <textarea name="additional_notes" id="tp_notes" rows="4" placeholder="Briefly describe background, motivations, training facilities/needs..."
                          class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-light leading-relaxed dark:text-white"></textarea>
            </div>

            <button type="submit" class="w-full py-2.5 bg-bushgreen hover:bg-bushgreen-light text-white text-xs font-bold rounded-xl transition shadow-md border border-gold/20">
                Submit Pipeline Registration
            </button>
        </form>
    </div>

    <!-- History & Status (Col 7) -->
    <div class="lg:col-span-7 bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
        <div class="border-b border-slate-50 dark:border-slate-700 pb-3 flex justify-between items-center">
            <h3 class="text-slate-800 dark:text-white font-bold text-sm font-display">My Talent Pipeline Submissions</h3>
            <span class="text-[9px] bg-gold/15 text-gold-dark font-extrabold px-2 py-0.5 rounded uppercase tracking-wider font-mono">
                <?php echo count($talent_submissions); ?> Registrations
            </span>
        </div>

        <div class="space-y-4 max-h-[600px] overflow-y-auto pr-1">
            <?php if (empty($talent_submissions)): ?>
                <p class="text-xs text-slate-400 italic py-12 text-center">You have not submitted any pipeline registrations yet.</p>
            <?php else: ?>
                <?php foreach ($talent_submissions as $sub): ?>
                    <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-150 dark:border-slate-800 rounded-2xl space-y-3">
                        <div class="flex justify-between items-start">
                            <div>
                                <div class="flex flex-wrap gap-1.5 items-center">
                                    <span class="px-2 py-0.5 rounded text-[8px] font-bold uppercase tracking-widest <?php echo $sub['role_type'] === 'trainer' ? 'bg-bushgreen text-white' : 'bg-gold/20 text-gold-dark'; ?>">
                                        <?php echo htmlspecialchars($sub['role_type']); ?>
                                    </span>
                                    <span class="px-2 py-0.5 rounded text-[8px] font-bold uppercase tracking-widest bg-slate-200 dark:bg-slate-850 text-slate-700 dark:text-slate-350">
                                        <?php echo ($sub['registration_type'] ?? 'register_self') === 'register_talent' ? 'Third-Party' : 'Self'; ?>
                                    </span>
                                </div>
                                <h4 class="font-bold text-slate-850 dark:text-white text-xs mt-2"><?php echo htmlspecialchars($sub['skill']); ?></h4>
                            </div>
                            <span class="px-2.5 py-0.5 rounded-full text-[9px] font-extrabold uppercase tracking-wide
                                <?php 
                                if ($sub['status'] === 'approved') echo 'bg-emerald-50 text-emerald-800 border border-emerald-250';
                                elseif ($sub['status'] === 'shortlisted') echo 'bg-blue-50 text-blue-800 border border-blue-200';
                                elseif ($sub['status'] === 'rejected') echo 'bg-red-50 text-red-800 border border-red-200';
                                else echo 'bg-amber-50 text-amber-800 border border-amber-200';
                                ?>">
                                <?php echo htmlspecialchars($sub['status']); ?>
                            </span>
                        </div>

                        <!-- Applicant Info Details -->
                        <?php if (($sub['registration_type'] ?? 'register_self') === 'register_talent'): ?>
                            <div class="bg-white dark:bg-slate-950 p-2.5 rounded-xl border border-slate-100 dark:border-slate-800 text-[10px] space-y-1">
                                <div class="font-bold text-slate-700 dark:text-slate-300">Registered Talent Info:</div>
                                <div>Name: <span class="font-semibold text-slate-850 dark:text-white"><?php echo htmlspecialchars($sub['talent_name'] ?? ''); ?></span></div>
                                <?php if (!empty($sub['talent_email'])): ?>
                                    <div>Email: <span class="font-semibold text-slate-850 dark:text-white font-mono"><?php echo htmlspecialchars($sub['talent_email']); ?></span></div>
                                <?php endif; ?>
                                <?php if (!empty($sub['talent_phone'])): ?>
                                    <div>Phone: <span class="font-semibold text-slate-850 dark:text-white"><?php echo htmlspecialchars($sub['talent_phone']); ?></span></div>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>

                        <div class="text-[11px] text-slate-500 dark:text-slate-400 font-light leading-relaxed">
                            <strong>Intent Details:</strong> <?php echo htmlspecialchars($sub['additional_notes'] ?: 'No description provided.'); ?>
                        </div>

                        <?php if (!empty($sub['moderation_notes'])): ?>
                            <div class="p-3 bg-slate-100 dark:bg-slate-950 rounded-xl text-[10px] text-slate-600 dark:text-slate-400 border-l-4 border-gold">
                                <strong>Steering Council Notes:</strong> <?php echo htmlspecialchars($sub['moderation_notes']); ?>
                            </div>
                        <?php endif; ?>

                        <div class="flex justify-between items-center text-[9px] text-slate-400 pt-2 border-t border-slate-150 dark:border-slate-800">
                            <span>Experience: <strong><?php echo (int)$sub['experience_years']; ?> Years</strong></span>
                            <span>Submitted: <strong><?php echo date('Y-m-d H:i', strtotime($sub['created_at'])); ?></strong></span>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</div>
