<?php
/**
 * Grassroots Ambassador Dashboard (Role 7)
 * Digital Empowerment & Community Action Hub
 */
if (!defined('DB_HOST')) {
    exit('Access Denied');
}

$active_tab = $_GET['tab'] ?? 'overview';
$user = Auth::user();
$user_id = $user['id'];

try {
    $db = Database::connect();
    
    // Resolve ambassador properties
    $stmt = $db->prepare("
        SELECT a.*, u.name, u.email, u.phone, u.avatar, s.name as state_name, l.name as lga_name
        FROM `ambassadors` a
        JOIN `users` u ON a.user_id = u.id
        LEFT JOIN `states` s ON a.state_id = s.id
        LEFT JOIN `lgas` l ON a.lga_id = l.id
        WHERE a.user_id = ? LIMIT 1
    ");
    $stmt->execute([$user_id]);
    $ambassador = $stmt->fetch();
    
    if (!$ambassador) {
        throw new Exception("Ambassador profile details not found.");
    }
    
    $state_id = $ambassador['state_id'];
    $lga_id = $ambassador['lga_id'];
    $impact_score = $ambassador['impact_score'];
    $uuid = $ambassador['uuid'];
    $qr_code_hash = $ambassador['qr_code_hash'];
    $state_name = $ambassador['state_name'] ?? 'Lagos';
    $lga_name = $ambassador['lga_name'] ?? 'Ikeja';
    
    // Fetch reports filed by this ambassador
    $stmt_reports = $db->prepare("
        SELECT * FROM `reports` 
        WHERE user_id = ? 
        ORDER BY created_at DESC
    ");
    $stmt_reports->execute([$user_id]);
    $reports = $stmt_reports->fetchAll();
    
    // Fetch events in this state/LGA
    $stmt_events = $db->prepare("
        SELECT e.*, u.name as creator_name 
        FROM `events` e 
        JOIN `users` u ON e.created_by = u.id
        WHERE e.location LIKE ? OR e.location LIKE ? OR e.created_by = 1 
        ORDER BY e.event_date DESC
    ");
    $stmt_events->execute(['%' . $lga_name . '%', '%' . $state_name . '%']);
    $events = $stmt_events->fetchAll();

    // Fetch user RSVPs
    $stmt_rsvps = $db->prepare("SELECT event_id FROM `event_registrants` WHERE user_id = ?");
    $stmt_rsvps->execute([$user_id]);
    $user_rsvps = $stmt_rsvps->fetchAll(PDO::FETCH_COLUMN);
    
    // Fetch active polls
    $stmt_polls = $db->prepare("SELECT * FROM `nsc_polls` ORDER BY created_at DESC");
    $stmt_polls->execute();
    $polls = $stmt_polls->fetchAll();
    
    // Fetch notifications
    $stmt_nots = $db->prepare("
        SELECT * FROM `notifications` 
        WHERE user_id = ? OR user_id IS NULL 
        ORDER BY created_at DESC LIMIT 5
    ");
    $stmt_nots->execute([$user_id]);
    $notifications = $stmt_nots->fetchAll();
    
    // Fetch top scoring ambassadors (leaderboard)
    $stmt_leaderboard = $db->prepare("
        SELECT a.impact_score, u.name, l.name as lga_name
        FROM `ambassadors` a
        JOIN `users` u ON a.user_id = u.id
        LEFT JOIN `lgas` l ON a.lga_id = l.id
        ORDER BY a.impact_score DESC LIMIT 5
    ");
    $stmt_leaderboard->execute();
    $leaderboard = $stmt_leaderboard->fetchAll();

    // Fetch talent pipeline registrations for current user
    $stmt_tp = $db->prepare("SELECT * FROM `talent_pipeline` WHERE `user_id` = ? ORDER BY `created_at` DESC");
    $stmt_tp->execute([$user_id]);
    $talent_submissions = $stmt_tp->fetchAll();

    // Fetch volunteer profile for current user
    $stmt_vol = $db->prepare("SELECT * FROM `volunteers` WHERE `user_id` = ? LIMIT 1");
    $stmt_vol->execute([$user_id]);
    $volunteer_profile = $stmt_vol->fetch() ?: null;
    
} catch (Exception $e) {
    $ambassador = ['impact_score' => 10, 'uuid' => 'MOCK-UUID', 'qr_code_hash' => 'MOCK-HASH', 'name' => $user['name'], 'email' => $user['email']];
    $reports = [];
    $events = [];
    $polls = [];
    $notifications = [];
    $leaderboard = [];
    $talent_submissions = [];
    $volunteer_profile = null;
}

// Gamified Rank Calculation
$rank_name = "Bronze Partner";
$rank_icon = "🥉";
$next_milestone = 200;
if ($impact_score >= 300) {
    $rank_name = "Elite Gold Strategist";
    $rank_icon = "👑";
    $next_milestone = 500;
} elseif ($impact_score >= 150) {
    $rank_name = "Silver Champion";
    $rank_icon = "🥈";
    $next_milestone = 300;
} elseif ($impact_score >= 50) {
    $rank_name = "Grassroots Advocate";
    $rank_icon = "🥇";
    $next_milestone = 150;
}
$milestone_pct = min(100, ($impact_score / $next_milestone) * 100);
?>

<div class="space-y-8" x-data="{ activeTab: '<?php echo htmlspecialchars($active_tab); ?>' }">

    <!-- Ambassador Welcome Header -->
    <div class="bg-gradient-to-r from-bushgreen to-bushgreen-light text-white p-8 rounded-3xl shadow-xl relative overflow-hidden border border-gold/30">
        <div class="absolute inset-0 bg-cover bg-center mix-blend-overlay opacity-10 bg-[url('https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=600&q=80')]"></div>
        <div class="relative z-10 space-y-3">
            <span class="px-2.5 py-1 bg-gold/20 text-gold rounded-full text-[9px] font-bold uppercase tracking-widest leading-none font-display border border-gold/25">Grassroots Action Hub</span>
            <h2 class="text-3xl font-black font-display leading-tight text-white tracking-tight">Welcome, <?php echo htmlspecialchars($user['name']); ?>!</h2>
            <p class="text-slate-300 text-xs font-light max-w-xl">
                Mobilize local youth communities, complete weekly sensitization missions, check-in to town halls, and share advocacy graphics to earn impact recognition.
            </p>
        </div>
    </div>

    <!-- MAIN DYNAMIC CONTENT ROUTER -->

    <!-- TAB 1: PERSONAL DASHBOARD -->
    <div x-show="activeTab === 'overview'" class="space-y-8">
        <!-- KPI Row -->
        <div class="grid grid-cols-1 sm:grid-cols-4 gap-6">
            <div class="bg-white dark:bg-slate-800 p-6 rounded-3xl border border-slate-100 dark:border-slate-700 shadow-sm flex items-center justify-between">
                <div class="space-y-1">
                    <span class="text-slate-400 text-[10px] font-bold uppercase tracking-wider block">Impact Points</span>
                    <div class="text-3xl font-black text-bushgreen dark:text-white font-display"><?php echo number_format($impact_score); ?> pts</div>
                    <span class="text-[9px] text-emerald-600 font-bold bg-emerald-50 px-2 py-0.5 rounded"><?php echo $rank_icon; ?> <?php echo $rank_name; ?></span>
                </div>
                <div class="w-12 h-12 rounded-2xl bg-bushgreen/5 flex items-center justify-center text-bushgreen dark:text-gold"><svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg></div>
            </div>

            <div class="bg-white dark:bg-slate-800 p-6 rounded-3xl border border-slate-100 dark:border-slate-700 shadow-sm flex items-center justify-between">
                <div class="space-y-1">
                    <span class="text-slate-400 text-[10px] font-bold uppercase tracking-wider block">Outreach Filed</span>
                    <div class="text-3xl font-black text-bushgreen dark:text-white font-display"><?php echo count($reports); ?> Reports</div>
                    <span class="text-[9px] text-slate-400">Briefings uploaded</span>
                </div>
                <div class="w-12 h-12 rounded-2xl bg-bushgreen/5 flex items-center justify-center text-bushgreen dark:text-gold"><svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg></div>
            </div>

            <div class="bg-white dark:bg-slate-800 p-6 rounded-3xl border border-slate-100 dark:border-slate-700 shadow-sm flex items-center justify-between">
                <div class="space-y-1">
                    <span class="text-slate-400 text-[10px] font-bold uppercase tracking-wider block">Chapter coordinate</span>
                    <div class="text-xl font-bold text-bushgreen dark:text-white font-display"><?php echo htmlspecialchars($lga_name); ?> LGA</div>
                    <span class="text-[9px] text-slate-400 font-light block"><?php echo htmlspecialchars($state_name); ?> State</span>
                </div>
                <div class="w-12 h-12 rounded-2xl bg-bushgreen/5 flex items-center justify-center text-bushgreen dark:text-gold"><svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/></svg></div>
            </div>

            <div class="bg-white dark:bg-slate-800 p-6 rounded-3xl border border-slate-100 dark:border-slate-700 shadow-sm flex items-center justify-between">
                <div class="space-y-1">
                    <span class="text-slate-400 text-[10px] font-bold uppercase tracking-wider block">Next Level milestone</span>
                    <div class="text-3xl font-black text-bushgreen dark:text-white font-display"><?php echo $next_milestone; ?> pts</div>
                    <div class="w-full bg-slate-100 dark:bg-slate-900 rounded-full h-1.5 overflow-hidden mt-1">
                        <div class="bg-gold h-full rounded-full" style="width: <?php echo $milestone_pct; ?>%"></div>
                    </div>
                </div>
                <div class="w-12 h-12 rounded-2xl bg-bushgreen/5 flex items-center justify-center text-bushgreen dark:text-gold"><svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 8v8m-4-5v5m-4-2v2m-2 4h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg></div>
            </div>
        </div>

        <!-- Missions checklist & Active schedules -->
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-8">
            
            <!-- Missions checklist (Col 7) -->
            <div class="lg:col-span-7 bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
                <h3 class="text-slate-850 dark:text-white font-bold text-sm font-display border-b border-slate-50 dark:border-slate-700 pb-3">Ambassador Daily Checklist</h3>
                
                <div class="space-y-4">
                    <div class="flex items-center gap-3 p-3 bg-slate-50 dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800">
                        <input type="checkbox" checked disabled class="rounded text-bushgreen focus:ring-bushgreen w-4 h-4">
                        <div class="space-y-0.5">
                            <h4 class="font-bold text-slate-800 dark:text-white text-xs">Verify My ID Badge</h4>
                            <p class="text-[10px] text-slate-400">Access your double-sided verified credentials card in the My ID Badge section.</p>
                        </div>
                    </div>
                    
                    <div class="flex items-center gap-3 p-3 bg-slate-50 dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800">
                        <input type="checkbox" <?php echo count($reports) > 0 ? 'checked' : ''; ?> disabled class="rounded text-bushgreen focus:ring-bushgreen w-4 h-4">
                        <div class="space-y-0.5">
                            <h4 class="font-bold text-slate-800 dark:text-white text-xs">Submit Field sensitizing report</h4>
                            <p class="text-[10px] text-slate-400">Upload a sensitization brief with photo verification of a local meeting.</p>
                        </div>
                    </div>

                    <div class="flex items-center gap-3 p-3 bg-slate-50 dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800">
                        <input type="checkbox" disabled class="rounded text-bushgreen focus:ring-bushgreen w-4 h-4">
                        <div class="space-y-0.5">
                            <h4 class="font-bold text-slate-800 dark:text-white text-xs">Share Campaign graphic flyer</h4>
                            <p class="text-[10px] text-slate-400">Go to Toolkit tab, copy referral invitations, and share on social media.</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Ticker notifications (Col 5) -->
            <div class="lg:col-span-5 space-y-8">
                
                <div class="bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-4">
                    <h4 class="text-slate-855 dark:text-white font-bold text-xs font-display flex items-center gap-1.5 border-b border-slate-50 dark:border-slate-700 pb-2">
                        🔔 Leadership bulletin
                    </h4>
                    <div class="space-y-3 max-h-48 overflow-y-auto pr-1 text-[10px]">
                        <?php if (empty($notifications)): ?>
                            <p class="italic text-slate-400 text-center py-4">No leadership announcements filed.</p>
                        <?php else: ?>
                            <?php foreach ($notifications as $note): ?>
                                <div class="p-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-xl">
                                    <p class="text-slate-700 dark:text-slate-350 leading-relaxed"><?php echo htmlspecialchars($note['message']); ?></p>
                                    <span class="text-[8px] text-slate-400 block mt-1"><?php echo date('M d, H:i', strtotime($note['created_at'])); ?></span>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <!-- TAB 3: TASK & MISSION CENTER -->
    <div x-show="activeTab === 'missions'" class="bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
        <h3 class="text-slate-850 dark:text-white font-bold text-sm font-display border-b border-slate-50 dark:border-slate-700 pb-3">Active Weekly Missions</h3>
        
        <div class="space-y-4">
            
            <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-850 rounded-2xl flex flex-col sm:flex-row justify-between gap-4 items-start sm:items-center">
                <div class="space-y-1">
                    <span class="px-2 py-0.5 bg-gold/10 text-gold border border-gold/20 text-[8px] font-bold rounded uppercase tracking-wider">Weekly Challenge</span>
                    <h4 class="font-bold text-slate-800 dark:text-white text-xs mt-1">Register 3 community members</h4>
                    <p class="text-[10px] text-slate-500 font-light">Onboard new local youths in your ward chapter to earn points.</p>
                </div>
                <form method="POST" action="">
                    <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                    <input type="hidden" name="action" value="claim_mission_reward">
                    <input type="hidden" name="redirect_tab" value="missions">
                    <input type="hidden" name="points" value="15">
                    <input type="hidden" name="mission_name" value="Community Onboarding">
                    <button type="submit" class="py-1.5 px-4 bg-bushgreen hover:bg-bushgreen-light text-white text-xs font-bold rounded-lg transition shadow">
                        Claim +15 Points
                    </button>
                </form>
            </div>

            <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-850 rounded-2xl flex flex-col sm:flex-row justify-between gap-4 items-start sm:items-center">
                <div class="space-y-1">
                    <span class="px-2 py-0.5 bg-gold/10 text-gold border border-gold/20 text-[8px] font-bold rounded uppercase tracking-wider">Weekly Challenge</span>
                    <h4 class="font-bold text-slate-800 dark:text-white text-xs mt-1">Submit Field sensitization report</h4>
                    <p class="text-[10px] text-slate-500 font-light">Upload a brief summarizing local meeting activities to claim reward.</p>
                </div>
                <form method="POST" action="">
                    <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                    <input type="hidden" name="action" value="claim_mission_reward">
                    <input type="hidden" name="redirect_tab" value="missions">
                    <input type="hidden" name="points" value="20">
                    <input type="hidden" name="mission_name" value="Outreach Briefing Submit">
                    <button type="submit" class="py-1.5 px-4 bg-bushgreen hover:bg-bushgreen-light text-white text-xs font-bold rounded-lg transition shadow">
                        Claim +20 Points
                    </button>
                </form>
            </div>

            <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-850 rounded-2xl flex flex-col sm:flex-row justify-between gap-4 items-start sm:items-center">
                <div class="space-y-1">
                    <span class="px-2 py-0.5 bg-gold/10 text-gold border border-gold/20 text-[8px] font-bold rounded uppercase tracking-wider">Weekly Challenge</span>
                    <h4 class="font-bold text-slate-800 dark:text-white text-xs mt-1">Vote in Town Hall Interactive Poll</h4>
                    <p class="text-[10px] text-slate-500 font-light">Cast your civic opinion vote in the active community polls tab.</p>
                </div>
                <form method="POST" action="">
                    <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                    <input type="hidden" name="action" value="claim_mission_reward">
                    <input type="hidden" name="redirect_tab" value="missions">
                    <input type="hidden" name="points" value="10">
                    <input type="hidden" name="mission_name" value="Civic Voting Action">
                    <button type="submit" class="py-1.5 px-4 bg-bushgreen hover:bg-bushgreen-light text-white text-xs font-bold rounded-lg transition shadow">
                        Claim +10 Points
                    </button>
                </form>
            </div>

        </div>
    </div>

    <!-- TAB 4: EVENT PARTICIPATION SYSTEM -->
    <div x-show="activeTab === 'events'" class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        <!-- Live streams YouTube player (Col 7) -->
        <div class="lg:col-span-7 bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-4">
            <h3 class="text-slate-850 dark:text-white font-bold text-sm font-display border-b border-slate-50 dark:border-slate-700 pb-3">Livestream Town Hall Broadcast</h3>
            
            <div class="relative bg-black rounded-2xl overflow-hidden aspect-video border border-slate-800">
                <iframe class="w-full h-full" src="https://www.youtube.com/embed/dQw4w9WgXcQ" title="Smart Nation Town Hall" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            </div>
            
            <div class="flex justify-between items-center text-[10px] text-slate-400">
                <span>Subject: <strong>Smart Nation e-Governance Webinar</strong></span>
                <span class="px-2 py-0.5 bg-rose-500 text-white rounded font-bold uppercase tracking-wider text-[8px] animate-pulse">Live</span>
            </div>
        </div>

        <!-- Schedule list (Col 5) -->
        <div class="lg:col-span-5 bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
            <h3 class="text-slate-855 dark:text-white font-bold text-sm font-display border-b border-slate-50 dark:border-slate-700 pb-3">Upcoming Schedules</h3>
            
            <div class="space-y-4 max-h-96 overflow-y-auto pr-1">
                <?php if (empty($events)): ?>
                    <p class="text-xs text-slate-400 italic py-4 text-center">No community events listed.</p>
                <?php else: ?>
                    <?php foreach ($events as $event): ?>
                        <div class="p-3 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-850 rounded-2xl space-y-2">
                            <h4 class="font-bold text-slate-800 dark:text-white text-xs"><?php echo htmlspecialchars($event['title']); ?></h4>
                            <p class="text-[10px] text-slate-500 font-light leading-relaxed"><?php echo htmlspecialchars($event['description']); ?></p>
                            <div class="pt-2 border-t border-slate-100 dark:border-slate-800 flex justify-between items-center text-[9px] text-slate-400">
                                <span>Date: <strong><?php echo date('Y-m-d H:i', strtotime($event['event_date'])); ?></strong></span>
                                <?php if (in_array($event['id'], $user_rsvps)): ?>
                                    <span class="py-1 px-2.5 bg-emerald-50 text-emerald-800 border border-emerald-250/20 text-[9px] font-bold rounded-lg flex items-center gap-1">
                                        ✓ RSVPed
                                    </span>
                                <?php else: ?>
                                    <form method="POST" action="">
                                        <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                                        <input type="hidden" name="action" value="ambassador_rsvp">
                                        <input type="hidden" name="redirect_tab" value="events">
                                        <input type="hidden" name="event_id" value="<?php echo $event['id']; ?>">
                                        <button type="submit" class="py-1 px-3 bg-gold text-bushgreen text-[9px] font-black rounded-lg transition hover:bg-gold-light shadow-sm">
                                            RSVP Join
                                        </button>
                                    </form>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>

    </div>

    <!-- TAB 5: SMART REPORT SUBMISSION SYSTEM -->
    <div x-show="activeTab === 'reports'" class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        <!-- Outreach briefs logs (Col 7) -->
        <div class="lg:col-span-7 bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
            <h3 class="text-slate-850 dark:text-white font-bold text-sm font-display border-b border-slate-50 dark:border-slate-700 pb-3">Outreach Briefings History</h3>
            
            <div class="space-y-4">
                <?php if (empty($reports)): ?>
                    <p class="text-xs text-slate-400 italic py-4 text-center">No outreach briefings filed by you yet.</p>
                <?php else: ?>
                    <?php foreach ($reports as $rep): ?>
                        <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl space-y-2">
                            <div class="flex justify-between items-center">
                                <h4 class="font-bold text-slate-850 dark:text-white text-xs"><?php echo htmlspecialchars($rep['title']); ?></h4>
                                <span class="px-2 py-0.5 rounded text-[8px] font-bold uppercase tracking-wide
                                    <?php 
                                    if ($rep['status'] === 'approved') echo 'bg-emerald-50 text-emerald-700 border border-emerald-100';
                                    elseif ($rep['status'] === 'rejected') echo 'bg-red-50 text-red-700 border border-red-100';
                                    else echo 'bg-amber-50 text-amber-700 border border-amber-100'; 
                                    ?>">
                                    <?php echo htmlspecialchars($rep['status']); ?>
                                </span>
                            </div>
                            <p class="text-[11px] text-slate-500 dark:text-slate-400 font-light leading-relaxed"><?php echo htmlspecialchars($rep['description']); ?></p>
                            <?php if (!empty($rep['file_path'])): ?>
                                <div class="text-[9px] text-bushgreen dark:text-gold font-bold">
                                    Attachment: <a href="<?php echo htmlspecialchars($rep['file_path']); ?>" target="_blank" class="hover:underline">View Document</a>
                                </div>
                            <?php endif; ?>
                            <span class="text-[9px] text-slate-400 block pt-1.5 border-t border-slate-100 dark:border-slate-800/50">Submitted: <strong><?php echo date('Y-m-d H:i', strtotime($rep['created_at'])); ?></strong></span>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>

        <!-- Submit form (Col 5) -->
        <div class="lg:col-span-5 bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
            <h3 class="text-slate-800 dark:text-white font-bold text-sm font-display border-b border-slate-50 dark:border-slate-700 pb-3">File Outreach Brief</h3>
            
            <form method="POST" action="" enctype="multipart/form-data" class="space-y-4">
                <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                <input type="hidden" name="action" value="submit_ambassador_report">
                <input type="hidden" name="redirect_tab" value="reports">

                <div>
                    <label class="block text-slate-655 dark:text-slate-400 text-xs font-semibold mb-1" for="r_title_amb">Brief Title *</label>
                    <input type="text" name="title" id="r_title_amb" required placeholder="e.g. Ward 2 Youth Meetup Briefing"
                           class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen dark:text-white">
                </div>

                <div>
                    <label class="block text-slate-655 dark:text-slate-400 text-xs font-semibold mb-1" for="r_desc_amb">Outreach Summary *</label>
                    <textarea name="description" id="r_desc_amb" required rows="4" placeholder="Detail community feedback, local questions raised and targets reached..."
                              class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-light leading-relaxed dark:text-white"></textarea>
                </div>

                <div>
                    <label class="block text-slate-655 dark:text-slate-400 text-xs font-semibold mb-1" for="r_cat_amb">Category</label>
                    <select name="category" id="r_cat_amb" class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen dark:text-white">
                        <option value="Grassroots Outreach">Grassroots Outreach</option>
                        <option value="Youth Assembly">Youth Assembly</option>
                        <option value="AI Sensitization">AI Sensitization</option>
                    </select>
                </div>

                <div>
                    <label class="block text-slate-655 dark:text-slate-400 text-xs font-semibold mb-1" for="r_file_amb">Media Attachment (PDF / JPG / PNG)</label>
                    <input type="file" name="attachment_file" id="r_file_amb" class="w-full text-xs text-slate-500 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg p-2 focus:outline-none">
                </div>

                <button type="submit" class="w-full py-2 bg-bushgreen hover:bg-bushgreen-light text-white text-xs font-bold rounded-lg transition shadow-md">
                    Submit Field Briefing
                </button>
            </form>
        </div>

    </div>

    <!-- TAB 6: COMMUNITY ENGAGEMENT CENTER -->
    <div x-show="activeTab === 'engagement'" class="bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
        <h3 class="text-slate-850 dark:text-white font-bold text-sm font-display border-b border-slate-50 dark:border-slate-700 pb-3">Civic Voting & Suggestions</h3>
        
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            
            <!-- Opinion polls -->
            <div class="lg:col-span-7 space-y-6">
                <h4 class="font-bold text-slate-700 dark:text-slate-350 text-xs font-display">Active National Steering Polls</h4>
                
                <div class="space-y-4">
                    <?php if (empty($polls)): ?>
                        <p class="text-xs text-slate-400 italic">No community polls active.</p>
                    <?php else: ?>
                        <?php foreach ($polls as $poll): 
                            $options = json_decode($poll['options_json'], true);
                            $votes = json_decode($poll['votes_json'], true);
                            $total_votes = array_sum($votes);
                        ?>
                            <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl space-y-3">
                                <h4 class="font-bold text-slate-800 dark:text-white text-xs"><?php echo htmlspecialchars($poll['question']); ?></h4>
                                
                                <div class="space-y-2">
                                    <?php foreach ($options as $idx => $opt): 
                                        $pct = $total_votes > 0 ? round(($votes[$idx] / $total_votes) * 105 / 1.05) : 0;
                                    ?>
                                        <div class="space-y-1">
                                            <div class="flex justify-between text-[10px] font-semibold text-slate-700 dark:text-slate-350">
                                                <span><?php echo htmlspecialchars($opt); ?></span>
                                                <span><?php echo $pct; ?>% (<?php echo $votes[$idx]; ?> votes)</span>
                                            </div>
                                            <div class="w-full bg-slate-100 dark:bg-slate-950 rounded-full h-1.5 overflow-hidden flex items-center justify-between">
                                                <div class="bg-gold h-full rounded-full" style="width: <?php echo $pct; ?>%"></div>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>

                                <form method="POST" action="" class="pt-2 border-t border-slate-100 dark:border-slate-800 flex gap-2">
                                    <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                                    <input type="hidden" name="action" value="ambassador_vote">
                                    <input type="hidden" name="redirect_tab" value="engagement">
                                    <input type="hidden" name="poll_id" value="<?php echo $poll['id']; ?>">
                                    
                                    <span class="text-[9px] text-slate-400 mt-1 mr-2">Cast Vote:</span>
                                    <?php foreach ($options as $idx => $opt): ?>
                                        <button type="submit" name="option_index" value="<?php echo $idx; ?>" class="py-0.5 px-2 bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-755 text-slate-700 dark:text-slate-300 text-[9px] font-bold rounded-lg border border-slate-200 dark:border-slate-700 transition">
                                            <?php echo htmlspecialchars($opt); ?>
                                        </button>
                                    <?php endforeach; ?>
                                </form>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Suggestion box -->
            <div class="lg:col-span-5 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-3xl p-6 space-y-4">
                <h4 class="font-bold text-slate-850 dark:text-white text-xs font-display border-b border-slate-100 dark:border-slate-800 pb-2">Community Suggestion Box</h4>
                <form onsubmit="event.preventDefault(); alert('Sugerence successfully registered: Outbound alerts dispatched to LGA coordinator.'); this.reset();" class="space-y-3">
                    <textarea required placeholder="Outlines suggestions, questions or community concerns to coordinator offices..." class="w-full px-3 py-1.5 bg-white dark:bg-slate-850 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-light dark:text-white" rows="4"></textarea>
                    <button type="submit" class="py-1.5 px-4 bg-bushgreen text-white text-xs font-bold rounded-lg transition shadow">
                        Log Sugerence
                    </button>
                </form>
            </div>

        </div>
    </div>

    <!-- TAB 7: NOTIFICATION CENTER -->
    <div x-show="activeTab === 'notifications'" class="bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
        <h3 class="text-slate-850 dark:text-white font-bold text-sm font-display border-b border-slate-50 dark:border-slate-700 pb-3">Strategic Alerts & Directive Bulletins</h3>
        
        <div class="space-y-4">
            <?php if (empty($notifications)): ?>
                <p class="text-xs text-slate-400 italic py-4 text-center">No alerts logged in your directive feed.</p>
            <?php else: ?>
                <?php foreach ($notifications as $note): ?>
                    <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-850 rounded-2xl flex gap-3 text-xs items-start">
                        <span class="w-2.5 h-2.5 rounded-full flex-shrink-0 mt-1 bg-gold animate-pulse"></span>
                        <div class="space-y-1">
                            <p class="text-slate-700 dark:text-slate-350 leading-relaxed"><?php echo htmlspecialchars($note['message']); ?></p>
                            <span class="text-[9px] text-slate-400 block font-light"><?php echo date('Y-m-d H:i', strtotime($note['created_at'])); ?></span>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <!-- TAB 8: LEADERBOARD & RECOGNITION SYSTEM -->
    <div x-show="activeTab === 'leaderboard'" class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        <!-- Leaderboard list (Col 7) -->
        <div class="lg:col-span-7 bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
            <h3 class="text-slate-855 dark:text-white font-bold text-sm font-display border-b border-slate-50 dark:border-slate-700 pb-3">Outreach Leaderboard</h3>
            
            <div class="space-y-3">
                <?php if (empty($leaderboard)): ?>
                    <p class="text-xs text-slate-450 italic">No rankings registered.</p>
                <?php else: 
                    $pos = 1;
                    foreach ($leaderboard as $lead): 
                ?>
                    <div class="p-3 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-850 rounded-2xl flex items-center justify-between">
                        <div class="flex items-center gap-3">
                            <span class="w-6 h-6 bg-gold/15 text-gold rounded-full flex items-center justify-center font-bold text-xs"><?php echo $pos++; ?></span>
                            <div>
                                <h4 class="font-bold text-slate-800 dark:text-white text-xs"><?php echo htmlspecialchars($lead['name']); ?></h4>
                                <span class="text-[9px] text-slate-400 block"><?php echo htmlspecialchars($lead['lga_name'] ?? 'Headquarters'); ?> LGA Chapter</span>
                            </div>
                        </div>
                        <span class="font-black text-bushgreen dark:text-gold text-xs"><?php echo $lead['impact_score']; ?> pts</span>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
            </div>
        </div>

        <!-- Badges (Col 5) -->
        <div class="lg:col-span-5 bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
            <h3 class="text-slate-850 dark:text-white font-bold text-sm font-display border-b border-slate-50 dark:border-slate-700 pb-3">Earned Achievements</h3>
            
            <div class="grid grid-cols-3 gap-4 text-center">
                <div class="p-3 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-850 rounded-2xl space-y-1 opacity-100">
                    <span class="text-xl">🎖️</span>
                    <h4 class="font-bold text-slate-800 dark:text-white text-[9px] font-display">Early Pioneer</h4>
                    <span class="text-[8px] text-slate-400">Awarded</span>
                </div>
                <div class="p-3 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-850 rounded-2xl space-y-1 <?php echo $impact_score >= 50 ? 'opacity-100' : 'opacity-40'; ?>">
                    <span class="text-xl">🔥</span>
                    <h4 class="font-bold text-slate-800 dark:text-white text-[9px] font-display">Community Catalyst</h4>
                    <span class="text-[8px] text-slate-400"><?php echo $impact_score >= 50 ? 'Awarded' : 'Locked'; ?></span>
                </div>
                <div class="p-3 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-850 rounded-2xl space-y-1 <?php echo $impact_score >= 150 ? 'opacity-100' : 'opacity-40'; ?>">
                    <span class="text-xl">🏆</span>
                    <h4 class="font-bold text-slate-800 dark:text-white text-[9px] font-display">Campaign Champion</h4>
                    <span class="text-[8px] text-slate-400"><?php echo $impact_score >= 150 ? 'Awarded' : 'Locked'; ?></span>
                </div>
            </div>
        </div>

    </div>

    <!-- TAB 9: DIGITAL SKILLS & LEARNING HUB -->
    <div x-show="activeTab === 'learning'" class="bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
        <h3 class="text-slate-850 dark:text-white font-bold text-sm font-display border-b border-slate-50 dark:border-slate-700 pb-3">Educational Learning Vault</h3>
        
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-850 rounded-2xl space-y-2">
                <span class="text-xl">📘</span>
                <h4 class="font-bold text-slate-800 dark:text-white text-xs font-display">Smart Nation Mobilization Manual</h4>
                <p class="text-[10px] text-slate-450 leading-relaxed font-light">Complete guidelines on hosting grassroots campaigns and youth assemblies.</p>
                <a href="#" onclick="alert('Asset downloaded successfully.'); return false;" class="text-[9px] text-gold font-bold block hover:underline">Download Guide (PDF)</a>
            </div>
            <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-850 rounded-2xl space-y-2">
                <span class="text-xl">🤖</span>
                <h4 class="font-bold text-slate-800 dark:text-white text-xs font-display">AI Awareness Course Notes</h4>
                <p class="text-[10px] text-slate-450 leading-relaxed font-light">Essential outlines summarizing machine learning models and prompts for local classes.</p>
                <a href="#" onclick="alert('Asset downloaded successfully.'); return false;" class="text-[9px] text-gold font-bold block hover:underline">Download Guide (PDF)</a>
            </div>
            <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-850 rounded-2xl space-y-2">
                <span class="text-xl">📺</span>
                <h4 class="font-bold text-slate-800 dark:text-white text-xs font-display">Leadership Training Slides</h4>
                <p class="text-[10px] text-slate-450 leading-relaxed font-light">Powerpoint summary detailing community structures and engagement indexes rules.</p>
                <a href="#" onclick="alert('Asset downloaded successfully.'); return false;" class="text-[9px] text-gold font-bold block hover:underline">Download Guide (PDF)</a>
            </div>
        </div>
    </div>

    <!-- TAB 10: SOCIAL MEDIA ADVOCACY TOOLKIT -->
    <div x-show="activeTab === 'social_toolkit'" class="bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
        <h3 class="text-slate-855 dark:text-white font-bold text-sm font-display border-b border-slate-50 dark:border-slate-700 pb-3">Shareable Outreach Graphics</h3>
        
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-850 rounded-2xl space-y-3">
                <div class="w-full h-32 bg-bushgreen-light rounded-xl flex items-center justify-center text-white text-xs font-bold">
                    [Flyer: Digital Revolution]
                </div>
                <h4 class="font-bold text-slate-800 dark:text-white text-xs font-display">Outreach Campaign Banner</h4>
                <button onclick="alert('Image banner successfully compiled & downloaded.');" class="w-full py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 dark:text-slate-300 dark:bg-slate-800 text-[10px] font-bold rounded-lg border border-slate-200 dark:border-slate-700 transition">
                    Download PNG
                </button>
            </div>
            
            <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-850 rounded-2xl space-y-3">
                <div class="w-full h-32 bg-bushgreen rounded-xl flex items-center justify-center text-white text-xs font-bold border border-gold/20">
                    [Flyer: AI Education]
                </div>
                <h4 class="font-bold text-slate-800 dark:text-white text-xs font-display">AI Literacy Awareness Flyer</h4>
                <button onclick="alert('Image banner successfully compiled & downloaded.');" class="w-full py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 dark:text-slate-300 dark:bg-slate-800 text-[10px] font-bold rounded-lg border border-slate-200 dark:border-slate-700 transition">
                    Download PNG
                </button>
            </div>

            <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-850 rounded-2xl space-y-3">
                <div class="p-3 bg-white dark:bg-slate-850 border border-slate-100 dark:border-slate-750 rounded-xl space-y-2">
                    <span class="text-[9px] text-slate-400 block uppercase font-bold">Shareable Hashtags</span>
                    <p class="text-[10px] font-mono text-gold leading-relaxed">#PBATSmartNation #DigitalNigeria #GrassrootsAwareness</p>
                </div>
                <button onclick="navigator.clipboard.writeText('#PBATSmartNation #DigitalNigeria #GrassrootsAwareness'); alert('Hashtags copied to clipboard!');" class="w-full py-1.5 bg-bushgreen hover:bg-bushgreen-light text-white text-[10px] font-bold rounded-lg transition shadow">
                    Copy Hashtag Toolkit
                </button>
            </div>
        </div>
    </div>

    <!-- TAB 11: AMBASSADOR NETWORKING HUB -->
    <div x-show="activeTab === 'networking'" class="bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
        <h3 class="text-slate-850 dark:text-white font-bold text-sm font-display border-b border-slate-50 dark:border-slate-700 pb-3">State Chapter Discussion Wall</h3>
        
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            
            <!-- Messages list -->
            <div class="lg:col-span-7 space-y-4">
                <h4 class="font-bold text-slate-700 dark:text-slate-300 text-xs font-display">Recent check-in posts</h4>
                <div class="space-y-3 max-h-80 overflow-y-auto pr-1">
                    <div class="p-3 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-850 rounded-2xl space-y-1">
                        <div class="flex justify-between text-[9px] text-slate-400">
                            <span>Advocate: <strong>Amara Eke</strong></span>
                            <span>Ikeja LGA Chapter</span>
                        </div>
                        <p class="text-xs font-light text-slate-700 dark:text-slate-300">"Our local AI awareness drive was a massive success today. Lots of youth interest!"</p>
                    </div>
                    <div class="p-3 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-850 rounded-2xl space-y-1">
                        <div class="flex justify-between text-[9px] text-slate-400">
                            <span>Advocate: <strong>Tunde Coker</strong></span>
                            <span>Alimosho LGA Chapter</span>
                        </div>
                        <p class="text-xs font-light text-slate-700 dark:text-slate-300">"We scheduled a tech mobilization summit for this Saturday. Ready to onboard new members."</p>
                    </div>
                </div>
            </div>

            <!-- Share message form -->
            <div class="lg:col-span-5 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-3xl p-6 space-y-4">
                <h4 class="font-bold text-slate-850 dark:text-white text-xs font-display border-b border-slate-100 dark:border-slate-800 pb-2">Share Check-in Idea</h4>
                
                <form method="POST" action="" class="space-y-3">
                    <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                    <input type="hidden" name="action" value="submit_networking_post">
                    <input type="hidden" name="redirect_tab" value="networking">
                    
                    <textarea name="message" required placeholder="Outlines ideas, mobilization summaries or local event details to share with team..." class="w-full px-3 py-1.5 bg-white dark:bg-slate-850 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-light dark:text-white" rows="4"></textarea>
                    
                    <button type="submit" class="py-1.5 px-4 bg-bushgreen text-white text-xs font-bold rounded-lg transition shadow">
                        Share on Wall (+5 Points)
                    </button>
                </form>
            </div>

        </div>
    </div>

    <!-- TAB 12: IMPACT ANALYTICS -->
    <div x-show="activeTab === 'analytics'" class="bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
        <h3 class="text-slate-850 dark:text-white font-bold text-sm font-display border-b border-slate-50 dark:border-slate-700 pb-3">Your Impact Index Analytics</h3>
        
        <div class="grid grid-cols-1 md:grid-cols-2 gap-8 text-xs font-light leading-relaxed">
            <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-850 rounded-2xl space-y-2">
                <h4 class="font-bold text-slate-800 dark:text-white text-xs font-display">Monthly Score Achievements</h4>
                <p>Track your score growth indices. You earned <strong>+50 points</strong> this month from submitting field reports and checking-in to local town halls.</p>
                <div class="w-full bg-slate-200 dark:bg-slate-950 rounded-full h-3 overflow-hidden flex items-center justify-between">
                    <div class="bg-bushgreen dark:bg-gold h-full rounded-full" style="width: 75%"></div>
                </div>
            </div>
            <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-850 rounded-2xl space-y-2">
                <h4 class="font-bold text-slate-800 dark:text-white text-xs font-display">Participation Analytics Summary</h4>
                <p>Attendances checks: <strong>100%</strong> of weekly events RSVPed were verified at town hall QR check-in gates successfully.</p>
            </div>
        </div>
    </div>

    <!-- TAB 13: NATIONAL TALENT PIPELINE REGISTRATION -->
    <div x-show="activeTab === 'talent_pipeline'" class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        <!-- Registration Form (Col 5) -->
        <div class="lg:col-span-5 bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
            <div class="border-b border-slate-50 dark:border-slate-700 pb-3">
                <h3 class="text-slate-850 dark:text-white font-bold text-sm font-display">National Talent Pipeline Registration</h3>
                <p class="text-[10px] text-slate-400">Join the national initiative to train others or get trained in high-demand IT fields.</p>
            </div>

            <form method="POST" action="" class="space-y-4">
                <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                <input type="hidden" name="action" value="submit_talent_pipeline">
                <input type="hidden" name="redirect_tab" value="talent_pipeline">

                <div>
                    <label class="block text-slate-655 dark:text-slate-400 text-xs font-semibold mb-1">I want to register as a: *</label>
                    <div class="grid grid-cols-2 gap-4">
                        <label class="flex items-center gap-2 p-3 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl cursor-pointer">
                            <input type="radio" name="role_type" value="trainer" required class="text-bushgreen focus:ring-bushgreen">
                            <span class="text-xs font-bold text-slate-700 dark:text-slate-300">Trainer</span>
                        </label>
                        <label class="flex items-center gap-2 p-3 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl cursor-pointer">
                            <input type="radio" name="role_type" value="trainee" required checked class="text-bushgreen focus:ring-bushgreen">
                            <span class="text-xs font-bold text-slate-700 dark:text-slate-300">Trainee</span>
                        </label>
                    </div>
                </div>

                <div>
                    <label class="block text-slate-655 dark:text-slate-400 text-xs font-semibold mb-1" for="tp_skill">Select IT Skill *</label>
                    <select name="skill" id="tp_skill" required class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen dark:text-white font-semibold">
                        <option value="Software Engineering & Web Development">Software Engineering & Web Development</option>
                        <option value="Mobile App Development (Flutter/React Native)">Mobile App Development (Flutter/React Native)</option>
                        <option value="Cloud Computing (AWS/GCP/Azure)">Cloud Computing (AWS/GCP/Azure)</option>
                        <option value="Cyber Security & Ethical Hacking">Cyber Security & Ethical Hacking</option>
                        <option value="Artificial Intelligence & Machine Learning">Artificial Intelligence & Machine Learning</option>
                        <option value="Data Science & Advanced Analytics">Data Science & Advanced Analytics</option>
                        <option value="UI/UX Design & Product Design">UI/UX Design & Product Design</option>
                        <option value="Product Management & Agile Methodologies">Product Management & Agile Methodologies</option>
                        <option value="Blockchain & Web3 Technologies">Blockchain & Web3 Technologies</option>
                        <option value="DevOps & Site Reliability Engineering (SRE)">DevOps & Site Reliability Engineering (SRE)</option>
                    </select>
                </div>

                <div>
                    <label class="block text-slate-655 dark:text-slate-400 text-xs font-semibold mb-1" for="tp_exp">Years of Experience in this Area</label>
                    <input type="number" name="experience_years" id="tp_exp" min="0" max="40" value="0"
                           class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen dark:text-white">
                </div>

                <div>
                    <label class="block text-slate-655 dark:text-slate-400 text-xs font-semibold mb-1" for="tp_notes">Statement of Intent & Additional Details</label>
                    <textarea name="additional_notes" id="tp_notes" rows="4" placeholder="Briefly describe your motivation, background, or training facilities/interest..."
                              class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-light leading-relaxed dark:text-white"></textarea>
                </div>

                <button type="submit" class="w-full py-2 bg-bushgreen hover:bg-bushgreen-light text-white text-xs font-bold rounded-lg transition shadow-md">
                    Submit Registration
                </button>
            </form>
        </div>

        <!-- History & Status (Col 7) -->
        <div class="lg:col-span-7 bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
            <h3 class="text-slate-800 dark:text-white font-bold text-sm font-display border-b border-slate-50 dark:border-slate-700 pb-3">My Talent Pipeline Submissions</h3>

            <div class="space-y-4">
                <?php if (empty($talent_submissions)): ?>
                    <p class="text-xs text-slate-400 italic py-8 text-center">You have not submitted any pipeline registrations yet.</p>
                <?php else: ?>
                    <?php foreach ($talent_submissions as $sub): ?>
                        <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-150 dark:border-slate-800 rounded-2xl space-y-3">
                            <div class="flex justify-between items-start">
                                <div>
                                    <span class="px-2 py-0.5 rounded text-[8px] font-bold uppercase tracking-widest <?php echo $sub['role_type'] === 'trainer' ? 'bg-bushgreen text-white' : 'bg-gold/20 text-gold-dark'; ?>">
                                        <?php echo htmlspecialchars($sub['role_type']); ?>
                                    </span>
                                    <h4 class="font-bold text-slate-850 dark:text-white text-xs mt-1.5"><?php echo htmlspecialchars($sub['skill']); ?></h4>
                                </div>
                                <span class="px-2.5 py-0.5 rounded-full text-[9px] font-extrabold uppercase tracking-wide
                                    <?php 
                                    if ($sub['status'] === 'approved') echo 'bg-emerald-50 text-emerald-800 border border-emerald-250';
                                    elseif ($sub['status'] === 'shortlisted') echo 'bg-blue-50 text-blue-800 border border-blue-200';
                                    elseif ($sub['status'] === 'rejected') echo 'bg-red-50 text-red-800 border border-red-200';
                                    else echo 'bg-amber-50 text-amber-800 border border-amber-200';
                                    ?>">
                                    <?php echo htmlspecialchars($sub['status']); ?>
                                </span>
                            </div>

                            <div class="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed font-light space-y-1.5">
                                <p><span class="font-semibold text-slate-700 dark:text-slate-300">Experience:</span> <?php echo $sub['experience_years']; ?> Years</p>
                                <?php if (!empty($sub['additional_notes'])): ?>
                                    <p><span class="font-semibold text-slate-700 dark:text-slate-300">Notes:</span> <?php echo htmlspecialchars($sub['additional_notes']); ?></p>
                                <?php endif; ?>
                            </div>

                            <?php if (!empty($sub['moderation_notes'])): ?>
                                <div class="p-3 bg-white dark:bg-slate-950 rounded-xl border border-slate-100 dark:border-slate-900 text-[10px] space-y-1">
                                    <span class="font-bold text-gold uppercase tracking-wider block text-[8px]">Moderator Decision Feedback:</span>
                                    <p class="text-slate-655 dark:text-slate-400 italic">"<?php echo htmlspecialchars($sub['moderation_notes']); ?>"</p>
                                </div>
                            <?php endif; ?>

                            <div class="text-[9px] text-slate-400 pt-2 border-t border-slate-100 dark:border-slate-800/40">
                                Submitted on: <strong><?php echo date('Y-m-d H:i', strtotime($sub['created_at'])); ?></strong>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>

    </div>

    <!-- TAB 14: MOBILISATION & VOLUNTEERS SYSTEM -->
    <div x-show="activeTab === 'volunteers'" class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        <!-- Volunteer Enlistment Form (Col 6) -->
        <div class="lg:col-span-6 bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
            <div class="border-b border-slate-50 dark:border-slate-700 pb-3">
                <h3 class="text-slate-850 dark:text-white font-bold text-sm font-display">Volunteer Mobilisation Enlistment</h3>
                <p class="text-[10px] text-slate-400">Configure your volunteering availability, preferences, and mobilization skills.</p>
            </div>

            <form method="POST" action="" class="space-y-4">
                <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                <input type="hidden" name="action" value="submit_volunteer_profile">
                <input type="hidden" name="redirect_tab" value="volunteers">

                <div>
                    <label class="block text-slate-655 dark:text-slate-400 text-xs font-semibold mb-2">Select Areas of Volunteering Interest: *</label>
                    <div class="space-y-2">
                        <?php 
                        $vol_areas = [
                            'Outreach'      => 'Community Mobilisation & Grassroots Outreach',
                            'Mentoring'     => 'Technical Training & IT Mentorship',
                            'Logistics'     => 'Event Management & Logistics Setup',
                            'Media'         => 'Publicity, Media & Content Writing',
                            'IT_Setup'      => 'Systems Support & Hardware Installation',
                            'Onboarding'    => 'Onboarding & Registration Assistance',
                            'Monitoring'    => 'Monitoring, Evaluation & Impact Reporting'
                        ];
                        
                        $selected_areas = [];
                        if ($volunteer_profile && !empty($volunteer_profile['volunteer_areas'])) {
                            $selected_areas = json_decode($volunteer_profile['volunteer_areas'], true) ?: [];
                        }

                        foreach ($vol_areas as $key => $label):
                            $checked = in_array($key, $selected_areas) ? 'checked' : '';
                        ?>
                            <label class="flex items-start gap-2.5 p-2 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-xl cursor-pointer">
                                <input type="checkbox" name="volunteer_areas[]" value="<?php echo $key; ?>" <?php echo $checked; ?> class="rounded text-bushgreen focus:ring-bushgreen w-4 h-4 mt-0.5">
                                <span class="text-xs text-slate-700 dark:text-slate-300 font-medium"><?php echo $label; ?></span>
                            </label>
                        <?php endforeach; ?>
                    </div>
                </div>

                <div>
                    <label class="block text-slate-655 dark:text-slate-400 text-xs font-semibold mb-1" for="v_availability">Weekly Availability *</label>
                    <select name="availability" id="v_availability" required class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen dark:text-white">
                        <option value="Weekends Only" <?php echo ($volunteer_profile && $volunteer_profile['availability'] === 'Weekends Only') ? 'selected' : ''; ?>>Weekends Only</option>
                        <option value="Weekdays Only" <?php echo ($volunteer_profile && $volunteer_profile['availability'] === 'Weekdays Only') ? 'selected' : ''; ?>>Weekdays Only</option>
                        <option value="Flexible (Weekdays & Weekends)" <?php echo ($volunteer_profile && $volunteer_profile['availability'] === 'Flexible (Weekdays & Weekends)') ? 'selected' : ''; ?>>Flexible (Weekdays & Weekends)</option>
                        <option value="Full-Time Active Deployment" <?php echo ($volunteer_profile && $volunteer_profile['availability'] === 'Full-Time Active Deployment') ? 'selected' : ''; ?>>Full-Time Active Deployment</option>
                    </select>
                </div>

                <div>
                    <label class="block text-slate-655 dark:text-slate-400 text-xs font-semibold mb-1" for="v_exp">Past Mobilisation or Voluntary Experience</label>
                    <textarea name="experience" id="v_exp" rows="3" placeholder="Briefly describe any past experience in community programs or training mobilization..."
                              class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-light leading-relaxed dark:text-white"><?php echo $volunteer_profile ? htmlspecialchars($volunteer_profile['experience']) : ''; ?></textarea>
                </div>

                <button type="submit" class="w-full py-2 bg-bushgreen hover:bg-bushgreen-light text-white text-xs font-bold rounded-lg transition shadow-md">
                    <?php echo $volunteer_profile ? 'Update Enlistment Profile' : 'Enlist as Volunteer'; ?>
                </button>
            </form>
        </div>

        <!-- Status Panel (Col 6) -->
        <div class="lg:col-span-6 space-y-6">
            <div class="bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
                <h3 class="text-slate-800 dark:text-white font-bold text-sm font-display border-b border-slate-50 dark:border-slate-700 pb-3">Enlistment Status</h3>

                <?php if (!$volunteer_profile): ?>
                    <div class="p-8 text-center text-slate-400 italic text-xs space-y-3">
                        <p>You have not enlisted in the Mobilisation & Volunteers register yet.</p>
                        <p class="text-[10px] text-slate-500 font-light">Complete the preferences form on the left to activate your volunteer coordinate.</p>
                    </div>
                <?php else: ?>
                    <div class="space-y-4">
                        <div class="flex justify-between items-center p-4 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl">
                            <span class="text-xs font-bold text-slate-700 dark:text-slate-300">Volunteer Verification Status</span>
                            <span class="px-2.5 py-0.5 rounded-full text-[9px] font-extrabold uppercase tracking-wide
                                <?php 
                                if ($volunteer_profile['status'] === 'approved') echo 'bg-emerald-50 text-emerald-800 border border-emerald-250';
                                elseif ($volunteer_profile['status'] === 'rejected') echo 'bg-red-50 text-red-800 border border-red-200';
                                else echo 'bg-amber-50 text-amber-800 border border-amber-200';
                                ?>">
                                <?php echo htmlspecialchars($volunteer_profile['status']); ?>
                            </span>
                        </div>

                        <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl space-y-3 text-xs">
                            <h4 class="font-bold text-slate-800 dark:text-white text-xs font-display">My Registered Preferences</h4>
                            
                            <div class="space-y-2">
                                <div>
                                    <span class="text-slate-400 block text-[10px] font-semibold">Active Availability</span>
                                    <span class="font-bold text-slate-800 dark:text-white"><?php echo htmlspecialchars($volunteer_profile['availability']); ?></span>
                                </div>
                                <div>
                                    <span class="text-slate-400 block text-[10px] font-semibold">Enlisted Volunteer Roles</span>
                                    <div class="flex flex-wrap gap-1.5 mt-1">
                                        <?php 
                                        foreach ($selected_areas as $area_key) {
                                            $name = $vol_areas[$area_key] ?? $area_key;
                                            echo '<span class="px-2 py-0.5 bg-bushgreen/10 text-bushgreen dark:bg-gold/10 dark:text-gold rounded text-[9px] font-semibold">' . htmlspecialchars($name) . '</span>';
                                        }
                                        ?>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="text-[9px] text-slate-400 text-center pt-2 font-mono">
                            Last Updated: <?php echo date('Y-m-d H:i', strtotime($volunteer_profile['updated_at'])); ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
            
            <div class="bg-gradient-to-r from-bushgreen to-bushgreen-light text-white p-6 rounded-3xl shadow-md space-y-3">
                <h4 class="font-bold text-xs uppercase tracking-wider font-display text-gold">Volunteer Mobilization Code of Conduct</h4>
                <p class="text-[10px] leading-relaxed font-light text-slate-350">
                    PBAT volunteers must operate with maximum transparency, assist citizens professionally, and align coordinates with LGA chapter circular rules. Unauthorized mobilization is strictly prohibited.
                </p>
            </div>
        </div>

    </div>

</div>

