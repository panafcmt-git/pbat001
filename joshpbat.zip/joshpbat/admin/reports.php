<?php
/**
 * PBAT Smart Nation Initiative - Smart Reporting Center
 * Report approval workflow, media uploads, categories, suspicious flagging, and PDF print formatting.
 */
require_once dirname(__DIR__) . '/helpers/auth.php';
require_once dirname(__DIR__) . '/helpers/common.php';
require_once dirname(__DIR__) . '/helpers/notifications.php';
require_once dirname(__DIR__) . '/config/database.php';

if (!Auth::isLoggedIn()) {
    header("Location: ../login.php");
    exit;
}

$user = Auth::user();
$role = $user['role'];
$user_id = $user['id'];

$error = '';
$success = '';
$reports = [];
$states_list = [];

try {
    $db = Database::connect();

    // 1. Handle Report Submission (For Ambassadors)
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'submit_report') {
        $title = trim($_POST['title']);
        $description = trim($_POST['description']);
        $state_id = (int)$_POST['state_id'];
        $category = trim($_POST['category'] ?? 'General');
        $media_path = '';

        // Handle attachment file upload
        if (isset($_FILES['attachment_file']) && $_FILES['attachment_file']['error'] === UPLOAD_ERR_OK) {
            $file = $_FILES['attachment_file'];
            $file_name = basename($file['name']);
            $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
            $allowed = ['jpg', 'jpeg', 'png', 'pdf'];

            if (in_array($file_ext, $allowed) && $file['size'] < 5 * 1024 * 1024) {
                $upload_dir = dirname(__DIR__) . '/uploads/';
                if (!is_dir($upload_dir)) {
                    mkdir($upload_dir, 0755, true);
                }
                $new_name = 'REP-' . uniqid() . '.' . $file_ext;
                if (move_uploaded_file($file['tmp_name'], $upload_dir . $new_name)) {
                    $media_path = 'uploads/' . $new_name;
                    
                    // Save to media_uploads
                    $stmt_media = $db->prepare("INSERT INTO `media_uploads` (`user_id`, `title`, `file_path`, `file_type`) VALUES (?, ?, ?, ?)");
                    $stmt_media->execute([$user_id, $file_name, $media_path, $file['type']]);
                }
            }
        }

        if (empty($title) || empty($description) || empty($state_id)) {
            $error = "Please provide all required briefing credentials.";
        } else {
            $stmt = $db->prepare("INSERT INTO `reports` (`user_id`, `title`, `description`, `file_path`, `state_id`, `status`) VALUES (?, ?, ?, ?, ?, 'submitted')");
            $stmt->execute([$user_id, $title, $description, $media_path, $state_id]);
            
            // Notify State Chairman for this state
            $stmt_leader = $db->prepare("SELECT u.name, u.email FROM users u JOIN user_leadership ul ON u.id = ul.user_id WHERE ul.state_id = ? AND u.role_id = 5 LIMIT 1");
            $stmt_leader->execute([$state_id]);
            $leader = $stmt_leader->fetch();
            
            $leader_email = $leader ? $leader['email'] : 'admin@pbat-smartnation.ng';
            $leader_name = $leader ? $leader['name'] : 'State Chapter Chairman';
            NotificationEmail::sendBriefingFiled($leader_email, $leader_name, $user['name'], $title);

            // Trigger audit log
            Auth::logAction($user_id, 'REPORT_SUBMIT', "Submitted briefing report: '{$title}'");

            // Update stats
            $db->exec("UPDATE `analytics_summary` SET `reports_filed` = `reports_filed` + 1, `impact_score` = `impact_score` + 50 WHERE `state_id` = {$state_id}");

            $success = "Report filed successfully! Reviewed by state committee shortly.";
        }
    }

    // 2. Handle Status Review & Suspicious Flagging
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'review_report') {
        if (Auth::hasRole(['super_admin', 'founder_circle', 'national_steering', 'state_chairman'])) {
            $report_id = (int)$_POST['report_id'];
            $status = trim($_POST['status']);

            if (in_array($status, ['approved', 'rejected', 'flagged'])) {
                $stmt = $db->prepare("UPDATE `reports` SET `status` = ? WHERE `id` = ?");
                $stmt->execute([$status, $report_id]);

                // Fetch report and author details for notification
                $stmt_rep = $db->prepare("SELECT r.title, u.name, u.email FROM reports r JOIN users u ON r.user_id = u.id WHERE r.id = ?");
                $stmt_rep->execute([$report_id]);
                $rep_data = $stmt_rep->fetch();
                
                if ($rep_data && $status !== 'flagged') {
                    NotificationEmail::sendBriefingReviewed($rep_data['email'], $rep_data['name'], $rep_data['title'], $status, $user['name']);
                }

                Auth::logAction($user_id, 'REPORT_REVIEW', "Reviewed report ID {$report_id} as {$status}");
                $success = "Report status updated to '{$status}' successfully.";
            }
        }
    }

    // 3. Search and Filters
    $filter_state = trim($_GET['state_id'] ?? '');
    $filter_status = trim($_GET['status'] ?? '');
    $filter_search = trim($_GET['search'] ?? '');

    $query = "
        SELECT r.*, u.name as author_name, s.name as state_name, s.zone 
        FROM `reports` r 
        JOIN `users` u ON r.user_id = u.id 
        JOIN `states` s ON r.state_id = s.id 
        WHERE 1=1
    ";
    $params = [];

    if (!Auth::hasRole(['super_admin', 'founder_circle', 'national_steering', 'zonal_chairman'])) {
        $query .= " AND r.user_id = ?";
        $params[] = $user_id;
    }

    if (!empty($filter_state)) {
        $query .= " AND r.state_id = ?";
        $params[] = (int)$filter_state;
    }

    if (!empty($filter_status)) {
        $query .= " AND r.status = ?";
        $params[] = $filter_status;
    }

    if (!empty($filter_search)) {
        $query .= " AND (r.title LIKE ? OR r.description LIKE ?)";
        $search_val = "%{$filter_search}%";
        $params[] = $search_val;
        $params[] = $search_val;
    }

    $query .= " ORDER BY r.created_at DESC";
    $stmt = $db->prepare($query);
    $stmt->execute($params);
    $reports = $stmt->fetchAll();

    // Fetch States
    $stmt = $db->query("SELECT * FROM `states` ORDER BY `name` ASC");
    $states_list = $stmt->fetchAll();

} catch (Exception $e) {
    $error = "Reports Center Error: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Smart Reporting Center - PBAT Smart Nation</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        bushgreen: {
                            DEFAULT: '#063C1E',
                            light: '#0A4D27',
                            dark: '#03200F',
                        },
                        gold: '#D4AF37'
                    }
                }
            }
        }
    </script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        [x-cloak] { display: none !important; }
        body { font-family: 'Inter', sans-serif; }
        h1, h2, h3, h4, .font-display { font-family: 'Outfit', sans-serif; }
        @media print {
            body { background: white; color: black; }
            .no-print { display: none !important; }
            .print-layout { box-shadow: none !important; border: 1px solid #ccc !important; padding: 2rem !important; }
        }
    </style>
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
</head>
<body class="bg-slate-50 text-slate-800 transition-colors duration-200 min-h-screen flex flex-col antialiased"
      x-data="{ darkMode: localStorage.getItem('darkMode') === 'true' }"
      x-init="$watch('darkMode', val => localStorage.setItem('darkMode', val))"
      :class="{ 'dark bg-slate-900 text-slate-100': darkMode }">

    <!-- Header Navbar -->
    <header class="bg-bushgreen text-white border-b-2 border-gold h-20 flex items-center justify-between px-6 shadow-md relative z-30 no-print">
        <div class="flex items-center gap-3">
            <a href="dashboard.php" class="py-1.5 px-3 border border-white/20 hover:bg-white/10 text-white rounded-lg text-xs font-bold transition">
                &larr; Back to Dashboard
            </a>
            <div class="w-8 h-8 rounded bg-white/10 flex items-center justify-center border border-white/20 p-1 flex-shrink-0">
                <?php echo getAppLogoHtml('w-full h-full object-contain', 'dashboard'); ?>
            </div>
            <span class="text-white font-extrabold text-sm font-display hidden sm:inline">PBAT SMART NATION INITIATIVE</span>
        </div>
        <div class="flex items-center gap-4 text-xs font-bold text-gold uppercase tracking-wider">
            <!-- Dark Mode Toggle -->
            <button @click="darkMode = !darkMode" class="p-2 rounded-lg border border-gold/45 text-gold hover:bg-gold/10 transition flex items-center justify-center">
                <svg x-show="darkMode" class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364-6.364l-.707.707M6.364 17.636l-.707.707M18.364 17.636l-.707-.707M6.364 6.364l-.707-.707M15 12a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                <svg x-show="!darkMode" class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z"/></svg>
            </button>
            <span>Advocacy Reporting Module</span>
        </div>
    </header>

    <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 flex-grow w-full space-y-10">
        
        <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 no-print">
            <div class="space-y-1">
                <h1 class="text-2xl sm:text-3xl font-black text-bushgreen dark:text-gold font-display">Smart Reporting Center</h1>
                <p class="text-slate-500 dark:text-slate-400 text-xs font-light">Filing activity briefings, verifying submissions, and flagging suspicious content.</p>
            </div>
            
            <?php if (!empty($success)): ?>
                <div class="px-4 py-2 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs font-semibold">
                    <?php echo $success; ?>
                </div>
            <?php endif; ?>
        </div>

        <!-- Filters Section (no-print) -->
        <div class="bg-white dark:bg-slate-800 p-6 rounded-2xl border border-slate-100 dark:border-slate-700 shadow-sm no-print">
            <form method="GET" action="" class="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div>
                    <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="search">Search Keywords</label>
                    <input type="text" name="search" id="search" value="<?php echo htmlspecialchars($filter_search); ?>" placeholder="Search titles..." class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs">
                </div>
                <div>
                    <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="state_id">Filter by State</label>
                    <select name="state_id" id="state_id" class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs">
                        <option value="">All States</option>
                        <?php foreach ($states_list as $st): ?>
                            <option value="<?php echo $st['id']; ?>" <?php echo $filter_state == $st['id'] ? 'selected' : ''; ?>><?php echo htmlspecialchars($st['name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div>
                    <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="status">Filter by Status</label>
                    <select name="status" id="status" class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs">
                        <option value="">All Statuses</option>
                        <option value="submitted" <?php echo $filter_status === 'submitted' ? 'selected' : ''; ?>>Submitted</option>
                        <option value="approved" <?php echo $filter_status === 'approved' ? 'selected' : ''; ?>>Approved</option>
                        <option value="rejected" <?php echo $filter_status === 'rejected' ? 'selected' : ''; ?>>Rejected</option>
                        <option value="flagged" <?php echo $filter_status === 'flagged' ? 'selected' : ''; ?>>Flagged Suspicious</option>
                    </select>
                </div>
                <div class="flex items-end">
                    <button type="submit" class="w-full py-2 bg-bushgreen hover:bg-bushgreen-light text-white text-xs font-bold rounded-lg transition shadow-md">Apply Filters</button>
                </div>
            </form>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start print-layout">
            
            <!-- LIST COLUMN (Col 7) -->
            <div class="lg:col-span-7 bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
                <div class="flex justify-between items-center no-print">
                    <h3 class="text-slate-800 dark:text-slate-200 font-bold text-sm">Briefing Archives</h3>
                    <button onclick="window.print()" class="py-1 px-3 border border-gold text-gold text-[10px] font-bold rounded-lg transition uppercase">
                        Print / Download PDF
                    </button>
                </div>
                
                <div class="space-y-4">
                    <?php if (empty($reports)): ?>
                        <div class="text-slate-400 italic text-xs py-8 text-center">No reports matching selections.</div>
                    <?php endif; ?>
                    <?php foreach ($reports as $rep): ?>
                        <div class="p-4 rounded-xl border border-slate-100 dark:border-slate-750 hover:border-gold/30 transition space-y-3">
                            <div class="flex justify-between items-start">
                                <div>
                                    <h4 class="font-bold text-slate-800 dark:text-slate-200 text-xs"><?php echo htmlspecialchars($rep['title']); ?></h4>
                                    <span class="text-[10px] text-slate-400">Filed by <strong class="font-semibold text-slate-600 dark:text-slate-400"><?php echo htmlspecialchars($rep['author_name']); ?></strong> &bull; <?php echo htmlspecialchars($rep['state_name']); ?> State (<?php echo htmlspecialchars($rep['zone'] ?? 'N/A'); ?>)</span>
                                </div>
                                <span class="px-2.5 py-0.5 rounded-full text-[9px] font-bold uppercase tracking-wider
                                    <?php echo $rep['status'] === 'approved' ? 'bg-emerald-50 text-emerald-800 border border-emerald-250' : ($rep['status'] === 'flagged' ? 'bg-red-500 text-white border border-red-600' : 'bg-amber-50 text-amber-800 border border-amber-250'); ?>">
                                    <?php echo htmlspecialchars($rep['status']); ?>
                                </span>
                            </div>
                            <p class="text-slate-500 dark:text-slate-400 text-xs leading-relaxed font-light"><?php echo htmlspecialchars($rep['description']); ?></p>

                            <!-- Attachment Path -->
                            <?php if (!empty($rep['file_path'])): ?>
                                <div class="text-[10px] text-slate-400">
                                    Attachment: <a href="../<?php echo htmlspecialchars($rep['file_path']); ?>" target="_blank" class="text-bushgreen dark:text-gold font-bold underline select-all">View Attached Document</a>
                                </div>
                            <?php endif; ?>

                            <!-- Admin Reviews controls (no-print) -->
                            <?php if (Auth::hasRole(['super_admin', 'state_chairman']) && $rep['status'] === 'submitted'): ?>
                                <div class="flex gap-2 pt-2 border-t border-slate-50 dark:border-slate-700 no-print">
                                    <form method="POST" action="">
                                        <input type="hidden" name="action" value="review_report">
                                        <input type="hidden" name="report_id" value="<?php echo $rep['id']; ?>">
                                        <input type="hidden" name="status" value="approved">
                                        <button type="submit" class="py-1 px-3 bg-emerald-600 hover:bg-emerald-700 text-white text-[9px] font-bold rounded uppercase">
                                            Approve
                                        </button>
                                    </form>
                                    <form method="POST" action="">
                                        <input type="hidden" name="action" value="review_report">
                                        <input type="hidden" name="report_id" value="<?php echo $rep['id']; ?>">
                                        <input type="hidden" name="status" value="flagged">
                                        <button type="submit" class="py-1 px-3 bg-red-600 hover:bg-red-700 text-white text-[9px] font-bold rounded uppercase">
                                            Flag Suspicious
                                        </button>
                                    </form>
                                    <form method="POST" action="">
                                        <input type="hidden" name="action" value="review_report">
                                        <input type="hidden" name="report_id" value="<?php echo $rep['id']; ?>">
                                        <input type="hidden" name="status" value="rejected">
                                        <button type="submit" class="py-1 px-3 bg-slate-800 hover:bg-slate-700 text-white text-[9px] font-bold rounded uppercase">
                                            Decline
                                        </button>
                                    </form>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- SUBMIT FORM COLUMN (Col 5) (no-print) -->
            <div class="lg:col-span-5 bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6 no-print">
                <div class="pb-3 border-b border-slate-100 dark:border-slate-700">
                    <h3 class="text-slate-800 dark:text-slate-200 font-bold text-sm">Submit Activity Briefing</h3>
                    <p class="text-[10px] text-slate-400">Ambassadors can report tech inclusion, coding seminars, or municipal advocacy accomplishments.</p>
                </div>

                <form method="POST" action="" enctype="multipart/form-data" class="space-y-4">
                    <input type="hidden" name="action" value="submit_report">
                    
                    <div>
                        <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="title">Program/Brief Title *</label>
                        <input type="text" name="title" id="title" required placeholder="e.g. Alimosho Cyber Security Seminar"
                               class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                    </div>

                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="state_id">State Chapter *</label>
                            <select name="state_id" id="state_id" required
                                    class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                                <option value="">-- Choose --</option>
                                <?php foreach ($states_list as $st): ?>
                                    <option value="<?php echo $st['id']; ?>"><?php echo htmlspecialchars($st['name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div>
                            <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="category">Category *</label>
                            <select name="category" id="category" required
                                    class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                                <option value="Tech Sensitization">Tech Sensitization</option>
                                <option value="AI Literacy">AI Literacy</option>
                                <option value="Infrastructure">Infrastructure</option>
                                <option value="Civic Mobilization">Civic Mobilization</option>
                            </select>
                        </div>
                    </div>

                    <div>
                        <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="attachment_file">Attach Document Cover / PDF (Max: 5MB)</label>
                        <input type="file" name="attachment_file" id="attachment_file" accept=".jpg,.jpeg,.png,.pdf"
                               class="w-full text-xs text-slate-500 file:mr-4 file:py-1.5 file:px-3 file:rounded-xl file:border-0 file:bg-bushgreen/10 file:text-bushgreen">
                    </div>

                    <div>
                        <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="description">Detailed Activity Description *</label>
                        <textarea name="description" id="description" required rows="6" placeholder="Document the attendance list, technology tools introduced, and impact score highlights..."
                                  class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-light"></textarea>
                    </div>

                    <button type="submit" class="w-full py-2.5 bg-bushgreen hover:bg-bushgreen-light text-white text-xs font-bold rounded-lg transition shadow-md shadow-bushgreen/10">
                        Dispatch Advocacy Report Briefing
                    </button>
                </form>
            </div>

        </div>

    </main>
</body>
</html>
