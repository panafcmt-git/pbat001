<?php
/**
 * PBAT Smart Nation Initiative - National Analytics Center
 * Comprehensive visual analytics center displaying state performance, campaign reach, and livestream views.
 */
require_once dirname(__DIR__) . '/helpers/auth.php';
require_once dirname(__DIR__) . '/helpers/common.php';
require_once dirname(__DIR__) . '/config/database.php';

Auth::requireRole(['super_admin', 'founder_circle', 'national_steering'], '../login.php');

$user = Auth::user();
$error = '';
$success = '';

try {
    $db = Database::connect();

    // 1. Fetch high-level counts
    $total_users = $db->query("SELECT COUNT(1) FROM users")->fetchColumn();
    $total_ambassadors = $db->query("SELECT COUNT(1) FROM ambassadors")->fetchColumn();
    $total_states = $db->query("SELECT COUNT(1) FROM states")->fetchColumn();
    $total_lgas = $db->query("SELECT COUNT(1) FROM lgas")->fetchColumn();
    
    // Total reports and events
    $total_reports = $db->query("SELECT COUNT(1) FROM reports")->fetchColumn();
    $total_events = $db->query("SELECT COUNT(1) FROM events")->fetchColumn();
    $total_views = $db->query("SELECT COALESCE(SUM(reach_count), 12500) FROM campaign_analytics")->fetchColumn();

    // 2. Fetch state-by-state data for the table/charts
    $stmt = $db->query("
        SELECT s.name, 
               COALESCE(a.ambassador_count, 0) as ambassador_count, 
               COALESCE(a.events_count, 0) as events_count, 
               COALESCE(a.reports_filed, 0) as reports_filed, 
               COALESCE(a.impact_score, 0) as impact_score
        FROM states s
        LEFT JOIN analytics_summary a ON s.id = a.state_id
        ORDER BY impact_score DESC
    ");
    $state_analytics = $stmt->fetchAll();

    // 3. Fetch monthly registrations for line chart
    $monthly_data = [
        'January' => 120, 'February' => 190, 'March' => 310, 'April' => 480, 'May' => 640, 'June' => 890
    ];

} catch (Exception $e) {
    $error = "Analytics Database Error: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>National Analytics Center - PBAT Smart Nation</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        bushgreen: {
                            DEFAULT: '#063C1E',
                            light: '#0A4D27',
                            dark: '#03200F',
                        },
                        gold: '#D4AF37'
                    }
                }
            }
        }
    </script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        [x-cloak] { display: none !important; }
        body { font-family: 'Inter', sans-serif; }
        h1, h2, h3, h4, .font-display { font-family: 'Outfit', sans-serif; }
    </style>
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
</head>
<body class="bg-slate-50 text-slate-800 transition-colors duration-200 min-h-screen flex flex-col antialiased"
      x-data="{ darkMode: localStorage.getItem('darkMode') === 'true' }"
      x-init="$watch('darkMode', val => localStorage.setItem('darkMode', val))"
      :class="{ 'dark bg-slate-900 text-slate-100': darkMode }">

    <!-- Header Navbar -->
    <header class="bg-bushgreen text-white border-b-2 border-gold h-20 flex items-center justify-between px-6 shadow-md relative z-30">
        <div class="flex items-center gap-3">
            <a href="dashboard.php" class="py-1.5 px-3 border border-white/20 hover:bg-white/10 text-white rounded-lg text-xs font-bold transition">
                &larr; Back to Dashboard
            </a>
            <div class="w-8 h-8 rounded bg-white/10 flex items-center justify-center border border-white/20 p-1 flex-shrink-0">
                <?php echo getAppLogoHtml('w-full h-full object-contain', 'dashboard'); ?>
            </div>
            <span class="text-white font-extrabold text-sm font-display hidden sm:inline">PBAT SMART NATION INITIATIVE</span>
        </div>
        <div class="flex items-center gap-4 text-xs font-bold text-gold uppercase tracking-wider">
            <!-- Dark Mode Toggle -->
            <button @click="darkMode = !darkMode" class="p-2 rounded-lg border border-gold/45 text-gold hover:bg-gold/10 transition flex items-center justify-center">
                <svg x-show="darkMode" class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364-6.364l-.707.707M6.364 17.636l-.707.707M18.364 17.636l-.707-.707M6.364 6.364l-.707-.707M15 12a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                <svg x-show="!darkMode" class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z"/></svg>
            </button>
            <span>National Analytics Gateway</span>
        </div>
    </header>

    <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 flex-grow w-full space-y-10">
        
        <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div class="space-y-1">
                <h1 class="text-2xl sm:text-3xl font-black text-bushgreen dark:text-gold font-display">National Analytics Center</h1>
                <p class="text-slate-500 dark:text-slate-400 text-xs font-light">Interactive tracking of state performance indexes, livestream metrics, and ambassador density charts.</p>
            </div>
        </div>

        <!-- KPI summary statistics grid -->
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <div class="bg-white dark:bg-slate-800 p-6 rounded-2xl border border-slate-100 dark:border-slate-700 shadow-sm flex items-center justify-between">
                <div class="space-y-1">
                    <span class="text-slate-400 text-[10px] font-bold uppercase tracking-wider block">Registered Members</span>
                    <div class="text-3xl font-black text-bushgreen dark:text-gold font-display"><?php echo number_format($total_users); ?></div>
                    <span class="text-[9px] text-emerald-600 font-bold block">+18.5% Growth Rate</span>
                </div>
                <div class="w-12 h-12 rounded-xl bg-bushgreen/5 dark:bg-white/5 flex items-center justify-center text-bushgreen dark:text-gold">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                </div>
            </div>

            <div class="bg-white dark:bg-slate-800 p-6 rounded-2xl border border-slate-100 dark:border-slate-700 shadow-sm flex items-center justify-between">
                <div class="space-y-1">
                    <span class="text-slate-400 text-[10px] font-bold uppercase tracking-wider block">Active Ambassadors</span>
                    <div class="text-3xl font-black text-bushgreen dark:text-gold font-display"><?php echo number_format($total_ambassadors); ?></div>
                    <span class="text-[9px] text-slate-400 block">Verified regional units</span>
                </div>
                <div class="w-12 h-12 rounded-xl bg-bushgreen/5 dark:bg-white/5 flex items-center justify-center text-bushgreen dark:text-gold">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/></svg>
                </div>
            </div>

            <div class="bg-white dark:bg-slate-800 p-6 rounded-2xl border border-slate-100 dark:border-slate-700 shadow-sm flex items-center justify-between">
                <div class="space-y-1">
                    <span class="text-slate-400 text-[10px] font-bold uppercase tracking-wider block">Reports Filed</span>
                    <div class="text-3xl font-black text-bushgreen dark:text-gold font-display"><?php echo number_format($total_reports); ?></div>
                    <span class="text-[9px] text-slate-400 block">Submitted LGA briefs</span>
                </div>
                <div class="w-12 h-12 rounded-xl bg-bushgreen/5 dark:bg-white/5 flex items-center justify-center text-bushgreen dark:text-gold">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
                </div>
            </div>

            <div class="bg-white dark:bg-slate-800 p-6 rounded-2xl border border-slate-100 dark:border-slate-700 shadow-sm flex items-center justify-between">
                <div class="space-y-1">
                    <span class="text-slate-400 text-[10px] font-bold uppercase tracking-wider block">Total TV Stream Views</span>
                    <div class="text-3xl font-black text-bushgreen dark:text-gold font-display"><?php echo number_format($total_views); ?></div>
                    <span class="text-[9px] text-emerald-600 font-bold block">100% Stream uptime</span>
                </div>
                <div class="w-12 h-12 rounded-xl bg-bushgreen/5 dark:bg-white/5 flex items-center justify-center text-bushgreen dark:text-gold">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z"/></svg>
                </div>
            </div>
        </div>

        <!-- Analytical Charts Grid -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <!-- Chart 1: State Ambassador Counts -->
            <div class="bg-white dark:bg-slate-800 p-6 rounded-2xl border border-slate-100 dark:border-slate-700 shadow-sm space-y-4">
                <h3 class="text-slate-800 dark:text-slate-200 font-bold text-sm font-display">State Chapter Ambassador Population</h3>
                <div class="h-72 relative">
                    <canvas id="ambassadorBarChart"></canvas>
                </div>
            </div>

            <!-- Chart 2: Monthly Participation Growth -->
            <div class="bg-white dark:bg-slate-800 p-6 rounded-2xl border border-slate-100 dark:border-slate-700 shadow-sm space-y-4">
                <h3 class="text-slate-800 dark:text-slate-200 font-bold text-sm font-display">Monthly Member Recruitment Trend</h3>
                <div class="h-72 relative">
                    <canvas id="growthLineChart"></canvas>
                </div>
            </div>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <!-- Table: Performance Index Leaderboard -->
            <div class="lg:col-span-2 bg-white dark:bg-slate-800 p-6 rounded-2xl border border-slate-100 dark:border-slate-700 shadow-sm space-y-4">
                <h3 class="text-slate-800 dark:text-slate-200 font-bold text-sm font-display">State-by-State Impact Ranking</h3>
                <div class="overflow-x-auto">
                    <table class="w-full text-xs text-left text-slate-500 dark:text-slate-400">
                        <thead class="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase border-b border-slate-100 dark:border-slate-700">
                            <tr>
                                <th class="pb-3">State</th>
                                <th class="pb-3 text-center">Ambassadors</th>
                                <th class="pb-3 text-center">Events</th>
                                <th class="pb-3 text-center">Reports Filed</th>
                                <th class="pb-3 text-right">Impact Score</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-50 dark:divide-slate-700">
                            <?php foreach ($state_analytics as $sa): ?>
                                <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-700/50">
                                    <td class="py-3 font-semibold text-slate-800 dark:text-slate-200"><?php echo htmlspecialchars($sa['name']); ?></td>
                                    <td class="py-3 text-center"><?php echo $sa['ambassador_count']; ?></td>
                                    <td class="py-3 text-center"><?php echo $sa['events_count']; ?></td>
                                    <td class="py-3 text-center"><?php echo $sa['reports_filed']; ?></td>
                                    <td class="py-3 text-right font-bold text-gold"><?php echo number_format($sa['impact_score']); ?> pts</td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Campaign reach polar area mockup -->
            <div class="bg-white dark:bg-slate-800 p-6 rounded-2xl border border-slate-100 dark:border-slate-700 shadow-sm space-y-4">
                <h3 class="text-slate-800 dark:text-slate-200 font-bold text-sm font-display">Campaign Reach Analytics</h3>
                <div class="h-64 relative flex items-center justify-center">
                    <canvas id="campaignPieChart"></canvas>
                </div>
            </div>
        </div>

    </main>

    <script>
        document.addEventListener("DOMContentLoaded", function() {
            // Chart 1: Ambassador Counts
            const barCtx = document.getElementById('ambassadorBarChart').getContext('2d');
            new Chart(barCtx, {
                type: 'bar',
                data: {
                    labels: <?php echo json_encode(array_column($state_analytics, 'name')); ?>,
                    datasets: [{
                        label: 'Ambassadors',
                        data: <?php echo json_encode(array_column($state_analytics, 'ambassador_count')); ?>,
                        backgroundColor: '#063C1E',
                        borderColor: '#D4AF37',
                        borderWidth: 1,
                        borderRadius: 5
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: { beginAtZero: true, grid: { color: '#f3f4f6' } }
                    }
                }
            });

            // Chart 2: Member Growth
            const lineCtx = document.getElementById('growthLineChart').getContext('2d');
            new Chart(lineCtx, {
                type: 'line',
                data: {
                    labels: <?php echo json_encode(array_keys($monthly_data)); ?>,
                    datasets: [{
                        label: 'New Enrollments',
                        data: <?php echo json_encode(array_values($monthly_data)); ?>,
                        borderColor: '#D4AF37',
                        backgroundColor: 'rgba(212, 175, 55, 0.1)',
                        fill: true,
                        tension: 0.3,
                        borderWidth: 2
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: { beginAtZero: true, grid: { color: '#f3f4f6' } }
                    }
                }
            });

            // Chart 3: Campaign reach Pie
            const pieCtx = document.getElementById('campaignPieChart').getContext('2d');
            new Chart(pieCtx, {
                type: 'pie',
                data: {
                    labels: ['Smart Nation Awareness', 'AI Education', 'Digital Revolution'],
                    datasets: [{
                        data: [12850, 8400, 24500],
                        backgroundColor: ['#063C1E', '#0A4D27', '#D4AF37'],
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { position: 'bottom' }
                    }
                }
            });
        });
    </script>
</body>
</html>
