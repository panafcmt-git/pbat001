<?php
/**
 * PBAT Smart Nation Initiative - Digital ID Card Generator
 * Renders a highly polished double-sided ID badge with active verification QR Code.
 */
require_once dirname(__DIR__) . '/helpers/auth.php';
require_once dirname(__DIR__) . '/helpers/common.php';
require_once dirname(__DIR__) . '/config/database.php';

if (!Auth::isLoggedIn()) {
    header("Location: ../login.php");
    exit;
}

$user = Auth::user();
$target_user_id = $user['id'];

// If Admin/Founder and target user_id is provided, show that card
if (Auth::hasRole(['super_admin', 'founder_circle', 'national_steering']) && isset($_GET['user_id'])) {
    $target_user_id = (int)$_GET['user_id'];
}

$ambassador = null;

try {
    $db = Database::connect();
    
    // Fetch details
    $stmt = $db->prepare("
        SELECT a.*, u.name, u.avatar, u.role_id, u.email_verified, u.membership_code, u.profile_completed, r.display_name as role_name, s.name as state_name, l.name as lga_name, w.name as ward_name, ke.kyc_status 
        FROM `users` u
        JOIN `roles` r ON u.role_id = r.id
        LEFT JOIN `ambassadors` a ON u.id = a.user_id
        LEFT JOIN `states` s ON a.state_id = s.id 
        LEFT JOIN `lgas` l ON a.lga_id = l.id 
        LEFT JOIN `wards` w ON a.ward_id = w.id
        LEFT JOIN `user_kyc_extended` ke ON u.id = ke.user_id
        WHERE u.id = ? 
        LIMIT 1
    ");
    $stmt->execute([$target_user_id]);
    $ambassador = $stmt->fetch();

    // Verification guard: block display if email is not verified, profile is not complete, photo is missing, or KYC is not approved
    $bypass_for_demo = false; 
    
    $has_avatar = !empty($ambassador['avatar']) && $ambassador['avatar'] !== 'assets/img/default-avatar.png';
    $email_verified = (int)($ambassador['email_verified'] ?? 0) === 1;
    $profile_completed = (int)($ambassador['profile_completed'] ?? 0) === 1;
    $kyc_status = $ambassador['kyc_status'] ?? 'pending_review';
    $kyc_completed = ($kyc_status === 'approved');

    if (!$bypass_for_demo && $ambassador && (!$email_verified || !$profile_completed || !$has_avatar || !$kyc_completed)) {
        ?>
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Action Required - PBAT Smart Nation</title>
            <script src="https://cdn.tailwindcss.com"></script>
            <script>
                tailwind.config = {
                    theme: {
                        extend: {
                            colors: {
                                bushgreen: '#063C1E',
                                gold: '#D4AF37'
                            }
                        }
                    }
                }
            </script>
            <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700&display=swap" rel="stylesheet">
            <style>body { font-family: 'Outfit', sans-serif; }</style>
        </head>
        <body class="bg-slate-50 min-h-screen p-6 flex flex-col items-center justify-center gap-8">
            <div class="max-w-md w-full bg-white rounded-3xl shadow-2xl p-8 border border-red-100 text-center space-y-4">
                <div class="w-16 h-16 bg-red-50 rounded-full border border-red-200 flex items-center justify-center mx-auto text-red-500">
                    <svg class="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01M5.071 19h13.858c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/></svg>
                </div>
                
                <?php if (!$email_verified): ?>
                    <h3 class="text-slate-800 font-extrabold text-lg">Email Verification Required</h3>
                    <p class="text-xs text-slate-500 leading-relaxed font-light">
                        You must verify your email address to access and print your Dynamic ID Card.
                    </p>
                <?php elseif (!$kyc_completed): ?>
                    <h3 class="text-slate-800 font-extrabold text-lg">KYC Verification Required</h3>
                    <p class="text-xs text-slate-550 leading-relaxed font-light">
                        Your KYC status is currently <strong class="text-bushgreen"><?php echo htmlspecialchars(ucwords(str_replace('_', ' ', $kyc_status ?: 'not started'))); ?></strong>. You must complete your KYC profile and it must be approved by an administrator before you can access and print your official ID card.
                    </p>
                <?php else: ?>
                    <h3 class="text-slate-800 font-extrabold text-lg">KYC Profile Photo Required</h3>
                    <p class="text-xs text-slate-500 leading-relaxed font-light">
                        You must complete your KYC profile and upload a valid profile photo before you can access and print your ID badge.
                    </p>
                <?php endif; ?>
                
                <div class="pt-4 border-t border-slate-100 flex gap-3 justify-center">
                    <a href="dashboard.php?tab=profile" class="inline-block py-2.5 px-6 bg-gold text-bushgreen rounded-xl text-xs font-bold hover:bg-yellow-500 transition">
                        Complete Profile (KYC)
                    </a>
                    <a href="dashboard.php" class="inline-block py-2.5 px-6 bg-bushgreen text-white rounded-xl text-xs font-bold hover:bg-emerald-800 transition">
                        Dashboard Home
                    </a>
                </div>
            </div>
        </body>
        </html>
        <?php
        exit;
    }

} catch (Exception $e) {
    // Fallback if DB not active or not representing an ambassador
}

// Ensure fallback details exist for representation
if (!$ambassador) {
    $ambassador = [
        'name' => $user['name'],
        'avatar' => 'assets/img/default-avatar.png',
        'uuid' => 'AMB-6A3B91-3829',
        'state_name' => 'Lagos',
        'lga_name' => 'Alimosho',
        'ward_name' => 'Ward 02',
        'qr_code_hash' => 'hash-simulated-code-1928',
        'role_id' => $user['role_id'],
        'role_name' => str_replace('_', ' ', $user['role']),
        'membership_code' => ''
    ];
}

$uuid = !empty($ambassador['uuid']) ? $ambassador['uuid'] : 'LDR-' . str_pad($target_user_id, 4, '0', STR_PAD_LEFT);
$m_code = !empty($ambassador['membership_code']) ? $ambassador['membership_code'] : $uuid;
$qr_hash = !empty($ambassador['qr_code_hash']) ? $ambassador['qr_code_hash'] : 'hash-simulated-' . $target_user_id;

// Uniform Premium ID Card Design (using Admin theme styling for all roles)
$border_color = 'border-gold';
$bg_gradient = 'from-slate-900 via-slate-800 to-slate-950';

$role_labels = [
    1 => 'System Super Admin',
    2 => 'Founder Circle',
    3 => 'National Steering Committee',
    4 => 'Zonal Chairman',
    5 => 'State Chairman',
    6 => 'LGA Coordinator',
    7 => 'Grassroots Ambassador'
];
$role_badge = $role_labels[$ambassador['role_id']] ?? ($ambassador['role_name'] ?: 'Member');

// Generate the fully qualified public verification URI
$http_host = $_SERVER['HTTP_HOST'] ?? 'localhost';
$verify_url = "http://{$http_host}" . dirname(dirname($_SERVER['PHP_SELF'])) . "/verify.php?uuid=" . urlencode($m_code);
$qr_api_url = "https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=" . urlencode($verify_url);

// Extract first name and remaining names for 2-line rendering
$name_parts = explode(' ', trim($ambassador['name']));
$first_name = strtoupper($name_parts[0]);
$last_names = strtoupper(implode(' ', array_slice($name_parts, 1)));

// Format membership code for tracking-widest (e.g. adding spaces around slashes)
$formatted_code = str_replace('/', ' / ', strtoupper($m_code));

// Resolve assigned jurisdiction
$jurisdiction = 'National';
if (!empty($ambassador['ward_name']) && $ambassador['ward_name'] !== 'Not Applicable') {
    $jurisdiction = $ambassador['ward_name'];
} elseif (!empty($ambassador['lga_name']) && $ambassador['lga_name'] !== 'Not Applicable') {
    $jurisdiction = $ambassador['lga_name'];
} elseif (!empty($ambassador['state_name'])) {
    $jurisdiction = $ambassador['state_name'];
}
$jurisdiction = strtoupper($jurisdiction);

// Resolve logo url dynamically
$logo_src = '../assets/img/logo.png'; // default fallback
try {
    $db_conn = isset($db) ? $db : Database::connect();
    $stmt_l = $db_conn->query("SELECT `setting_value` FROM `system_settings` WHERE `setting_key` = 'logo_url' LIMIT 1");
    $db_logo = $stmt_l->fetchColumn();
    if (!empty($db_logo)) {
        $logo_src = '../' . ltrim($db_logo, '/');
    }
} catch (Exception $e) {}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Digital ID Card - PBAT Smart Nation</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        bushgreen: {
                            DEFAULT: '#063C1E',
                            light: '#0A4D27',
                            dark: '#03200F',
                        },
                        gold: '#D4AF37'
                    }
                }
            }
        }
    </script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Outfit', sans-serif; }
        @media print {
            body { 
                background: white !important; 
                padding: 0 !important;
                margin: 0 !important;
            }
            .no-print { display: none !important; }
            @page {
                margin: 0.5cm !important;
            }
            .print-container {
                display: flex !important;
                flex-direction: row !important;
                justify-content: center !important;
                align-items: center !important;
                gap: 1.5cm !important;
                width: 100% !important;
                margin: 1.5cm auto 0 auto !important;
                page-break-inside: avoid !important;
            }
            .print-card { 
                box-shadow: none !important; 
                width: 8.56cm !important;
                height: 13.5cm !important;
                border-width: 6px !important;
                page-break-inside: avoid !important;
                -webkit-print-color-adjust: exact !important;
                print-color-adjust: exact !important;
            }
            .print-card * {
                -webkit-print-color-adjust: exact !important;
                print-color-adjust: exact !important;
            }
        }
    </style>
</head>
<body class="bg-slate-50 min-h-screen p-6 flex flex-col items-center justify-center gap-8">

    <!-- Top nav no-print -->
    <div class="max-w-2xl w-full flex justify-between items-center no-print">
        <a href="dashboard.php" class="py-2 px-4 bg-slate-800 text-white rounded-xl text-xs font-bold hover:bg-slate-700 transition flex items-center gap-1.5 shadow-sm">
            <svg class="w-4 h-4 text-gold" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/></svg>
            Back to Dashboard
        </a>
        <button onclick="window.print()" class="py-2 px-5 bg-bushgreen hover:bg-bushgreen-light text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-sm">
            <svg class="w-4 h-4 text-gold" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z"/></svg>
            Print ID Card
        </button>
    </div>

    <!-- Double Sided ID Layout -->
    <div class="print-container flex flex-col md:flex-row gap-8 items-center justify-center">
        
        <!-- CARD FRONT -->
        <div class="print-card w-80 aspect-[1/1.58] bg-white text-slate-800 rounded-3xl relative border-[8px] border-[#063C1E] shadow-2xl overflow-hidden flex flex-col justify-between">
            
            <!-- Card Header -->
            <div class="relative h-20 flex border-b border-slate-150 rounded-b-[50%_12px] overflow-hidden flex-shrink-0">
                <!-- Left Logo Container -->
                <div class="w-[43%] bg-white flex items-center justify-center p-2.5 border-r border-slate-100">
                    <img src="<?php echo htmlspecialchars($logo_src); ?>" class="h-10 object-contain" alt="PBAT Logo">
                </div>
                <!-- Right Hero Banner -->
                <div class="w-[57%] relative">
                    <div class="absolute inset-0 bg-cover bg-center" style="background-image: url('../uploads/pbat_hero.jpg');"></div>
                </div>
            </div>

            <!-- Card Body -->
            <div class="flex-grow flex flex-col justify-between px-6 py-2">
                <!-- Title -->
                <div>
                    <span class="text-[#D22B2B] font-extrabold text-[10px] uppercase tracking-[0.2em] font-display block text-center mt-1">OFFICIAL ID BADGE</span>
                    
                    <!-- Name -->
                    <h3 class="text-center font-black text-[#063C1E] text-base leading-tight uppercase tracking-wide font-display mt-2">
                        <?php echo htmlspecialchars($first_name); ?><br>
                        <span class="text-xs sm:text-sm font-extrabold"><?php echo htmlspecialchars($last_names); ?></span>
                    </h3>
                </div>

                <!-- Role Badge -->
                <div class="text-center mt-1">
                    <span class="inline-block bg-[#063C1E] text-white text-[9px] font-bold px-6 py-1.5 rounded-full shadow-sm tracking-wider uppercase">
                        <?php echo htmlspecialchars($role_badge); ?>
                    </span>
                </div>

                <!-- Assigned Jurisdiction -->
                <div class="mt-2 max-w-[85%] w-full mx-auto bg-slate-50/50 border border-slate-100 rounded-2xl p-1.5 text-center">
                    <span class="block text-slate-400 text-[8px] font-bold uppercase tracking-wider">Assigned Jurisdiction</span>
                    <span class="text-[#063C1E] text-[10px] font-black uppercase tracking-wide block mt-0.5"><?php echo htmlspecialchars($jurisdiction); ?></span>
                </div>

                <!-- QR Code Container -->
                <div class="text-center mt-3">
                    <div class="relative inline-block">
                        <div class="p-2 bg-white rounded-2xl border border-slate-150 shadow-md">
                            <img src="<?php echo $qr_api_url; ?>" alt="Verification QR Code" class="w-24 h-24 mx-auto">
                        </div>
                        <div class="absolute -bottom-2 left-1/2 -translate-x-1/2 bg-white border border-slate-150 px-4 py-0.5 rounded-full shadow text-[7px] font-black text-[#063C1E] tracking-wider whitespace-nowrap">
                            SCAN FOR NODE AUTH
                        </div>
                    </div>
                </div>

                <!-- Membership Code -->
                <div class="text-center mt-3">
                    <span class="block text-slate-400 text-[8px] font-bold uppercase tracking-wider mb-1">Membership Code</span>
                    <div class="bg-slate-50 border border-slate-150 rounded-full px-4 py-1 inline-block text-[10px] font-extrabold text-[#063C1E] tracking-[0.12em] font-mono shadow-sm">
                        <?php echo htmlspecialchars($formatted_code); ?>
                    </div>
                </div>
            </div>

            <!-- Bottom bar (gold strip) -->
            <div class="h-2.5 bg-[#D4AF37] w-full mt-auto flex-shrink-0"></div>
        </div>

        <!-- CARD BACK -->
        <div class="print-card w-80 aspect-[1/1.58] bg-white text-slate-800 rounded-3xl relative border-[8px] border-[#063C1E] shadow-2xl overflow-hidden flex flex-col justify-between animate-fade-in">
            
            <!-- Card Header (matching front style) -->
            <div class="relative h-20 flex border-b border-slate-150 rounded-b-[50%_12px] overflow-hidden flex-shrink-0">
                <!-- Left Logo Container -->
                <div class="w-[43%] bg-white flex items-center justify-center p-2.5 border-r border-slate-100">
                    <img src="<?php echo htmlspecialchars($logo_src); ?>" class="h-10 object-contain" alt="PBAT Logo">
                </div>
                <!-- Right Hero Banner -->
                <div class="w-[57%] relative">
                    <div class="absolute inset-0 bg-cover bg-center" style="background-image: url('../uploads/pbat_hero.jpg');"></div>
                </div>
            </div>

            <!-- Card Body -->
            <div class="flex-grow flex flex-col justify-between px-6 py-4 text-center">
                <div>
                    <span class="text-[#D22B2B] font-bold text-[10px] uppercase tracking-[0.2em] font-display block">VERIFICATION GATEWAY</span>
                    <p class="text-slate-500 text-[9px] leading-relaxed px-2 mt-2">
                        Scanning the QR Code on the front of this badge will redirect you to the public verification endpoint validating dynamic security certificates and assignment status.
                    </p>
                </div>

                <div class="my-auto space-y-3 px-2">
                    <div class="h-0.5 bg-gradient-to-r from-transparent via-slate-100 to-transparent"></div>
                    <p class="text-[8px] text-slate-400 leading-normal text-justify">
                        This badge remains the property of the PBAT Smart Nation Initiative. Unauthorized replication or falsification is punishable under cybersecurity frameworks.
                    </p>
                    <div class="h-0.5 bg-gradient-to-r from-transparent via-slate-100 to-transparent"></div>
                    <div class="text-[9px] text-[#063C1E] font-black tracking-widest uppercase font-display">
                        PBAT SMART NATION INITIATIVE
                    </div>
                </div>
            </div>

            <!-- Bottom bar (gold strip) -->
            <div class="h-2.5 bg-[#D4AF37] w-full mt-auto flex-shrink-0"></div>
        </div>

    </div>

    <!-- Print info dialog no-print -->
    <div class="max-w-md text-center no-print space-y-2">
        <h4 class="text-xs font-bold text-slate-600">Scan Notice:</h4>
        <p class="text-[11px] text-slate-500 leading-relaxed">
            The QR Code generated points directly to: <br>
            <code class="text-bushgreen font-bold font-mono text-[9px] break-all"><?php echo $verify_url; ?></code>
        </p>
    </div>
</body>
</html>
