<?php
/**
 * PBAT Smart Nation Initiative - System Maintenance & Diagnostics
 * Restricted panel showing table statistics, server metrics, and diagnostics.
 */
require_once dirname(__DIR__) . '/helpers/auth.php';
require_once dirname(__DIR__) . '/helpers/common.php';
require_once dirname(__DIR__) . '/config/database.php';

// Route protector - Restrict to Super Admin & Founder Circle only
Auth::requireRole(['super_admin'], '../login.php');

$user = Auth::user();
$error = '';
$success = '';
$table_stats = [];

// Storage Checks
$emails_dir = dirname(__DIR__) . '/emails/';
$emails_writable = is_dir($emails_dir) && is_writable($emails_dir);

$uploads_dir = dirname(__DIR__) . '/uploads/';
// Create uploads dir if it doesn't exist
if (!is_dir($uploads_dir)) {
    @mkdir($uploads_dir, 0755, true);
}
$uploads_writable = is_dir($uploads_dir) && is_writable($uploads_dir);

try {
    $db = Database::connect();
    
    // Fetch MySQL Table Stats
    $db_name = DB_NAME;
    $stmt = $db->prepare("
        SELECT TABLE_NAME, TABLE_ROWS, DATA_LENGTH, INDEX_LENGTH, ENGINE 
        FROM information_schema.TABLES 
        WHERE TABLE_SCHEMA = ?
        ORDER BY (DATA_LENGTH + INDEX_LENGTH) DESC
    ");
    $stmt->execute([$db_name]);
    $table_stats = $stmt->fetchAll();

} catch (Exception $e) {
    $error = "Failed to fetch database table diagnostics: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>System Maintenance - PBAT Smart Nation</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        bushgreen: {
                            DEFAULT: '#063C1E',
                            light: '#0A4D27',
                            dark: '#03200F',
                        },
                        gold: '#D4AF37'
                    }
                }
            }
        }
    </script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Outfit', sans-serif; }
    </style>
</head>
<body class="bg-slate-50 min-h-screen flex flex-col antialiased">

    <!-- Header Navbar -->
    <header class="bg-bushgreen text-white border-b-2 border-gold h-20 flex items-center justify-between px-6 shadow-md relative z-30">
        <div class="flex items-center gap-3">
            <a href="dashboard.php" class="py-1.5 px-3 border border-white/20 hover:bg-white/10 text-white rounded-lg text-xs font-bold transition">
                &larr; Back to Dashboard
            </a>
            <div class="w-8 h-8 rounded bg-white/10 flex items-center justify-center border border-white/20 p-1 flex-shrink-0">
                <?php echo getAppLogoHtml('w-full h-full object-contain', 'dashboard'); ?>
            </div>
            <span class="text-white font-extrabold text-sm font-display hidden sm:inline">PBAT SMART NATION INITIATIVE</span>
        </div>
        <div class="flex items-center gap-3 text-xs font-bold text-gold uppercase tracking-wider">
            System Maintenance Portal
        </div>
    </header>

    <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 flex-grow w-full space-y-10">
        
        <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div class="space-y-1">
                <h1 class="text-2xl sm:text-3xl font-black text-bushgreen font-display">System Diagnostics & Maintenance</h1>
                <p class="text-slate-500 text-xs font-light">Inspect active database table allocations, local storage parameters, and core server configurations.</p>
            </div>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            
            <!-- DATABASE TABLES SIZING (Col 8) -->
            <div class="lg:col-span-8 bg-white rounded-2xl border border-slate-100 p-6 shadow-sm space-y-6">
                <div>
                    <h3 class="text-slate-800 font-bold text-sm">MySQL Database Sizing Statistics</h3>
                    <p class="text-[10px] text-slate-400">Analysis of the tables allocated under schema: <strong class="font-mono"><?php echo htmlspecialchars(DB_NAME); ?></strong></p>
                </div>

                <div class="overflow-x-auto">
                    <table class="w-full text-xs text-left text-slate-500">
                        <thead class="text-[10px] text-slate-400 font-bold uppercase tracking-wider border-b border-slate-100">
                            <tr>
                                <th class="pb-3">Table Name</th>
                                <th class="pb-3 text-center">Row Count</th>
                                <th class="pb-3 text-right">Data Size</th>
                                <th class="pb-3 text-right">Index Size</th>
                                <th class="pb-3 text-right">Engine</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-50">
                            <?php if (empty($table_stats)): ?>
                                <tr>
                                    <td colspan="5" class="py-6 text-center text-slate-400 italic">No table statistics available.</td>
                                </tr>
                            <?php else: ?>
                                <?php 
                                $total_rows = 0;
                                $total_bytes = 0;
                                foreach ($table_stats as $table): 
                                    $size_kb = ($table['DATA_LENGTH']) / 1024;
                                    $index_kb = ($table['INDEX_LENGTH']) / 1024;
                                    $total_rows += $table['TABLE_ROWS'];
                                    $total_bytes += ($table['DATA_LENGTH'] + $table['INDEX_LENGTH']);
                                ?>
                                    <tr class="hover:bg-slate-50/50">
                                        <td class="py-3 font-semibold text-slate-800 font-mono"><?php echo htmlspecialchars($table['TABLE_NAME']); ?></td>
                                        <td class="py-3 text-center font-mono"><?php echo number_format($table['TABLE_ROWS']); ?></td>
                                        <td class="py-3 text-right font-mono"><?php echo number_format($size_kb, 1); ?> KB</td>
                                        <td class="py-3 text-right font-mono"><?php echo number_format($index_kb, 1); ?> KB</td>
                                        <td class="py-3 text-right font-semibold text-slate-400 uppercase"><?php echo htmlspecialchars($table['ENGINE']); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                                <tr class="bg-slate-50 font-bold border-t border-slate-200">
                                    <td class="py-3 text-slate-800">Total Schema Allocation</td>
                                    <td class="py-3 text-center font-mono"><?php echo number_format($total_rows); ?></td>
                                    <td colspan="2" class="py-3 text-right font-mono"><?php echo number_format($total_bytes / 1024, 1); ?> KB</td>
                                    <td></td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- SERVER ENVIRONMENT DETAILS & CHECKS (Col 4) -->
            <div class="lg:col-span-4 space-y-6">
                
                <!-- Environment Checks -->
                <div class="bg-white rounded-2xl border border-slate-100 p-6 shadow-sm space-y-6">
                    <div class="pb-3 border-b border-slate-100">
                        <h3 class="text-slate-800 font-bold text-sm">System Specs & Settings</h3>
                        <p class="text-[10px] text-slate-400">Core parameters from active PHP interpreter node.</p>
                    </div>

                    <div class="space-y-3.5 text-xs">
                        <div class="flex justify-between items-center">
                            <span class="text-slate-400">PHP Version:</span>
                            <span class="font-bold text-slate-800 font-mono"><?php echo phpversion(); ?></span>
                        </div>
                        <div class="flex justify-between items-center">
                            <span class="text-slate-400">Timezone:</span>
                            <span class="font-bold text-slate-800 font-mono"><?php echo date_default_timezone_get(); ?></span>
                        </div>
                        <div class="flex justify-between items-center">
                            <span class="text-slate-400">Max Upload Limit:</span>
                            <span class="font-bold text-slate-800 font-mono"><?php echo ini_get('upload_max_filesize'); ?></span>
                        </div>
                        <div class="flex justify-between items-center">
                            <span class="text-slate-400">Max Post Request:</span>
                            <span class="font-bold text-slate-800 font-mono"><?php echo ini_get('post_max_size'); ?></span>
                        </div>
                        <div class="flex justify-between items-center">
                            <span class="text-slate-400">DB Connectivity:</span>
                            <span class="px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 font-bold uppercase text-[9px] border border-emerald-100">Connected</span>
                        </div>
                    </div>
                </div>

                <!-- Storage Health Checks -->
                <div class="bg-white rounded-2xl border border-slate-100 p-6 shadow-sm space-y-6">
                    <div class="pb-3 border-b border-slate-100">
                        <h3 class="text-slate-800 font-bold text-sm">File Storage Permissions</h3>
                        <p class="text-[10px] text-slate-400">Verify folders are writable by system process.</p>
                    </div>

                    <div class="space-y-4">
                        <div class="p-3.5 rounded-xl border flex justify-between items-center <?php echo $emails_writable ? 'bg-emerald-50 border-emerald-100 text-emerald-800' : 'bg-red-50 border-red-100 text-red-800'; ?>">
                            <div class="space-y-0.5">
                                <span class="text-xs font-bold block">Emails Preview Outbox</span>
                                <span class="text-[9px] font-mono opacity-80">/emails/</span>
                            </div>
                            <span class="text-[10px] font-bold uppercase"><?php echo $emails_writable ? 'Writable' : 'Locked'; ?></span>
                        </div>

                        <div class="p-3.5 rounded-xl border flex justify-between items-center <?php echo $uploads_writable ? 'bg-emerald-50 border-emerald-100 text-emerald-800' : 'bg-red-50 border-red-100 text-red-800'; ?>">
                            <div class="space-y-0.5">
                                <span class="text-xs font-bold block">Media Files Uploads</span>
                                <span class="text-[9px] font-mono opacity-80">/uploads/</span>
                            </div>
                            <span class="text-[10px] font-bold uppercase"><?php echo $uploads_writable ? 'Writable' : 'Locked'; ?></span>
                        </div>
                    </div>
                </div>

                <!-- Database Schema Alignment & Repair -->
                <div class="bg-white rounded-2xl border border-slate-100 p-6 shadow-sm space-y-6">
                    <div class="pb-3 border-b border-slate-100">
                        <h3 class="text-slate-800 font-bold text-sm">Database Schema Alignment</h3>
                        <p class="text-[10px] text-slate-400">Scan database for missing tables/columns and align schemas.</p>
                    </div>

                    <div class="space-y-4">
                        <p class="text-xs text-slate-500 leading-relaxed font-light">
                            If you get SQL table errors or logo/settings update failures, some table migrations may be missing. Run repair to safely restore tables and columns.
                        </p>
                        <a href="../run_migrations.php" target="_blank" class="w-full py-2.5 bg-bushgreen hover:bg-emerald-800 text-white rounded-xl text-xs font-bold text-center block transition shadow-md">
                            Run Schema Repair & Align
                        </a>
                    </div>
                </div>

                <!-- System Update Center Card -->
                <div class="bg-white rounded-2xl border border-slate-100 p-6 shadow-sm space-y-6">
                    <div class="pb-3 border-b border-slate-100">
                        <h3 class="text-slate-800 font-bold text-sm">System Update Center</h3>
                        <p class="text-[10px] text-slate-400">Apply zip package code updates, run migrations, and manage backups.</p>
                    </div>

                    <div class="space-y-4">
                        <p class="text-xs text-slate-500 leading-relaxed font-light">
                            Current Version: <strong class="font-mono bg-slate-100 px-2 py-0.5 rounded text-bushgreen"><?php 
                                try {
                                    $db_version = Database::connect()->query("SELECT `setting_value` FROM `system_settings` WHERE `setting_key` = 'system_version' LIMIT 1")->fetchColumn();
                                    echo htmlspecialchars($db_version ?: '1.0.0');
                                } catch (Exception $e) {
                                    echo '1.0.0';
                                }
                            ?></strong>
                        </p>
                        <a href="update-system.php" class="w-full py-2.5 bg-bushgreen hover:bg-emerald-800 text-white rounded-xl text-xs font-bold text-center block transition shadow-md">
                            Open Update Center
                        </a>
                    </div>
                </div>
                
            </div>

        </div>

    </main>
</body>
</html>
