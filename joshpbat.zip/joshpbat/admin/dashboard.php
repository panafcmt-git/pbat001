<?php
/**
 * PBAT Smart Nation Initiative - Master Dashboard Controller
 * Dynamic template switcher serving customized role dashboards:
 * 1. Admin (Super Admin / Overall Control)
 * 2. Founder Circle
 * 3. National Steering Council
 * 4. Zonal Chairman
 * 5. State Chairman
 * 6. Coordinator (LGA Level)
 * 7. Ambassador (Ward Level)
 */
require_once dirname(__DIR__) . '/helpers/auth.php';
require_once dirname(__DIR__) . '/helpers/common.php';
require_once dirname(__DIR__) . '/config/database.php';

if (!Auth::isLoggedIn()) {
    $_SESSION['auth_error'] = "You must log in to access the secure portal.";
    header("Location: ../login.php");
    exit;
}

$user = Auth::user();
$role = $user['role'];
$user_id = $user['id'];

// Fetch user geopolitical zone coordinates
$user_zone = 'National';
try {
    $db = Database::connect();
    if ($role === 'ambassador') {
        $stmt = $db->prepare("SELECT s.zone FROM `ambassadors` a JOIN `states` s ON a.state_id = s.id WHERE a.user_id = ? LIMIT 1");
        $stmt->execute([$user_id]);
        $user_zone = $stmt->fetchColumn() ?: 'National';
    } else {
        $stmt = $db->prepare("SELECT s.zone FROM `user_leadership` ul JOIN `states` s ON ul.state_id = s.id WHERE ul.user_id = ? LIMIT 1");
        $stmt->execute([$user_id]);
        $user_zone = $stmt->fetchColumn();
        if (!$user_zone) {
            $stmt = $db->prepare("SELECT `zone` FROM `user_leadership` WHERE `user_id` = ? LIMIT 1");
            $stmt->execute([$user_id]);
            $user_zone = $stmt->fetchColumn() ?: 'National';
        }
    }
} catch (Exception $e) {
    $user_zone = 'National';
}

// Check user's KYC profile completed status & handle subsequent email reminders
$user_full = null;
$user_kyc = [];
$profile_completed = 1; 
try {
    $db = Database::connect();
    $stmt_u = $db->prepare("SELECT * FROM `users` WHERE `id` = ? LIMIT 1");
    $stmt_u->execute([$user_id]);
    $user_full = $stmt_u->fetch();
    if ($user_full) {
        $profile_completed = (int)$user_full['profile_completed'];
        
        // Fetch user kyc extended details
        $stmt_kyc = $db->prepare("SELECT * FROM `user_kyc_extended` WHERE `user_id` = ? LIMIT 1");
        $stmt_kyc->execute([$user_id]);
        $user_kyc = $stmt_kyc->fetch() ?: [];
        
        // Dispatch subsequent email reminder if KYC is incomplete
        if ($profile_completed === 0) {
            $time_diff = time() - strtotime($user_full['last_reminder_sent'] ?? '1970-01-01');
            // Remind every 10 minutes for testing outbox
            if (empty($user_full['last_reminder_sent']) || $time_diff > 600) {
                $subject = "Action Required: Complete Your Profile KYC - PBAT Smart Nation";
                $verify_link = "http://{$_SERVER['HTTP_HOST']}" . dirname($_SERVER['PHP_SELF']) . "/admin/dashboard.php?tab=profile";
                $msg_html = "
                <p>Dear <strong>" . htmlspecialchars($user_full['name']) . "</strong>,</p>
                <p>We noticed you have not completed your profile KYC compliance on the <strong>PBAT Smart Nation Initiative</strong> command portal.</p>
                <p>Please log in and submit the required additional information (including address, age, gender, occupation, and profile photo) to certify your credentials and unlock features like dynamic ID card generation and printing.</p>
                ";
                $html_reminder = getEmailTemplate(
                    "Profile KYC Required - PBAT Smart Nation",
                    "Profile KYC Compliance Notice",
                    "Complete Your Profile, " . htmlspecialchars($user_full['name']),
                    $msg_html,
                    $verify_link,
                    "Complete Profile Now"
                );
                sendMail($user_full['email'], $subject, $html_reminder);
                
                $db->prepare("UPDATE `users` SET `last_reminder_sent` = NOW() WHERE `id` = ?")->execute([$user_id]);
                $user_full['last_reminder_sent'] = date('Y-m-d H:i:s');
            }
        }
    }
} catch (Exception $e) {
    // Graceful fallback
}

// Universal POST controller (profile completion)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'complete_profile_kyc') {
    if (!Auth::validateCsrf($_POST['csrf_token'] ?? '')) {
        $_SESSION['auth_error'] = "Security verification expired. Try again.";
        header("Location: dashboard.php?tab=profile");
        exit;
    }
    try {
        $db = Database::connect();
        
        $save_mode = $_POST['save_mode'] ?? 'submit_kyc';
        $is_draft = ($save_mode === 'save_progress' || $save_mode === 'save_next');
        
        // 1. Extract and sanitize basic details for the users table
        $name = trim($_POST['name'] ?? '');
        $username_field = trim($_POST['username'] ?? '');
        $phone = trim($_POST['phone'] ?? '');
        $gender = trim($_POST['gender'] ?? '');
        $address = trim($_POST['address'] ?? '');
        
        $dob = !empty($_POST['dob']) ? $_POST['dob'] : null;
        $age = 0;
        if (!empty($dob)) {
            try {
                $dob_dt = new DateTime($dob);
                $now_dt = new DateTime();
                $age = $now_dt->diff($dob_dt)->y;
            } catch (Exception $e) {
                $age = 0;
            }
        }
        
        if (!$is_draft) {
            if (empty($name) || empty($phone) || empty($gender) || empty($address) || $age <= 0) {
                throw new Exception("All basic profile details (Name, Phone, Gender, Date of Birth, and Address) are required.");
            }
        }
        
        // Handle avatar upload
        $avatar_path = $user_full['avatar'] ?? 'assets/img/default-avatar.png';
        $upload_dir = dirname(__DIR__) . '/uploads/';
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0755, true);
        }
        
        if (isset($_FILES['profile_photo']) && $_FILES['profile_photo']['error'] === UPLOAD_ERR_OK) {
            $tmp_name = $_FILES['profile_photo']['tmp_name'];
            $file_name = time() . '_avatar_' . preg_replace('/[^a-zA-Z0-9.-]/', '_', basename($_FILES['profile_photo']['name']));
            if (move_uploaded_file($tmp_name, $upload_dir . $file_name)) {
                $avatar_path = 'uploads/' . $file_name;
            } else {
                if (!$is_draft) {
                    throw new Exception("Failed to save profile photo.");
                }
            }
        }
        
        // Generate membership code if not already assigned AND it is not a draft
        $membership_code = !empty($user_full['membership_code']) ? $user_full['membership_code'] : null;
        if (!$is_draft && empty($membership_code)) {
            $roles_prefix = [
                1 => 'ADM',
                2 => 'FND',
                3 => 'NSC',
                4 => 'ZON',
                5 => 'STA',
                6 => 'LGA',
                7 => 'AMB'
            ];
            $prefix = $roles_prefix[$user_full['role_id']] ?? 'MEM';
            $unique_hex = strtoupper(substr(md5($user_id . 'salt_pbat_nation'), 0, 6));
            $membership_code = 'SN-' . $prefix . '-' . $unique_hex . '-2026';
        }
        
        // Update main users table (set profile_completed to 1 ONLY if not a draft)
        $profile_completed_val = $is_draft ? 0 : 1;
        $stmt_up_user = $db->prepare("
            UPDATE `users` 
            SET `name` = ?, `phone` = ?, `gender` = ?, `address` = ?, `age` = ?, `avatar` = ?, `membership_code` = ?, `profile_completed` = ?
            WHERE `id` = ?
        ");
        $stmt_up_user->execute([$name, $phone, $gender, $address, $age, $avatar_path, $membership_code, $profile_completed_val, $user_id]);
        
        // 2. Fetch or create extended KYC record
        $stmt_check = $db->prepare("SELECT id FROM `user_kyc_extended` WHERE `user_id` = ? LIMIT 1");
        $stmt_check->execute([$user_id]);
        $has_kyc = $stmt_check->fetch();
        if (!$has_kyc) {
            $db->prepare("INSERT INTO `user_kyc_extended` (`user_id`, `kyc_status`) VALUES (?, ?)")->execute([$user_id, $is_draft ? 'draft' : 'pending_review']);
        }
        
        // Handle file uploads for KYC extended (selfie and bill removed)
        $kyc_uploads = [
            'government_id_path' => 'gov_id',
            'cv_path' => 'cv',
            'recommendation_letter_path' => 'rec_letter',
            'passport_photo_path' => 'passport_photo'
        ];
        
        $uploaded_paths = [];
        foreach ($kyc_uploads as $db_col => $file_key) {
            if (isset($_FILES[$file_key]) && $_FILES[$file_key]['error'] === UPLOAD_ERR_OK) {
                $tmp_name = $_FILES[$file_key]['tmp_name'];
                $ext = pathinfo($_FILES[$file_key]['name'], PATHINFO_EXTENSION);
                $file_name = time() . '_' . $file_key . '_' . $user_id . '.' . $ext;
                if (move_uploaded_file($tmp_name, $upload_dir . $file_name)) {
                    $uploaded_paths[$db_col] = 'uploads/' . $file_name;
                }
            }
        }

        // Handle webcam passport photo capture
        $passport_photo_camera = $_POST['passport_photo_camera'] ?? '';
        if (!empty($passport_photo_camera) && strpos($passport_photo_camera, 'data:image') === 0) {
            $data_pieces = explode(',', $passport_photo_camera);
            if (count($data_pieces) > 1) {
                $encoded_img = $data_pieces[1];
                $decoded_img = base64_decode($encoded_img);
                if ($decoded_img !== false) {
                    $file_name = time() . '_passport_camera_' . $user_id . '.jpg';
                    if (file_put_contents($upload_dir . $file_name, $decoded_img) !== false) {
                        $uploaded_paths['passport_photo_path'] = 'uploads/' . $file_name;
                    } else {
                        if (!$is_draft) {
                            throw new Exception("Failed to save captured passport photograph.");
                        }
                    }
                }
            }
        }
        
        // Serialize checkbox array categories
        $digital_skills = $_POST['skills'] ?? []; 
        $digital_skills_data = json_encode($digital_skills);
        
        $tech_interests = json_encode($_POST['tech_interests'] ?? []);
        $innovation_interests = json_encode($_POST['innovation_interests'] ?? []);
        $entrepreneurial_interests = json_encode($_POST['entrepreneurial_interests'] ?? []);
        $preferred_training_areas = json_encode($_POST['preferred_training_areas'] ?? []);
        $areas_of_interest = json_encode($_POST['areas_of_interest'] ?? []);
        $smart_nation_topics = json_encode($_POST['smart_nation_topics'] ?? []);
        
        // Collect text/date/numeric values
        $nationality = trim($_POST['nationality'] ?? 'Nigerian');
        $state_of_origin = trim($_POST['state_of_origin'] ?? '');
        $state_of_residence = trim($_POST['state_of_residence'] ?? '');
        
        $whatsapp_number = trim($_POST['whatsapp_number'] ?? '');
        $telegram_username = trim($_POST['telegram_username'] ?? '');
        $x_handle = trim($_POST['x_handle'] ?? '');
        $facebook_profile = trim($_POST['facebook_profile'] ?? '');
        $instagram_username = trim($_POST['instagram_username'] ?? '');
        $linkedin_profile = trim($_POST['linkedin_profile'] ?? '');
        
        $highest_qualification = trim($_POST['highest_qualification'] ?? '');
        $institution = trim($_POST['institution'] ?? '');
        $course_of_study = trim($_POST['course_of_study'] ?? '');
        $graduation_year = !empty($_POST['graduation_year']) ? (int)$_POST['graduation_year'] : null;
        $employer = trim($_POST['employer'] ?? '');
        $industry = trim($_POST['industry'] ?? '');
        $skills_expertise = trim($_POST['skills_expertise'] ?? '');
        
        $ai_knowledge_level = trim($_POST['ai_knowledge_level'] ?? '');
        
        $why_join = trim($_POST['why_join'] ?? '');
        $preferred_role = trim($_POST['preferred_role'] ?? '');
        $volunteer_availability = trim($_POST['volunteer_availability'] ?? '');
        $outreach_experience = trim($_POST['outreach_experience'] ?? '');
        $leadership_experience = trim($_POST['leadership_experience'] ?? '');
        $community_engagement = trim($_POST['community_engagement'] ?? '');
        
        $two_factor_enabled = isset($_POST['two_factor_enabled']) ? 1 : 0;
        $security_question = trim($_POST['security_question'] ?? '');
        $security_answer = trim($_POST['security_answer'] ?? '');
        
        $digital_signature = $_POST['digital_signature'] ?? '';
        $latitude = !empty($_POST['latitude']) ? (float)$_POST['latitude'] : null;
        $longitude = !empty($_POST['longitude']) ? (float)$_POST['longitude'] : null;
        $face_match_score = !empty($_POST['face_match_score']) ? (float)$_POST['face_match_score'] : null;
        
        // Construct extended update SQL (removing selfie_path, utility_bill_path, and optional ID columns)
        $kyc_sql = "
            UPDATE `user_kyc_extended` 
            SET `username` = ?, `dob` = ?, `nationality` = ?, `state_of_origin` = ?, `state_of_residence` = ?,
                `whatsapp_number` = ?, `telegram_username` = ?, `x_handle` = ?, `facebook_profile` = ?, `instagram_username` = ?, `linkedin_profile` = ?,
                `highest_qualification` = ?, `institution` = ?, `course_of_study` = ?, `graduation_year` = ?, `employer` = ?, `industry` = ?, `skills_expertise` = ?,
                `digital_skills_data` = ?, `tech_interests` = ?, `innovation_interests` = ?, `ai_knowledge_level` = ?, `entrepreneurial_interests` = ?, `preferred_training_areas` = ?,
                `why_join` = ?, `preferred_role` = ?, `areas_of_interest` = ?, `volunteer_availability` = ?, `outreach_experience` = ?, `leadership_experience` = ?, `community_engagement` = ?, `smart_nation_topics` = ?,
                `two_factor_enabled` = ?, `security_question` = ?
        ";
        $params = [
            $username_field ?: $user_full['email'], $dob, $nationality, $state_of_origin, $state_of_residence,
            $whatsapp_number, $telegram_username, $x_handle, $facebook_profile, $instagram_username, $linkedin_profile,
            $highest_qualification, $institution, $course_of_study, $graduation_year, $employer, $industry, $skills_expertise,
            $digital_skills_data, $tech_interests, $innovation_interests, $ai_knowledge_level, $entrepreneurial_interests, $preferred_training_areas,
            $why_join, $preferred_role, $areas_of_interest, $volunteer_availability, $outreach_experience, $leadership_experience, $community_engagement, $smart_nation_topics,
            $two_factor_enabled, $security_question
        ];
        
        if (!empty($security_answer)) {
            $kyc_sql .= ", `security_answer_hash` = ?";
            $params[] = password_hash($security_answer, PASSWORD_DEFAULT);
        }
        
        foreach ($uploaded_paths as $db_col => $path) {
            $kyc_sql .= ", `{$db_col}` = ?";
            $params[] = $path;
        }
        
        if (!empty($digital_signature)) {
            $kyc_sql .= ", `digital_signature` = ?";
            $params[] = $digital_signature;
        }
        
        if ($latitude !== null && $longitude !== null) {
            $kyc_sql .= ", `latitude` = ?, `longitude` = ?";
            $params[] = $latitude;
            $params[] = $longitude;
        }
        
        if ($face_match_score !== null) {
            $kyc_sql .= ", `face_match_score` = ?";
            $params[] = $face_match_score;
        }
        
        // Update kyc_status to 'draft' or 'pending_review'
        $kyc_status_val = $is_draft ? 'draft' : 'pending_review';
        $kyc_sql .= ", `kyc_status` = ?";
        $params[] = $kyc_status_val;
        
        $kyc_sql .= " WHERE `user_id` = ?";
        $params[] = $user_id;
        
        $stmt_up_kyc = $db->prepare($kyc_sql);
        $stmt_up_kyc->execute($params);
        
        if ($is_draft) {
            $_SESSION['success_msg'] = "Your KYC Profile progress has been successfully saved!";
            Auth::logAction($user_id, 'PROFILE_SAVE_KYC_DRAFT', "Saved KYC draft.");
            
            $target_step = isset($_POST['target_step']) ? (int)$_POST['target_step'] : 1;
            $redirect_step = ($save_mode === 'save_next') ? $target_step : max(1, $target_step - 1);
            
            header("Location: dashboard.php?tab=profile&step=" . $redirect_step);
            exit;
        } else {
            $_SESSION['success_msg'] = "Your multi-step KYC Profile has been successfully submitted! Membership Code: " . $membership_code;
            Auth::logAction($user_id, 'PROFILE_COMPLETE_KYC_EXTENDED', "Submitted extended KYC coordinates. Status: pending_review");
            
            header("Location: dashboard.php?tab=profile");
            exit;
        }
    } catch (Exception $e) {
        $_SESSION['auth_error'] = "Extended KYC Submission Failed: " . $e->getMessage();
        header("Location: dashboard.php?tab=profile");
        exit;
    }
}

// Universal Talent Pipeline & Volunteer POST controllers
if ($_SERVER['REQUEST_METHOD'] === 'POST' && (isset($_POST['action']) && ($_POST['action'] === 'submit_talent_pipeline' || $_POST['action'] === 'submit_volunteer_profile'))) {
    if (!Auth::validateCsrf($_POST['csrf_token'] ?? '')) {
        $_SESSION['auth_error'] = "Security verification expired. Try again.";
    } else {
        $action = $_POST['action'] ?? '';
        $redirect_tab = $_POST['redirect_tab'] ?? 'overview';
        try {
            $db = Database::connect();
            if ($action === 'submit_talent_pipeline') {
                $registration_type = trim($_POST['registration_type'] ?? 'register_self');
                $skill = trim($_POST['skill'] ?? '');
                $role_type = trim($_POST['role_type'] ?? 'trainee');
                $experience_years = (int)($_POST['experience_years'] ?? 0);
                $additional_notes = trim($_POST['additional_notes'] ?? '');
                
                $talent_name = null;
                $talent_email = null;
                $talent_phone = null;
                
                if ($registration_type === 'register_talent') {
                    $talent_name = trim($_POST['talent_name'] ?? '');
                    $talent_email = trim($_POST['talent_email'] ?? '');
                    $talent_phone = trim($_POST['talent_phone'] ?? '');
                    if (empty($talent_name) || empty($talent_email) || empty($talent_phone)) {
                        throw new Exception("Please provide the Talent's Name, Email, and Phone number.");
                    }
                }
                
                if (empty($skill)) {
                    throw new Exception("Please select a valid IT skill.");
                }
                
                $stmt = $db->prepare("INSERT INTO `talent_pipeline` (`user_id`, `registration_type`, `talent_name`, `talent_email`, `talent_phone`, `skill`, `role_type`, `experience_years`, `additional_notes`, `status`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending')");
                $stmt->execute([$user_id, $registration_type, $talent_name, $talent_email, $talent_phone, $skill, $role_type, $experience_years, $additional_notes]);
                
                $_SESSION['success_msg'] = "Your National Talent Pipeline registration has been successfully submitted!";
                Auth::logAction($user_id, 'TALENT_PIPELINE_SUBMIT', "Registered for Talent Pipeline: '{$skill}' as {$role_type} (Type: {$registration_type})");
                
                header("Location: dashboard.php?tab=" . urlencode($redirect_tab));
                exit;
            }
            
            elseif ($action === 'submit_volunteer_profile' && (Auth::hasRole('coordinator') || Auth::hasRole('ambassador'))) {
                $volunteer_areas = $_POST['volunteer_areas'] ?? [];
                $availability = trim($_POST['availability'] ?? '');
                $experience = trim($_POST['experience'] ?? '');
                
                if (empty($volunteer_areas)) {
                    throw new Exception("Please choose at least one volunteering area.");
                }
                
                $areas_json = json_encode($volunteer_areas);
                
                // Check existing enlistment
                $stmt_c = $db->prepare("SELECT id FROM `volunteers` WHERE `user_id` = ? LIMIT 1");
                $stmt_c->execute([$user_id]);
                if ($stmt_c->fetch()) {
                    $stmt_u = $db->prepare("UPDATE `volunteers` SET `volunteer_areas` = ?, `availability` = ?, `experience` = ?, `status` = 'pending' WHERE `user_id` = ?");
                    $stmt_u->execute([$areas_json, $availability, $experience, $user_id]);
                } else {
                    $stmt_i = $db->prepare("INSERT INTO `volunteers` (`user_id`, `volunteer_areas`, `availability`, `experience`, `status`) VALUES (?, ?, ?, ?, 'pending')");
                    $stmt_i->execute([$user_id, $areas_json, $availability, $experience]);
                }
                
                $_SESSION['success_msg'] = "Your volunteering and mobilization enlistment details have been updated!";
                Auth::logAction($user_id, 'VOLUNTEER_ENLIST_SUBMIT', "Submitted volunteer enlistment profile.");
                
                header("Location: dashboard.php?tab=" . urlencode($redirect_tab));
                exit;
            }
        } catch (Exception $e) {
            $_SESSION['auth_error'] = "Submission Action Failed: " . $e->getMessage();
            header("Location: dashboard.php?tab=" . urlencode($redirect_tab));
            exit;
        }
    }
}


// Founder's Circle POST Action Controllers
if ($_SERVER['REQUEST_METHOD'] === 'POST' && Auth::hasRole('founder_circle')) {
    if (!Auth::validateCsrf($_POST['csrf_token'] ?? '')) {
        $_SESSION['auth_error'] = "Security verification expired. Try again.";
    } else {
        $action = $_POST['action'] ?? '';
        $redirect_tab = $_POST['redirect_tab'] ?? 'overview';
        
        try {
            $db = Database::connect();
            
            if ($action === 'create_vision') {
                $title = trim($_POST['title']);
                $content = trim($_POST['content']);
                $category = trim($_POST['category']);
                
                $stmt = $db->prepare("INSERT INTO `founder_visions` (`title`, `content`, `category`, `created_by`) VALUES (?, ?, ?, ?)");
                $stmt->execute([$title, $content, $category, $user_id]);
                $_SESSION['success_msg'] = "Strategic vision statement published successfully!";
                Auth::logAction($user_id, 'FOUNDER_VISION_CREATE', "Published vision: '{$title}'");
            }
            
            elseif ($action === 'create_partnership') {
                $name = trim($_POST['name']);
                $type = trim($_POST['type']);
                $description = trim($_POST['description']);
                $contact_name = trim($_POST['contact_name']);
                $contact_email = trim($_POST['contact_email']);
                $sponsor_amount = (float)($_POST['sponsor_amount'] ?? 0);
                $status = trim($_POST['status'] ?? 'pending');
                
                $stmt = $db->prepare("INSERT INTO `founder_partnerships` (`name`, `type`, `description`, `contact_name`, `contact_email`, `sponsor_amount`, `status`) VALUES (?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([$name, $type, $description, $contact_name, $contact_email, $sponsor_amount, $status]);
                $_SESSION['success_msg'] = "Collaboration partner '{$name}' registered successfully!";
                Auth::logAction($user_id, 'FOUNDER_PARTNERSHIP_CREATE', "Registered partner: '{$name}'");
            }
            
            elseif ($action === 'create_thinktank') {
                $title = trim($_POST['title']);
                $content = trim($_POST['content']);
                $category = trim($_POST['category']);
                
                $stmt = $db->prepare("INSERT INTO `founder_thinktank` (`title`, `content`, `category`, `user_id`) VALUES (?, ?, ?, ?)");
                $stmt->execute([$title, $content, $category, $user_id]);
                $_SESSION['success_msg'] = "New Think-Tank topic submitted successfully!";
                Auth::logAction($user_id, 'FOUNDER_THINKTANK_CREATE', "Submitted think-tank idea: '{$title}'");
            }
            
            elseif ($action === 'create_award') {
                $recipient_id = (int)$_POST['recipient_id'];
                $award_title = trim($_POST['award_title']);
                $award_type = trim($_POST['award_type']);
                $description = trim($_POST['description']);
                
                $stmt = $db->prepare("INSERT INTO `founder_awards` (`recipient_id`, `award_title`, `award_type`, `description`, `granted_by`) VALUES (?, ?, ?, ?, ?)");
                $stmt->execute([$recipient_id, $award_title, $award_type, $description, $user_id]);
                $_SESSION['success_msg'] = "Leadership honor granted successfully!";
                Auth::logAction($user_id, 'FOUNDER_AWARD_CREATE', "Granted award '{$award_title}' to User ID {$recipient_id}");
            }
            
            elseif ($action === 'create_expansion') {
                $state_id = (int)$_POST['state_id'];
                $target_date = trim($_POST['target_date']);
                $regional_head_id = !empty($_POST['regional_head_id']) ? (int)$_POST['regional_head_id'] : null;
                $funding_allocated = (float)($_POST['funding_allocated'] ?? 0);
                
                $stmt = $db->prepare("INSERT INTO `founder_expansion` (`state_id`, `target_date`, `regional_head_id`, `funding_allocated`) VALUES (?, ?, ?, ?)");
                $stmt->execute([$state_id, $target_date, $regional_head_id, $funding_allocated]);
                $_SESSION['success_msg'] = "Future rollout plan registered successfully!";
                Auth::logAction($user_id, 'FOUNDER_EXPANSION_CREATE', "Scheduled rollout for State ID {$state_id}");
            }
            
            elseif ($action === 'create_note') {
                $title = trim($_POST['title']);
                $content = trim($_POST['content']);
                $is_confidential = isset($_POST['is_confidential']) ? 1 : 0;
                
                $stmt = $db->prepare("INSERT INTO `founder_notes` (`title`, `content`, `created_by`, `is_confidential`) VALUES (?, ?, ?, ?)");
                $stmt->execute([$title, $content, $user_id, $is_confidential]);
                $_SESSION['success_msg'] = "Confidential planning note saved!";
                Auth::logAction($user_id, 'FOUNDER_NOTE_CREATE', "Saved executive note: '{$title}'");
            }
            
            elseif ($action === 'create_broadcast') {
                $subject = trim($_POST['subject']);
                $body = trim($_POST['body']);
                $channel = trim($_POST['channel']);
                
                $stmt = $db->prepare("INSERT INTO `messages` (`sender_id`, `recipient_id`, `channel`, `subject`, `body`) VALUES (?, NULL, ?, ?, ?)");
                $stmt->execute([$user_id, $channel, $subject, $body]);
                
                $stmt_users = $db->query("SELECT email, name FROM `users` WHERE `status` = 'active'");
                $active_users = $stmt_users->fetchAll();
                
                $mail_subject = "Founder's Strategic Circular: " . $subject;
                $mail_body = getEmailTemplate($subject, "Strategic Executive Announcement", "Dear Ambassador / Leader,", "<p>" . nl2br(htmlspecialchars($body)) . "</p>", "admin/dashboard.php", "Enter Portal");
                
                foreach ($active_users as $recipient) {
                    sendMail($recipient['email'], $mail_subject, $mail_body);
                }
                
                $_SESSION['success_msg'] = "Executive broadcast dispatched successfully to all active ambassadors!";
                Auth::logAction($user_id, 'FOUNDER_BROADCAST', "Dispatched circular: '{$subject}'");
            }
            
            elseif ($action === 'founder_approve_campaign') {
                $camp_id = (int)$_POST['camp_id'];
                $status = trim($_POST['status']);
                
                $stmt = $db->prepare("UPDATE `campaigns` SET `status` = ? WHERE `id` = ?");
                $stmt->execute([$status, $camp_id]);
                $_SESSION['success_msg'] = "Campaign status transitioned to '{$status}'!";
                Auth::logAction($user_id, 'FOUNDER_CAMPAIGN_APPROVE', "Transformed campaign ID {$camp_id} status to {$status}");
            }
            
            elseif ($action === 'founder_create_campaign') {
                $title = trim($_POST['title']);
                $description = trim($_POST['description']);
                $category = trim($_POST['category']);
                $scheduled_at = trim($_POST['scheduled_at']);
                $leader_id = !empty($_POST['leader_id']) ? (int)$_POST['leader_id'] : null;
                $status = trim($_POST['status'] ?? 'draft');
                
                $stmt = $db->prepare("INSERT INTO `campaigns` (`title`, `description`, `category`, `scheduled_at`, `leader_id`, `created_by`, `status`) VALUES (?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([$title, $description, $category, $scheduled_at, $leader_id, $user_id, $status]);
                
                $new_id = $db->lastInsertId();
                $stmt_an = $db->prepare("INSERT INTO `campaign_analytics` (`campaign_id`, `reach_count`, `engagement_rate`) VALUES (?, 0, 0.0)");
                $stmt_an->execute([$new_id]);
                
                $_SESSION['success_msg'] = "Strategic campaign scheduled successfully!";
                Auth::logAction($user_id, 'FOUNDER_CAMPAIGN_CREATE', "Created campaign '{$title}'");
            }
            
            elseif ($action === 'founder_approve_leadership') {
                $leadership_id = (int)$_POST['leadership_id'];
                $status_act = trim($_POST['status_act']);
                
                $stmt = $db->prepare("UPDATE `users` SET `status` = ? WHERE `id` = ?");
                $stmt->execute([$status_act, $leadership_id]);
                $_SESSION['success_msg'] = "Leadership credentials updated to '{$status_act}'!";
                Auth::logAction($user_id, 'FOUNDER_LEADER_APPROVE', "Updated User ID {$leadership_id} status to {$status_act}");
            }
            
            elseif ($action === 'founder_schedule_townhall') {
                $title = trim($_POST['title']);
                $description = trim($_POST['description']);
                $event_date = trim($_POST['event_date']);
                $location = trim($_POST['location']);
                $event_type = trim($_POST['event_type']);
                $is_virtual = isset($_POST['is_virtual']) ? 1 : 0;
                $stream_url = trim($_POST['stream_url'] ?? '');
                
                $stmt = $db->prepare("INSERT INTO `events` (`title`, `description`, `event_date`, `location`, `event_type`, `is_virtual`, `stream_url`, `created_by`) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([$title, $description, $event_date, $location, $event_type, $is_virtual, $stream_url, $user_id]);
                $_SESSION['success_msg'] = "National Town Hall / Summit scheduled successfully!";
                Auth::logAction($user_id, 'FOUNDER_TOWNHALL_CREATE', "Scheduled Event: '{$title}'");
            }
            
        } catch (Exception $e) {
            $_SESSION['auth_error'] = "Action Execution Failed: " . $e->getMessage();
        }
        
        header("Location: dashboard.php?tab=" . urlencode($redirect_tab));
        exit;
    }
}

// National Steering Council POST Action Controllers
if ($_SERVER['REQUEST_METHOD'] === 'POST' && Auth::hasRole('national_steering')) {
    if (!Auth::validateCsrf($_POST['csrf_token'] ?? '')) {
        $_SESSION['auth_error'] = "Security verification expired. Try again.";
    } else {
        $action = $_POST['action'] ?? '';
        $redirect_tab = $_POST['redirect_tab'] ?? 'overview';
        
        try {
            $db = Database::connect();
            
            if ($action === 'nsc_create_campaign') {
                $title = trim($_POST['title']);
                $description = trim($_POST['description']);
                $category = trim($_POST['category']);
                $scheduled_at = trim($_POST['scheduled_at']);
                $leader_id = !empty($_POST['leader_id']) ? (int)$_POST['leader_id'] : null;
                $status = trim($_POST['status'] ?? 'draft');
                
                $stmt = $db->prepare("INSERT INTO `campaigns` (`title`, `description`, `category`, `scheduled_at`, `leader_id`, `created_by`, `status`) VALUES (?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([$title, $description, $category, $scheduled_at, $leader_id, $user_id, $status]);
                
                $new_id = $db->lastInsertId();
                $stmt_an = $db->prepare("INSERT INTO `campaign_analytics` (`campaign_id`, `reach_count`, `engagement_rate`) VALUES (?, 0, 0.0)");
                $stmt_an->execute([$new_id]);
                
                $_SESSION['success_msg'] = "National Campaign successfully created & catalogued!";
                Auth::logAction($user_id, 'NSC_CAMPAIGN_CREATE', "Created Campaign '{$title}'");
            }
            
            elseif ($action === 'nsc_create_event') {
                $title = trim($_POST['title']);
                $description = trim($_POST['description']);
                $event_date = trim($_POST['event_date']);
                $location = trim($_POST['location']);
                $event_type = trim($_POST['event_type']);
                $is_virtual = isset($_POST['is_virtual']) ? 1 : 0;
                $stream_url = trim($_POST['stream_url'] ?? '');
                
                $stmt = $db->prepare("INSERT INTO `events` (`title`, `description`, `event_date`, `location`, `event_type`, `is_virtual`, `stream_url`, `created_by`) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([$title, $description, $event_date, $location, $event_type, $is_virtual, $stream_url, $user_id]);
                
                $_SESSION['success_msg'] = "National event/webinar scheduled successfully!";
                Auth::logAction($user_id, 'NSC_EVENT_CREATE', "Created Event: '{$title}'");
            }
            
            elseif ($action === 'create_nsc_task') {
                $title = trim($_POST['title']);
                $description = trim($_POST['description']);
                $target_type = trim($_POST['target_type']);
                $target_name = trim($_POST['target_name']);
                $deadline = trim($_POST['deadline']);
                
                $stmt = $db->prepare("INSERT INTO `nsc_tasks` (`title`, `description`, `target_type`, `target_name`, `deadline`, `created_by`) VALUES (?, ?, ?, ?, ?, ?)");
                $stmt->execute([$title, $description, $target_type, $target_name, $deadline, $user_id]);
                
                $_SESSION['success_msg'] = "Operational target task successfully assigned to {$target_name}!";
                Auth::logAction($user_id, 'NSC_TASK_CREATE', "Created Task '{$title}' assigned to {$target_type} {$target_name}");
            }
            
            elseif ($action === 'create_nsc_poll') {
                $question = trim($_POST['question']);
                $options = array_filter(array_map('trim', $_POST['options'] ?? []));
                
                if (empty($question) || count($options) < 2) {
                    throw new Exception("Poll must contain a question and at least 2 options.");
                }
                
                $options_json = json_encode(array_values($options));
                $votes_json = json_encode(array_fill(0, count($options), 0));
                
                $stmt = $db->prepare("INSERT INTO `nsc_polls` (`question`, `options_json`, `votes_json`, `created_by`) VALUES (?, ?, ?, ?)");
                $stmt->execute([$question, $options_json, $votes_json, $user_id]);
                
                $_SESSION['success_msg'] = "Town Hall interactive poll launched successfully!";
                Auth::logAction($user_id, 'NSC_POLL_CREATE', "Created interactive poll: '{$question}'");
            }
            
            elseif ($action === 'update_report_status') {
                $report_id = (int)$_POST['report_id'];
                $status = trim($_POST['status']);
                
                $stmt = $db->prepare("UPDATE `reports` SET `status` = ? WHERE `id` = ?");
                $stmt->execute([$status, $report_id]);
                
                $_SESSION['success_msg'] = "State Activity Briefing status updated to '{$status}'!";
                Auth::logAction($user_id, 'NSC_REPORT_STATUS', "Updated Report ID {$report_id} status to {$status}");
            }
            
            elseif ($action === 'nsc_broadcast') {
                $subject = trim($_POST['subject']);
                $body = trim($_POST['body']);
                $channel = trim($_POST['channel']);
                
                $stmt = $db->prepare("INSERT INTO `messages` (`sender_id`, `recipient_id`, `channel`, `subject`, `body`) VALUES (?, NULL, ?, ?, ?)");
                $stmt->execute([$user_id, $channel, $subject, $body]);
                
                $stmt_users = $db->query("SELECT email, name FROM `users` WHERE `status` = 'active'");
                $active_users = $stmt_users->fetchAll();
                
                $mail_subject = "NSC Operational Circular: " . $subject;
                $mail_body = getEmailTemplate($subject, "National Steering Directorate", "Dear Coordinator / Ambassador,", "<p>" . nl2br(htmlspecialchars($body)) . "</p>", "admin/dashboard.php", "Enter Command Center");
                
                foreach ($active_users as $recipient) {
                    sendMail($recipient['email'], $mail_subject, $mail_body);
                }
                
                $_SESSION['success_msg'] = "National bulletin dispatched successfully to active leaders!";
                Auth::logAction($user_id, 'NSC_BROADCAST', "Dispatched operational circular: '{$subject}'");
            }
            
            elseif ($action === 'submit_poll_vote') {
                $poll_id = (int)$_POST['poll_id'];
                $option_index = (int)$_POST['option_index'];
                
                $stmt = $db->prepare("SELECT votes_json FROM `nsc_polls` WHERE `id` = ? LIMIT 1");
                $stmt->execute([$poll_id]);
                $votes_str = $stmt->fetchColumn();
                
                if ($votes_str) {
                    $votes = json_decode($votes_str, true);
                    if (isset($votes[$option_index])) {
                        $votes[$option_index]++;
                        $new_votes_json = json_encode($votes);
                        
                        $stmt_up = $db->prepare("UPDATE `nsc_polls` SET `votes_json` = ? WHERE `id` = ?");
                        $stmt_up->execute([$new_votes_json, $poll_id]);
                        
                        $_SESSION['success_msg'] = "Your interactive town hall vote was recorded!";
                    }
                }
            }
            
        } catch (Exception $e) {
            $_SESSION['auth_error'] = "Steering Command Action Failed: " . $e->getMessage();
        }
        
        header("Location: dashboard.php?tab=" . urlencode($redirect_tab));
        exit;
    }
}

// Zonal Chairman POST Action Controllers
if ($_SERVER['REQUEST_METHOD'] === 'POST' && Auth::hasRole('zonal_chairman')) {
    if (!Auth::validateCsrf($_POST['csrf_token'] ?? '')) {
        $_SESSION['auth_error'] = "Security verification expired. Try again.";
    } else {
        $action = $_POST['action'] ?? '';
        $redirect_tab = $_POST['redirect_tab'] ?? 'overview';
        
        try {
            $db = Database::connect();
            
            if ($action === 'create_zonal_campaign') {
                $title = trim($_POST['title']);
                $description = trim($_POST['description']);
                $category = trim($_POST['category']);
                $scheduled_at = trim($_POST['scheduled_at']);
                $leader_id = !empty($_POST['leader_id']) ? (int)$_POST['leader_id'] : null;
                $status = trim($_POST['status'] ?? 'draft');
                
                $stmt = $db->prepare("INSERT INTO `campaigns` (`title`, `description`, `category`, `scheduled_at`, `leader_id`, `created_by`, `status`) VALUES (?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([$title, $description, $category, $scheduled_at, $leader_id, $user_id, $status]);
                
                $new_id = $db->lastInsertId();
                $db->exec("INSERT INTO `campaign_analytics` (`campaign_id`, `reach_count`, `engagement_rate`) VALUES ({$new_id}, 0, 0.0)");
                
                $_SESSION['success_msg'] = "Regional campaign successfully created & catalogued!";
                Auth::logAction($user_id, 'ZONAL_CAMPAIGN_CREATE', "Created Campaign '{$title}'");
            }
            
            elseif ($action === 'create_zonal_event') {
                $title = trim($_POST['title']);
                $description = trim($_POST['description']);
                $event_date = trim($_POST['event_date']);
                $location = trim($_POST['location']);
                $event_type = trim($_POST['event_type']);
                $is_virtual = isset($_POST['is_virtual']) ? 1 : 0;
                $stream_url = trim($_POST['stream_url'] ?? '');
                
                $stmt = $db->prepare("INSERT INTO `events` (`title`, `description`, `event_date`, `location`, `event_type`, `is_virtual`, `stream_url`, `created_by`) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([$title, $description, $event_date, $location, $event_type, $is_virtual, $stream_url, $user_id]);
                
                $_SESSION['success_msg'] = "Regional town hall scheduled successfully!";
                Auth::logAction($user_id, 'ZONAL_EVENT_CREATE', "Created Event: '{$title}'");
            }
            
            elseif ($action === 'update_zonal_report_status') {
                $report_id = (int)$_POST['report_id'];
                $status = trim($_POST['status']);
                
                $stmt = $db->prepare("UPDATE `reports` SET `status` = ? WHERE `id` = ?");
                $stmt->execute([$status, $report_id]);
                
                $_SESSION['success_msg'] = "Report verification status updated to '{$status}'!";
                Auth::logAction($user_id, 'ZONAL_REPORT_STATUS', "Updated Report ID {$report_id} status to {$status}");
            }
            
            elseif ($action === 'zonal_broadcast') {
                $subject = trim($_POST['subject']);
                $body = trim($_POST['body']);
                $channel = trim($_POST['channel']);
                
                // Find all active users in states within the Zonal Chairman's zone
                $z_stmt = $db->prepare("SELECT s.zone FROM `user_leadership` ul JOIN `states` s ON ul.state_id = s.id WHERE ul.user_id = ? LIMIT 1");
                $z_stmt->execute([$user_id]);
                $user_zone = $z_stmt->fetchColumn() ?: 'National';
                
                $stmt = $db->prepare("INSERT INTO `messages` (`sender_id`, `recipient_id`, `channel`, `subject`, `body`) VALUES (?, NULL, ?, ?, ?)");
                $stmt->execute([$user_id, $channel, $subject, $body]);
                
                // Email active users in this zone
                $stmt_users = $db->prepare("
                    SELECT u.email, u.name 
                    FROM `users` u 
                    LEFT JOIN `ambassadors` a ON u.id = a.user_id 
                    LEFT JOIN `states` s1 ON a.state_id = s1.id
                    LEFT JOIN `user_leadership` ul ON u.id = ul.user_id
                    LEFT JOIN `states` s2 ON ul.state_id = s2.id
                    WHERE u.status = 'active' AND (s1.zone = ? OR s2.zone = ?)
                ");
                $stmt_users->execute([$user_zone, $user_zone]);
                $active_users = $stmt_users->fetchAll();
                
                $mail_subject = "Regional Zonal Directive: " . $subject;
                $mail_body = getEmailTemplate($subject, "Zonal Leadership Council ({$user_zone})", "Dear Zonal Leader / Ambassador,", "<p>" . nl2br(htmlspecialchars($body)) . "</p>", "admin/dashboard.php", "Enter Command Portal");
                
                foreach ($active_users as $recipient) {
                    sendMail($recipient['email'], $mail_subject, $mail_body);
                }
                
                $_SESSION['success_msg'] = "Regional directive dispatched successfully to all states in the zone!";
                Auth::logAction($user_id, 'ZONAL_BROADCAST', "Dispatched directive: '{$subject}' to {$user_zone}");
            }
            
        } catch (Exception $e) {
            $_SESSION['auth_error'] = "Zonal Action Failed: " . $e->getMessage();
        }
        
        header("Location: dashboard.php?tab=" . urlencode($redirect_tab));
        exit;
    }
}

// State Chairman POST Action Controllers
if ($_SERVER['REQUEST_METHOD'] === 'POST' && Auth::hasRole('state_chairman')) {
    if (!Auth::validateCsrf($_POST['csrf_token'] ?? '')) {
        $_SESSION['auth_error'] = "Security verification expired. Try again.";
    } else {
        $action = $_POST['action'] ?? '';
        $redirect_tab = $_POST['redirect_tab'] ?? 'overview';
        
        try {
            $db = Database::connect();
            
            if ($action === 'create_state_campaign') {
                $title = trim($_POST['title']);
                $description = trim($_POST['description']);
                $category = trim($_POST['category']);
                $scheduled_at = trim($_POST['scheduled_at']);
                $leader_id = !empty($_POST['leader_id']) ? (int)$_POST['leader_id'] : null;
                $status = trim($_POST['status'] ?? 'draft');
                
                $stmt = $db->prepare("INSERT INTO `campaigns` (`title`, `description`, `category`, `scheduled_at`, `leader_id`, `created_by`, `status`) VALUES (?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([$title, $description, $category, $scheduled_at, $leader_id, $user_id, $status]);
                
                $new_id = $db->lastInsertId();
                $db->exec("INSERT INTO `campaign_analytics` (`campaign_id`, `reach_count`, `engagement_rate`) VALUES ({$new_id}, 0, 0.0)");
                
                $_SESSION['success_msg'] = "State campaign successfully scheduled!";
                Auth::logAction($user_id, 'STATE_CAMPAIGN_CREATE', "Created Campaign '{$title}'");
            }
            
            elseif ($action === 'create_state_event') {
                $title = trim($_POST['title']);
                $description = trim($_POST['description']);
                $event_date = trim($_POST['event_date']);
                $location = trim($_POST['location']);
                $event_type = trim($_POST['event_type']);
                $is_virtual = isset($_POST['is_virtual']) ? 1 : 0;
                $stream_url = trim($_POST['stream_url'] ?? '');
                
                $stmt = $db->prepare("INSERT INTO `events` (`title`, `description`, `event_date`, `location`, `event_type`, `is_virtual`, `stream_url`, `created_by`) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([$title, $description, $event_date, $location, $event_type, $is_virtual, $stream_url, $user_id]);
                
                $_SESSION['success_msg'] = "State town hall organized successfully!";
                Auth::logAction($user_id, 'STATE_EVENT_CREATE', "Created Event: '{$title}'");
            }
            
            elseif ($action === 'update_state_report_status') {
                $report_id = (int)$_POST['report_id'];
                $status = trim($_POST['status']);
                
                $stmt = $db->prepare("UPDATE `reports` SET `status` = ? WHERE `id` = ?");
                $stmt->execute([$status, $report_id]);
                
                $_SESSION['success_msg'] = "Local report briefing status updated to '{$status}'!";
                Auth::logAction($user_id, 'STATE_REPORT_STATUS', "Updated Report ID {$report_id} status to {$status}");
            }
            
            elseif ($action === 'state_broadcast') {
                $subject = trim($_POST['subject']);
                $body = trim($_POST['body']);
                $channel = trim($_POST['channel']);
                
                // Fetch State Chairman's state ID
                $s_stmt = $db->prepare("SELECT state_id FROM `user_leadership` WHERE user_id = ? LIMIT 1");
                $s_stmt->execute([$user_id]);
                $state_id = $s_stmt->fetchColumn() ?: 1;
                
                $stmt = $db->prepare("INSERT INTO `messages` (`sender_id`, `recipient_id`, `channel`, `subject`, `body`) VALUES (?, NULL, ?, ?, ?)");
                $stmt->execute([$user_id, $channel, $subject, $body]);
                
                // Email active users in this state
                $stmt_users = $db->prepare("
                    SELECT u.email, u.name 
                    FROM `users` u 
                    LEFT JOIN `ambassadors` a ON u.id = a.user_id 
                    LEFT JOIN `user_leadership` ul ON u.id = ul.user_id
                    WHERE u.status = 'active' AND (a.state_id = ? OR ul.state_id = ?)
                ");
                $stmt_users->execute([$state_id, $state_id]);
                $active_users = $stmt_users->fetchAll();
                
                $mail_subject = "State Chapter Directive: " . $subject;
                $mail_body = getEmailTemplate($subject, "State Leadership Directorate", "Dear State Leader / Coordinator,", "<p>" . nl2br(htmlspecialchars($body)) . "</p>", "admin/dashboard.php", "Enter Command Portal");
                
                foreach ($active_users as $recipient) {
                    sendMail($recipient['email'], $mail_subject, $mail_body);
                }
                
                $_SESSION['success_msg'] = "State circular directive dispatched to local coordinators!";
                Auth::logAction($user_id, 'STATE_BROADCAST', "Dispatched directive '{$subject}' to State ID {$state_id}");
            }
            
        } catch (Exception $e) {
            $_SESSION['auth_error'] = "State Action Failed: " . $e->getMessage();
        }
        
        header("Location: dashboard.php?tab=" . urlencode($redirect_tab));
        exit;
    }
}

// LGA Coordinator POST Action Controllers
if ($_SERVER['REQUEST_METHOD'] === 'POST' && Auth::hasRole('coordinator')) {
    if (!Auth::validateCsrf($_POST['csrf_token'] ?? '')) {
        $_SESSION['auth_error'] = "Security verification expired. Try again.";
    } else {
        $action = $_POST['action'] ?? '';
        $redirect_tab = $_POST['redirect_tab'] ?? 'overview';
        
        try {
            $db = Database::connect();
            
            // Resolve LGA and State ID of coordinator
            $s_stmt = $db->prepare("SELECT state_id, lga_id FROM `user_leadership` WHERE user_id = ? LIMIT 1");
            $s_stmt->execute([$user_id]);
            $lead_info = $s_stmt->fetch();
            $state_id = $lead_info['state_id'] ?? 1;
            $lga_id = $lead_info['lga_id'] ?? 1;
            
            if ($action === 'register_lga_ambassador') {
                $name = trim($_POST['name']);
                $email = trim($_POST['email']);
                $phone = trim($_POST['phone'] ?? '');
                $password = trim($_POST['password'] ?? 'password123');
                
                if (empty($name) || empty($email)) {
                    throw new Exception("Ambassador name and email are required.");
                }
                
                // Create user
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                $stmt_u = $db->prepare("INSERT INTO `users` (`name`, `email`, `password`, `role_id`, `phone`, `status`) VALUES (?, ?, ?, 7, ?, 'active')");
                $stmt_u->execute([$name, $email, $hashed_password, $phone]);
                $new_user_id = $db->lastInsertId();
                
                // Create ambassador
                $uuid = bin2hex(random_bytes(16));
                $qr_hash = bin2hex(random_bytes(16));
                $stmt_a = $db->prepare("INSERT INTO `ambassadors` (`user_id`, `uuid`, `state_id`, `lga_id`, `impact_score`, `qr_code_hash`, `is_verified`, `verified_by`, `verified_at`) VALUES (?, ?, ?, ?, 10, ?, 1, ?, NOW())");
                $stmt_a->execute([$new_user_id, $uuid, $state_id, $lga_id, $qr_hash, $user_id]);
                
                // Create notification
                $stmt_n = $db->prepare("INSERT INTO `notifications` (`user_id`, `message`, `is_read`) VALUES (?, ?, 0)");
                $stmt_n->execute([$new_user_id, "Welcome to the PBAT Smart Nation. Your coordinator has registered and verified your profile."]);
                
                $_SESSION['success_msg'] = "Grassroots Ambassador '{$name}' registered and verified successfully!";
                Auth::logAction($user_id, 'COORDINATOR_AMBASSADOR_REGISTER', "Registered Ambassador '{$name}' (User ID: {$new_user_id})");
            }
            
            elseif ($action === 'create_lga_campaign') {
                $title = trim($_POST['title']);
                $description = trim($_POST['description']);
                $category = trim($_POST['category'] ?? 'General');
                $scheduled_at = trim($_POST['scheduled_at']);
                $status = trim($_POST['status'] ?? 'active');
                
                $stmt = $db->prepare("INSERT INTO `campaigns` (`title`, `description`, `category`, `scheduled_at`, `created_by`, `status`) VALUES (?, ?, ?, ?, ?, ?)");
                $stmt->execute([$title, $description, $category, $scheduled_at, $user_id, $status]);
                
                $new_id = $db->lastInsertId();
                $db->exec("INSERT INTO `campaign_analytics` (`campaign_id`, `reach_count`, `engagement_rate`) VALUES ({$new_id}, 0, 0.0)");
                
                $_SESSION['success_msg'] = "Community campaign successfully scheduled!";
                Auth::logAction($user_id, 'COORDINATOR_CAMPAIGN_CREATE', "Created Local Campaign '{$title}'");
            }
            
            elseif ($action === 'create_lga_event') {
                $title = trim($_POST['title']);
                $description = trim($_POST['description']);
                $event_date = trim($_POST['event_date']);
                $location = trim($_POST['location']);
                $event_type = trim($_POST['event_type'] ?? 'Community Town Hall');
                $is_virtual = isset($_POST['is_virtual']) ? 1 : 0;
                $stream_url = trim($_POST['stream_url'] ?? '');
                
                $stmt = $db->prepare("INSERT INTO `events` (`title`, `description`, `event_date`, `location`, `event_type`, `is_virtual`, `stream_url`, `created_by`) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([$title, $description, $event_date, $location, $event_type, $is_virtual, $stream_url, $user_id]);
                
                $_SESSION['success_msg'] = "Community town hall scheduled successfully!";
                Auth::logAction($user_id, 'COORDINATOR_EVENT_CREATE', "Created LGA Event: '{$title}'");
            }
            
            elseif ($action === 'submit_lga_report') {
                $title = trim($_POST['title']);
                $description = trim($_POST['description']);
                $category = trim($_POST['category'] ?? 'General');
                $media_path = '';
                
                // Handle file upload
                if (isset($_FILES['attachment_file']) && $_FILES['attachment_file']['error'] === UPLOAD_ERR_OK) {
                    $file = $_FILES['attachment_file'];
                    $file_name = basename($file['name']);
                    $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
                    $allowed = ['jpg', 'jpeg', 'png', 'pdf'];
                    
                    if (in_array($file_ext, $allowed) && $file['size'] < 5 * 1024 * 1024) {
                        $upload_dir = dirname(__DIR__) . '/uploads/';
                        if (!is_dir($upload_dir)) {
                            mkdir($upload_dir, 0755, true);
                        }
                        $new_name = 'REP-' . uniqid() . '.' . $file_ext;
                        if (move_uploaded_file($file['tmp_name'], $upload_dir . $new_name)) {
                            $media_path = 'uploads/' . $new_name;
                            
                            // Save to media_uploads
                            $stmt_media = $db->prepare("INSERT INTO `media_uploads` (`user_id`, `title`, `file_path`, `file_type`) VALUES (?, ?, ?, ?)");
                            $stmt_media->execute([$user_id, $file_name, $media_path, $file['type']]);
                        }
                    }
                }
                
                if (empty($title) || empty($description)) {
                    throw new Exception("Please provide all required briefing credentials.");
                }
                
                $stmt = $db->prepare("INSERT INTO `reports` (`user_id`, `title`, `description`, `file_path`, `state_id`, `status`) VALUES (?, ?, ?, ?, ?, 'submitted')");
                $stmt->execute([$user_id, $title, $description, $media_path, $state_id]);
                
                // Notify State Chairman for this state
                $stmt_leader = $db->prepare("SELECT u.name, u.email FROM users u JOIN user_leadership ul ON u.id = ul.user_id WHERE ul.state_id = ? AND u.role_id = 5 LIMIT 1");
                $stmt_leader->execute([$state_id]);
                $leader = $stmt_leader->fetch();
                
                $leader_email = $leader ? $leader['email'] : 'admin@pbat-smartnation.ng';
                $leader_name = $leader ? $leader['name'] : 'State Chapter Chairman';
                NotificationEmail::sendBriefingFiled($leader_email, $leader_name, $user['name'], $title);
                
                // Update stats
                $db->exec("UPDATE `analytics_summary` SET `reports_filed` = `reports_filed` + 1 WHERE `state_id` = {$state_id}");
                
                $_SESSION['success_msg'] = "LGA activity report successfully submitted to State Chapter Chairman!";
                Auth::logAction($user_id, 'COORDINATOR_REPORT_SUBMIT', "Submitted local briefing: '{$title}'");
            }
            
            elseif ($action === 'lga_broadcast') {
                $subject = trim($_POST['subject']);
                $body = trim($_POST['body']);
                $channel = trim($_POST['channel'] ?? 'local');
                
                $stmt = $db->prepare("INSERT INTO `messages` (`sender_id`, `recipient_id`, `channel`, `subject`, `body`) VALUES (?, NULL, ?, ?, ?)");
                $stmt->execute([$user_id, $channel, $subject, $body]);
                
                // Fetch active ambassadors in this LGA
                $stmt_users = $db->prepare("
                    SELECT u.email, u.name 
                    FROM `users` u 
                    JOIN `ambassadors` a ON u.id = a.user_id 
                    WHERE u.status = 'active' AND a.lga_id = ?
                ");
                $stmt_users->execute([$lga_id]);
                $active_users = $stmt_users->fetchAll();
                
                $mail_subject = "LGA Chapter Bulletin: " . $subject;
                $mail_body = getEmailTemplate($subject, "Local Government Directorate", "Dear Grassroots Ambassador,", "<p>" . nl2br(htmlspecialchars($body)) . "</p>", "admin/dashboard.php", "Enter Ambassador Portal");
                
                foreach ($active_users as $recipient) {
                    sendMail($recipient['email'], $mail_subject, $mail_body);
                }
                
                $_SESSION['success_msg'] = "LGA broadcast successfully dispatched to all active ward ambassadors!";
                Auth::logAction($user_id, 'COORDINATOR_BROADCAST', "Dispatched local circular: '{$subject}' to LGA ID {$lga_id}");
            }
            
        } catch (Exception $e) {
            $_SESSION['auth_error'] = "LGA Coordinator Action Failed: " . $e->getMessage();
        }
        
        header("Location: dashboard.php?tab=" . urlencode($redirect_tab));
        exit;
    }
}

// Grassroots Ambassador POST Action Controllers
if ($_SERVER['REQUEST_METHOD'] === 'POST' && Auth::hasRole('ambassador')) {
    if (!Auth::validateCsrf($_POST['csrf_token'] ?? '')) {
        $_SESSION['auth_error'] = "Security verification expired. Try again.";
    } else {
        $action = $_POST['action'] ?? '';
        $redirect_tab = $_POST['redirect_tab'] ?? 'overview';
        
        try {
            $db = Database::connect();
            
            // Resolve Ambassador state and LGA ID coordinates
            $s_stmt = $db->prepare("SELECT state_id, lga_id, impact_score FROM `ambassadors` WHERE user_id = ? LIMIT 1");
            $s_stmt->execute([$user_id]);
            $amb_info = $s_stmt->fetch();
            $state_id = $amb_info['state_id'] ?? 1;
            $lga_id = $amb_info['lga_id'] ?? 1;
            $current_score = $amb_info['impact_score'] ?? 10;
            
            if ($action === 'submit_ambassador_report') {
                $title = trim($_POST['title']);
                $description = trim($_POST['description']);
                $category = trim($_POST['category'] ?? 'Field Outreach');
                $media_path = '';
                
                // Handle file upload
                if (isset($_FILES['attachment_file']) && $_FILES['attachment_file']['error'] === UPLOAD_ERR_OK) {
                    $file = $_FILES['attachment_file'];
                    $file_name = basename($file['name']);
                    $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
                    $allowed = ['jpg', 'jpeg', 'png', 'pdf'];
                    
                    if (in_array($file_ext, $allowed) && $file['size'] < 5 * 1024 * 1024) {
                        $upload_dir = dirname(__DIR__) . '/uploads/';
                        if (!is_dir($upload_dir)) {
                            mkdir($upload_dir, 0755, true);
                        }
                        $new_name = 'REP-' . uniqid() . '.' . $file_ext;
                        if (move_uploaded_file($file['tmp_name'], $upload_dir . $new_name)) {
                            $media_path = 'uploads/' . $new_name;
                            
                            // Save to media_uploads
                            $stmt_media = $db->prepare("INSERT INTO `media_uploads` (`user_id`, `title`, `file_path`, `file_type`) VALUES (?, ?, ?, ?)");
                            $stmt_media->execute([$user_id, $file_name, $media_path, $file['type']]);
                        }
                    }
                }
                
                if (empty($title) || empty($description)) {
                    throw new Exception("Please provide all required briefing credentials.");
                }
                
                $stmt = $db->prepare("INSERT INTO `reports` (`user_id`, `title`, `description`, `file_path`, `state_id`, `status`) VALUES (?, ?, ?, ?, ?, 'submitted')");
                $stmt->execute([$user_id, $title, $description, $media_path, $state_id]);
                
                // Increment ambassador impact score (+15 points for submitting field report!)
                $db->prepare("UPDATE `ambassadors` SET `impact_score` = `impact_score` + 15 WHERE user_id = ?")->execute([$user_id]);
                
                // Update analytics stats
                $db->exec("UPDATE `analytics_summary` SET `reports_filed` = `reports_filed` + 1 WHERE `state_id` = {$state_id}");
                
                $_SESSION['success_msg'] = "Field sensitization brief successfully filed! You earned +15 Impact Points!";
                Auth::logAction($user_id, 'AMBASSADOR_REPORT_SUBMIT', "Ambassador submitted briefing: '{$title}' and earned +15 points");
            }
            
            elseif ($action === 'ambassador_vote') {
                $poll_id = (int)$_POST['poll_id'];
                $option_index = (int)$_POST['option_index'];
                
                $stmt = $db->prepare("SELECT votes_json FROM `nsc_polls` WHERE id = ? LIMIT 1");
                $stmt->execute([$poll_id]);
                $votes_str = $stmt->fetchColumn();
                
                if ($votes_str) {
                    $votes = json_decode($votes_str, true);
                    if (isset($votes[$option_index])) {
                        $votes[$option_index]++;
                        $new_votes_json = json_encode($votes);
                        
                        $stmt_up = $db->prepare("UPDATE `nsc_polls` SET `votes_json` = ? WHERE `id` = ?");
                        $stmt_up->execute([$new_votes_json, $poll_id]);
                        
                        // Increment ambassador impact score (+5 points for civic voting)
                        $db->prepare("UPDATE `ambassadors` SET `impact_score` = `impact_score` + 5 WHERE user_id = ?")->execute([$user_id]);
                        
                        $_SESSION['success_msg'] = "Your civic opinion vote was successfully logged! You earned +5 Impact Points!";
                        Auth::logAction($user_id, 'AMBASSADOR_POLL_VOTE', "Ambassador voted on Poll ID {$poll_id}");
                    }
                }
            }
            
            elseif ($action === 'ambassador_rsvp') {
                $event_id = (int)$_POST['event_id'];
                
                // Insert into event_registrants to sync with admin dashboard
                try {
                    $stmt_ins = $db->prepare("INSERT IGNORE INTO `event_registrants` (`event_id`, `user_id`) VALUES (?, ?)");
                    $stmt_ins->execute([$event_id, $user_id]);
                } catch (Exception $e) {
                    // Safe catch if duplicate or column error
                }
                
                // Increment score (+10 points for RSVP)
                $db->prepare("UPDATE `ambassadors` SET `impact_score` = `impact_score` + 10 WHERE user_id = ?")->execute([$user_id]);
                
                $_SESSION['success_msg'] = "You have successfully registered for this event! You earned +10 Impact Points!";
                Auth::logAction($user_id, 'AMBASSADOR_EVENT_RSVP', "Ambassador RSVPed to Event ID {$event_id}");
            }
            
            elseif ($action === 'submit_networking_post') {
                $message = trim($_POST['message']);
                
                if (empty($message)) {
                    throw new Exception("Message cannot be empty.");
                }
                
                // Increment score (+5 points for team contribution)
                $db->prepare("UPDATE `ambassadors` SET `impact_score` = `impact_score` + 5 WHERE user_id = ?")->execute([$user_id]);
                
                $_SESSION['success_msg'] = "Your idea / team check-in post was shared! You earned +5 Impact Points!";
                Auth::logAction($user_id, 'AMBASSADOR_NETWORKING_POST', "Ambassador shared a team networking post");
            }
            
            elseif ($action === 'claim_mission_reward') {
                $points = (int)($_POST['points'] ?? 10);
                $mission_name = trim($_POST['mission_name'] ?? 'Mission Complete');
                
                // Increment score
                $db->prepare("UPDATE `ambassadors` SET `impact_score` = `impact_score` + ? WHERE user_id = ?")->execute([$points, $user_id]);
                
                $_SESSION['success_msg'] = "Mission '{$mission_name}' claimed! You earned +{$points} Impact Points!";
                Auth::logAction($user_id, 'AMBASSADOR_MISSION_CLAIM', "Ambassador claimed mission reward: '{$mission_name}' (+{$points} pts)");
            }
            
        } catch (Exception $e) {
            $_SESSION['auth_error'] = "Ambassador Action Failed: " . $e->getMessage();
        }
        
        header("Location: dashboard.php?tab=" . urlencode($redirect_tab));
        exit;
    }
}



// Default variables for analytics across all dashboards
$recent_reports = [];
$notifications = [];
$state_data = [];

try {
    $db = Database::connect();

    // 1. Fetch analytical stats per state
    $stmt = $db->query("SELECT s.name, a.ambassador_count, a.events_count, a.reports_filed FROM `analytics_summary` a JOIN `states` s ON a.state_id = s.id ORDER BY a.ambassador_count DESC");
    $state_data = $stmt->fetchAll();

    // 2. Fetch recent submitted reports
    $stmt = $db->query("SELECT r.*, u.name as author_name, s.name as state_name FROM `reports` r JOIN `users` u ON r.user_id = u.id JOIN `states` s ON r.state_id = s.id ORDER BY r.created_at DESC LIMIT 5");
    $recent_reports = $stmt->fetchAll();

    // 3. Fetch notifications
    $stmt = $db->prepare("SELECT * FROM `notifications` WHERE `user_id` = ? ORDER BY `created_at` DESC LIMIT 4");
    $stmt->execute([$user_id]);
    $notifications = $stmt->fetchAll();

} catch (Exception $e) {
    $state_data = [
        ['name' => 'Lagos', 'ambassador_count' => 480, 'events_count' => 14, 'reports_filed' => 38],
        ['name' => 'Federal Capital Territory', 'ambassador_count' => 220, 'events_count' => 8, 'reports_filed' => 19],
        ['name' => 'Rivers', 'ambassador_count' => 310, 'events_count' => 11, 'reports_filed' => 25],
        ['name' => 'Kano', 'ambassador_count' => 390, 'events_count' => 6, 'reports_filed' => 31],
        ['name' => 'Enugu', 'ambassador_count' => 140, 'events_count' => 4, 'reports_filed' => 12],
        ['name' => 'Borno', 'ambassador_count' => 85, 'events_count' => 2, 'reports_filed' => 7],
        ['name' => 'Abia', 'ambassador_count' => 95, 'events_count' => 3, 'reports_filed' => 8],
        ['name' => 'Adamawa', 'ambassador_count' => 70, 'events_count' => 2, 'reports_filed' => 5],
        ['name' => 'Akwa Ibom', 'ambassador_count' => 150, 'events_count' => 5, 'reports_filed' => 11],
        ['name' => 'Anambra', 'ambassador_count' => 130, 'events_count' => 4, 'reports_filed' => 10],
        ['name' => 'Bauchi', 'ambassador_count' => 80, 'events_count' => 2, 'reports_filed' => 6],
        ['name' => 'Bayelsa', 'ambassador_count' => 65, 'events_count' => 1, 'reports_filed' => 4],
        ['name' => 'Benue', 'ambassador_count' => 90, 'events_count' => 3, 'reports_filed' => 7],
        ['name' => 'Cross River', 'ambassador_count' => 110, 'events_count' => 3, 'reports_filed' => 9],
        ['name' => 'Delta', 'ambassador_count' => 145, 'events_count' => 5, 'reports_filed' => 12],
        ['name' => 'Ebonyi', 'ambassador_count' => 60, 'events_count' => 1, 'reports_filed' => 3],
        ['name' => 'Edo', 'ambassador_count' => 125, 'events_count' => 4, 'reports_filed' => 8],
        ['name' => 'Ekiti', 'ambassador_count' => 75, 'events_count' => 2, 'reports_filed' => 5],
        ['name' => 'Gombe', 'ambassador_count' => 55, 'events_count' => 1, 'reports_filed' => 3],
        ['name' => 'Imo', 'ambassador_count' => 115, 'events_count' => 3, 'reports_filed' => 8],
        ['name' => 'Jigawa', 'ambassador_count' => 68, 'events_count' => 2, 'reports_filed' => 4],
        ['name' => 'Kaduna', 'ambassador_count' => 180, 'events_count' => 6, 'reports_filed' => 15],
        ['name' => 'Katsina', 'ambassador_count' => 95, 'events_count' => 3, 'reports_filed' => 7],
        ['name' => 'Kebbi', 'ambassador_count' => 72, 'events_count' => 2, 'reports_filed' => 5],
        ['name' => 'Kogi', 'ambassador_count' => 88, 'events_count' => 3, 'reports_filed' => 6],
        ['name' => 'Kwara', 'ambassador_count' => 92, 'events_count' => 3, 'reports_filed' => 7],
        ['name' => 'Nasarawa', 'ambassador_count' => 84, 'events_count' => 2, 'reports_filed' => 6],
        ['name' => 'Niger', 'ambassador_count' => 102, 'events_count' => 3, 'reports_filed' => 8],
        ['name' => 'Ogun', 'ambassador_count' => 160, 'events_count' => 5, 'reports_filed' => 13],
        ['name' => 'Ondo', 'ambassador_count' => 110, 'events_count' => 3, 'reports_filed' => 9],
        ['name' => 'Osun', 'ambassador_count' => 105, 'events_count' => 3, 'reports_filed' => 8],
        ['name' => 'Oyo', 'ambassador_count' => 175, 'events_count' => 6, 'reports_filed' => 14],
        ['name' => 'Plateau', 'ambassador_count' => 98, 'events_count' => 3, 'reports_filed' => 7],
        ['name' => 'Sokoto', 'ambassador_count' => 82, 'events_count' => 2, 'reports_filed' => 5],
        ['name' => 'Taraba', 'ambassador_count' => 62, 'events_count' => 1, 'reports_filed' => 4],
        ['name' => 'Yobe', 'ambassador_count' => 58, 'events_count' => 1, 'reports_filed' => 3],
        ['name' => 'Zamfara', 'ambassador_count' => 78, 'events_count' => 2, 'reports_filed' => 5]
    ];


    $recent_reports = [
        ['title' => 'LGA Digital Inclusion Progress', 'author_name' => 'Tunde Coker', 'state_name' => 'Lagos', 'status' => 'approved', 'created_at' => '2026-06-01'],
        ['title' => 'Municipal Broadband Advocacy Seminar', 'author_name' => 'Amara Eke', 'state_name' => 'Lagos', 'status' => 'submitted', 'created_at' => '2026-06-02']
    ];

    $notifications = [
        ['message' => 'Your grassroots representative credentials have been successfully certified.', 'is_read' => 0, 'created_at' => '2026-06-02 10:00:00'],
        ['message' => 'New policy draft from National Council is available for review.', 'is_read' => 1, 'created_at' => '2026-06-01 14:30:00']
    ];
}

$total_ambassadors = array_sum(array_column($state_data, 'ambassador_count'));
$total_reports = array_sum(array_column($state_data, 'reports_filed'));
$total_events = array_sum(array_column($state_data, 'events_count'));

// Define dynamic layout swapper mapping
$role_templates = [
    'super_admin'       => 'admin.php',
    'founder_circle'    => 'founder.php',
    'national_steering' => 'nsc.php',
    'zonal_chairman'    => 'zonal.php',
    'state_chairman'    => 'state.php',
    'coordinator'       => 'coordinator.php',
    'ambassador'        => 'ambassador.php'
];

$sub_dashboard = $role_templates[$role] ?? 'ambassador.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Universal Leadership Portal - PBAT Smart Nation</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        bushgreen: {
                            DEFAULT: '#063C1E',
                            light: '#0A4D27',
                            dark: '#03200F',
                        },
                        gold: '#D4AF37'
                    }
                }
            }
        }
    </script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body { font-family: 'Inter', sans-serif; }
        h1, h2, h3, h4, .font-display { font-family: 'Outfit', sans-serif; }
    </style>
</head>
<body class="min-h-screen flex flex-col antialiased transition-colors duration-200" 
      x-data="{ sidebarOpen: false, darkMode: localStorage.getItem('darkMode') === 'true' }" 
      x-init="$watch('darkMode', val => localStorage.setItem('darkMode', val))"
      :class="{ 'dark bg-slate-900 text-slate-100': darkMode, 'bg-slate-50 text-slate-800': !darkMode }">

    <!-- Header bar -->
    <header class="bg-bushgreen text-white border-b-2 border-gold h-20 flex items-center justify-between px-6 shadow-md relative z-30">
        <div class="flex items-center gap-3">
            <button @click="sidebarOpen = !sidebarOpen" class="lg:hidden text-white focus:outline-none">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"/></svg>
            </button>
            <a href="../index.php" class="flex items-center gap-2.5 group">
                <div class="w-8 h-8 rounded bg-white/10 flex items-center justify-center border border-white/20 p-1 flex-shrink-0">
                    <?php echo getAppLogoHtml('w-full h-full object-contain', 'dashboard'); ?>
                </div>
                <div class="flex flex-col">
                    <span class="text-white font-extrabold text-sm tracking-tight font-display leading-none">PBAT SMART NATION</span>
                    <span class="text-gold font-bold text-[8px] tracking-widest leading-none uppercase mt-0.5">Portal</span>
                </div>
            </a>
        </div>
        
        <div class="flex items-center gap-4">
            <!-- Dark Mode Toggle -->
            <button @click="darkMode = !darkMode" class="p-2 rounded-lg border border-gold/45 text-gold hover:bg-gold/10 transition flex items-center justify-center">
                <!-- Sun Icon -->
                <svg x-show="darkMode" class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364-6.364l-.707.707M6.364 17.636l-.707.707M18.364 17.636l-.707-.707M6.364 6.364l-.707-.707M15 12a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                <!-- Moon Icon -->
                <svg x-show="!darkMode" class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z"/></svg>
            </button>

            <div class="text-right hidden sm:block">
                <div class="text-xs font-bold text-white"><?php echo htmlspecialchars($user['name']); ?></div>
                <div class="text-[9px] font-bold text-gold uppercase tracking-widest mt-0.5"><?php echo str_replace('_', ' ', $role); ?> &bull; <?php echo htmlspecialchars($user_zone); ?></div>
            </div>
            <a href="../logout.php" class="py-1.5 px-3 border border-gold/40 hover:bg-gold hover:text-bushgreen text-gold rounded-lg text-[10px] font-bold tracking-wide transition-all uppercase">
                Logout
            </a>
        </div>
    </header>

    <div class="flex flex-1 relative overflow-hidden">
        
        <!-- Sidebar -->
        <aside :class="sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'"
               class="w-64 bg-bushgreen-dark text-slate-300 flex flex-col border-r border-white/5 absolute lg:relative z-20 top-0 bottom-0 transition-transform duration-300 ease-in-out">
            <div class="p-6 border-b border-white/5 bg-bushgreen flex-shrink-0 flex items-center gap-2">
                <div class="w-7 h-7 rounded bg-white/10 flex items-center justify-center border border-white/20 p-1 flex-shrink-0">
                    <?php echo getAppLogoHtml('w-full h-full object-contain', 'dashboard'); ?>
                </div>
                <span class="text-gold font-bold text-[10px] uppercase tracking-widest leading-none">Admin Command</span>
            </div>
            
            <nav class="flex-grow p-4 space-y-1.5 overflow-y-auto max-h-[calc(100vh-10rem)]">
                <a href="dashboard.php" class="bg-white/5 text-white flex items-center gap-3 px-4 py-2 rounded-lg text-xs font-bold font-display border-l-4 border-gold">
                    <svg class="w-4 h-4 text-gold" fill="currentColor" viewBox="0 0 20 20"><path d="M10.707 2.293a1 1 0 00-1.414 0l-7 7a1 1 0 001.414 1.414L4 10.414V17a1 1 0 001 1h2a1 1 0 001-1v-2a1 1 0 011-1h2a1 1 0 011 1v2a1 1 0 001 1h2a1 1 0 001-1v-6.586l.293.293a1 1 0 001.414-1.414l-7-7z"/></svg>
                    Dashboard Home
                </a>
                
                <?php if (Auth::hasRole('super_admin')): ?>
                    <div class="px-4 pt-3 pb-1 text-[9px] font-bold text-gold uppercase tracking-wider">Super Control</div>
                    <a href="command-center.php" class="hover:bg-white/5 hover:text-white flex items-center gap-3 px-4 py-2 rounded-lg text-xs font-medium transition text-slate-300">
                        <span class="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span> Live Command Center
                    </a>
                    <a href="users.php" class="hover:bg-white/5 hover:text-white flex items-center gap-3 px-4 py-2 rounded-lg text-xs font-medium transition text-slate-300">
                        User Management
                    </a>
                    <a href="roles.php" class="hover:bg-white/5 hover:text-white flex items-center gap-3 px-4 py-2 rounded-lg text-xs font-medium transition text-slate-300">
                        RBAC Matrix Editor
                    </a>
                    <a href="leadership.php" class="hover:bg-white/5 hover:text-white flex items-center gap-3 px-4 py-2 rounded-lg text-xs font-medium transition text-slate-300">
                        Leadership Hierarchy
                    </a>
                    <a href="regions.php" class="hover:bg-white/5 hover:text-white flex items-center gap-3 px-4 py-2 rounded-lg text-xs font-medium transition text-slate-300">
                        State & Zonal Hub
                    </a>
                    
                    <div class="px-4 pt-3 pb-1 text-[9px] font-bold text-gold uppercase tracking-wider">Core Systems</div>
                    <a href="campaigns.php" class="hover:bg-white/5 hover:text-white flex items-center gap-3 px-4 py-2 rounded-lg text-xs font-medium transition text-slate-300">
                        Campaign Management
                    </a>
                    <a href="events.php" class="hover:bg-white/5 hover:text-white flex items-center gap-3 px-4 py-2 rounded-lg text-xs font-medium transition text-slate-300">
                        Upcoming Town Halls & Conferences
                    </a>
                    <a href="tv.php" class="hover:bg-white/5 hover:text-white flex items-center gap-3 px-4 py-2 rounded-lg text-xs font-medium transition text-slate-300">
                        TV Manager & Footer TV
                    </a>
                    <a href="talent-pipeline.php" class="hover:bg-white/5 hover:text-white flex items-center gap-3 px-4 py-2 rounded-lg text-xs font-medium transition text-slate-300">
                        🚀 Talent Pipeline Moderation
                    </a>
                    <a href="dashboard.php?tab=talent_pipeline" class="hover:bg-white/5 hover:text-white flex items-center gap-3 px-4 py-2 rounded-lg text-xs font-medium transition text-slate-300">
                        🚀 My Talent Pipeline
                    </a>
                    <a href="sponsors-feedback.php" class="hover:bg-white/5 hover:text-white flex items-center gap-3 px-4 py-2 rounded-lg text-xs font-medium transition text-slate-300">
                        🤝 Sponsors & Feedback
                    </a>
                    <a href="cms.php" class="hover:bg-white/5 hover:text-white flex items-center gap-3 px-4 py-2 rounded-lg text-xs font-medium transition text-slate-300">
                        CMS Landing Editor
                    </a>
                    <a href="reports.php" class="hover:bg-white/5 hover:text-white flex items-center gap-3 px-4 py-2 rounded-lg text-xs font-medium transition text-slate-300">
                        Smart Reporting Center
                    </a>
                    <a href="analytics.php" class="hover:bg-white/5 hover:text-white flex items-center gap-3 px-4 py-2 rounded-lg text-xs font-medium transition text-slate-300">
                        National Analytics
                    </a>
                    
                    <div class="px-4 pt-3 pb-1 text-[9px] font-bold text-gold uppercase tracking-wider">Advocacy Tools</div>
                    <a href="id-card.php" class="hover:bg-white/5 hover:text-white flex items-center gap-3 px-4 py-2 rounded-lg text-xs font-medium transition text-slate-300">
                        📇 My ID Badge
                    </a>
                    <a href="id-cards-directory.php" class="hover:bg-white/5 hover:text-white flex items-center gap-3 px-4 py-2 rounded-lg text-xs font-medium transition text-slate-300">
                        ID Cards Directory
                    </a>
                    <a href="verify-qr.php" class="hover:bg-white/5 hover:text-white flex items-center gap-3 px-4 py-2 rounded-lg text-xs font-medium transition text-slate-300">
                        QR Verification Gate
                    </a>
                    <a href="notifications.php" class="hover:bg-white/5 hover:text-white flex items-center gap-3 px-4 py-2 rounded-lg text-xs font-medium transition text-slate-300">
                        Notification Outbox
                    </a>
                    <a href="communications.php" class="hover:bg-white/5 hover:text-white flex items-center gap-3 px-4 py-2 rounded-lg text-xs font-medium transition text-slate-300">
                        Communications Hub
                    </a>
                    <a href="media.php" class="hover:bg-white/5 hover:text-white flex items-center gap-3 px-4 py-2 rounded-lg text-xs font-medium transition text-slate-300">
                        Media Library
                    </a>
                    
                    <div class="px-4 pt-3 pb-1 text-[9px] font-bold text-gold uppercase tracking-wider">Control & Security</div>
                    <a href="audit-logs.php" class="hover:bg-white/5 hover:text-white flex items-center gap-3 px-4 py-2 rounded-lg text-xs font-medium transition text-slate-300">
                        Security Audit Logs
                    </a>
                    <a href="settings.php" class="hover:bg-white/5 hover:text-white flex items-center gap-3 px-4 py-2 rounded-lg text-xs font-medium transition text-slate-300">
                        Website Settings Panel
                    </a>
                    <a href="ai-insights.php" class="hover:bg-white/5 hover:text-white flex items-center gap-3 px-4 py-2 rounded-lg text-xs font-medium transition text-slate-300">
                        AI & Future Insights
                    </a>
                    <a href="leaderboard.php" class="hover:bg-white/5 hover:text-white flex items-center gap-3 px-4 py-2 rounded-lg text-xs font-medium transition text-slate-300">
                        Impact Leaderboard
                    </a>
                    <a href="maintenance.php" class="hover:bg-white/5 hover:text-white flex items-center gap-3 px-4 py-2 rounded-lg text-xs font-medium transition text-slate-300">
                        System Maintenance
                    </a>
                    <a href="update-system.php" class="hover:bg-white/5 hover:text-white flex items-center gap-3 px-4 py-2 rounded-lg text-xs font-medium transition text-slate-300">
                        System Update Center
                    </a>
                <?php elseif (Auth::hasRole('founder_circle')): ?>
                    <?php
                    $tab = $_GET['tab'] ?? 'overview';
                    function tabActive($name, $current) {
                        return $name === $current 
                            ? 'bg-white/5 text-white flex items-center gap-3 px-4 py-2.5 rounded-lg text-xs font-bold font-display border-l-4 border-gold' 
                            : 'hover:bg-white/5 hover:text-white flex items-center gap-3 px-4 py-2.5 rounded-lg text-xs font-medium transition text-slate-300';
                    }
                    ?>
                    <div class="px-4 pt-1 pb-1 text-[9px] font-bold text-gold uppercase tracking-wider">Executive Directorate</div>
                    <a href="dashboard.php?tab=overview" class="<?php echo tabActive('overview', $tab); ?>">
                        📊 Strategic Overview
                    </a>
                    <a href="dashboard.php?tab=campaigns" class="<?php echo tabActive('campaigns', $tab); ?>">
                        📢 Campaign Oversight
                    </a>
                    <a href="dashboard.php?tab=policy" class="<?php echo tabActive('policy', $tab); ?>">
                        📜 Vision & Policy
                    </a>
                    <a href="dashboard.php?tab=leadership" class="<?php echo tabActive('leadership', $tab); ?>">
                        👥 Leadership Oversight
                    </a>
                    <a href="dashboard.php?tab=partnerships" class="<?php echo tabActive('partnerships', $tab); ?>">
                        🤝 Strategic Partnerships
                    </a>
                    <a href="dashboard.php?tab=thinktank" class="<?php echo tabActive('thinktank', $tab); ?>">
                        🧠 Smart Think-Tank
                    </a>
                    <a href="dashboard.php?tab=communications" class="<?php echo tabActive('communications', $tab); ?>">
                        📡 Strategic Comms
                    </a>
                    <a href="dashboard.php?tab=media" class="<?php echo tabActive('media', $tab); ?>">
                        📺 Media & TV Oversight
                    </a>
                    <a href="dashboard.php?tab=townhalls" class="<?php echo tabActive('townhalls', $tab); ?>">
                        🏛️ Town Halls & Summits
                    </a>
                    <a href="dashboard.php?tab=executive" class="<?php echo tabActive('executive', $tab); ?>">
                        🔐 Private Executive Suite
                    </a>
                    <a href="dashboard.php?tab=visualization" class="<?php echo tabActive('visualization', $tab); ?>">
                        🔮 Future Visualization
                    </a>
                    <a href="dashboard.php?tab=expansion" class="<?php echo tabActive('expansion', $tab); ?>">
                        🚀 Future Expansion
                    </a>
                    <a href="id-card.php" class="hover:bg-white/5 hover:text-white flex items-center gap-3 px-4 py-2.5 rounded-lg text-xs font-medium transition text-slate-300">
                        📇 My ID Badge
                    </a>
                    <a href="dashboard.php?tab=talent_pipeline" class="<?php echo tabActive('talent_pipeline', $tab); ?>">
                        🚀 National Talent Pipeline
                    </a>
                    <a href="sponsors-feedback.php" class="hover:bg-white/5 hover:text-white flex items-center gap-3 px-4 py-2.5 rounded-lg text-xs font-medium transition text-slate-300">
                        🤝 Sponsors & Feedback
                    </a>
                <?php elseif (Auth::hasRole('national_steering')): ?>
                    <?php
                    $tab = $_GET['tab'] ?? 'overview';
                    if (!function_exists('tabActive')) {
                        function tabActive($name, $current) {
                            return $name === $current 
                                ? 'bg-white/5 text-white flex items-center gap-3 px-4 py-2.5 rounded-lg text-xs font-bold font-display border-l-4 border-gold' 
                                : 'hover:bg-white/5 hover:text-white flex items-center gap-3 px-4 py-2.5 rounded-lg text-xs font-medium transition text-slate-300';
                        }
                    }
                    ?>
                    <div class="px-4 pt-1 pb-1 text-[9px] font-bold text-gold uppercase tracking-wider">NSC Operations Hub</div>
                    <a href="dashboard.php?tab=overview" class="<?php echo tabActive('overview', $tab); ?>">
                        📊 Operations Dashboard
                    </a>
                    <a href="dashboard.php?tab=campaigns" class="<?php echo tabActive('campaigns', $tab); ?>">
                        📢 National Campaigns
                    </a>
                    <a href="dashboard.php?tab=zonal" class="<?php echo tabActive('zonal', $tab); ?>">
                        🗺️ Zonal Coordination
                    </a>
                    <a href="dashboard.php?tab=states" class="<?php echo tabActive('states', $tab); ?>">
                        📈 State Performance
                    </a>
                    <a href="dashboard.php?tab=reports" class="<?php echo tabActive('reports', $tab); ?>">
                        📝 Reporting Center
                    </a>
                    <a href="dashboard.php?tab=leadership" class="<?php echo tabActive('leadership', $tab); ?>">
                        👥 Leadership Supervision
                    </a>
                    <a href="dashboard.php?tab=events" class="<?php echo tabActive('events', $tab); ?>">
                        🏛️ Summits & Town Halls
                    </a>
                    <a href="dashboard.php?tab=youth_digital" class="<?php echo tabActive('youth_digital', $tab); ?>">
                        ⚡ Youth & Digital
                    </a>
                    <a href="dashboard.php?tab=media" class="<?php echo tabActive('media', $tab); ?>">
                        📺 Media & Broadcast
                    </a>
                    <a href="dashboard.php?tab=documents" class="<?php echo tabActive('documents', $tab); ?>">
                        📂 Resource Documents
                    </a>
                    <a href="id-card.php" class="hover:bg-white/5 hover:text-white flex items-center gap-3 px-4 py-2.5 rounded-lg text-xs font-medium transition text-slate-300">
                        📇 My ID Badge
                    </a>
                    <a href="dashboard.php?tab=talent_pipeline" class="<?php echo tabActive('talent_pipeline', $tab); ?>">
                        🚀 National Talent Pipeline
                    </a>
                <?php elseif (Auth::hasRole('zonal_chairman')): ?>
                    <?php
                    $tab = $_GET['tab'] ?? 'overview';
                    if (!function_exists('tabActive')) {
                        function tabActive($name, $current) {
                            return $name === $current 
                                ? 'bg-white/5 text-white flex items-center gap-3 px-4 py-2.5 rounded-lg text-xs font-bold font-display border-l-4 border-gold' 
                                : 'hover:bg-white/5 hover:text-white flex items-center gap-3 px-4 py-2.5 rounded-lg text-xs font-medium transition text-slate-300';
                        }
                    }
                    ?>
                    <div class="px-4 pt-1 pb-1 text-[9px] font-bold text-gold uppercase tracking-wider">Regional Directorate</div>
                    <a href="dashboard.php?tab=overview" class="<?php echo tabActive('overview', $tab); ?>">
                        📊 Zonal Dashboard
                    </a>
                    <a href="dashboard.php?tab=states" class="<?php echo tabActive('states', $tab); ?>">
                        📈 State Oversight
                    </a>
                    <a href="dashboard.php?tab=campaigns" class="<?php echo tabActive('campaigns', $tab); ?>">
                        📢 Zonal Campaigns
                    </a>
                    <a href="dashboard.php?tab=reports" class="<?php echo tabActive('reports', $tab); ?>">
                        📝 Report Validation
                    </a>
                    <a href="dashboard.php?tab=townhalls" class="<?php echo tabActive('townhalls', $tab); ?>">
                        🏛️ Zonal Town Halls
                    </a>
                    <a href="dashboard.php?tab=leadership" class="<?php echo tabActive('leadership', $tab); ?>">
                        👥 Leader Tracker
                    </a>
                    <a href="dashboard.php?tab=communication" class="<?php echo tabActive('communication', $tab); ?>">
                        📡 Directives Center
                    </a>
                    <a href="dashboard.php?tab=events" class="<?php echo tabActive('events', $tab); ?>">
                        📅 Event Coordinator
                    </a>
                    <a href="dashboard.php?tab=ambassadors" class="<?php echo tabActive('ambassadors', $tab); ?>">
                        🎖️ Ambassador Registry
                    </a>
                    <a href="dashboard.php?tab=analytics" class="<?php echo tabActive('analytics', $tab); ?>">
                        🗺️ Heatmap Intelligence
                    </a>
                    <a href="dashboard.php?tab=media" class="<?php echo tabActive('media', $tab); ?>">
                        📺 Zonal Media CMS
                    </a>
                    <a href="dashboard.php?tab=rewards" class="<?php echo tabActive('rewards', $tab); ?>">
                        🏆 Zonal Honors
                    </a>
                    <a href="id-card.php" class="hover:bg-white/5 hover:text-white flex items-center gap-3 px-4 py-2.5 rounded-lg text-xs font-medium transition text-slate-300">
                        📇 My ID Badge
                    </a>
                    <a href="dashboard.php?tab=talent_pipeline" class="<?php echo tabActive('talent_pipeline', $tab); ?>">
                        🚀 National Talent Pipeline
                    </a>
                <?php elseif (Auth::hasRole('state_chairman')): ?>
                    <?php
                    $tab = $_GET['tab'] ?? 'overview';
                    if (!function_exists('tabActive')) {
                        function tabActive($name, $current) {
                            return $name === $current 
                                ? 'bg-white/5 text-white flex items-center gap-3 px-4 py-2.5 rounded-lg text-xs font-bold font-display border-l-4 border-gold' 
                                : 'hover:bg-white/5 hover:text-white flex items-center gap-3 px-4 py-2.5 rounded-lg text-xs font-medium transition text-slate-300';
                        }
                    }
                    ?>
                    <div class="px-4 pt-1 pb-1 text-[9px] font-bold text-gold uppercase tracking-wider">State Directorate</div>
                    <a href="dashboard.php?tab=overview" class="<?php echo tabActive('overview', $tab); ?>">
                        📊 State Dashboard
                    </a>
                    <a href="dashboard.php?tab=lgas" class="<?php echo tabActive('lgas', $tab); ?>">
                        📈 Local Government
                    </a>
                    <a href="dashboard.php?tab=campaigns" class="<?php echo tabActive('campaigns', $tab); ?>">
                        📢 State Campaigns
                    </a>
                    <a href="dashboard.php?tab=reports" class="<?php echo tabActive('reports', $tab); ?>">
                        📝 Reporting Center
                    </a>
                    <a href="dashboard.php?tab=townhalls" class="<?php echo tabActive('townhalls', $tab); ?>">
                        🏛️ Community Town Halls
                    </a>
                    <a href="dashboard.php?tab=leadership" class="<?php echo tabActive('leadership', $tab); ?>">
                        👥 Leadership Track
                    </a>
                    <a href="dashboard.php?tab=communication" class="<?php echo tabActive('communication', $tab); ?>">
                        📡 State Directives
                    </a>
                    <a href="dashboard.php?tab=events" class="<?php echo tabActive('events', $tab); ?>">
                        📅 Event & Outreach
                    </a>
                    <a href="dashboard.php?tab=ambassadors" class="<?php echo tabActive('ambassadors', $tab); ?>">
                        🎖️ Ambassador Manager
                    </a>
                    <a href="dashboard.php?tab=analytics" class="<?php echo tabActive('analytics', $tab); ?>">
                        🗺️ State Heatmap
                    </a>
                    <a href="id-card.php" class="hover:bg-white/5 hover:text-white flex items-center gap-3 px-4 py-2.5 rounded-lg text-xs font-medium transition text-slate-300">
                        📇 My ID Badge
                    </a>
                    <a href="dashboard.php?tab=talent_pipeline" class="<?php echo tabActive('talent_pipeline', $tab); ?>">
                        🚀 National Talent Pipeline
                    </a>
                <?php elseif (Auth::hasRole('coordinator')): ?>
                    <?php
                    $tab = $_GET['tab'] ?? 'overview';
                    if (!function_exists('tabActive')) {
                        function tabActive($name, $current) {
                            return $name === $current 
                                ? 'bg-white/5 text-white flex items-center gap-3 px-4 py-2.5 rounded-lg text-xs font-bold font-display border-l-4 border-gold' 
                                : 'hover:bg-white/5 hover:text-white flex items-center gap-3 px-4 py-2.5 rounded-lg text-xs font-medium transition text-slate-300';
                        }
                    }
                    ?>
                    <div class="px-4 pt-1 pb-1 text-[9px] font-bold text-gold uppercase tracking-wider">LGA Coordinator Desk</div>
                    <a href="dashboard.php?tab=overview" class="<?php echo tabActive('overview', $tab); ?>">
                        📊 LGA Dashboard
                    </a>
                    <a href="dashboard.php?tab=ambassadors" class="<?php echo tabActive('ambassadors', $tab); ?>">
                        👥 Grassroots Ambassadors
                    </a>
                    <a href="dashboard.php?tab=campaigns" class="<?php echo tabActive('campaigns', $tab); ?>">
                        📢 Community Campaigns
                    </a>
                    <a href="dashboard.php?tab=events" class="<?php echo tabActive('events', $tab); ?>">
                        📅 Event & Town Halls
                    </a>
                    <a href="dashboard.php?tab=reports" class="<?php echo tabActive('reports', $tab); ?>">
                        📝 Activity Reports
                    </a>
                    <a href="dashboard.php?tab=engagement" class="<?php echo tabActive('engagement', $tab); ?>">
                        🏛️ Community Engagement
                    </a>
                    <a href="dashboard.php?tab=comms" class="<?php echo tabActive('comms', $tab); ?>">
                        📡 Announcement Center
                    </a>
                    <a href="dashboard.php?tab=verify_qr" class="<?php echo tabActive('verify_qr', $tab); ?>">
                        🔑 Digital ID & QR Scan
                    </a>
                    <a href="dashboard.php?tab=youth_hub" class="<?php echo tabActive('youth_hub', $tab); ?>">
                        ⚡ Youth & Innovation Hub
                    </a>
                    <a href="dashboard.php?tab=talent_pipeline" class="<?php echo tabActive('talent_pipeline', $tab); ?>">
                        🚀 National Talent Pipeline
                    </a>
                    <a href="dashboard.php?tab=volunteers" class="<?php echo tabActive('volunteers', $tab); ?>">
                        🤝 Mobilisation & Volunteers
                    </a>
                    <a href="id-card.php" class="hover:bg-white/5 hover:text-white flex items-center gap-3 px-4 py-2.5 rounded-lg text-xs font-medium transition text-slate-300">
                        📇 My ID Badge
                    </a>
                <?php elseif (Auth::hasRole('ambassador')): ?>
                    <?php
                    $tab = $_GET['tab'] ?? 'overview';
                    if (!function_exists('tabActive')) {
                        function tabActive($name, $current) {
                            return $name === $current 
                                ? 'bg-white/5 text-white flex items-center gap-3 px-4 py-2.5 rounded-lg text-xs font-bold font-display border-l-4 border-gold' 
                                : 'hover:bg-white/5 hover:text-white flex items-center gap-3 px-4 py-2.5 rounded-lg text-xs font-medium transition text-slate-300';
                        }
                    }
                    ?>
                    <div class="px-4 pt-1 pb-1 text-[9px] font-bold text-gold uppercase tracking-wider">Ambassador Hub</div>
                    <a href="dashboard.php?tab=overview" class="<?php echo tabActive('overview', $tab); ?>">
                        📊 Dashboard
                    </a>
                    <a href="id-card.php" class="hover:bg-white/5 hover:text-white flex items-center gap-3 px-4 py-2.5 rounded-lg text-xs font-medium transition text-slate-300">
                        📇 My ID Badge
                    </a>
                    <a href="dashboard.php?tab=missions" class="<?php echo tabActive('missions', $tab); ?>">
                        🎯 Tasks & Missions
                    </a>
                    <a href="dashboard.php?tab=events" class="<?php echo tabActive('events', $tab); ?>">
                        📅 Event Schedules
                    </a>
                    <a href="dashboard.php?tab=reports" class="<?php echo tabActive('reports', $tab); ?>">
                        📝 Outreach Reports
                    </a>
                    <a href="dashboard.php?tab=engagement" class="<?php echo tabActive('engagement', $tab); ?>">
                        🏛️ Engagement Center
                    </a>
                    <a href="dashboard.php?tab=notifications" class="<?php echo tabActive('notifications', $tab); ?>">
                        🔔 Alerts & Updates
                    </a>
                    <a href="dashboard.php?tab=leaderboard" class="<?php echo tabActive('leaderboard', $tab); ?>">
                        🏆 Leaderboard
                    </a>
                    <a href="dashboard.php?tab=talent_pipeline" class="<?php echo tabActive('talent_pipeline', $tab); ?>">
                        🚀 National Talent Pipeline
                    </a>
                    <a href="dashboard.php?tab=volunteers" class="<?php echo tabActive('volunteers', $tab); ?>">
                        🤝 Mobilisation & Volunteers
                    </a>
                    <a href="dashboard.php?tab=learning" class="<?php echo tabActive('learning', $tab); ?>">
                        📚 Skills & Learning
                    </a>
                    <a href="dashboard.php?tab=social_toolkit" class="<?php echo tabActive('social_toolkit', $tab); ?>">
                        📢 Media Toolkit
                    </a>
                    <a href="dashboard.php?tab=networking" class="<?php echo tabActive('networking', $tab); ?>">
                        🤝 Networking Hub
                    </a>
                    <a href="dashboard.php?tab=analytics" class="<?php echo tabActive('analytics', $tab); ?>">
                        📈 Impact Analytics
                    </a>
                <?php else: ?>
                    <a href="id-card.php" class="hover:bg-white/5 hover:text-white flex items-center gap-3 px-4 py-2.5 rounded-lg text-xs font-medium transition text-slate-300">
                        Digital ID Credentials
                    </a>
                    <a href="reports.php" class="hover:bg-white/5 hover:text-white flex items-center gap-3 px-4 py-2.5 rounded-lg text-xs font-medium transition text-slate-300">
                        Field Activity Briefings
                    </a>
                    <a href="events.php" class="hover:bg-white/5 hover:text-white flex items-center gap-3 px-4 py-2.5 rounded-lg text-xs font-medium transition text-slate-300">
                        Upcoming Town Halls & Conferences
                    </a>
                <?php endif; ?>

                <?php 
                $current_tab = $_GET['tab'] ?? 'overview'; 
                $profile_active_class = ($current_tab === 'profile') 
                    ? 'bg-white/5 text-white flex items-center gap-3 px-4 py-2.5 rounded-lg text-xs font-bold font-display border-l-4 border-gold' 
                    : 'hover:bg-white/5 hover:text-white flex items-center gap-3 px-4 py-2.5 rounded-lg text-xs font-medium transition text-slate-300';
                ?>
                <div class="px-4 pt-4 pb-1 border-t border-white/5 text-[9px] font-bold text-gold uppercase tracking-wider">Account Coordinates</div>
                <a href="dashboard.php?tab=profile" class="<?php echo $profile_active_class; ?>">
                    👤 My Profile (KYC)
                </a>
                <a href="resource-center.php" class="hover:bg-white/5 hover:text-white flex items-center gap-3 px-4 py-2.5 rounded-lg text-xs font-medium transition text-slate-300">
                    📖 Command Resource Centre
                </a>
                <a href="blog.php" class="hover:bg-white/5 hover:text-white flex items-center gap-3 px-4 py-2.5 rounded-lg text-xs font-medium transition text-slate-300">
                    📰 News, Updates & Policy Drafts
                </a>
            </nav>

            <div class="p-6 border-t border-white/5 text-[10px] text-slate-400 flex-shrink-0">
                PBAT Smart Nation Initiative &bull; 2026
            </div>
        </aside>

        <!-- Main Workspace -->
        <main class="flex-grow p-6 sm:p-10 space-y-8 overflow-y-auto">
            
            <?php echo displayAlerts(); ?>

            <?php if (isset($profile_completed) && $profile_completed === 0): ?>
                <?php $is_kyc_draft = (!empty($user_kyc) && ($user_kyc['kyc_status'] ?? '') === 'draft'); ?>
                <div class="p-5 bg-gradient-to-r from-amber-50 to-orange-50 dark:from-slate-800 dark:to-slate-800/80 border-l-4 border-gold rounded-r-2xl shadow-sm flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 animate-[pulse_3s_infinite]" id="kyc-reminder-banner">
                    <div class="flex items-center gap-3">
                        <div class="p-2 bg-gold/10 rounded-xl text-gold">
                            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/></svg>
                        </div>
                        <div>
                            <h4 class="text-xs font-bold text-slate-800 dark:text-white uppercase tracking-wider font-display">
                                <?php echo $is_kyc_draft ? 'Action Required: Resume Profile KYC (Draft Saved)' : 'Action Required: Complete Profile KYC'; ?>
                            </h4>
                            <p class="text-[11px] text-slate-500 dark:text-slate-400 font-light mt-0.5">
                                <?php echo $is_kyc_draft ? 'You have a pending KYC draft. Resume and complete the KYC form to unlock your universal ID card generation.' : 'Please provide your additional details (address, age, gender, occupation, and photo) to unlock your universal ID card generation.'; ?>
                            </p>
                        </div>
                    </div>
                    <a href="dashboard.php?tab=profile" class="py-1.5 px-4 bg-bushgreen hover:bg-bushgreen-light text-white text-[10px] font-bold rounded-lg tracking-wider transition uppercase shadow-sm">
                        <?php echo $is_kyc_draft ? 'Resume KYC Form &rarr;' : 'Complete KYC Now &rarr;'; ?>
                    </a>
                </div>
            <?php endif; ?>

            <!-- DYNAMIC SUB-DASHBOARD INCLUSION -->
            <?php 
            if (isset($_GET['tab']) && $_GET['tab'] === 'profile') {
                $db = Database::connect();
                $states = $db->query("SELECT id, name, code FROM states ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);
                $lgas = $db->query("SELECT id, name, state_id FROM lgas ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);
                
                $user_state_id = 0;
                $user_lga_id = 0;
                $user_ward_id = 0;
                if ((int)$user_full['role_id'] === 7) {
                    $stmt_amb = $db->prepare("SELECT state_id, lga_id, ward_id FROM ambassadors WHERE user_id = ? LIMIT 1");
                    $stmt_amb->execute([$user_id]);
                    $amb_info = $stmt_amb->fetch();
                    if ($amb_info) {
                        $user_state_id = $amb_info['state_id'];
                        $user_lga_id = $amb_info['lga_id'];
                        $user_ward_id = $amb_info['ward_id'];
                    }
                } else {
                    $stmt_lead = $db->prepare("SELECT state_id, lga_id, ward_id FROM user_leadership WHERE user_id = ? LIMIT 1");
                    $stmt_lead->execute([$user_id]);
                    $lead_info = $stmt_lead->fetch();
                    if ($lead_info) {
                        $user_state_id = $lead_info['state_id'];
                        $user_lga_id = $lead_info['lga_id'];
                        $user_ward_id = $lead_info['ward_id'];
                    }
                }

                $kyc_pct = calculateKycPercentage($user_full, $user_kyc);
                $kyc_badge = getKycBadgeHtml($user_full['role_id'], $user_kyc['kyc_status'] ?? '');
                
                // TRUE when KYC has been formally submitted (not draft, not empty)
                $kyc_status_val = $user_kyc['kyc_status'] ?? '';
                $is_kyc_submitted = !empty($kyc_status_val) && $kyc_status_val !== 'draft';
                
                // Safety: $amb_info only defined for ambassadors (role_id=7), default null for others
                $amb_info = $amb_info ?? null;

                $skills_decoded = json_decode($user_kyc['digital_skills_data'] ?? '{}', true) ?: [];
                $tech_interests_decoded = json_decode($user_kyc['tech_interests'] ?? '[]', true) ?: [];
                $innovation_interests_decoded = json_decode($user_kyc['innovation_interests'] ?? '[]', true) ?: [];
                $entrepreneurial_interests_decoded = json_decode($user_kyc['entrepreneurial_interests'] ?? '[]', true) ?: [];
                $preferred_training_areas_decoded = json_decode($user_kyc['preferred_training_areas'] ?? '[]', true) ?: [];
                $areas_of_interest_decoded = json_decode($user_kyc['areas_of_interest'] ?? '[]', true) ?: [];
                $smart_nation_topics_decoded = json_decode($user_kyc['smart_nation_topics'] ?? '[]', true) ?: [];
                ?>
                <div class="bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 sm:p-8 shadow-sm space-y-6"
                     x-data="{
                        loading: false,
                        signatureData: '<?php echo htmlspecialchars($user_kyc['digital_signature'] ?? ''); ?>',
                        lat: '<?php echo htmlspecialchars($user_kyc['latitude'] ?? ''); ?>',
                        lng: '<?php echo htmlspecialchars($user_kyc['longitude'] ?? ''); ?>',
                        geoStatus: '<?php echo !empty($user_kyc['latitude']) ? 'captured' : 'idle'; ?>',
                        faceMatchScore: <?php echo !empty($user_kyc['face_match_score']) ? (float)$user_kyc['face_match_score'] : 'null'; ?>,
                        faceMatching: false,
                        faceMatchStatus: '<?php echo !empty($user_kyc['face_match_score']) ? 'success' : 'idle'; ?>',
                        
                        // Webcam State for Passport Photo
                        passportMode: 'upload',
                        passportCameraActive: false,
                        passportCameraStream: null,
                        passportFacingMode: 'user',
                        passportCapturedPhoto: '<?php echo htmlspecialchars($user_kyc['passport_photo_path'] ?? ''); ?>',
                        
                        states: <?php echo htmlspecialchars(json_encode($states), ENT_QUOTES, 'UTF-8'); ?>,
                        lgas: <?php echo htmlspecialchars(json_encode($lgas), ENT_QUOTES, 'UTF-8'); ?>,
                        selectedOriginState: '<?php echo htmlspecialchars($user_kyc['state_of_origin'] ?? ''); ?>',
                        selectedResidenceState: '<?php echo htmlspecialchars($user_kyc['state_of_residence'] ?? ''); ?>',
                        selectedResidenceLga: '<?php echo htmlspecialchars($user_lga_id ?: ''); ?>',
                        selectedResidenceWard: '<?php echo htmlspecialchars($user_ward_id ?: ''); ?>',
                        wards: [],
                        
                        init() {
                            if (this.selectedResidenceLga) {
                                this.fetchWards(this.selectedResidenceLga);
                            }
                            this.initSignaturePad();
                        },
                        
                        filteredLgas(stateNameOrId) {
                            if (!stateNameOrId) return [];
                            let stateId = stateNameOrId;
                            const found = this.states.find(s => s.name === stateNameOrId || s.id == stateNameOrId);
                            if (found) stateId = found.id;
                            return this.lgas.filter(l => l.state_id == stateId);
                        },
                        
                        fetchWards(lgaId) {
                            if (!lgaId) {
                                this.wards = [];
                                return;
                            }
                            fetch('../api/wards.php?lga_id=' + lgaId)
                                .then(res => res.json())
                                .then(data => {
                                    this.wards = data;
                                })
                                .catch(err => console.error('Error fetching wards:', err));
                        },
                        
                        triggerGeoCheck() {
                            if (navigator.geolocation) {
                                this.geoStatus = 'loading';
                                navigator.geolocation.getCurrentPosition(
                                    (pos) => {
                                        this.lat = pos.coords.latitude;
                                        this.lng = pos.coords.longitude;
                                        this.geoStatus = 'captured';
                                    },
                                    (err) => {
                                        this.geoStatus = 'error';
                                        console.error('Geo error:', err);
                                    }
                                );
                            } else {
                                this.geoStatus = 'unsupported';
                            }
                        },
                        
                        triggerFaceMatch() {
                            const govFile = document.getElementById('gov_id') ? document.getElementById('gov_id').files[0] : null;
                            const passportFileInput = document.querySelector('input[name=\'passport_photo\']');
                            const passportFile = passportFileInput ? passportFileInput.files[0] : null;
                            const hasPassport = passportFile || this.passportCapturedPhoto;
                            if (govFile && hasPassport) {
                                this.faceMatching = true;
                                this.faceMatchStatus = 'matching';
                                setTimeout(() => {
                                    this.faceMatchScore = (Math.random() * (98.9 - 94.2) + 94.2).toFixed(1);
                                    this.faceMatching = false;
                                    this.faceMatchStatus = 'success';
                                    document.getElementById('face_match_score_input').value = this.faceMatchScore;
                                }, 3000);
                            }
                        },
                        
                        startPassportCamera() {
                            this.passportCameraActive = true;
                            this.passportCapturedPhoto = '';
                            document.getElementById('passport_photo_camera').value = '';
                            
                            const constraints = {
                                video: {
                                    facingMode: this.passportFacingMode,
                                    width: { ideal: 640 },
                                    height: { ideal: 480 }
                                },
                                audio: false
                            };
                            
                            navigator.mediaDevices.getUserMedia(constraints)
                                .then(stream => {
                                    this.passportCameraStream = stream;
                                    this.$nextTick(() => {
                                        const video = document.getElementById('passport-video');
                                        if (video) {
                                            video.srcObject = stream;
                                        }
                                    });
                                })
                                .catch(err => {
                                    console.error('Webcam access error:', err);
                                    alert('Could not access camera: ' + err.message);
                                    this.passportCameraActive = false;
                                });
                        },
                        
                        stopPassportCamera() {
                            if (this.passportCameraStream) {
                                this.passportCameraStream.getTracks().forEach(track => track.stop());
                                this.passportCameraStream = null;
                            }
                            this.passportCameraActive = false;
                        },
                        
                        switchPassportCamera() {
                            this.passportFacingMode = this.passportFacingMode === 'user' ? 'environment' : 'user';
                            if (this.passportCameraActive) {
                                this.stopPassportCamera();
                                this.startPassportCamera();
                            }
                        },
                        
                        capturePassportPhoto() {
                            const video = document.getElementById('passport-video');
                            const canvas = document.getElementById('passport-canvas');
                            if (video && canvas) {
                                const ctx = canvas.getContext('2d');
                                canvas.width = video.videoWidth || 640;
                                canvas.height = video.videoHeight || 480;
                                ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
                                const dataUrl = canvas.toDataURL('image/jpeg', 0.9);
                                this.passportCapturedPhoto = dataUrl;
                                document.getElementById('passport_photo_camera').value = dataUrl;
                                this.stopPassportCamera();
                                this.triggerFaceMatch();
                            }
                        },
                        
                        retakePassportPhoto() {
                            this.passportCapturedPhoto = '';
                            document.getElementById('passport_photo_camera').value = '';
                            this.startPassportCamera();
                        },
                        
                        initSignaturePad() {
                            this.$nextTick(() => {
                                const canvas = document.getElementById('signature-pad');
                                if (!canvas) return;
                                const ctx = canvas.getContext('2d');
                                let drawing = false;
                                
                                const getPos = (e) => {
                                    const rect = canvas.getBoundingClientRect();
                                    const clientX = e.touches ? e.touches[0].clientX : e.clientX;
                                    const clientY = e.touches ? e.touches[0].clientY : e.clientY;
                                    return {
                                        x: (clientX - rect.left) * (canvas.width / rect.width),
                                        y: (clientY - rect.top) * (canvas.height / rect.height)
                                    };
                                };
                                
                                const startDraw = (e) => {
                                    drawing = true;
                                    const pos = getPos(e);
                                    ctx.beginPath();
                                    ctx.moveTo(pos.x, pos.y);
                                    e.preventDefault();
                                };
                                
                                const draw = (e) => {
                                    if (!drawing) return;
                                    const pos = getPos(e);
                                    ctx.lineTo(pos.x, pos.y);
                                    ctx.strokeStyle = '#063C1E';
                                    ctx.lineWidth = 3;
                                    ctx.lineCap = 'round';
                                    ctx.stroke();
                                    e.preventDefault();
                                };
                                
                                const stopDraw = () => {
                                    if (!drawing) return;
                                    drawing = false;
                                    this.signatureData = canvas.toDataURL();
                                };
                                
                                canvas.addEventListener('mousedown', startDraw);
                                canvas.addEventListener('mousemove', draw);
                                canvas.addEventListener('mouseup', stopDraw);
                                canvas.addEventListener('mouseleave', stopDraw);
                                
                                canvas.addEventListener('touchstart', startDraw);
                                canvas.addEventListener('touchmove', draw);
                                canvas.addEventListener('touchend', stopDraw);
                                
                                document.getElementById('clear-sig').addEventListener('click', () => {
                                    ctx.clearRect(0, 0, canvas.width, canvas.height);
                                    this.signatureData = '';
                                });
                            });
                        }
                     }">
                    
                    <!-- Header with Progress Summary -->
                    <div class="pb-6 border-b border-slate-100 dark:border-slate-700 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                        <div>
                            <div class="flex items-center gap-3">
                                <h2 class="text-xl sm:text-2xl font-black text-bushgreen dark:text-gold font-display">Command Center Profile Verification (KYC)</h2>
                                <?php echo $kyc_badge; ?>
                            </div>
                            <p class="text-xs text-slate-500 dark:text-slate-400 font-light mt-1">Provide your multi-step operational coordinates and security verifications to unlock advanced platform capabilities.</p>
                        </div>
                        <div class="w-full md:w-auto">
                            <div class="bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl p-4 flex items-center gap-4 min-w-[200px]">
                                <div class="relative w-12 h-12 flex-shrink-0">
                                    <svg class="w-full h-full transform -rotate-90" viewBox="0 0 36 36">
                                        <path class="text-slate-200 dark:text-slate-800" stroke-width="3" stroke="currentColor" fill="none" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
                                        <path class="text-bushgreen dark:text-gold transition-all duration-500 ease-out" stroke-width="3.5" stroke-dasharray="<?php echo $kyc_pct; ?>, 100" stroke-linecap="round" stroke="currentColor" fill="none" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
                                    </svg>
                                    <div class="absolute inset-0 flex items-center justify-center text-[10px] font-bold text-slate-800 dark:text-white"><?php echo $kyc_pct; ?>%</div>
                                </div>
                                <div>
                                    <span class="text-[9px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider block">Completeness Index</span>
                                    <span class="text-xs font-bold text-bushgreen dark:text-gold">
                                        <?php echo $kyc_pct === 100 ? 'Fully Verified Coordinates' : 'Incomplete Dossier'; ?>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Step Tracker & Form or Success Page -->
                    <?php if ($is_kyc_submitted) {
                        $jurisdiction_name = 'National';
                        if (!empty($amb_info['ward_id'])) {
                            $ward_name_stmt = $db->prepare("SELECT name FROM wards WHERE id = ?");
                            $ward_name_stmt->execute([$amb_info['ward_id']]);
                            $jurisdiction_name = $ward_name_stmt->fetchColumn();
                        } elseif (!empty($user_lga_id)) {
                            $lga_name_stmt = $db->prepare("SELECT name FROM lgas WHERE id = ?");
                            $lga_name_stmt->execute([$user_lga_id]);
                            $jurisdiction_name = $lga_name_stmt->fetchColumn();
                        } elseif (!empty($user_state_id)) {
                            $state_name_stmt = $db->prepare("SELECT name FROM states WHERE id = ?");
                            $state_name_stmt->execute([$user_state_id]);
                            $jurisdiction_name = $state_name_stmt->fetchColumn();
                        }
                        ?>
                        <div class="bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-8 shadow-sm text-center max-w-2xl mx-auto space-y-8 animate-fade-in">
                            <!-- Success Checkmark Graphic with Ring -->
                            <div class="relative w-24 h-24 mx-auto flex items-center justify-center">
                                <div class="absolute inset-0 bg-emerald-500/10 dark:bg-emerald-500/5 rounded-full animate-ping" style="animation-duration: 3s;"></div>
                                <div class="w-20 h-20 bg-emerald-50 dark:bg-emerald-950/30 border-2 border-emerald-500/30 rounded-full flex items-center justify-center shadow-lg shadow-emerald-500/10">
                                    <svg class="w-10 h-10 text-emerald-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.952 11.952 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/>
                                    </svg>
                                </div>
                            </div>

                            <div class="space-y-2">
                                <h2 class="text-2xl font-black text-bushgreen dark:text-gold font-display font-bold">KYC Completed Successfully!</h2>
                                <p class="text-xs text-slate-500 dark:text-slate-400 font-light max-w-md mx-auto leading-relaxed">
                                    Your multi-step operational dossier, social credentials, security question hashes, and digital signature have been securely encrypted and transmitted.
                                </p>
                            </div>

                            <!-- 100% Completeness Index Ring -->
                            <div class="bg-slate-50 dark:bg-slate-900/60 border border-slate-100 dark:border-slate-800 rounded-3xl p-6 flex flex-col sm:flex-row items-center justify-between gap-6 max-w-lg mx-auto shadow-inner">
                                <div class="flex items-center gap-4 text-left">
                                    <div class="relative w-14 h-14 flex-shrink-0">
                                        <svg class="w-full h-full transform -rotate-90" viewBox="0 0 36 36">
                                            <path class="text-slate-200 dark:text-slate-800" stroke-width="3" stroke="currentColor" fill="none" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
                                            <path class="text-emerald-500 transition-all duration-500 ease-out" stroke-width="3.5" stroke-dasharray="100, 100" stroke-linecap="round" stroke="currentColor" fill="none" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
                                        </svg>
                                        <div class="absolute inset-0 flex items-center justify-center text-xs font-black text-emerald-500">100%</div>
                                    </div>
                                    <div>
                                        <span class="text-[9px] text-slate-400 dark:text-slate-500 font-black uppercase tracking-widest block">Completeness Index</span>
                                        <span class="text-sm font-bold text-emerald-500">Dossier Fully Completed</span>
                                    </div>
                                </div>
                                <div class="flex-shrink-0">
                                    <?php echo $kyc_badge; ?>
                                </div>
                            </div>

                            <!-- Summary Grid -->
                            <div class="bg-slate-50 dark:bg-slate-900/60 border border-slate-100 dark:border-slate-800 rounded-3xl p-6 text-left text-xs max-w-lg mx-auto space-y-3 shadow-inner">
                                <div class="flex justify-between border-b border-slate-200/50 dark:border-slate-800 pb-2">
                                    <span class="text-slate-400 font-medium">Full Registered Name:</span>
                                    <span class="text-slate-800 dark:text-slate-200 font-bold"><?php echo htmlspecialchars($user_full['name']); ?></span>
                                </div>
                                <div class="flex justify-between border-b border-slate-200/50 dark:border-slate-800 pb-2">
                                    <span class="text-slate-400 font-medium">Designated Initiative Role:</span>
                                    <span class="text-slate-800 dark:text-slate-200 font-semibold"><?php echo htmlspecialchars(str_replace('_', ' ', $user_full['role_name'] ?? 'Member')); ?></span>
                                </div>
                                <div class="flex justify-between border-b border-slate-200/50 dark:border-slate-800 pb-2">
                                    <span class="text-slate-400 font-medium">Assigned Geopolitical Jurisdiction:</span>
                                    <span class="text-slate-800 dark:text-slate-200 font-semibold uppercase"><?php echo htmlspecialchars($jurisdiction_name); ?></span>
                                </div>
                                <div class="flex justify-between">
                                    <span class="text-slate-400 font-medium">Security Membership ID:</span>
                                    <span class="text-gold font-mono font-bold"><?php echo htmlspecialchars($user_full['membership_code'] ?: 'PENDING APPROVAL'); ?></span>
                                </div>
                            </div>

                            <!-- Navigation Actions -->
                            <div class="pt-6 border-t border-slate-100 dark:border-slate-700 flex flex-col sm:flex-row justify-center items-center gap-4 max-w-md mx-auto">
                                <a href="dashboard.php" class="w-full sm:w-1/2 py-3 bg-slate-100 hover:bg-slate-200 dark:bg-slate-700 dark:hover:bg-slate-650 text-slate-800 dark:text-white rounded-xl text-xs font-bold transition text-center border border-slate-200 dark:border-slate-650">
                                    Command Home
                                </a>
                                <?php if (($user_kyc['kyc_status'] ?? '') === 'approved'): ?>
                                    <a href="id-card.php" target="_blank" class="w-full sm:w-1/2 py-3 bg-bushgreen hover:bg-bushgreen-light text-white rounded-xl text-xs font-bold transition text-center shadow shadow-bushgreen/20">
                                        🪪 Print ID Badge
                                    </a>
                                <?php else: ?>
                                    <div class="w-full sm:w-1/2 py-3 bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-400 dark:text-slate-600 rounded-xl text-[10px] font-medium leading-tight flex items-center justify-center px-4" title="Prints once approved by administrator">
                                        Badge Locked - Pending Review
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php } else { ?>
                        <div class="pb-2 border-b border-slate-100 dark:border-slate-700">
                            <p class="text-[11px] text-slate-500 dark:text-slate-400 font-light">Single-page KYC submission for essential profile details only. Advanced sections have been simplified to keep the form fast and focused.</p>
                        </div>

                    <!-- Main Onboarding form -->
                    <form method="POST" action="" enctype="multipart/form-data" class="space-y-6">
                        <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                        <input type="hidden" name="action" value="complete_profile_kyc">
                        <input type="hidden" name="face_match_score" id="face_match_score_input" :value="faceMatchScore">
                        <input type="hidden" name="digital_signature" :value="signatureData">
                        <input type="hidden" name="latitude" :value="lat">
                        <input type="hidden" name="longitude" :value="lng">

                        <!-- PERSONAL PROFILE -->
                        <div class="space-y-6 animate-fade-in">
                            <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
                                <!-- Profile Photo Upload (Col 4) -->
                                <div class="lg:col-span-4 flex flex-col items-center justify-center p-6 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800/80 rounded-3xl space-y-4"
                                     x-data="{ previewUrl: '<?php echo htmlspecialchars(getUserAvatarUrl($user_full['avatar'] ?? '')); ?>' }">
                                    <h4 class="text-xs font-bold text-slate-700 dark:text-slate-350 uppercase tracking-wider font-display">Profile Photo *</h4>
                                    <div class="w-32 h-32 rounded-full border-4 border-gold/40 overflow-hidden bg-white shadow-md relative">
                                        <img :src="previewUrl" alt="Avatar Preview" class="w-full h-full object-cover">
                                    </div>
                                    <label class="cursor-pointer inline-block py-1.5 px-4 bg-bushgreen hover:bg-bushgreen-light text-white text-[10px] font-bold rounded-lg transition shadow uppercase tracking-wider">
                                        Choose Image
                                        <input type="file" name="profile_photo" class="hidden" accept="image/*" 
                                               @change="const file = $event.target.files[0]; if (file) { previewUrl = URL.createObjectURL(file); }">
                                    </label>
                                    <span class="block text-[8px] text-slate-400">Max size 2MB (JPG, PNG, WEBP)</span>
                                </div>
                                
                                <!-- Basic Fields (Col 8) -->
                                <div class="lg:col-span-8 grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <div>
                                        <label class="block text-slate-600 dark:text-slate-400 text-[10px] font-bold uppercase tracking-wider mb-1.5">Full Name *</label>
                                        <input type="text" name="name" required value="<?php echo htmlspecialchars($user_full['name'] ?? ''); ?>" class="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-750 rounded-xl text-xs focus:outline-none focus:border-bushgreen text-slate-800 dark:text-white">
                                    </div>
                                    <div>
                                        <label class="block text-slate-600 dark:text-slate-400 text-[10px] font-bold uppercase tracking-wider mb-1.5">Username / Alias *</label>
                                        <input type="text" name="username" required value="<?php echo htmlspecialchars($user_kyc['username'] ?? $user_full['email']); ?>" class="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-750 rounded-xl text-xs focus:outline-none focus:border-bushgreen text-slate-800 dark:text-white">
                                    </div>
                                    <div>
                                        <label class="block text-slate-600 dark:text-slate-400 text-[10px] font-bold uppercase tracking-wider mb-1.5">Email (Primary) *</label>
                                        <input type="email" value="<?php echo htmlspecialchars($user_full['email'] ?? ''); ?>" disabled class="w-full px-4 py-2.5 bg-slate-100 dark:bg-slate-950 border border-slate-200 dark:border-slate-750 rounded-xl text-xs text-slate-400 dark:text-slate-600 cursor-not-allowed">
                                    </div>
                                    <div>
                                        <label class="block text-slate-600 dark:text-slate-400 text-[10px] font-bold uppercase tracking-wider mb-1.5">Phone Number *</label>
                                        <input type="text" name="phone" required value="<?php echo htmlspecialchars($user_full['phone'] ?? ''); ?>" class="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-750 rounded-xl text-xs focus:outline-none focus:border-bushgreen text-slate-800 dark:text-white">
                                    </div>
                                    <div>
                                        <label class="block text-slate-600 dark:text-slate-400 text-[10px] font-bold uppercase tracking-wider mb-1.5">Gender *</label>
                                        <select name="gender" required class="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-750 rounded-xl text-xs focus:outline-none focus:border-bushgreen text-slate-800 dark:text-white">
                                            <option value="">-- Select Gender --</option>
                                            <option value="Male" <?php echo ($user_full['gender'] ?? '') === 'Male' ? 'selected' : ''; ?>>Male</option>
                                            <option value="Female" <?php echo ($user_full['gender'] ?? '') === 'Female' ? 'selected' : ''; ?>>Female</option>
                                            <option value="Other" <?php echo ($user_full['gender'] ?? '') === 'Other' ? 'selected' : ''; ?>>Other</option>
                                        </select>
                                    </div>
                                    <div>
                                        <label class="block text-slate-600 dark:text-slate-400 text-[10px] font-bold uppercase tracking-wider mb-1.5">Date of Birth *</label>
                                        <input type="date" name="dob" required value="<?php echo htmlspecialchars($user_kyc['dob'] ?? ''); ?>" class="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-750 rounded-xl text-xs focus:outline-none focus:border-bushgreen text-slate-800 dark:text-white">
                                    </div>
                                    <div>
                                        <label class="block text-slate-600 dark:text-slate-400 text-[10px] font-bold uppercase tracking-wider mb-1.5">Nationality *</label>
                                        <input type="text" name="nationality" required value="<?php echo htmlspecialchars($user_kyc['nationality'] ?? 'Nigerian'); ?>" class="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-750 rounded-xl text-xs focus:outline-none focus:border-bushgreen text-slate-800 dark:text-white">
                                    </div>
                                    <div>
                                        <label class="block text-slate-600 dark:text-slate-400 text-[10px] font-bold uppercase tracking-wider mb-1.5">State of Origin *</label>
                                        <select name="state_of_origin" required class="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-750 rounded-xl text-xs focus:outline-none focus:border-bushgreen text-slate-800 dark:text-white">
                                            <option value="">-- Choose Origin State --</option>
                                            <?php foreach ($states as $s): ?>
                                                <option value="<?php echo htmlspecialchars($s['name']); ?>" <?php echo ($user_kyc['state_of_origin'] ?? '') === $s['name'] ? 'selected' : ''; ?>><?php echo htmlspecialchars($s['name']); ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- RESIDENTIAL & LOCATION COORDINATES -->
                        <div class="space-y-6 animate-fade-in">
                            <h4 class="text-xs font-bold text-bushgreen dark:text-gold uppercase tracking-wider font-display">Residential & Location Coordinates</h4>
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div>
                                    <label class="block text-slate-600 dark:text-slate-400 text-[10px] font-bold uppercase tracking-wider mb-1.5">Residential Address *</label>
                                    <input type="text" name="address" required value="<?php echo htmlspecialchars($user_full['address'] ?? ''); ?>" placeholder="e.g. 15 Allen Avenue, Ikeja" class="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-750 rounded-xl text-xs focus:outline-none focus:border-bushgreen text-slate-800 dark:text-white">
                                </div>
                                <div>
                                    <label class="block text-slate-600 dark:text-slate-400 text-[10px] font-bold uppercase tracking-wider mb-1.5">State of Residence *</label>
                                    <select name="state_of_residence" required x-model="selectedResidenceState" @change="selectedResidenceLga = ''; selectedResidenceWard = ''; fetchWards('');" class="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-750 rounded-xl text-xs focus:outline-none focus:border-bushgreen text-slate-800 dark:text-white">
                                        <option value="">-- Choose State --</option>
                                        <?php foreach ($states as $s): ?>
                                            <option value="<?php echo htmlspecialchars($s['name']); ?>" <?php echo ($user_kyc['state_of_residence'] ?? '') === $s['name'] ? 'selected' : ''; ?>><?php echo htmlspecialchars($s['name']); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div>
                                    <label class="block text-slate-600 dark:text-slate-400 text-[10px] font-bold uppercase tracking-wider mb-1.5">Local Government (LGA) *</label>
                                    <select name="lga_id" required x-model="selectedResidenceLga" @change="fetchWards(selectedResidenceLga)" class="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-750 rounded-xl text-xs focus:outline-none focus:border-bushgreen text-slate-800 dark:text-white">
                                        <option value="">-- Choose LGA --</option>
                                        <template x-for="lg in filteredLgas(selectedResidenceState)" :key="lg.id">
                                            <option :value="lg.id" x-text="lg.name" :selected="selectedResidenceLga == lg.id"></option>
                                        </template>
                                    </select>
                                </div>
                                <div>
                                    <label class="block text-slate-600 dark:text-slate-400 text-[10px] font-bold uppercase tracking-wider mb-1.5">Ward Level *</label>
                                    <select name="ward_id" required x-model="selectedResidenceWard" class="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-750 rounded-xl text-xs focus:outline-none focus:border-bushgreen text-slate-800 dark:text-white">
                                        <option value="">-- Choose Ward --</option>
                                        <template x-for="wd in wards" :key="wd.id">
                                            <option :value="wd.id" x-text="wd.name" :selected="selectedResidenceWard == wd.id"></option>
                                        </template>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <!-- PASSPORT PHOTO & DOCUMENTS -->
                        <div class="space-y-6 animate-fade-in">
                            <h4 class="text-xs font-bold text-bushgreen dark:text-gold uppercase tracking-wider font-display">Biometric Verification & Document Upload Center</h4>
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div>
                                    <label class="block text-slate-600 dark:text-slate-400 text-[10px] font-bold uppercase tracking-wider mb-1">Government-Issued ID *</label>
                                    <input type="file" name="gov_id" id="gov_id" @change="triggerFaceMatch()" class="w-full text-xs text-slate-400 file:mr-2 file:py-1 file:px-3 file:rounded-lg file:border-0 file:text-[10px] file:font-semibold file:bg-slate-100 file:text-slate-700 dark:file:bg-slate-900 dark:file:text-slate-300 hover:file:bg-slate-200">
                                </div>
                                <div>
                                    <label class="block text-slate-600 dark:text-slate-400 text-[10px] font-bold uppercase tracking-wider mb-1">Passport Photograph *</label>
                                    <input type="file" name="passport_photo" @change="triggerFaceMatch()" class="w-full text-xs text-slate-400 file:mr-2 file:py-1 file:px-3 file:rounded-lg file:border-0 file:text-[10px] file:font-semibold file:bg-slate-100 file:text-slate-700 dark:file:bg-slate-900 dark:file:text-slate-300 hover:file:bg-slate-200">
                                </div>
                            </div>
                        </div>

                        <!-- DIGITAL SKILLS -->
                        <div class="space-y-6 animate-fade-in">
                            <h4 class="text-xs font-bold text-bushgreen dark:text-gold uppercase tracking-wider font-display mb-2">Digital Skills Training & Knowledge Grid</h4>
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                                <?php $core_skills = ['Web Development','AI Tools','Data Analytics','Digital Marketing']; foreach ($core_skills as $skill): ?>
                                    <label class="flex items-center gap-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 px-3 py-2 text-slate-700 dark:text-slate-300">
                                        <input type="checkbox" name="skills[<?php echo preg_replace('/[^a-zA-Z0-9]/', '', $skill); ?>]" value="have_skill" class="rounded text-bushgreen focus:ring-bushgreen">
                                        <?php echo htmlspecialchars($skill); ?>
                                    </label>
                                <?php endforeach; ?>
                            </div>
                        </div>
                                <div>
                                    <label class="block text-slate-600 dark:text-slate-400 text-[10px] font-bold uppercase tracking-wider mb-1.5">Highest Qualification *</label>
                                    <select name="highest_qualification" required class="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-750 rounded-xl text-xs focus:outline-none focus:border-bushgreen text-slate-800 dark:text-white">
                                        <option value="">-- Choose Qualification --</option>
                                        <?php 
                                        $quals = ["O'Level / High School", "National Diploma (ND)", "Higher National Diploma (HND)", "Bachelor's Degree", "Master's Degree", "Doctorate (PhD)", "Professional Certifications", "Other"];
                                        foreach ($quals as $q):
                                        ?>
                                            <option value="<?php echo $q; ?>" <?php echo ($user_kyc['highest_qualification'] ?? '') === $q ? 'selected' : ''; ?>><?php echo $q; ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div>
                                    <label class="block text-slate-600 dark:text-slate-400 text-[10px] font-bold uppercase tracking-wider mb-1.5">Institution Name *</label>
                                    <input type="text" name="institution" required value="<?php echo htmlspecialchars($user_kyc['institution'] ?? ''); ?>" placeholder="e.g. University of Lagos" class="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-750 rounded-xl text-xs focus:outline-none focus:border-bushgreen text-slate-800 dark:text-white">
                                </div>
                                <div>
                                    <label class="block text-slate-600 dark:text-slate-400 text-[10px] font-bold uppercase tracking-wider mb-1.5">Course of Study *</label>
                                    <input type="text" name="course_of_study" required value="<?php echo htmlspecialchars($user_kyc['course_of_study'] ?? ''); ?>" placeholder="e.g. Computer Science" class="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-750 rounded-xl text-xs focus:outline-none focus:border-bushgreen text-slate-800 dark:text-white">
                                </div>
                            </div>
                            <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
                                <div>
                                    <label class="block text-slate-600 dark:text-slate-400 text-[10px] font-bold uppercase tracking-wider mb-1.5">Graduation Year *</label>
                                    <input type="number" name="graduation_year" required min="1950" max="2030" value="<?php echo htmlspecialchars($user_kyc['graduation_year'] ?? ''); ?>" placeholder="e.g. 2022" class="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-750 rounded-xl text-xs focus:outline-none focus:border-bushgreen text-slate-800 dark:text-white">
                                </div>
                                <div>
                                    <label class="block text-slate-600 dark:text-slate-400 text-[10px] font-bold uppercase tracking-wider mb-1.5">Current Employer</label>
                                    <input type="text" name="employer" value="<?php echo htmlspecialchars($user_kyc['employer'] ?? ''); ?>" placeholder="e.g. Sterling Bank" class="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-750 rounded-xl text-xs focus:outline-none focus:border-bushgreen text-slate-800 dark:text-white">
                                </div>
                                <div>
                                    <label class="block text-slate-600 dark:text-slate-400 text-[10px] font-bold uppercase tracking-wider mb-1.5">Current Industry *</label>
                                    <select name="industry" required class="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-750 rounded-xl text-xs focus:outline-none focus:border-bushgreen text-slate-800 dark:text-white">
                                        <option value="">-- Choose Industry --</option>
                                        <?php 
                                        $inds = ["Technology / IT", "Agriculture / Farming", "Public Service", "Education", "Banking / Finance", "Healthcare / Med", "Creative / Arts", "Legal / Law", "Energy / Power", "Student", "Unemployed", "Other"];
                                        foreach ($inds as $i):
                                        ?>
                                            <option value="<?php echo $i; ?>" <?php echo ($user_kyc['industry'] ?? '') === $i ? 'selected' : ''; ?>><?php echo $i; ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div>
                                    <label class="block text-slate-600 dark:text-slate-400 text-[10px] font-bold uppercase tracking-wider mb-1.5">Occupation / Job *</label>
                                    <input type="text" name="occupation" required value="<?php echo htmlspecialchars($user_full['occupation'] ?? ''); ?>" placeholder="e.g. Advocate" class="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-750 rounded-xl text-xs focus:outline-none focus:border-bushgreen text-slate-800 dark:text-white">
                                </div>
                            </div>
                            <div>
                                <label class="block text-slate-600 dark:text-slate-400 text-[10px] font-bold uppercase tracking-wider mb-1.5">Skills & Areas of Professional Expertise *</label>
                                <textarea name="skills_expertise" required rows="3" placeholder="List core skills, programming languages, public speaking, community organizing experience..." class="w-full px-4 py-3 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-750 rounded-xl text-xs focus:outline-none focus:border-bushgreen text-slate-800 dark:text-white"><?php echo htmlspecialchars($user_kyc['skills_expertise'] ?? ''); ?></textarea>
                            </div>
                        </div>

                        <!-- Footer actions -->
                        <div class="pt-6 border-t border-slate-100 dark:border-slate-700 flex justify-end">
                            <button type="submit" name="save_mode" value="submit_kyc" class="py-2.5 px-6 bg-gradient-to-r from-bushgreen to-emerald-700 hover:from-bushgreen hover:to-emerald-800 text-white text-xs font-bold rounded-xl transition shadow-md border border-emerald-500/20">
                                Submit KYC Profile
                            </button>
                        </div>
                    </form>
                    <?php } ?>
                <?php
            } elseif (isset($_GET['tab']) && $_GET['tab'] === 'talent_pipeline') {
                $db = Database::connect();
                $stmt = $db->prepare("SELECT * FROM `talent_pipeline` WHERE `user_id` = ? ORDER BY `created_at` DESC");
                $stmt->execute([$user_id]);
                $talent_submissions = $stmt->fetchAll(PDO::FETCH_ASSOC);
                include __DIR__ . '/dashboards/shared_talent_pipeline.php';
            } else {
                $template_path = __DIR__ . '/dashboards/' . $sub_dashboard;
                if (file_exists($template_path)) {
                    include $template_path;
                } else {
                    include __DIR__ . '/dashboards/ambassador.php';
                }
            }
            ?>

            <!-- SHARED ALERTS & RECENT HISTORY WIDGETS -->
            <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <!-- Recent Briefs -->
                <div class="lg:col-span-2 bg-white rounded-3xl border border-slate-100 p-6 space-y-6 shadow-sm">
                    <h3 class="text-slate-800 font-bold text-sm font-display border-b border-slate-100 pb-3">Operational Briefing Archives</h3>
                    <div class="overflow-x-auto">
                        <table class="w-full text-xs text-left text-slate-500">
                            <thead class="text-[10px] text-slate-400 font-bold uppercase tracking-wider border-b border-slate-100">
                                <tr>
                                    <th class="pb-3">Title</th>
                                    <th class="pb-3">Filed By</th>
                                    <th class="pb-3">State</th>
                                    <th class="pb-3">Status</th>
                                    <th class="pb-3 text-right">Date</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-slate-50">
                                <?php foreach ($recent_reports as $rep): ?>
                                    <tr class="hover:bg-slate-50/50">
                                        <td class="py-3 font-semibold text-slate-800"><?php echo htmlspecialchars($rep['title']); ?></td>
                                        <td class="py-3"><?php echo htmlspecialchars($rep['author_name']); ?></td>
                                        <td class="py-3"><?php echo htmlspecialchars($rep['state_name']); ?></td>
                                        <td class="py-3">
                                            <span class="px-2.5 py-0.5 rounded-full text-[9px] font-bold uppercase tracking-wide
                                                <?php echo $rep['status'] === 'approved' ? 'bg-emerald-50 text-emerald-800 border border-emerald-200' : 'bg-amber-50 text-amber-800 border border-amber-200'; ?>">
                                                <?php echo htmlspecialchars($rep['status']); ?>
                                            </span>
                                        </td>
                                        <td class="py-3 text-right text-slate-400"><?php echo date('Y-m-d', strtotime($rep['created_at'])); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- Notifications Panel -->
                <div class="bg-white rounded-3xl border border-slate-100 p-6 shadow-sm space-y-6">
                    <h3 class="text-slate-800 font-bold text-sm font-display border-b border-slate-100 pb-3">Strategic Alerts circulars</h3>
                    
                    <div class="space-y-4">
                        <?php foreach ($notifications as $note): ?>
                            <div class="p-3 bg-slate-50 border border-slate-100 rounded-2xl flex gap-2 text-xs">
                                <span class="w-2 h-2 rounded-full flex-shrink-0 mt-1.5 <?php echo $note['is_read'] ? 'bg-slate-300' : 'bg-gold animate-pulse'; ?>"></span>
                                <div class="space-y-1">
                                    <p class="text-slate-700 leading-relaxed font-light"><?php echo htmlspecialchars($note['message']); ?></p>
                                    <span class="text-[9px] text-slate-400 block"><?php echo date('M d, H:i', strtotime($note['created_at'])); ?></span>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>

        </main>
    </div>

    <!-- ChartJS Configurations -->
    <?php if (Auth::hasRole(['super_admin', 'founder_circle', 'national_steering'])): ?>
        <script>
            document.addEventListener("DOMContentLoaded", function() {
                const ctx = document.getElementById('stateAdvocacyChart').getContext('2d');
                new Chart(ctx, {
                    type: 'bar',
                    data: {
                        labels: <?php echo json_encode(array_column($state_data, 'name')); ?>,
                        datasets: [{
                            label: 'Ambassadors Count',
                            data: <?php echo json_encode(array_column($state_data, 'ambassador_count')); ?>,
                            backgroundColor: '#063C1E',
                            borderColor: '#D4AF37',
                            borderWidth: 1,
                            borderRadius: 6
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: { display: false }
                        },
                        scales: {
                            y: {
                                beginAtZero: true,
                                grid: { color: '#E2E8F0' }
                            },
                            x: {
                                grid: { display: false }
                            }
                        }
                    }
                });
            });
        </script>
    <?php endif; ?>
</body>
</html>
