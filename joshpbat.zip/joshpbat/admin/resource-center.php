<?php
/**
 * PBAT Smart Nation Initiative - Command Resource Centre
 * Highly polished interactive portal with customized training, ethical codes, 
 * and dashboard orientation walkthroughs for all 7 roles.
 */
require_once dirname(__DIR__) . '/helpers/auth.php';
require_once dirname(__DIR__) . '/helpers/common.php';
require_once dirname(__DIR__) . '/config/database.php';

if (!Auth::isLoggedIn()) {
    $_SESSION['auth_error'] = "You must log in to access the Command Resource Centre.";
    header("Location: ../login.php");
    exit;
}

$user = Auth::user();
$role = $user['role'];
$user_id = $user['id'];

// Resolve zone coordinate
$user_zone = 'National';
$db = null;
try {
    $db = Database::connect();
    if ($role === 'ambassador') {
        $stmt = $db->prepare("SELECT s.zone FROM `ambassadors` a JOIN `states` s ON a.state_id = s.id WHERE a.user_id = ? LIMIT 1");
        $stmt->execute([$user_id]);
        $user_zone = $stmt->fetchColumn() ?: 'National';
    } else {
        $stmt = $db->prepare("SELECT s.zone FROM `user_leadership` ul JOIN `states` s ON ul.state_id = s.id WHERE ul.user_id = ? LIMIT 1");
        $stmt->execute([$user_id]);
        $user_zone = $stmt->fetchColumn() ?: 'National';
    }
} catch (Exception $e) {
    $user_zone = 'National';
}

$success_msg = '';
$error_msg = '';

if ($db && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'upload_resource' && $role === 'super_admin') {
        if (!Auth::validateCsrf($_POST['csrf_token'] ?? '')) {
            $error_msg = "Security validation expired. Upload aborted.";
        } else {
            $title = sanitize($_POST['title'] ?? '');
            $description = sanitize($_POST['description'] ?? '');
            $target_role = sanitize($_POST['target_role'] ?? 'all');
            
            if (empty($title) || !isset($_FILES['resource_file']) || $_FILES['resource_file']['error'] !== UPLOAD_ERR_OK) {
                $error_msg = "Title and File are required.";
            } else {
                $file = $_FILES['resource_file'];
                $file_name = basename($file['name']);
                $file_size = $file['size'];
                $file_tmp = $file['tmp_name'];
                $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
                
                $allowed_extensions = ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'zip', 'png', 'jpg', 'jpeg'];
                if (!in_array($file_ext, $allowed_extensions)) {
                    $error_msg = "Invalid file extension. Allowed: " . implode(', ', $allowed_extensions);
                } elseif ($file_size > 10485760) { // 10MB
                    $error_msg = "File size exceeds 10MB limit.";
                } else {
                    $upload_dir = dirname(__DIR__) . '/uploads/resources/';
                    if (!is_dir($upload_dir)) {
                        @mkdir($upload_dir, 0755, true);
                    }
                    
                    $new_file_name = uniqid('RES-', true) . '.' . $file_ext;
                    $target_path = $upload_dir . $new_file_name;
                    $db_path = 'uploads/resources/' . $new_file_name;
                    
                    if (move_uploaded_file($file_tmp, $target_path)) {
                        try {
                            $stmt_ins = $db->prepare("INSERT INTO `command_resources` (`title`, `description`, `file_path`, `file_type`, `target_role`, `uploaded_by`) VALUES (?, ?, ?, ?, ?, ?)");
                            $stmt_ins->execute([$title, $description, $db_path, $file_ext, $target_role, $user_id]);
                            
                            Auth::logAction($user_id, 'RESOURCE_UPLOAD', "Uploaded resource: '{$title}' for target role: {$target_role}");
                            $success_msg = "Resource '{$title}' uploaded successfully!";
                        } catch (Exception $e) {
                            $error_msg = "Database Error: " . $e->getMessage();
                        }
                    } else {
                        $error_msg = "Failed to move uploaded file.";
                    }
                }
            }
        }
    } elseif ($_POST['action'] === 'delete_resource' && $role === 'super_admin') {
        if (!Auth::validateCsrf($_POST['csrf_token'] ?? '')) {
            $error_msg = "Security validation expired. Delete aborted.";
        } else {
            $delete_id = (int)$_POST['delete_id'];
            try {
                $stmt_file = $db->prepare("SELECT `file_path`, `title` FROM `command_resources` WHERE `id` = ?");
                $stmt_file->execute([$delete_id]);
                $res_data = $stmt_file->fetch();
                
                if ($res_data) {
                    $full_path = dirname(__DIR__) . '/' . $res_data['file_path'];
                    if (file_exists($full_path)) {
                        @unlink($full_path);
                    }
                    
                    $stmt_del = $db->prepare("DELETE FROM `command_resources` WHERE `id` = ?");
                    $stmt_del->execute([$delete_id]);
                    
                    Auth::logAction($user_id, 'RESOURCE_DELETE', "Deleted resource: '{$res_data['title']}'");
                    $success_msg = "Resource deleted successfully!";
                } else {
                    $error_msg = "Resource not found.";
                }
            } catch (Exception $e) {
                $error_msg = "Database Error: " . $e->getMessage();
            }
        }
    }
}

// Fetch resources
$resources = [];
if ($db) {
    try {
        if ($role === 'super_admin') {
            $stmt_res = $db->query("SELECT r.*, u.name as uploader_name FROM `command_resources` r JOIN `users` u ON r.uploaded_by = u.id ORDER BY r.created_at DESC");
            $resources = $stmt_res->fetchAll();
        } else {
            $stmt_res = $db->prepare("SELECT r.*, u.name as uploader_name FROM `command_resources` r JOIN `users` u ON r.uploaded_by = u.id WHERE r.target_role = 'all' OR r.target_role = ? ORDER BY r.created_at DESC");
            $stmt_res->execute([$role]);
            $resources = $stmt_res->fetchAll();
        }
    } catch (Exception $e) {
        $resources = [];
    }
}

// Define the role hierarchy and labels
$role_labels = [
    'super_admin'       => 'Super Admin / Master Control',
    'founder_circle'    => 'Founder\'s Circle Executive',
    'national_steering' => 'National Steering Director',
    'zonal_chairman'    => 'Zonal Chairman Coordinate',
    'state_chairman'    => 'State Chapter Chairman',
    'coordinator'       => 'LGA Coordinator',
    'ambassador'        => 'Grassroots Ward Ambassador'
];

$my_label = $role_labels[$role] ?? 'Staff';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Command Resource Centre - PBAT Smart Nation</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        bushgreen: {
                            DEFAULT: '#063C1E',
                            light: '#0A4D27',
                            dark: '#03200F',
                        },
                        gold: '#D4AF37'
                    }
                }
            }
        }
    </script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;750;900&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
    <style>
        [x-cloak] { display: none !important; }
        body { font-family: 'Inter', sans-serif; }
        h1, h2, h3, h4, .font-display { font-family: 'Outfit', sans-serif; }
    </style>
</head>
<body class="bg-slate-50 text-slate-800 transition-colors duration-200 min-h-screen flex flex-col antialiased"
      x-data="{ 
          darkMode: localStorage.getItem('darkMode') === 'true',
          activeSection: 'orientation'
      }"
      x-init="$watch('darkMode', val => localStorage.setItem('darkMode', val))"
      :class="{ 'dark bg-slate-900 text-slate-100': darkMode }">

    <!-- Header Navbar -->
    <header class="bg-bushgreen text-white border-b-2 border-gold h-20 flex items-center justify-between px-6 shadow-md relative z-30">
        <div class="flex items-center gap-3">
            <a href="dashboard.php" class="py-1.5 px-3 border border-white/20 hover:bg-white/10 text-white rounded-lg text-xs font-bold transition">
                &larr; Back to Dashboard
            </a>
            <div class="w-8 h-8 rounded bg-white/10 flex items-center justify-center border border-white/20 p-1 flex-shrink-0">
                <?php echo getAppLogoHtml('w-full h-full object-contain', 'dashboard'); ?>
            </div>
            <span class="text-white font-extrabold text-sm font-display hidden sm:inline">PBAT SMART NATION INITIATIVE</span>
        </div>
        <div class="flex items-center gap-4 text-xs font-bold text-gold uppercase tracking-wider font-display">
            <!-- Dark Mode Toggle -->
            <button @click="darkMode = !darkMode" class="p-2 rounded-lg border border-gold/45 text-gold hover:bg-gold/10 transition flex items-center justify-center">
                <svg x-show="darkMode" class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364-6.364l-.707.707M6.364 17.636l-.707.707M18.364 17.636l-.707-.707M6.364 6.364l-.707-.707M15 12a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                <svg x-show="!darkMode" class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z"/></svg>
            </button>
            <span>Command Resource Centre</span>
        </div>
    </header>

    <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 flex-grow w-full space-y-10">

        <?php if (!empty($success_msg)): ?>
            <div class="p-4 bg-emerald-50 dark:bg-emerald-950/20 border-l-4 border-emerald-500 text-emerald-850 dark:text-emerald-400 rounded-r-xl text-xs font-bold flex items-center gap-2">
                <svg class="w-4 h-4 text-emerald-500" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/></svg>
                <span><?php echo htmlspecialchars($success_msg); ?></span>
            </div>
        <?php endif; ?>

        <?php if (!empty($error_msg)): ?>
            <div class="p-4 bg-red-50 dark:bg-red-950/20 border-l-4 border-red-500 text-red-850 dark:text-red-400 rounded-r-xl text-xs font-bold flex items-center gap-2">
                <svg class="w-4 h-4 text-red-500" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clip-rule="evenodd"/></svg>
                <span><?php echo htmlspecialchars($error_msg); ?></span>
            </div>
        <?php endif; ?>
        
        <!-- Welcome Banner -->
        <div class="bg-gradient-to-r from-bushgreen-dark to-bushgreen border border-gold/30 rounded-3xl p-6 sm:p-8 md:p-10 shadow-xl relative overflow-hidden flex flex-col md:flex-row justify-between items-center gap-6">
            <div class="absolute top-0 right-0 w-[400px] h-[400px] bg-gold/5 rounded-full blur-[100px] pointer-events-none"></div>
            <div class="space-y-3 max-w-2xl text-center md:text-left">
                <div class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 border border-white/20 backdrop-blur-sm">
                    <span class="w-1.5 h-1.5 rounded-full bg-gold animate-pulse"></span>
                    <span class="text-gold font-bold text-[9px] uppercase tracking-widest leading-none font-display">Command Academy</span>
                </div>
                <h1 class="text-2xl sm:text-3xl md:text-4xl font-extrabold text-white font-display uppercase tracking-tight">Command Resource Centre</h1>
                <p class="text-slate-300 text-xs sm:text-sm font-light leading-relaxed">
                    Welcome, <strong><?php echo htmlspecialchars($user['name']); ?></strong>. As a <strong><?php echo htmlspecialchars($my_label); ?></strong> in the <?php echo htmlspecialchars($user_zone); ?> Coordinate, this interactive resource panel holds your operational orientation manuals, ethical standards, and interactive dashboard orientation manuals.
                </p>
            </div>
            <div class="flex-shrink-0 bg-white/5 border border-white/10 rounded-2xl p-4 text-center">
                <span class="text-[9px] uppercase font-bold tracking-wider text-gold block">Your Access Tier</span>
                <span class="text-white font-bold text-sm tracking-wide font-display mt-1 block uppercase"><?php echo str_replace('_', ' ', $role); ?></span>
            </div>
        </div>

        <!-- Layout Grids -->
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            
            <!-- Navigation Tabs Sidebar (Col 3) -->
            <div class="lg:col-span-3 space-y-2">
                <button @click="activeSection = 'orientation'" :class="activeSection === 'orientation' ? 'bg-bushgreen text-white dark:bg-gold dark:text-bushgreen border-l-4 border-gold' : 'bg-white dark:bg-slate-800 text-slate-655 hover:bg-slate-100/50'" class="w-full text-left p-4 rounded-xl text-xs font-bold transition flex items-center gap-3 shadow-sm">
                    <span class="text-sm">🧭</span>
                    Dashboard Orientation
                </button>
                <button @click="activeSection = 'training'" :class="activeSection === 'training' ? 'bg-bushgreen text-white dark:bg-gold dark:text-bushgreen border-l-4 border-gold' : 'bg-white dark:bg-slate-800 text-slate-655 hover:bg-slate-100/50'" class="w-full text-left p-4 rounded-xl text-xs font-bold transition flex items-center gap-3 shadow-sm">
                    <span class="text-sm">📚</span>
                    Operational Training
                </button>
                <button @click="activeSection = 'ethics'" :class="activeSection === 'ethics' ? 'bg-bushgreen text-white dark:bg-gold dark:text-bushgreen border-l-4 border-gold' : 'bg-white dark:bg-slate-800 text-slate-655 hover:bg-slate-100/50'" class="w-full text-left p-4 rounded-xl text-xs font-bold transition flex items-center gap-3 shadow-sm">
                    <span class="text-sm">📜</span>
                    Ethical Code of Conduct
                </button>
                <button @click="activeSection = 'downloads'" :class="activeSection === 'downloads' ? 'bg-bushgreen text-white dark:bg-gold dark:text-bushgreen border-l-4 border-gold' : 'bg-white dark:bg-slate-800 text-slate-655 hover:bg-slate-100/50'" class="w-full text-left p-4 rounded-xl text-xs font-bold transition flex items-center gap-3 shadow-sm">
                    <span class="text-sm">📥</span>
                    Training Assets Download
                </button>
            </div>

            <!-- Content Area (Col 9) -->
            <div class="lg:col-span-9 bg-white dark:bg-slate-800 border border-slate-100 dark:border-slate-700 rounded-3xl p-6 sm:p-8 shadow-sm">
                
                <!-- SECTION 1: DASHBOARD ORIENTATION -->
                <div x-show="activeSection === 'orientation'" x-transition class="space-y-6">
                    <div class="border-b border-slate-100 dark:border-slate-700 pb-4">
                        <h2 class="text-lg sm:text-xl font-black text-bushgreen dark:text-gold uppercase tracking-tight font-display">Dashboard Navigation Orientation</h2>
                        <p class="text-slate-500 dark:text-slate-400 text-xs font-light mt-1">Orientation walkthrough of your specific dashboard buttons, menus, and tools.</p>
                    </div>

                    <?php if ($role === 'super_admin'): ?>
                        <div class="space-y-4 text-xs font-light leading-relaxed">
                            <p>As the **Super Admin**, your master dashboard operates as the Command Hub. Below is an overview of the tools at your disposal:</p>
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
                                <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-150 dark:border-slate-800 rounded-2xl space-y-1.5">
                                    <h4 class="font-bold text-slate-850 dark:text-white">1. Live Command Center</h4>
                                    <p class="text-slate-500 dark:text-slate-400">Monitor active user logins, database status, transaction queues, and error reports in real-time.</p>
                                </div>
                                <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-150 dark:border-slate-800 rounded-2xl space-y-1.5">
                                    <h4 class="font-bold text-slate-850 dark:text-white">2. User & RBAC Matrix Editor</h4>
                                    <p class="text-slate-500 dark:text-slate-400">View list of users, ban/activate coordinates, change role privileges, and edit user tier roles dynamically.</p>
                                </div>
                                <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-150 dark:border-slate-800 rounded-2xl space-y-1.5">
                                    <h4 class="font-bold text-slate-850 dark:text-white">3. Talent Pipeline Moderation</h4>
                                    <p class="text-slate-500 dark:text-slate-400">Audit registrations, select shortlisted profiles, update steering directorate notes, and toggle statuses.</p>
                                </div>
                                <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-150 dark:border-slate-800 rounded-2xl space-y-1.5">
                                    <h4 class="font-bold text-slate-850 dark:text-white">4. Sponsors & Feedback Console</h4>
                                    <p class="text-slate-500 dark:text-slate-400">Track and respond to sponsors proposals, public contact forms, and export subscribers registry to CSV files.</p>
                                </div>
                            </div>
                        </div>

                    <?php elseif ($role === 'founder_circle'): ?>
                        <div class="space-y-4 text-xs font-light leading-relaxed">
                            <p>As a member of the **Founder\'s Circle**, your orientation guides you through strategic direction tools:</p>
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
                                <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-150 dark:border-slate-800 rounded-2xl space-y-1.5">
                                    <h4 class="font-bold text-slate-850 dark:text-white">1. Vision & Policy Directorate</h4>
                                    <p class="text-slate-500 dark:text-slate-400">Publish strategic visions and core nation guidelines that are displayed to all grassroots ambassadors.</p>
                                </div>
                                <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-150 dark:border-slate-800 rounded-2xl space-y-1.5">
                                    <h4 class="font-bold text-slate-850 dark:text-white">2. Think-Tank Forum</h4>
                                    <p class="text-slate-500 dark:text-slate-400">Draft topics of technological interest to invite steering committee debates and strategic inputs.</p>
                                </div>
                                <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-150 dark:border-slate-800 rounded-2xl space-y-1.5">
                                    <h4 class="font-bold text-slate-850 dark:text-white">3. Strategic Partnerships console</h4>
                                    <p class="text-slate-500 dark:text-slate-400">Review corporate proposals, register active sponsors, and keep notes on national tech rollouts.</p>
                                </div>
                                <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-150 dark:border-slate-800 rounded-2xl space-y-1.5">
                                    <h4 class="font-bold text-slate-850 dark:text-white">4. Executive Broadcast Center</h4>
                                    <p class="text-slate-500 dark:text-slate-400">Dispatch email broadcasts and important circular bulletins to all registered members nationwide.</p>
                                </div>
                            </div>
                        </div>

                    <?php elseif ($role === 'national_steering'): ?>
                        <div class="space-y-4 text-xs font-light leading-relaxed">
                            <p>As a **National Steering Director**, your orientation focuses on national coordination and operational management:</p>
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
                                <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-150 dark:border-slate-800 rounded-2xl space-y-1.5">
                                    <h4 class="font-bold text-slate-850 dark:text-white">1. Operations Performance Dashboard</h4>
                                    <p class="text-slate-500 dark:text-slate-400">Track state-by-state ambassador enlistments and activity index via charts and interactive metrics.</p>
                                </div>
                                <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-150 dark:border-slate-800 rounded-2xl space-y-1.5">
                                    <h4 class="font-bold text-slate-850 dark:text-white">2. Operations Target Assignment</h4>
                                    <p class="text-slate-500 dark:text-slate-400">Assign task deadlines and mobilization goals directly to Zonal and State Chairman coordinate accounts.</p>
                                </div>
                                <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-150 dark:border-slate-800 rounded-2xl space-y-1.5">
                                    <h4 class="font-bold text-slate-850 dark:text-white">3. Activity Briefings review</h4>
                                    <p class="text-slate-500 dark:text-slate-400">Vett reports submitted by State Chairmen and local Coordinators; approve or shortlist achievements.</p>
                                </div>
                                <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-150 dark:border-slate-800 rounded-2xl space-y-1.5">
                                    <h4 class="font-bold text-slate-850 dark:text-white">4. Resource Documents CMS</h4>
                                    <p class="text-slate-500 dark:text-slate-400">Maintain training documents, slides, and files displayed to lower tiers inside the download center.</p>
                                </div>
                            </div>
                        </div>

                    <?php elseif ($role === 'zonal_chairman'): ?>
                        <div class="space-y-4 text-xs font-light leading-relaxed">
                            <p>As a **Zonal Chairman**, your orientation outlines your regional oversight dashboard tabs:</p>
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
                                <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-150 dark:border-slate-800 rounded-2xl space-y-1.5">
                                    <h4 class="font-bold text-slate-850 dark:text-white">1. State Chapter Oversight</h4>
                                    <p class="text-slate-500 dark:text-slate-400">Validate active state chairmen details, trace coordinates, and monitor local statistics.</p>
                                </div>
                                <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-150 dark:border-slate-800 rounded-2xl space-y-1.5">
                                    <h4 class="font-bold text-slate-850 dark:text-white">2. Regional Directives Hub</h4>
                                    <p class="text-slate-500 dark:text-slate-400">Broadcast instructions, campaign schedules, and notices to State Chairmen within your geopolitical zone.</p>
                                </div>
                                <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-150 dark:border-slate-800 rounded-2xl space-y-1.5">
                                    <h4 class="font-bold text-slate-850 dark:text-white">3. Report validation gate</h4>
                                    <p class="text-slate-500 dark:text-slate-400">Verify local briefings filed within your zone before they are pushed to the National Steering Council database.</p>
                                </div>
                                <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-150 dark:border-slate-800 rounded-2xl space-y-1.5">
                                    <h4 class="font-bold text-slate-850 dark:text-white">4. Zonal Honors Board</h4>
                                    <p class="text-slate-500 dark:text-slate-400">Distribute reward points and recommendation statuses to active state chapters and coordinators.</p>
                                </div>
                            </div>
                        </div>

                    <?php elseif ($role === 'state_chairman'): ?>
                        <div class="space-y-4 text-xs font-light leading-relaxed">
                            <p>As a **State Chapter Chairman**, your orientation guides you through state chapter operations panels:</p>
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
                                <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-150 dark:border-slate-800 rounded-2xl space-y-1.5">
                                    <h4 class="font-bold text-slate-850 dark:text-white">1. Local Government coordinator registry</h4>
                                    <p class="text-slate-500 dark:text-slate-400">Review LGA coordinator registrations, approve active status, and assign local jurisdictions.</p>
                                </div>
                                <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-150 dark:border-slate-800 rounded-2xl space-y-1.5">
                                    <h4 class="font-bold text-slate-850 dark:text-white">2. State Chapters Directives</h4>
                                    <p class="text-slate-500 dark:text-slate-400">Send direct operational briefs and campaign schedules to all coordinators inside the state.</p>
                                </div>
                                <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-150 dark:border-slate-800 rounded-2xl space-y-1.5">
                                    <h4 class="font-bold text-slate-850 dark:text-white">3. Local Activity Reports Vetting</h4>
                                    <p class="text-slate-500 dark:text-slate-400">Monitor LGA events and filed reports; elevate reports to Zonal and National dashboard streams.</p>
                                </div>
                                <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-150 dark:border-slate-800 rounded-2xl space-y-1.5">
                                    <h4 class="font-bold text-slate-850 dark:text-white">4. State Heatmap Analytics</h4>
                                    <p class="text-slate-500 dark:text-slate-400">Trace ambassador density, count active mobilization units, and review local digital training progress.</p>
                                </div>
                            </div>
                        </div>

                    <?php elseif ($role === 'coordinator'): ?>
                        <div class="space-y-4 text-xs font-light leading-relaxed">
                            <p>As an **LGA Coordinator**, your dashboard orientation walks you through local operation panels:</p>
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
                                <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-150 dark:border-slate-800 rounded-2xl space-y-1.5">
                                    <h4 class="font-bold text-slate-850 dark:text-white">1. Ambassador Register & Onboarding</h4>
                                    <p class="text-slate-500 dark:text-slate-400">Manage ward ambassador profiles, confirm KYC submissions, verify details, and approve credentials.</p>
                                </div>
                                <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-150 dark:border-slate-800 rounded-2xl space-y-1.5">
                                    <h4 class="font-bold text-slate-850 dark:text-white">2. Local Campaigns & Events Scheduler</h4>
                                    <p class="text-slate-500 dark:text-slate-400">Schedule local coding sessions, AI workshops, and community sensitizations inside your LGA.</p>
                                </div>
                                <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-150 dark:border-slate-800 rounded-2xl space-y-1.5">
                                    <h4 class="font-bold text-slate-850 dark:text-white">3. Activity Briefings Upload</h4>
                                    <p class="text-slate-500 dark:text-slate-400">File official reports to the state chapter regarding tech rollouts, with pictures or PDF media links.</p>
                                </div>
                                <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-150 dark:border-slate-800 rounded-2xl space-y-1.5">
                                    <h4 class="font-bold text-slate-850 dark:text-white">4. Digital ID & QR validation</h4>
                                    <p class="text-slate-500 dark:text-slate-400">Scan QR codes on ambassador identity cards to confirm active membership status in field operations.</p>
                                </div>
                            </div>
                        </div>

                    <?php elseif ($role === 'ambassador'): ?>
                        <div class="space-y-4 text-xs font-light leading-relaxed">
                            <p>As a **Grassroots Ward Ambassador**, your orientation guide explains your advocacy dashboard tabs:</p>
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
                                <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-150 dark:border-slate-800 rounded-2xl space-y-1.5">
                                    <h4 class="font-bold text-slate-850 dark:text-white">1. Ambassador Hub Dashboard</h4>
                                    <p class="text-slate-500 dark:text-slate-400">Monitor your active point score and leadership level. The more points you gather, the higher you rise in the national registry.</p>
                                </div>
                                <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-150 dark:border-slate-800 rounded-2xl space-y-1.5">
                                    <h4 class="font-bold text-slate-850 dark:text-white">2. Tasks & Outreach Missions</h4>
                                    <p class="text-slate-500 dark:text-slate-400">Access active task directives. Claim points upon completing community outreach and tech awareness programs.</p>
                                </div>
                                <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-150 dark:border-slate-800 rounded-2xl space-y-1.5">
                                    <h4 class="font-bold text-slate-850 dark:text-white">3. Outreach Reports Center</h4>
                                    <p class="text-slate-500 dark:text-slate-400">File sensitization briefs summarizing local activities. Earn up to +15 points for every field briefing approved.</p>
                                </div>
                                <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-150 dark:border-slate-800 rounded-2xl space-y-1.5">
                                    <h4 class="font-bold text-slate-850 dark:text-white">4. Digital ID Badge Panel</h4>
                                    <p class="text-slate-500 dark:text-slate-400">Download, view, or trigger print layouts for your smart QR-code verified ambassador badge credentials.</p>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- SECTION 2: OPERATIONAL TRAINING -->
                <div x-show="activeSection === 'training'" x-cloak x-transition class="space-y-6">
                    <div class="border-b border-slate-100 dark:border-slate-700 pb-4">
                        <h2 class="text-lg sm:text-xl font-black text-bushgreen dark:text-gold uppercase tracking-tight font-display">Operational Duties & Training Manual</h2>
                        <p class="text-slate-500 dark:text-slate-400 text-xs font-light mt-1">Specific guidelines on how to execute your role tasks and coordinate with the hierarchy.</p>
                    </div>

                    <?php if ($role === 'super_admin'): ?>
                        <div class="space-y-4 text-xs font-light leading-relaxed">
                            <h4 class="font-bold text-bushgreen dark:text-gold uppercase tracking-wider font-display">Master Control Operations</h4>
                            <ul class="list-disc pl-5 space-y-2">
                                <li><strong>User Security Vetting</strong>: Regularly audit user logs. Pay special attention to coordinates check-in records and KYC status files to prevent fraudulent entries.</li>
                                <li><strong>RBAC Operations</strong>: Maintain standard security rules. Avoid altering permissions without official directives from the Founder\'s Circle.</li>
                                <li><strong>Talent Pipeline Moderation</strong>: Actively moderate the talent pipeline. Move registrations to `shortlisted` or `approved` based on the validation notes provided by coordinators.</li>
                            </ul>
                        </div>

                    <?php elseif ($role === 'founder_circle'): ?>
                        <div class="space-y-4 text-xs font-light leading-relaxed">
                            <h4 class="font-bold text-bushgreen dark:text-gold uppercase tracking-wider font-display">Strategic Leadership Operations</h4>
                            <ul class="list-disc pl-5 space-y-2">
                                <li><strong>National Agenda Alignment</strong>: Work closely with national development committees to ensure all campaigns support national tech adoption roadmaps.</li>
                                <li><strong>Think-Tank Facilitation</strong>: Propose constructive debate topics once every fortnight. Summarize steering council feedback and prepare reports for regional chairmen.</li>
                                <li><strong>Publicity & Collaboration Vetting</strong>: Ensure all sponsors, corporate partners, and resource contributions align with our non-profit, non-governmental charter.</li>
                            </ul>
                        </div>

                    <?php elseif ($role === 'national_steering'): ?>
                        <div class="space-y-4 text-xs font-light leading-relaxed">
                            <h4 class="font-bold text-bushgreen dark:text-gold uppercase tracking-wider font-display">Operations Coordination Manual</h4>
                            <ul class="list-disc pl-5 space-y-2">
                                <li><strong>Campaign Scheduling</strong>: Draft and align campaigns to keep regional coordination channels active. Provide state chapters with promotional templates.</li>
                                <li><strong>Task Progress Tracking</strong>: Follow up on task deadlines. When a Zonal Chairman flags a lagging state chapter, dispatch support instructions.</li>
                                <li><strong>Report Auditing</strong>: Audit briefings submitted from the field. Make sure media links and event logs are valid before marking them as approved.</li>
                            </ul>
                        </div>

                    <?php elseif ($role === 'zonal_chairman'): ?>
                        <div class="space-y-4 text-xs font-light leading-relaxed">
                            <h4 class="font-bold text-bushgreen dark:text-gold uppercase tracking-wider font-display">Geopolitical Regional Vetting</h4>
                            <ul class="list-disc pl-5 space-y-2">
                                <li><strong>Zonal Coordination Meetings</strong>: Coordinate state chairmen within your zone via bi-weekly virtual check-ins. Set state-level target deadlines.</li>
                                <li><strong>Briefing Verifications</strong>: Review reports from states. Confirm state-level events took place before updating their progress indicators.</li>
                                <li><strong>Ambassador Network Validation</strong>: Validate coordinator appointments in states. Review candidate credentials before confirming state leaders.</li>
                            </ul>
                        </div>

                    <?php elseif ($role === 'state_chairman'): ?>
                        <div class="space-y-4 text-xs font-light leading-relaxed">
                            <h4 class="font-bold text-bushgreen dark:text-gold uppercase tracking-wider font-display">State Chapter Operations</h4>
                            <ul class="list-disc pl-5 space-y-2">
                                <li><strong>LGA Coordinator Vetting</strong>: Ensure LGA coordinators submit their Government ID and LGA coordinate verifications before activation.</li>
                                <li><strong>Outreach Supervision</strong>: Inspect local town halls and tech sensitization workshops. Provide materials and template handouts to coordinators.</li>
                                <li><strong>State Data Accuracy</strong>: Verify that local briefings submitted by coordinators are backed by coordinator signatures and participant listings.</li>
                            </ul>
                        </div>

                    <?php elseif ($role === 'coordinator'): ?>
                        <div class="space-y-4 text-xs font-light leading-relaxed">
                            <h4 class="font-bold text-bushgreen dark:text-gold uppercase tracking-wider font-display">LGA Coordination Operations</h4>
                            <ul class="list-disc pl-5 space-y-2">
                                <li><strong>Ambassador KYC Validation</strong>: Ensure every registered ambassador completes their basic details, uploads a clear passport photograph, and captures their geolocation.</li>
                                <li><strong>Local Workshop Organization</strong>: Run coding classes and AI seminars. File reports including pictures, lists of attendees, and summary of topics.</li>
                                <li><strong>ID Verification Gate</strong>: Coordinate field operations by scanning QR codes on ambassador ID cards to verify credential parameters.</li>
                            </ul>
                        </div>

                    <?php elseif ($role === 'ambassador'): ?>
                        <div class="space-y-4 text-xs font-light leading-relaxed">
                            <h4 class="font-bold text-bushgreen dark:text-gold uppercase tracking-wider font-display">Grassroots Advocacy Operations</h4>
                            <ul class="list-disc pl-5 space-y-2">
                                <li><strong>Community Mobilization</strong>: Engage local youths at the ward level. Share digital literacy brochures, explain software career roadmaps, and organize study circles.</li>
                                <li><strong>Task Checklist Execution</strong>: Regularly check your dashboard for active missions. Click "Claim Mission Reward" only after satisfying the task coordinates.</li>
                                <li><strong>Field Report Submission</strong>: Submit a report for every outreach event. Include detailed notes and description of community tech challenges.</li>
                            </ul>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- SECTION 3: ETHICAL CODE OF CONDUCT -->
                <div x-show="activeSection === 'ethics'" x-cloak x-transition class="space-y-6">
                    <div class="border-b border-slate-100 dark:border-slate-700 pb-4">
                        <h2 class="text-lg sm:text-xl font-black text-bushgreen dark:text-gold uppercase tracking-tight font-display">Ethical standards & Code of Conduct</h2>
                        <p class="text-slate-505 dark:text-slate-400 text-xs font-light mt-1">Core rules of conduct to ensure transparency, data integrity, and local coordination standards.</p>
                    </div>

                    <div class="space-y-4 text-xs font-light leading-relaxed">
                        <p>All members of the **PBAT Smart Nation Initiative** are expected to strictly adhere to the following values in their operations:</p>
                        
                        <div class="space-y-3 pt-2">
                            <div class="p-4 bg-emerald-50/40 dark:bg-slate-900 border-l-4 border-bushgreen dark:border-gold rounded-r-2xl space-y-1">
                                <h4 class="font-bold text-bushgreen dark:text-gold">1. Data Integrity and Honesty</h4>
                                <p class="text-slate-600 dark:text-slate-400">All filed briefings, user coordinates, geolocations, and activity listings must be authentic. Fabricating reports or claiming mock points will lead to immediate account review and ban.</p>
                            </div>
                            
                            <div class="p-4 bg-emerald-50/40 dark:bg-slate-900 border-l-4 border-bushgreen dark:border-gold rounded-r-2xl space-y-1">
                                <h4 class="font-bold text-bushgreen dark:text-gold">2. Impartial Service and Community Empathy</h4>
                                <p class="text-slate-600 dark:text-slate-400">Our mandate is to scale tech capacity across all sectors. All advocacy campaigns and resource distribution must be carried out without regional or political bias.</p>
                            </div>

                            <div class="p-4 bg-emerald-50/40 dark:bg-slate-900 border-l-4 border-bushgreen dark:border-gold rounded-r-2xl space-y-1">
                                <h4 class="font-bold text-bushgreen dark:text-gold">3. Respect for Organizational Hierarchy</h4>
                                <p class="text-slate-600 dark:text-slate-400">Coordinators report to State Chairmen, State Chairmen report to Zonal Chairmen, and Zonal Chairmen align with the National Steering Council. Directives must be executed promptly inside local units.</p>
                            </div>

                            <div class="p-4 bg-emerald-50/40 dark:bg-slate-900 border-l-4 border-bushgreen dark:border-gold rounded-r-2xl space-y-1">
                                <h4 class="font-bold text-bushgreen dark:text-gold">4. Professional Ethics and Compliance</h4>
                                <p class="text-slate-600 dark:text-slate-400">Maintain high professional communication. Public engagements, social feeds, and forum comments must align with national transformation goals.</p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- SECTION 4: ASSETS DOWNLOAD -->
                <div x-show="activeSection === 'downloads'" x-cloak x-transition class="space-y-6">
                    <div class="border-b border-slate-100 dark:border-slate-700 pb-4">
                        <h2 class="text-lg sm:text-xl font-black text-bushgreen dark:text-gold uppercase tracking-tight font-display">Operational Materials & Assets</h2>
                        <p class="text-slate-505 dark:text-slate-400 text-xs font-light mt-1">Download templates, slides, and booklets customized for your operations.</p>
                    </div>

                    <?php if ($role === 'super_admin'): ?>
                        <!-- Super Admin Upload Form -->
                        <div class="bg-slate-50 dark:bg-slate-900 border border-slate-150 dark:border-slate-800 p-6 rounded-3xl space-y-4 mb-6 shadow-inner">
                            <h3 class="text-sm font-bold text-slate-800 dark:text-white flex items-center gap-2 font-display">
                                <span>📤</span> Upload New Command Asset
                            </h3>
                            <form method="POST" action="" enctype="multipart/form-data" class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                                <input type="hidden" name="action" value="upload_resource">
                                
                                <div class="space-y-3">
                                    <div>
                                        <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="title">Asset Title *</label>
                                        <input type="text" name="title" required placeholder="e.g. Grassroots Sensitization Handbook" class="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                                    </div>
                                    <div>
                                        <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="target_role">Target Leadership Tier *</label>
                                        <select name="target_role" required class="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                                            <option value="all">All Roles</option>
                                            <option value="super_admin">Super Admin</option>
                                            <option value="founder_circle">Founder Circle</option>
                                            <option value="national_steering">National Steering Council</option>
                                            <option value="zonal_chairman">Zonal Chairman</option>
                                            <option value="state_chairman">State Chairman</option>
                                            <option value="coordinator">LGA Coordinator</option>
                                            <option value="ambassador">Grassroots Ambassador</option>
                                        </select>
                                    </div>
                                </div>
                                
                                <div class="space-y-3">
                                    <div>
                                        <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="description">Short Description *</label>
                                        <textarea name="description" required rows="2" placeholder="Brief outline of contents, instructions, or target audience..." class="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen"></textarea>
                                    </div>
                                    <div>
                                        <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="resource_file">File Upload (PDF, Word, PPT, Zip, Excel, Image) *</label>
                                        <input type="file" name="resource_file" required class="w-full text-xs text-slate-500 file:mr-4 file:py-1.5 file:px-3 file:rounded-xl file:border-0 file:bg-bushgreen/10 file:text-bushgreen dark:file:bg-gold/10 dark:file:text-gold">
                                    </div>
                                </div>
                                
                                <div class="md:col-span-2 flex justify-end">
                                    <button type="submit" class="py-2.5 px-6 bg-bushgreen hover:bg-bushgreen-light text-white dark:bg-gold dark:text-bushgreen dark:hover:bg-gold/90 text-xs font-bold rounded-xl transition shadow-md">
                                        Upload & Publish Asset
                                    </button>
                                </div>
                            </form>
                        </div>
                    <?php endif; ?>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-150 dark:border-slate-800 rounded-2xl flex justify-between items-center">
                            <div>
                                <h4 class="text-xs font-bold text-slate-800 dark:text-white">Smart Nation Mobilization Handbook</h4>
                                <p class="text-[10px] text-slate-500 mt-1">Unified manual outlining campaigns and events strategies.</p>
                            </div>
                            <button onclick="alert('Asset downloaded successfully.');" class="py-1 px-3 bg-bushgreen text-white dark:bg-gold dark:text-bushgreen text-[9px] font-bold rounded-lg uppercase tracking-wider">
                                Download PDF
                            </button>
                        </div>

                        <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-150 dark:border-slate-800 rounded-2xl flex justify-between items-center">
                            <div>
                                <h4 class="text-xs font-bold text-slate-800 dark:text-white">Ethical Standards Reference Sheet</h4>
                                <p class="text-[10px] text-slate-500 mt-1">Conduct guidelines and reporting checklists.</p>
                            </div>
                            <button onclick="alert('Asset downloaded successfully.');" class="py-1 px-3 bg-bushgreen text-white dark:bg-gold dark:text-bushgreen text-[9px] font-bold rounded-lg uppercase tracking-wider">
                                Download PDF
                            </button>
                        </div>

                        <?php if ($role === 'super_admin' || $role === 'national_steering'): ?>
                            <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-150 dark:border-slate-800 rounded-2xl flex justify-between items-center">
                                <div>
                                    <h4 class="text-xs font-bold text-slate-800 dark:text-white">User Moderation & RBAC Manual</h4>
                                    <p class="text-[10px] text-slate-500 mt-1">Security parameters, role toggles, and database audit guidelines.</p>
                                </div>
                                <button onclick="alert('Asset downloaded successfully.');" class="py-1 px-3 bg-bushgreen text-white dark:bg-gold dark:text-bushgreen text-[9px] font-bold rounded-lg uppercase tracking-wider">
                                    Download PDF
                                </button>
                            </div>
                        <?php endif; ?>

                        <?php if ($role === 'coordinator' || $role === 'ambassador'): ?>
                            <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-150 dark:border-slate-800 rounded-2xl flex justify-between items-center">
                                <div>
                                    <h4 class="text-xs font-bold text-slate-800 dark:text-white">Grassroots Outreach Slides</h4>
                                    <p class="text-[10px] text-slate-500 mt-1">Interactive PPT presentation template for local town halls.</p>
                                </div>
                                <button onclick="alert('Asset downloaded successfully.');" class="py-1 px-3 bg-bushgreen text-white dark:bg-gold dark:text-bushgreen text-[9px] font-bold rounded-lg uppercase tracking-wider">
                                    Download PPT
                                </button>
                            </div>
                        <?php endif; ?>
                    </div>

                    <!-- Dynamic Custom Resources -->
                    <div class="space-y-4 pt-6 border-t border-slate-100 dark:border-slate-700">
                        <h3 class="text-sm font-bold text-slate-800 dark:text-slate-200 font-display uppercase tracking-wider">Operational Materials & Assets</h3>
                        
                        <?php if (empty($resources)): ?>
                            <p class="text-xs text-slate-400 italic">No custom assets have been uploaded for your role level yet.</p>
                        <?php else: ?>
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <?php foreach ($resources as $res): ?>
                                    <div class="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-150 dark:border-slate-800 rounded-2xl flex flex-col justify-between gap-3 shadow-inner">
                                        <div class="space-y-1">
                                            <div class="flex items-center justify-between">
                                                <h4 class="text-xs font-bold text-slate-800 dark:text-white"><?php echo htmlspecialchars($res['title']); ?></h4>
                                                <span class="text-[8px] px-2 py-0.5 rounded-full font-bold uppercase <?php echo $res['target_role'] === 'all' ? 'bg-emerald-50 text-emerald-700' : 'bg-gold/25 text-[#735A00]'; ?>">
                                                    <?php echo htmlspecialchars($res['target_role'] === 'all' ? 'All Tiers' : str_replace('_', ' ', $res['target_role'])); ?>
                                                </span>
                                            </div>
                                            <p class="text-[10px] text-slate-500 mt-1"><?php echo htmlspecialchars($res['description']); ?></p>
                                            <span class="text-[8px] text-slate-400 font-mono block">Uploaded by <?php echo htmlspecialchars($res['uploader_name']); ?> on <?php echo date('Y-m-d H:i', strtotime($res['created_at'])); ?></span>
                                        </div>
                                        <div class="flex items-center gap-2 mt-2">
                                            <a href="../<?php echo htmlspecialchars($res['file_path']); ?>" download class="py-1 px-3 bg-bushgreen hover:bg-bushgreen-light text-white dark:bg-gold dark:text-bushgreen dark:hover:bg-gold/90 text-[9px] font-bold rounded-lg uppercase tracking-wider text-center transition">
                                                Download <?php echo strtoupper($res['file_type']); ?>
                                            </a>
                                            
                                            <?php if ($role === 'super_admin'): ?>
                                                <form method="POST" action="" onsubmit="return confirm('Are you sure you want to delete this resource?');" class="inline">
                                                    <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                                                    <input type="hidden" name="action" value="delete_resource">
                                                    <input type="hidden" name="delete_id" value="<?php echo $res['id']; ?>">
                                                    <button type="submit" class="py-1 px-3 bg-red-500 hover:bg-red-650 text-white text-[9px] font-bold rounded-lg uppercase tracking-wider transition">
                                                        Delete
                                                    </button>
                                                </form>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

            </div>

        </div>
    </main>

    <footer class="bg-bushgreen text-white pt-10 pb-8 border-t-2 border-gold/45 mt-12 relative overflow-hidden">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-2 relative z-10">
            <p class="text-slate-400 text-xs">
                &copy; 2026 PBAT Smart Nation Initiative. Command Resource Centre.
            </p>
            <span class="text-[10px] text-slate-500 block">An independent, non-governmental public awareness & advocacy platform.</span>
        </div>
    </footer>
</body>
</html>
