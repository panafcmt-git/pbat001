<?php
/**
 * PBAT Smart Nation Initiative - Blog & Circulars CRUD Manager
 * Allows all registered users to manage news posts, progress updates, and technological policy drafts.
 */
require_once dirname(__DIR__) . '/helpers/auth.php';
require_once dirname(__DIR__) . '/helpers/common.php';
require_once dirname(__DIR__) . '/config/database.php';

// Route protector - Restrict to all registered user roles
Auth::requireRole(['super_admin', 'founder_circle', 'national_steering', 'zonal_chairman', 'state_chairman', 'coordinator', 'ambassador'], '../login.php');

$user = Auth::user();
$error = '';
$success = '';
$edit_post = null;
$is_admin = Auth::hasRole('super_admin');

try {
    $db = Database::connect();

    // 0. Handle Moderation POST Action (Approval / Rejection) by Super Admin
    if ($is_admin && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && ($_POST['action'] === 'approve' || $_POST['action'] === 'reject')) {
        if (!Auth::validateCsrf($_POST['csrf_token'] ?? '')) {
            $error = "CSRF Token validation failed.";
        } else {
            $post_id = (int)$_POST['post_id'];
            $status_val = $_POST['action'] === 'approve' ? 1 : 0;
            $stmt = $db->prepare("UPDATE `blog_posts` SET `is_approved` = ? WHERE `id` = ?");
            $stmt->execute([$status_val, $post_id]);
            Auth::logAction($user['id'], 'BLOG_MODERATE', ($status_val ? "Approved" : "Rejected") . " blog post ID {$post_id}");
            $success = $status_val ? "Blog post approved successfully!" : "Blog post rejected/disapproved.";
            header("Location: blog.php?success=" . urlencode($success));
            exit;
        }
    }

    // 1. Handle Delete Action
    if (isset($_GET['delete'])) {
        $delete_id = (int)$_GET['delete'];
        
        if ($is_admin) {
            $stmt = $db->prepare("DELETE FROM `blog_posts` WHERE `id` = ?");
            $stmt->execute([$delete_id]);
        } else {
            $stmt = $db->prepare("DELETE FROM `blog_posts` WHERE `id` = ? AND `author_id` = ?");
            $stmt->execute([$delete_id, $user['id']]);
        }
        
        if ($stmt->rowCount() > 0) {
            Auth::logAction($user['id'], 'BLOG_DELETE', "Deleted blog post ID {$delete_id}");
            $success = "Blog post deleted successfully!";
        } else {
            $error = "Failed to delete post or permission denied.";
        }
        header("Location: blog.php?success=" . urlencode($success) . "&error=" . urlencode($error));
        exit;
    }

    // 2. Handle Edit Selection
    if (isset($_GET['edit'])) {
        $edit_id = (int)$_GET['edit'];
        if ($is_admin) {
            $stmt = $db->prepare("SELECT * FROM `blog_posts` WHERE `id` = ? LIMIT 1");
            $stmt->execute([$edit_id]);
        } else {
            $stmt = $db->prepare("SELECT * FROM `blog_posts` WHERE `id` = ? AND `author_id` = ? LIMIT 1");
            $stmt->execute([$edit_id, $user['id']]);
        }
        $edit_post = $stmt->fetch();
        if (isset($_GET['edit']) && !$edit_post) {
            $error = "You do not have permission to edit this post or it does not exist.";
        }
    }

    // 3. Handle Form Submission (Create or Update)
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && (!isset($_POST['action']) || ($_POST['action'] !== 'approve' && $_POST['action'] !== 'reject'))) {
        if (!Auth::validateCsrf($_POST['csrf_token'] ?? '')) {
            $error = "Security token expired. Please refresh and try again.";
        } else {
            $title = trim($_POST['title']);
            $summary = trim($_POST['summary']);
            $content = trim($_POST['content']);
            $cover_image = trim($_POST['cover_image']);
            $category = trim($_POST['category'] ?? 'News');
            $status = trim($_POST['status']);
            $post_id = isset($_POST['post_id']) ? (int)$_POST['post_id'] : 0;

            if (empty($title) || empty($summary) || empty($content)) {
                $error = "Title, Summary, and Content body are required fields.";
            } else {
                // Process Featured Image Direct Upload
                if (isset($_FILES['cover_image_upload']) && $_FILES['cover_image_upload']['error'] === UPLOAD_ERR_OK) {
                    $file = $_FILES['cover_image_upload'];
                    $file_size = $file['size'];
                    $file_tmp = $file['tmp_name'];
                    $file_name = basename($file['name']);
                    $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

                    $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif', 'svg', 'webp'];
                    if (in_array($file_ext, $allowed_extensions)) {
                        if ($file_size <= 5242880) { // 5MB limit
                            $upload_dir = dirname(__DIR__) . '/uploads/';
                            if (!is_dir($upload_dir)) {
                                mkdir($upload_dir, 0755, true);
                            }
                            $new_file_name = 'blog_' . time() . '.' . $file_ext;
                            $target_file = $upload_dir . $new_file_name;
                            if (move_uploaded_file($file_tmp, $target_file)) {
                                $cover_image = 'uploads/' . $new_file_name;
                            } else {
                                $error = "Failed to write uploaded featured image to uploads folder.";
                            }
                        } else {
                            $error = "Featured image size exceeds 5MB limit.";
                        }
                    } else {
                        $error = "Invalid featured image file type. Only JPG, PNG, GIF, SVG, and WEBP formats are allowed.";
                    }
                }

                if (empty($error)) {
                    if (empty($cover_image)) {
                        $cover_image = 'assets/img/blog1.jpg'; // default fallback
                    }

                    if ($post_id > 0) {
                        // Check ownership first
                        if ($is_admin) {
                            $stmt_check = $db->prepare("SELECT id FROM `blog_posts` WHERE `id` = ?");
                            $stmt_check->execute([$post_id]);
                        } else {
                            $stmt_check = $db->prepare("SELECT id FROM `blog_posts` WHERE `id` = ? AND `author_id` = ?");
                            $stmt_check->execute([$post_id, $user['id']]);
                        }
                        
                        if ($stmt_check->fetch()) {
                            // Update
                            if ($is_admin) {
                                $stmt = $db->prepare("UPDATE `blog_posts` SET `title` = ?, `summary` = ?, `content` = ?, `cover_image` = ?, `status` = ?, `category` = ? WHERE `id` = ?");
                                $stmt->execute([$title, $summary, $content, $cover_image, $status, $category, $post_id]);
                            } else {
                                // Reset is_approved to 0 for non-admins when they update/edit their posts
                                $stmt = $db->prepare("UPDATE `blog_posts` SET `title` = ?, `summary` = ?, `content` = ?, `cover_image` = ?, `status` = ?, `category` = ?, `is_approved` = 0 WHERE `id` = ?");
                                $stmt->execute([$title, $summary, $content, $cover_image, $status, $category, $post_id]);
                            }
                            Auth::logAction($user['id'], 'BLOG_UPDATE', "Updated blog post: '{$title}'");
                            $success = "Circular updated successfully!";
                        } else {
                            $error = "Permission denied or post not found.";
                        }
                    } else {
                        // Create
                        $is_approved = $is_admin ? 1 : 0;
                        $stmt = $db->prepare("INSERT INTO `blog_posts` (`title`, `summary`, `content`, `cover_image`, `status`, `author_id`, `category`, `is_approved`) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
                        $stmt->execute([$title, $summary, $content, $cover_image, $status, $user['id'], $category, $is_approved]);
                        
                        Auth::logAction($user['id'], 'BLOG_CREATE', "Created blog post: '{$title}'");
                        $success = "Circular published successfully! " . ($is_approved ? "" : "Subject to super admin approval.");
                    }

                    if (empty($error)) {
                        header("Location: blog.php?success=" . urlencode($success));
                        exit;
                    }
                }
            }
        }
    }

    // 4. Fetch blog posts based on access level
    if ($is_admin) {
        $stmt = $db->query("SELECT b.*, u.name as author_name FROM `blog_posts` b JOIN `users` u ON b.author_id = u.id ORDER BY b.created_at DESC");
    } else {
        $stmt = $db->prepare("SELECT b.*, u.name as author_name FROM `blog_posts` b JOIN `users` u ON b.author_id = u.id WHERE b.author_id = ? ORDER BY b.created_at DESC");
        $stmt->execute([$user['id']]);
    }
    $blog_posts = $stmt->fetchAll();

} catch (Exception $e) {
    $error = "System Database Error: " . $e->getMessage();
    $blog_posts = [];
}

if (isset($_GET['success'])) {
    $success = $_GET['success'];
}
if (isset($_GET['error'])) {
    $error = $_GET['error'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>News, Updates & Policy Drafts - PBAT Smart Nation</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        bushgreen: {
                            DEFAULT: '#063C1E',
                            light: '#0A4D27',
                            dark: '#03200F',
                        },
                        gold: '#D4AF37'
                    }
                }
            }
        }
    </script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700&display=swap" rel="stylesheet">
    <!-- CKEditor 5 Super Build (full feature set) -->
    <script src="https://cdn.ckeditor.com/ckeditor5/41.4.2/super-build/ckeditor.js"></script>
    <style>
        body { font-family: 'Outfit', sans-serif; }

        /* WordPress-style editor styling */
        .ck.ck-editor {
            border-radius: 0.75rem !important;
            overflow: hidden;
            border: 1px solid #e2e8f0 !important;
            box-shadow: 0 1px 3px rgba(0,0,0,0.04);
        }
        .ck.ck-toolbar {
            background: #f8fafc !important;
            border-bottom: 1px solid #e2e8f0 !important;
            padding: 6px 8px !important;
            flex-wrap: wrap !important;
        }
        .ck.ck-toolbar .ck-toolbar__separator {
            background: #cbd5e1 !important;
        }
        .ck-editor__editable_inline {
            min-height: 600px;
            color: #1e293b;
            font-family: 'Outfit', sans-serif;
            font-size: 14px;
            line-height: 1.8;
            padding: 24px 28px !important;
        }
        .ck-editor__editable_inline:focus {
            border-color: #063C1E !important;
            box-shadow: 0 0 0 2px rgba(6, 60, 30, 0.08) !important;
        }
        .ck-editor__editable_inline h1 { font-size: 28px; font-weight: 800; margin: 16px 0 8px; }
        .ck-editor__editable_inline h2 { font-size: 22px; font-weight: 700; margin: 14px 0 6px; }
        .ck-editor__editable_inline h3 { font-size: 18px; font-weight: 700; margin: 12px 0 4px; }
        .ck-editor__editable_inline h4 { font-size: 16px; font-weight: 600; margin: 10px 0 4px; }
        .ck-editor__editable_inline p  { margin: 8px 0; }
        .ck-editor__editable_inline blockquote {
            border-left: 4px solid #D4AF37;
            padding: 12px 16px;
            margin: 12px 0;
            background: #f8fafc;
            font-style: italic;
            color: #475569;
        }
        .ck-editor__editable_inline ul, .ck-editor__editable_inline ol {
            padding-left: 24px;
            margin: 8px 0;
        }
        .ck-editor__editable_inline table {
            border-collapse: collapse;
            width: 100%;
        }
        .ck-editor__editable_inline table td,
        .ck-editor__editable_inline table th {
            border: 1px solid #e2e8f0;
            padding: 8px 12px;
        }
        .ck-editor__editable_inline table th {
            background: #f1f5f9;
            font-weight: 700;
        }
        .ck-editor__editable_inline a {
            color: #063C1E;
            text-decoration: underline;
        }
        .ck-editor__editable_inline hr {
            border: none;
            border-top: 2px solid #e2e8f0;
            margin: 20px 0;
        }
        /* Word count footer */
        .ck.ck-word-count {
            padding: 6px 12px;
            font-size: 11px;
            color: #94a3b8;
            background: #f8fafc;
            border-top: 1px solid #e2e8f0;
            font-family: 'Outfit', sans-serif;
        }
        /* Active tab styling */
        .editor-tab-btn.active {
            background: #063C1E;
            color: #D4AF37;
            border-color: #063C1E;
        }
    </style>
</head>
<body class="bg-slate-50 min-h-screen flex flex-col antialiased">

    <!-- Header Navbar -->
    <header class="bg-bushgreen text-white border-b-2 border-gold h-20 flex items-center justify-between px-6 shadow-md relative z-30">
        <div class="flex items-center gap-3">
            <a href="dashboard.php" class="py-1.5 px-3 border border-white/20 hover:bg-white/10 text-white rounded-lg text-xs font-bold transition">
                &larr; Back to Dashboard
            </a>
            <div class="w-8 h-8 rounded bg-white/10 flex items-center justify-center border border-white/20 p-1 flex-shrink-0">
                <?php echo getAppLogoHtml('w-full h-full object-contain', 'dashboard'); ?>
            </div>
            <span class="text-white font-extrabold text-sm font-display hidden sm:inline">PBAT SMART NATION INITIATIVE</span>
        </div>
        <div class="flex items-center gap-3 text-xs font-bold text-gold uppercase tracking-wider">
            News, Updates &amp; Policy Drafts
        </div>
    </header>

    <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 flex-grow w-full space-y-10">
        
        <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div class="space-y-1">
                <h1 class="text-2xl sm:text-3xl font-black text-bushgreen font-display">News, Updates &amp; Policy Drafts</h1>
                <p class="text-slate-500 text-xs font-light">Create, edit, and manage news posts, progress updates, and technological policy drafts.</p>
            </div>
            
            <?php if (!empty($success)): ?>
                <div class="px-4 py-2 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs font-semibold">
                    <?php echo htmlspecialchars($success); ?>
                </div>
            <?php endif; ?>

            <?php if (!empty($error)): ?>
                <div class="px-4 py-2 bg-red-50 border border-red-200 text-red-800 rounded-xl text-xs font-semibold">
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>
        </div>

        <!-- SECTION 1: Full-Width WYSIWYG Editor (Top) -->
        <div id="compose-editor" class="bg-white rounded-2xl border border-slate-100 shadow-sm">

            <!-- Editor Header Bar -->
            <div class="flex items-center justify-between px-6 py-4 border-b border-slate-100">
                <div>
                    <h3 class="text-slate-800 font-bold text-base"><?php echo $edit_post ? '✏️ Edit Circular Briefing' : '✍️ Compose New Circular Briefing'; ?></h3>
                    <p class="text-[10px] text-slate-400 mt-0.5">Draft national technological reports or policy updates. Use the toolbar for formatting, just like WordPress.</p>
                </div>
                <div class="flex items-center gap-2">
                    <?php if ($edit_post): ?>
                    <a href="blog.php" class="py-2 px-4 border border-slate-200 hover:bg-slate-50 text-slate-600 text-xs font-bold rounded-lg transition">Cancel Editing</a>
                    <?php endif; ?>
                </div>
            </div>

            <form method="POST" action="" enctype="multipart/form-data" class="space-y-0">
                <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                <?php if ($edit_post): ?>
                    <input type="hidden" name="post_id" value="<?php echo $edit_post['id']; ?>">
                <?php endif; ?>

                <!-- Metadata Bar -->
                <div class="px-6 py-4 bg-slate-50/50 border-b border-slate-100 space-y-3">
                    <div>
                        <label class="block text-slate-600 text-xs font-semibold mb-1" for="title">Title Headline *</label>
                        <input type="text" name="title" id="title" required value="<?php echo $edit_post ? htmlspecialchars($edit_post['title']) : ''; ?>" placeholder="e.g. Nationwide Smart Agriculture Initiative"
                               class="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-sm font-semibold focus:outline-none focus:border-bushgreen focus:ring-2 focus:ring-bushgreen/10 transition">
                    </div>

                    <div>
                        <label class="block text-slate-600 text-xs font-semibold mb-1" for="summary">Brief Summary *</label>
                        <input type="text" name="summary" id="summary" required value="<?php echo $edit_post ? htmlspecialchars($edit_post['summary']) : ''; ?>" placeholder="Summary for homepage previews (Max 2 sentences)..."
                               class="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-xs focus:outline-none focus:border-bushgreen focus:ring-2 focus:ring-bushgreen/10 transition">
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-3 gap-3">
                        <div>
                            <label class="block text-slate-600 text-xs font-semibold mb-1" for="category">Category *</label>
                            <select name="category" id="category" required
                                    class="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs focus:outline-none focus:border-bushgreen">
                                <option value="News" <?php echo ($edit_post && isset($edit_post['category']) && $edit_post['category'] === 'News') ? 'selected' : ''; ?>>News</option>
                                <option value="Updates" <?php echo ($edit_post && isset($edit_post['category']) && $edit_post['category'] === 'Updates') ? 'selected' : ''; ?>>Updates</option>
                                <option value="Policy Drafts" <?php echo ($edit_post && isset($edit_post['category']) && $edit_post['category'] === 'Policy Drafts') ? 'selected' : ''; ?>>Policy Drafts</option>
                            </select>
                        </div>
                        <div>
                            <label class="block text-slate-600 text-xs font-semibold mb-1" for="status">Status</label>
                            <select name="status" id="status"
                                    class="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs focus:outline-none focus:border-bushgreen">
                                <option value="published" <?php echo ($edit_post && $edit_post['status'] === 'published') ? 'selected' : ''; ?>>Published (Live)</option>
                                <option value="draft" <?php echo ($edit_post && $edit_post['status'] === 'draft') ? 'selected' : ''; ?>>Draft (Saved)</option>
                            </select>
                        </div>
                        <div>
                            <label class="block text-slate-600 text-xs font-semibold mb-1">Cover Image</label>
                            <div class="flex gap-2 items-center">
                                <input type="text" name="cover_image" id="cover_image_input" value="<?php echo $edit_post ? htmlspecialchars($edit_post['cover_image']) : ''; ?>" placeholder="URL or upload →"
                                       class="flex-grow px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs focus:outline-none focus:border-bushgreen font-mono">
                                <label class="flex items-center gap-1 py-2 px-2.5 bg-bushgreen/10 hover:bg-bushgreen/20 text-bushgreen text-[9px] font-bold rounded-xl cursor-pointer transition flex-shrink-0">
                                    <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"/></svg>
                                    Upload
                                    <input type="file" name="cover_image_upload" accept="image/*" class="hidden" onchange="document.getElementById('cover_image_input').value = 'uploads/' + this.files[0].name;" />
                                </label>
                            </div>
                            <?php if ($edit_post && !empty($edit_post['cover_image'])): ?>
                            <div class="flex items-center gap-2 mt-1">
                                <img src="../<?php echo htmlspecialchars($edit_post['cover_image']); ?>" alt="Cover" class="h-6 w-10 rounded border object-cover">
                                <span class="text-[8px] text-slate-400">Current</span>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- WYSIWYG Editor -->
                <div class="px-6 py-4">
                    <label class="block text-slate-600 text-xs font-semibold mb-2">Full Article Content *</label>
                    <textarea name="content" id="content" required><?php echo $edit_post ? htmlspecialchars($edit_post['content']) : ''; ?></textarea>
                </div>

                <!-- Action Bar -->
                <div class="px-6 py-3 border-t border-slate-100 bg-slate-50/50 rounded-b-2xl flex items-center justify-between gap-4">
                    <div class="text-[10px] text-slate-400 flex items-center gap-4">
                        <span id="word-count-display">Words: 0 &bull; Characters: 0</span>
                        <?php if ($edit_post): ?>
                        <span class="text-slate-300">|</span>
                        <span>Updated: <?php echo date('M d, Y @ h:i A', strtotime($edit_post['updated_at'] ?? $edit_post['created_at'])); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="flex gap-3">
                        <?php if ($edit_post): ?>
                            <a href="blog.php" class="py-2 px-4 border border-slate-200 hover:bg-slate-50 text-slate-600 text-xs font-bold rounded-xl transition">Cancel</a>
                        <?php endif; ?>
                        <button type="submit" class="py-2 px-6 bg-bushgreen hover:bg-bushgreen-light text-white text-xs font-bold rounded-xl transition shadow-md shadow-bushgreen/10 flex items-center gap-2">
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
                            <?php echo $edit_post ? 'Commit Update Changes' : 'Publish Circular Update'; ?>
                        </button>
                    </div>
                </div>
            </form>
        </div>

        <!-- SECTION 2: Posts Index (Full Width, Below Editor) -->
        <div class="bg-white rounded-2xl border border-slate-100 p-6 shadow-sm space-y-6">
            <div class="flex justify-between items-center">
                <h3 class="text-slate-800 font-bold text-sm">News, Updates &amp; Policy Drafts Index</h3>
                <span class="px-2 py-0.5 bg-slate-100 text-slate-500 text-[9px] font-bold rounded-full"><?php echo count($blog_posts); ?></span>
            </div>
            
            <div class="space-y-4">
                <?php if (empty($blog_posts)): ?>
                    <div class="text-center py-10 text-xs text-slate-400 italic border border-dashed border-slate-200 rounded-xl">
                        No news posts or policy updates have been published yet.
                    </div>
                <?php else: ?>
                    <?php foreach ($blog_posts as $post): ?>
                        <div class="p-4 rounded-xl border border-slate-100 hover:border-gold/30 transition flex flex-col sm:flex-row gap-4 justify-between items-start sm:items-center">
                            <div class="space-y-1.5 flex-grow">
                                <div class="flex flex-wrap items-center gap-2">
                                    <span class="px-2 py-0.5 rounded text-[8px] font-bold uppercase tracking-wide
                                        <?php echo $post['status'] === 'published' ? 'bg-emerald-50 text-emerald-700 border border-emerald-100' : 'bg-slate-100 text-slate-600 border border-slate-200'; ?>">
                                        <?php echo htmlspecialchars($post['status']); ?>
                                    </span>
                                    <span class="px-2 py-0.5 rounded text-[8px] font-bold uppercase tracking-wide bg-amber-50 text-amber-700 border border-amber-100">
                                        <?php echo htmlspecialchars($post['category'] ?? 'News'); ?>
                                    </span>
                                    <span class="px-2 py-0.5 rounded text-[8px] font-bold uppercase tracking-wide 
                                        <?php echo ($post['is_approved'] ?? 1) == 1 ? 'bg-green-50 text-green-700 border border-green-150' : 'bg-yellow-50 text-yellow-700 border border-yellow-200 animate-pulse'; ?>">
                                        <?php echo ($post['is_approved'] ?? 1) == 1 ? 'Approved' : 'Pending Approval'; ?>
                                    </span>
                                    <span class="text-[10px] text-slate-400">By: <strong class="font-semibold text-slate-600"><?php echo htmlspecialchars($post['author_name']); ?></strong> &bull; <?php echo date('M d, Y', strtotime($post['created_at'])); ?></span>
                                </div>
                                <h4 class="font-bold text-slate-800 text-sm"><?php echo htmlspecialchars($post['title']); ?></h4>
                                <p class="text-slate-500 text-xs font-light line-clamp-2"><?php echo htmlspecialchars($post['summary']); ?></p>
                            </div>
                            <div class="flex sm:flex-col gap-2 w-full sm:w-auto flex-shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-50">
                                <!-- Moderation controls for Super Admin -->
                                <?php if ($is_admin && $post['author_id'] != $user['id']): ?>
                                    <form method="POST" action="" class="inline w-full sm:w-auto">
                                        <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                                        <input type="hidden" name="post_id" value="<?php echo $post['id']; ?>">
                                        <?php if (($post['is_approved'] ?? 1) == 0): ?>
                                            <button type="submit" name="action" value="approve" class="w-full py-1.5 px-3 bg-emerald-600 hover:bg-emerald-700 text-center text-white text-[10px] font-bold rounded transition">
                                                Approve Post
                                            </button>
                                        <?php else: ?>
                                            <button type="submit" name="action" value="reject" class="w-full py-1.5 px-3 bg-amber-600 hover:bg-amber-700 text-center text-white text-[10px] font-bold rounded transition">
                                                Reject Post
                                            </button>
                                        <?php endif; ?>
                                    </form>
                                <?php endif; ?>
                                
                                <div class="flex gap-2 w-full">
                                    <a href="blog.php?edit=<?php echo $post['id']; ?>" class="flex-grow py-1.5 px-3 border border-slate-200 text-center hover:border-gold hover:text-gold text-slate-600 text-[10px] font-bold rounded transition">
                                        Edit
                                    </a>
                                    <a href="blog.php?delete=<?php echo $post['id']; ?>" onclick="return confirm('Are you absolutely sure you want to delete this circular update?');" 
                                       class="flex-grow py-1.5 px-3 bg-red-50 hover:bg-red-100 text-center text-red-600 text-[10px] font-bold rounded transition">
                                        Delete
                                    </a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>

    </main>
 
    <!-- Initialize CKEditor 5 Super Build with WordPress-style toolbar -->
    <script>
        CKEDITOR.ClassicEditor.create( document.querySelector( '#content' ), {
            toolbar: {
                items: [
                    'undo', 'redo',
                    '|',
                    'heading',
                    '|',
                    'fontSize', 'fontFamily',
                    '|',
                    'bold', 'italic', 'underline', 'strikethrough',
                    '|',
                    'fontColor', 'fontBackgroundColor',
                    '|',
                    'alignment',
                    '|',
                    'numberedList', 'bulletedList', 'todoList',
                    '|',
                    'outdent', 'indent',
                    '|',
                    'link', 'insertImage', 'blockQuote', 'insertTable', 'horizontalLine',
                    '|',
                    'removeFormat',
                    '|',
                    'sourceEditing'
                ],
                shouldNotGroupWhenFull: true
            },
            heading: {
                options: [
                    { model: 'paragraph', title: 'Paragraph', class: 'ck-heading_paragraph' },
                    { model: 'heading1', view: 'h1', title: 'Heading 1', class: 'ck-heading_heading1' },
                    { model: 'heading2', view: 'h2', title: 'Heading 2', class: 'ck-heading_heading2' },
                    { model: 'heading3', view: 'h3', title: 'Heading 3', class: 'ck-heading_heading3' },
                    { model: 'heading4', view: 'h4', title: 'Heading 4', class: 'ck-heading_heading4' }
                ]
            },
            fontSize: {
                options: [ 10, 12, 14, 'default', 18, 20, 24, 28, 32, 36 ],
                supportAllValues: true
            },
            fontFamily: {
                options: [
                    'default',
                    'Outfit, sans-serif',
                    'Arial, Helvetica, sans-serif',
                    'Georgia, serif',
                    'Courier New, Courier, monospace',
                    'Trebuchet MS, sans-serif',
                    'Verdana, Geneva, sans-serif',
                    'Times New Roman, serif'
                ],
                supportAllValues: true
            },
            alignment: {
                options: [ 'left', 'center', 'right', 'justify' ]
            },
            table: {
                contentToolbar: [
                    'tableColumn', 'tableRow', 'mergeTableCells',
                    'tableProperties', 'tableCellProperties'
                ]
            },
            image: {
                toolbar: [
                    'imageTextAlternative', 'toggleImageCaption', 'imageStyle:inline',
                    'imageStyle:block', 'imageStyle:side'
                ]
            },
            link: {
                decorators: {
                    openInNewTab: {
                        mode: 'manual',
                        label: 'Open in a new tab',
                        defaultValue: true,
                        attributes: {
                            target: '_blank',
                            rel: 'noopener noreferrer'
                        }
                    }
                }
            },
            placeholder: 'Start writing your article here... Use the toolbar above for formatting — headings, bold, font sizes, alignment, images, tables, and more.',
            // Remove unwanted plugins from the Super Build
            removePlugins: [
                'AIAssistant',
                'CKBox',
                'CKFinder',
                'EasyImage',
                'MultiLevelList',
                'RealTimeCollaborativeComments',
                'RealTimeCollaborativeTrackChanges',
                'RealTimeCollaborativeRevisionHistory',
                'PresenceList',
                'Comments',
                'TrackChanges',
                'TrackChangesData',
                'RevisionHistory',
                'Pagination',
                'WProofreader',
                'MathType',
                'SlashCommand',
                'Template',
                'DocumentOutline',
                'FormatPainter',
                'TableOfContents',
                'PasteFromOfficeEnhanced',
                'CaseChange'
            ]
        })
        .then( editor => {
            // Sync CKEditor data to hidden textarea on every change
            editor.model.document.on('change:data', () => {
                document.querySelector('#content').value = editor.getData();
                updateWordCount(editor);
            });
            // Initial word count
            updateWordCount(editor);
        })
        .catch( error => {
            console.error( 'CKEditor init error:', error );
        });

        function updateWordCount(editor) {
            const text = editor.getData().replace(/<[^>]*>/g, ' ').replace(/&nbsp;/g, ' ').replace(/\s+/g, ' ').trim();
            const words = text ? text.split(' ').length : 0;
            const chars = text.length;
            const el = document.getElementById('word-count-display');
            if (el) el.textContent = 'Words: ' + words + ' • Characters: ' + chars;
        }
    </script>
</body>
</html>

