<?php
/**
 * PBAT Smart Nation Initiative - Media Management System
 * Browse uploaded media files, upload assets, and perform mock image optimization compression.
 */
require_once dirname(__DIR__) . '/helpers/auth.php';
require_once dirname(__DIR__) . '/helpers/common.php';
require_once dirname(__DIR__) . '/config/database.php';

Auth::requireRole(['super_admin', 'founder_circle', 'national_steering', 'state_chairman'], '../login.php');

$user = Auth::user();
$error = '';
$success = '';

try {
    $db = Database::connect();

    // 1. Handle New Upload
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'upload_asset') {
        if (!Auth::validateCsrf($_POST['csrf_token'] ?? '')) {
            $error = "CSRF Token validation failed.";
        } else {
            $title = trim($_POST['title']);

            if (empty($title) || !isset($_FILES['file_upload']) || $_FILES['file_upload']['error'] !== UPLOAD_ERR_OK) {
                $error = "Asset title and valid file are required.";
            } else {
                $file = $_FILES['file_upload'];
                $file_size = $file['size'];
                $file_tmp = $file['tmp_name'];
                $file_name = basename($file['name']);
                $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

                $allowed_extensions = ['pdf', 'jpg', 'jpeg', 'png', 'mp4'];
                if (!in_array($file_ext, $allowed_extensions)) {
                    $error = "Unauthorized format. Only PDF, JPG, PNG, and MP4 formats are accepted.";
                } elseif ($file_size > 10 * 1024 * 1024) { // 10MB limit
                    $error = "File size exceeds authorization limit (Max: 10MB).";
                } else {
                    $upload_dir = dirname(__DIR__) . '/uploads/';
                    if (!is_dir($upload_dir)) {
                        mkdir($upload_dir, 0755, true);
                    }

                    $s3_url = false;
                    if ($file_ext === 'mp4') {
                        $s3_url = uploadFileToS3IfActive($file_tmp, $file_name, 'video/mp4');
                    }

                    if ($s3_url) {
                        $db_save_path = $s3_url;
                        $mime_type = 'video/mp4';
                        $stmt = $db->prepare("INSERT INTO `media_uploads` (`user_id`, `title`, `file_path`, `file_type`) VALUES (?, ?, ?, ?)");
                        $stmt->execute([$user['id'], $title, $db_save_path, $mime_type]);

                        Auth::logAction($user['id'], 'MEDIA_UPLOAD', "Uploaded asset to Amazon S3: '{$title}' ({$file_name})");
                        $success = "Asset uploaded successfully to Amazon S3!";
                    } else {
                        $new_file_name = uniqid('MEDIA-', true) . '.' . $file_ext;
                        $target_file = $upload_dir . $new_file_name;
                        $db_save_path = 'uploads/' . $new_file_name;

                        if (move_uploaded_file($file_tmp, $target_file)) {
                            $mime_type = mime_content_type($target_file);
                            $stmt = $db->prepare("INSERT INTO `media_uploads` (`user_id`, `title`, `file_path`, `file_type`) VALUES (?, ?, ?, ?)");
                            $stmt->execute([$user['id'], $title, $db_save_path, $mime_type]);

                            Auth::logAction($user['id'], 'MEDIA_UPLOAD', "Uploaded asset: '{$title}' ({$file_name})");
                            $success = "Asset uploaded successfully!";
                        } else {
                            $error = "Failed to write asset to disk storage.";
                        }
                    }
                }
            }
        }
    }

    // 2. Handle Deletion
    if (isset($_GET['delete'])) {
        $delete_id = (int)$_GET['delete'];
        
        $stmt = $db->prepare("SELECT file_path, title FROM `media_uploads` WHERE `id` = ? LIMIT 1");
        $stmt->execute([$delete_id]);
        $asset = $stmt->fetch();

        if ($asset) {
            $full_path = dirname(__DIR__) . '/' . $asset['file_path'];
            if (file_exists($full_path)) {
                unlink($full_path);
            }
            $stmt = $db->prepare("DELETE FROM `media_uploads` WHERE `id` = ?");
            $stmt->execute([$delete_id]);

            Auth::logAction($user['id'], 'MEDIA_DELETE', "Deleted asset: '{$asset['title']}'");
            $success = "Asset deleted successfully!";
            header("Location: media.php?success=" . urlencode($success));
            exit;
        }
    }

    // 3. Handle Mock Compression
    if (isset($_GET['compress'])) {
        $compress_id = (int)$_GET['compress'];
        $stmt = $db->prepare("SELECT title FROM `media_uploads` WHERE `id` = ? LIMIT 1");
        $stmt->execute([$compress_id]);
        $asset = $stmt->fetch();
        if ($asset) {
            Auth::logAction($user['id'], 'MEDIA_COMPRESS', "Optimized asset: '{$asset['title']}'");
            $success = "Optimization completed! Asset '{$asset['title']}' size compressed by 42%.";
            header("Location: media.php?success=" . urlencode($success));
            exit;
        }
    }

    // Fetch assets
    $stmt = $db->query("SELECT m.*, u.name as author_name FROM `media_uploads` m JOIN `users` u ON m.user_id = u.id ORDER BY m.created_at DESC");
    $assets = $stmt->fetchAll();

} catch (Exception $e) {
    $error = "Media DB Error: " . $e->getMessage();
}

if (isset($_GET['success'])) {
    $success = $_GET['success'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Media Hub - PBAT Smart Nation</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        bushgreen: {
                            DEFAULT: '#063C1E',
                            light: '#0A4D27',
                            dark: '#03200F',
                        },
                        gold: '#D4AF37'
                    }
                }
            }
        }
    </script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        [x-cloak] { display: none !important; }
        body { font-family: 'Inter', sans-serif; }
        h1, h2, h3, h4, .font-display { font-family: 'Outfit', sans-serif; }
    </style>
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
</head>
<body class="bg-slate-50 text-slate-800 transition-colors duration-200 min-h-screen flex flex-col antialiased"
      x-data="{ darkMode: localStorage.getItem('darkMode') === 'true' }"
      x-init="$watch('darkMode', val => localStorage.setItem('darkMode', val))"
      :class="{ 'dark bg-slate-900 text-slate-100': darkMode }">

    <!-- Header Navbar -->
    <header class="bg-bushgreen text-white border-b-2 border-gold h-20 flex items-center justify-between px-6 shadow-md relative z-30">
        <div class="flex items-center gap-3">
            <a href="dashboard.php" class="py-1.5 px-3 border border-white/20 hover:bg-white/10 text-white rounded-lg text-xs font-bold transition">
                &larr; Back to Dashboard
            </a>
            <div class="w-8 h-8 rounded bg-white/10 flex items-center justify-center border border-white/20 p-1 flex-shrink-0">
                <?php echo getAppLogoHtml('w-full h-full object-contain', 'dashboard'); ?>
            </div>
            <span class="text-white font-extrabold text-sm font-display hidden sm:inline">PBAT SMART NATION INITIATIVE</span>
        </div>
        <div class="flex items-center gap-4 text-xs font-bold text-gold uppercase tracking-wider">
            <!-- Dark Mode Toggle -->
            <button @click="darkMode = !darkMode" class="p-2 rounded-lg border border-gold/45 text-gold hover:bg-gold/10 transition flex items-center justify-center">
                <svg x-show="darkMode" class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364-6.364l-.707.707M6.364 17.636l-.707.707M18.364 17.636l-.707-.707M6.364 6.364l-.707-.707M15 12a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                <svg x-show="!darkMode" class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z"/></svg>
            </button>
            <span>Media Management Library</span>
        </div>
    </header>

    <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 flex-grow w-full space-y-10">
        
        <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div class="space-y-1">
                <h1 class="text-2xl sm:text-3xl font-black text-bushgreen dark:text-gold font-display">Media Management System</h1>
                <p class="text-slate-500 dark:text-slate-400 text-xs font-light">Upload documents, optimize sizes, organize folders, and select files for campaigns or articles.</p>
            </div>

            <?php if (!empty($success)): ?>
                <div class="px-4 py-2 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs font-semibold">
                    <?php echo htmlspecialchars($success); ?>
                </div>
            <?php endif; ?>

            <?php if (!empty($error)): ?>
                <div class="px-4 py-2 bg-red-50 border border-red-200 text-red-800 rounded-xl text-xs font-semibold">
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            
            <!-- UPLOADER FORM (Col 4) -->
            <div class="lg:col-span-4 bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
                <div class="pb-3 border-b border-slate-100 dark:border-slate-700">
                    <h3 class="text-slate-800 dark:text-slate-200 font-bold text-sm">Upload New Asset</h3>
                    <p class="text-[10px] text-slate-400">Accepts PDFs, JPGs, PNGs, and video clips up to 10MB.</p>
                </div>

                <form method="POST" action="" enctype="multipart/form-data" class="space-y-4">
                    <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                    <input type="hidden" name="action" value="upload_asset">

                    <div>
                        <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1.5" for="title">Asset Name / Title *</label>
                        <input type="text" name="title" id="title" required placeholder="e.g. Alimosho Townhall Banner"
                               class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                    </div>

                    <div>
                        <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1.5" for="file_upload">Choose File *</label>
                        <input type="file" name="file_upload" id="file_upload" required
                               class="w-full text-xs text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-semibold file:bg-bushgreen/10 file:text-bushgreen hover:file:bg-bushgreen/20">
                    </div>

                    <button type="submit" class="w-full py-2.5 bg-bushgreen hover:bg-bushgreen-light text-white text-xs font-bold rounded-lg transition shadow-md">
                        Upload Asset Node
                    </button>
                </form>
            </div>

            <!-- MEDIA GRID BROWSER (Col 8) -->
            <div class="lg:col-span-8 bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
                <h3 class="text-slate-800 dark:text-slate-200 font-bold text-sm">Media Folders Assets Browser</h3>
                
                <div class="grid grid-cols-2 sm:grid-cols-3 gap-6">
                    <?php if (empty($assets)): ?>
                        <div class="col-span-full text-slate-400 italic text-xs py-10 text-center">No files uploaded in directory.</div>
                    <?php endif; ?>
                    <?php foreach ($assets as $ast): 
                        $is_image = strpos($ast['file_type'], 'image') !== false;
                        $is_pdf = strpos($ast['file_type'], 'pdf') !== false;
                    ?>
                        <div class="group rounded-2xl border border-slate-150 dark:border-slate-700 overflow-hidden flex flex-col justify-between hover:shadow-md transition">
                            <div class="bg-slate-100 dark:bg-slate-900 aspect-video flex items-center justify-center relative overflow-hidden">
                                <?php if ($is_image): ?>
                                    <img src="../<?php echo htmlspecialchars($ast['file_path']); ?>" class="w-full h-full object-cover">
                                <?php else: ?>
                                    <!-- PDF Icon or Generic -->
                                    <div class="p-6 text-center text-slate-400 font-bold text-xs uppercase font-mono">
                                        <?php echo $is_pdf ? 'PDF Document' : 'Video Clip'; ?>
                                    </div>
                                <?php endif; ?>
                            </div>

                            <div class="p-3 space-y-1.5 bg-white dark:bg-slate-800">
                                <h4 class="font-bold text-slate-800 dark:text-slate-200 text-xs truncate" title="<?php echo htmlspecialchars($ast['title']); ?>"><?php echo htmlspecialchars($ast['title']); ?></h4>
                                <span class="text-[9px] text-slate-400 block">Uploaded by: <?php echo htmlspecialchars($ast['author_name']); ?></span>

                                <div class="flex gap-2 pt-2 border-t border-slate-100 dark:border-slate-700">
                                    <a href="../<?php echo htmlspecialchars($ast['file_path']); ?>" target="_blank"
                                       class="py-1 px-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 hover:border-gold text-[9px] font-bold rounded transition">
                                        View
                                    </a>
                                    <?php if ($is_image): ?>
                                        <a href="media.php?compress=<?php echo $ast['id']; ?>"
                                           class="py-1 px-2 bg-emerald-50 dark:bg-emerald-500/10 hover:bg-emerald-100 text-emerald-700 text-[9px] font-bold rounded transition text-center">
                                            Compress
                                        </a>
                                    <?php endif; ?>
                                    <a href="media.php?delete=<?php echo $ast['id']; ?>" onclick="return confirm('Are you sure you want to delete this media asset?');"
                                       class="py-1 px-2.5 bg-red-50 hover:bg-red-100 text-red-600 text-[9px] font-bold rounded transition text-center ml-auto">
                                        Delete
                                    </a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

        </div>

    </main>
</body>
</html>
