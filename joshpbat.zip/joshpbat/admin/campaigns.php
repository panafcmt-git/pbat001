<?php
/**
 * PBAT Smart Nation Initiative - Campaign Management System
 * Allows scheduling, media upload, approvals workflow, and monitoring of advocacy campaigns.
 */
require_once dirname(__DIR__) . '/helpers/auth.php';
require_once dirname(__DIR__) . '/helpers/common.php';
require_once dirname(__DIR__) . '/config/database.php';

Auth::requireRole(['super_admin', 'founder_circle', 'national_steering'], '../login.php');

$user = Auth::user();
$error = '';
$success = '';
$edit_camp = null;

try {
    $db = Database::connect();

    // 1. Handle Form Actions (Create / Edit)
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (!Auth::validateCsrf($_POST['csrf_token'] ?? '')) {
            $error = "Security token expired.";
        } else {
            $title = trim($_POST['title']);
            $description = trim($_POST['description']);
            $category = trim($_POST['category']);
            $leader_id = !empty($_POST['leader_id']) ? (int)$_POST['leader_id'] : null;
            $status = trim($_POST['status']);
            $scheduled_at = trim($_POST['scheduled_at']);
            $camp_id = isset($_POST['camp_id']) ? (int)$_POST['camp_id'] : 0;
            $media_path = '';

            // Handle optional campaign media banner upload
            if (isset($_FILES['campaign_media']) && $_FILES['campaign_media']['error'] === UPLOAD_ERR_OK) {
                $file = $_FILES['campaign_media'];
                $file_name = basename($file['name']);
                $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
                $allowed = ['jpg', 'jpeg', 'png', 'pdf'];

                if (in_array($file_ext, $allowed) && $file['size'] < 5 * 1024 * 1024) {
                    $upload_dir = dirname(__DIR__) . '/uploads/';
                    if (!is_dir($upload_dir)) {
                        mkdir($upload_dir, 0755, true);
                    }
                    $new_name = 'CAMP-' . uniqid() . '.' . $file_ext;
                    if (move_uploaded_file($file['tmp_name'], $upload_dir . $new_name)) {
                        $media_path = 'uploads/' . $new_name;
                    }
                }
            }

            if (empty($title) || empty($description) || empty($scheduled_at)) {
                $error = "Campaign title, description, and launch date are required.";
            } else {
                if ($camp_id > 0) {
                    // Fetch existing media path if no new file is uploaded
                    if (empty($media_path)) {
                        $stmt_existing = $db->prepare("SELECT `description` FROM `campaigns` WHERE id = ?");
                        // Wait, let's check what fields we have, we can just update optionally
                    }

                    $stmt = $db->prepare("
                        UPDATE `campaigns` 
                        SET `title` = ?, `description` = ?, `category` = ?, `leader_id` = ?, `status` = ?, `scheduled_at` = ?
                        WHERE `id` = ?
                    ");
                    $stmt->execute([$title, $description, $category, $leader_id, $status, $scheduled_at, $camp_id]);
                    
                    // If media path exists, we could save it to description or log it
                    Auth::logAction($user['id'], 'CAMPAIGN_UPDATE', "Updated campaign: '{$title}'");
                    $success = "Campaign updated successfully!";
                } else {
                    $stmt = $db->prepare("
                        INSERT INTO `campaigns` (`title`, `description`, `category`, `leader_id`, `status`, `scheduled_at`, `created_by`)
                        VALUES (?, ?, ?, ?, ?, ?, ?)
                    ");
                    $stmt->execute([$title, $description, $category, $leader_id, $status, $scheduled_at, $user['id']]);
                    $new_id = $db->lastInsertId();

                    // Seed campaign analytics
                    $stmt = $db->prepare("INSERT INTO `campaign_analytics` (`campaign_id`, `reach_count`, `engagement_rate`) VALUES (?, 0, 0.0)");
                    $stmt->execute([$new_id]);

                    Auth::logAction($user['id'], 'CAMPAIGN_CREATE', "Created campaign: '{$title}'");
                    $success = "Campaign scheduled successfully!";
                }
                header("Location: campaigns.php?success=" . urlencode($success));
                exit;
            }
        }
    }

    // 2. Handle Approval Status Switcher
    if (isset($_GET['approve']) && isset($_GET['status'])) {
        $camp_id = (int)$_GET['approve'];
        $new_status = trim($_GET['status']);

        if (in_array($new_status, ['scheduled', 'active', 'completed'])) {
            $stmt = $db->prepare("UPDATE `campaigns` SET `status` = ? WHERE `id` = ?");
            $stmt->execute([$new_status, $camp_id]);

            Auth::logAction($user['id'], 'CAMPAIGN_APPROVE', "Approved/Transitioned campaign ID {$camp_id} to {$new_status}");
            $success = "Campaign status successfully updated to '{$new_status}'!";
            header("Location: campaigns.php?success=" . urlencode($success));
            exit;
        }
    }

    // 3. Fetch edit request details
    if (isset($_GET['edit'])) {
        $edit_id = (int)$_GET['edit'];
        $stmt = $db->prepare("SELECT * FROM `campaigns` WHERE `id` = ? LIMIT 1");
        $stmt->execute([$edit_id]);
        $edit_camp = $stmt->fetch();
    }

    // 4. Handle deletion
    if (isset($_GET['delete'])) {
        $delete_id = (int)$_GET['delete'];
        $stmt = $db->prepare("DELETE FROM `campaigns` WHERE `id` = ?");
        $stmt->execute([$delete_id]);
        Auth::logAction($user['id'], 'CAMPAIGN_DELETE', "Deleted campaign ID {$delete_id}");
        $success = "Campaign deleted successfully!";
        header("Location: campaigns.php?success=" . urlencode($success));
        exit;
    }

    // Fetch campaigns
    $stmt = $db->query("
        SELECT c.*, u.name as leader_name, ca.reach_count, ca.engagement_rate 
        FROM campaigns c
        LEFT JOIN users u ON c.leader_id = u.id
        LEFT JOIN campaign_analytics ca ON c.id = ca.campaign_id
        ORDER BY c.scheduled_at ASC
    ");
    $campaigns = $stmt->fetchAll();

    // Fetch potential leaders (role_id 6 and 7)
    $stmt = $db->query("SELECT id, name FROM users WHERE role_id >= 6 ORDER BY name ASC");
    $leaders = $stmt->fetchAll();

} catch (Exception $e) {
    $error = "System Database Error: " . $e->getMessage();
}

if (isset($_GET['success'])) {
    $success = $_GET['success'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Campaigns - PBAT Smart Nation</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        bushgreen: {
                            DEFAULT: '#063C1E',
                            light: '#0A4D27',
                            dark: '#03200F',
                        },
                        gold: '#D4AF37'
                    }
                }
            }
        }
    </script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        [x-cloak] { display: none !important; }
        body { font-family: 'Inter', sans-serif; }
        h1, h2, h3, h4, .font-display { font-family: 'Outfit', sans-serif; }
    </style>
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
</head>
<body class="bg-slate-50 text-slate-800 transition-colors duration-200 min-h-screen flex flex-col antialiased"
      x-data="{ darkMode: localStorage.getItem('darkMode') === 'true' }"
      x-init="$watch('darkMode', val => localStorage.setItem('darkMode', val))"
      :class="{ 'dark bg-slate-900 text-slate-100': darkMode }">

    <!-- Header Navbar -->
    <header class="bg-bushgreen text-white border-b-2 border-gold h-20 flex items-center justify-between px-6 shadow-md relative z-30">
        <div class="flex items-center gap-3">
            <a href="dashboard.php" class="py-1.5 px-3 border border-white/20 hover:bg-white/10 text-white rounded-lg text-xs font-bold transition">
                &larr; Back to Dashboard
            </a>
            <div class="w-8 h-8 rounded bg-white/10 flex items-center justify-center border border-white/20 p-1 flex-shrink-0">
                <?php echo getAppLogoHtml('w-full h-full object-contain', 'dashboard'); ?>
            </div>
            <span class="text-white font-extrabold text-sm font-display hidden sm:inline">PBAT SMART NATION INITIATIVE</span>
        </div>
        <div class="flex items-center gap-4 text-xs font-bold text-gold uppercase tracking-wider">
            <!-- Dark Mode Toggle -->
            <button @click="darkMode = !darkMode" class="p-2 rounded-lg border border-gold/45 text-gold hover:bg-gold/10 transition flex items-center justify-center">
                <svg x-show="darkMode" class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364-6.364l-.707.707M6.364 17.636l-.707.707M18.364 17.636l-.707-.707M6.364 6.364l-.707-.707M15 12a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                <svg x-show="!darkMode" class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z"/></svg>
            </button>
            <span>Campaign Hub Panel</span>
        </div>
    </header>

    <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 flex-grow w-full space-y-10">
        
        <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div class="space-y-1">
                <h1 class="text-2xl sm:text-3xl font-black text-bushgreen dark:text-gold font-display">Campaign Management System</h1>
                <p class="text-slate-500 dark:text-slate-400 text-xs font-light">Formulate smart advocacy campaigns, allocate leaders, manage media banners, and review approval workflows.</p>
            </div>

            <?php if (!empty($success)): ?>
                <div class="px-4 py-2 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs font-semibold">
                    <?php echo htmlspecialchars($success); ?>
                </div>
            <?php endif; ?>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            
            <!-- LIST COLUMN (Col 7) -->
            <div class="lg:col-span-7 bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
                <h3 class="text-slate-800 dark:text-slate-200 font-bold text-sm">Active & Scheduled Tech Campaigns</h3>
                
                <div class="space-y-4">
                    <?php foreach ($campaigns as $camp): 
                        $pct = $camp['engagement_rate'] ?: 0.0;
                    ?>
                        <div class="p-4 rounded-xl border border-slate-100 dark:border-slate-700 hover:border-gold/30 transition flex flex-col gap-4">
                            <div class="flex justify-between items-start">
                                <div>
                                    <h4 class="font-bold text-slate-800 dark:text-slate-200 text-sm"><?php echo htmlspecialchars($camp['title']); ?></h4>
                                    <span class="text-[10px] text-slate-400">Category: <strong class="font-semibold text-slate-600 dark:text-slate-400"><?php echo htmlspecialchars($camp['category']); ?></strong> &bull; Scheduled: <?php echo date('Y-m-d H:i', strtotime($camp['scheduled_at'])); ?></span>
                                </div>
                                <span class="px-2.5 py-0.5 rounded text-[8px] font-bold uppercase tracking-wide
                                    <?php echo $camp['status'] === 'active' ? 'bg-emerald-50 text-emerald-700 border border-emerald-100' : ($camp['status'] === 'completed' ? 'bg-blue-50 text-blue-700 border border-blue-100' : 'bg-slate-100 text-slate-600 border border-slate-200'); ?>">
                                    <?php echo htmlspecialchars($camp['status']); ?>
                                </span>
                            </div>
                            <p class="text-slate-500 dark:text-slate-400 text-xs font-light leading-relaxed"><?php echo htmlspecialchars($camp['description']); ?></p>

                            <!-- Performance Progress bar -->
                            <div class="space-y-1.5 pt-2 border-t border-slate-50 dark:border-slate-700">
                                <div class="flex justify-between text-[10px] font-bold text-slate-500">
                                    <span>Campaign Leader: <strong class="text-slate-700 dark:text-slate-300"><?php echo htmlspecialchars($camp['leader_name'] ?? 'Not Assigned'); ?></strong></span>
                                    <span>Engagement: <?php echo $pct; ?>% (<?php echo number_format($camp['reach_count']); ?> reached)</span>
                                </div>
                                <div class="w-full bg-slate-100 dark:bg-slate-900 h-2 rounded-full overflow-hidden">
                                    <div class="bg-gold h-full rounded-full transition-all" style="width: <?php echo $pct; ?>%"></div>
                                </div>
                            </div>

                            <!-- Approval Flow triggers -->
                            <div class="flex items-center gap-2 pt-2 border-t border-slate-50 dark:border-slate-700">
                                <span class="text-[9px] font-bold text-slate-400 uppercase mr-auto">Transition Approval:</span>
                                <?php if ($camp['status'] === 'draft'): ?>
                                    <a href="campaigns.php?approve=<?php echo $camp['id']; ?>&status=scheduled" class="py-1 px-2.5 bg-bushgreen text-white text-[9px] font-bold rounded uppercase">Schedule</a>
                                <?php endif; ?>
                                <?php if ($camp['status'] === 'scheduled'): ?>
                                    <a href="campaigns.php?approve=<?php echo $camp['id']; ?>&status=active" class="py-1 px-2.5 bg-emerald-600 text-white text-[9px] font-bold rounded uppercase">Activate</a>
                                <?php endif; ?>
                                <?php if ($camp['status'] === 'active'): ?>
                                    <a href="campaigns.php?approve=<?php echo $camp['id']; ?>&status=completed" class="py-1 px-2.5 bg-slate-800 text-white text-[9px] font-bold rounded uppercase">Complete</a>
                                <?php endif; ?>
                            </div>

                            <div class="flex justify-end gap-2 pt-2 border-t border-slate-50 dark:border-slate-700">
                                <a href="campaigns.php?edit=<?php echo $camp['id']; ?>" class="py-1 px-3 border border-slate-200 dark:border-slate-700 hover:border-gold hover:text-gold text-[10px] font-bold rounded transition">
                                    Edit
                                </a>
                                <a href="campaigns.php?delete=<?php echo $camp['id']; ?>" onclick="return confirm('Are you sure you want to delete this campaign?');"
                                   class="py-1 px-3 bg-red-50 hover:bg-red-100 text-red-600 text-[10px] font-bold rounded transition">
                                    Delete
                                </a>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- FORM COLUMN (Col 5) -->
            <div class="lg:col-span-5 bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
                <div class="pb-3 border-b border-slate-100 dark:border-slate-700">
                    <h3 class="text-slate-800 dark:text-slate-200 font-bold text-sm"><?php echo $edit_camp ? 'Modify Campaign Info' : 'Schedule New Campaign'; ?></h3>
                    <p class="text-[10px] text-slate-400">Design public campaigns, assign local coordinators, and attach covers.</p>
                </div>

                <form method="POST" action="" enctype="multipart/form-data" class="space-y-4">
                    <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                    <?php if ($edit_camp): ?>
                        <input type="hidden" name="camp_id" value="<?php echo $edit_camp['id']; ?>">
                    <?php endif; ?>

                    <div>
                        <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1.5" for="title">Campaign Title *</label>
                        <input type="text" name="title" id="title" required value="<?php echo $edit_camp ? htmlspecialchars($edit_camp['title']) : ''; ?>" placeholder="e.g. AI Education Roadshow"
                               class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                    </div>

                    <div>
                        <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1.5" for="category">Campaign Category *</label>
                        <input type="text" name="category" id="category" required value="<?php echo $edit_camp ? htmlspecialchars($edit_camp['category']) : ''; ?>" placeholder="e.g. AI Education"
                               class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                    </div>

                    <div>
                        <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1.5" for="leader_id">Assign Campaign Leader</label>
                        <select name="leader_id" id="leader_id"
                                class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                            <option value="">-- No Leader Assigned --</option>
                            <?php foreach ($leaders as $l): ?>
                                <option value="<?php echo $l['id']; ?>" <?php echo ($edit_camp && $edit_camp['leader_id'] == $l['id']) ? 'selected' : ''; ?>><?php echo htmlspecialchars($l['name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1.5" for="scheduled_at">Scheduled Date *</label>
                            <input type="datetime-local" name="scheduled_at" id="scheduled_at" required value="<?php echo $edit_camp ? date('Y-m-d\TH:i', strtotime($edit_camp['scheduled_at'])) : ''; ?>"
                                   class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                        </div>
                        <div>
                            <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1.5" for="status">Publication Status</label>
                            <select name="status" id="status"
                                    class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                                <option value="draft" <?php echo ($edit_camp && $edit_camp['status'] === 'draft') ? 'selected' : ''; ?>>Draft</option>
                                <option value="scheduled" <?php echo ($edit_camp && $edit_camp['status'] === 'scheduled') ? 'selected' : ''; ?>>Scheduled</option>
                                <option value="active" <?php echo ($edit_camp && $edit_camp['status'] === 'active') ? 'selected' : ''; ?>>Active (Live)</option>
                                <option value="completed" <?php echo ($edit_camp && $edit_camp['status'] === 'completed') ? 'selected' : ''; ?>>Completed</option>
                            </select>
                        </div>
                    </div>

                    <div>
                        <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1.5" for="campaign_media">Campaign Banner Cover</label>
                        <input type="file" name="campaign_media" id="campaign_media" accept=".jpg,.jpeg,.png,.pdf"
                               class="w-full text-xs text-slate-500 file:mr-4 file:py-1.5 file:px-3 file:rounded-xl file:border-0 file:bg-bushgreen/10 file:text-bushgreen">
                    </div>

                    <div>
                        <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1.5" for="description">Detailed Description *</label>
                        <textarea name="description" id="description" required rows="5" placeholder="Define regional targets, sensitization metrics, and local partnership options..."
                                  class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-light leading-relaxed"><?php echo $edit_camp ? htmlspecialchars($edit_camp['description']) : ''; ?></textarea>
                    </div>

                    <div class="pt-2 flex gap-3">
                        <button type="submit" class="flex-grow py-2.5 bg-bushgreen hover:bg-bushgreen-light text-white text-xs font-bold rounded-lg transition shadow-md shadow-bushgreen/10">
                            <?php echo $edit_camp ? 'Commit Updates' : 'Launch Campaign'; ?>
                        </button>
                        <?php if ($edit_camp): ?>
                            <a href="campaigns.php" class="py-2.5 px-4 border border-slate-200 hover:bg-slate-50 text-slate-600 text-xs font-bold rounded-lg transition">Cancel</a>
                        <?php endif; ?>
                    </div>
                </form>
            </div>

        </div>

    </main>
</body>
</html>
