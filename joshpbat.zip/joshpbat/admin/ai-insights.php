<?php
/**
 * PBAT Smart Nation Initiative - AI Insights & Future Features
 * Integrates simulated AI content suggestions, report summaries, trends, and participation forecasts.
 */
require_once dirname(__DIR__) . '/helpers/auth.php';
require_once dirname(__DIR__) . '/helpers/common.php';
require_once dirname(__DIR__) . '/config/database.php';

Auth::requireRole(['super_admin', 'founder_circle', 'national_steering'], '../login.php');

$user = Auth::user();
$error = '';
$success = '';
$summarized_report = null;

try {
    $db = Database::connect();

    // Fetch reports list to populate selector
    $reports = $db->query("SELECT r.id, r.title, r.description FROM `reports` r ORDER BY r.created_at DESC")->fetchAll();

    // 1. Handle Summarize Action
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'summarize_report') {
        $rep_id = (int)$_POST['report_id'];
        if ($rep_id > 0) {
            $stmt = $db->prepare("SELECT title, description FROM `reports` WHERE id = ? LIMIT 1");
            $stmt->execute([$rep_id]);
            $summarized_report = $stmt->fetch();
        }
    }

} catch (Exception $e) {
    $error = "AI Insights DB Error: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AI Insights - PBAT Smart Nation</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        bushgreen: {
                            DEFAULT: '#063C1E',
                            light: '#0A4D27',
                            dark: '#03200F',
                        },
                        gold: '#D4AF37'
                    }
                }
            }
        }
    </script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        [x-cloak] { display: none !important; }
        body { font-family: 'Inter', sans-serif; }
        h1, h2, h3, h4, .font-display { font-family: 'Outfit', sans-serif; }
    </style>
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
</head>
<body class="bg-slate-50 text-slate-800 transition-colors duration-200 min-h-screen flex flex-col antialiased"
      x-data="{ darkMode: localStorage.getItem('darkMode') === 'true' }"
      x-init="$watch('darkMode', val => localStorage.setItem('darkMode', val))"
      :class="{ 'dark bg-slate-900 text-slate-100': darkMode }">

    <!-- Header Navbar -->
    <header class="bg-bushgreen text-white border-b-2 border-gold h-20 flex items-center justify-between px-6 shadow-md relative z-30">
        <div class="flex items-center gap-3">
            <a href="dashboard.php" class="py-1.5 px-3 border border-white/20 hover:bg-white/10 text-white rounded-lg text-xs font-bold transition">
                &larr; Back to Dashboard
            </a>
            <div class="w-8 h-8 rounded bg-white/10 flex items-center justify-center border border-white/20 p-1 flex-shrink-0">
                <?php echo getAppLogoHtml('w-full h-full object-contain', 'dashboard'); ?>
            </div>
            <span class="text-white font-extrabold text-sm font-display hidden sm:inline">PBAT SMART NATION INITIATIVE</span>
        </div>
        <div class="flex items-center gap-4 text-xs font-bold text-gold uppercase tracking-wider">
            <!-- Dark Mode Toggle -->
            <button @click="darkMode = !darkMode" class="p-2 rounded-lg border border-gold/45 text-gold hover:bg-gold/10 transition flex items-center justify-center">
                <svg x-show="darkMode" class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364-6.364l-.707.707M6.364 17.636l-.707.707M18.364 17.636l-.707-.707M6.364 6.364l-.707-.707M15 12a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                <svg x-show="!darkMode" class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z"/></svg>
            </button>
            <span>AI Predictive Engine</span>
        </div>
    </header>

    <main class="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-10 flex-grow w-full space-y-10">
        
        <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div class="space-y-1">
                <h1 class="text-2xl sm:text-3xl font-black text-bushgreen dark:text-gold font-display">AI Insights & Future Tools</h1>
                <p class="text-slate-500 dark:text-slate-400 text-xs font-light">Generate content, summarize briefings, check trending topics, and view participation predictions.</p>
            </div>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            
            <!-- LEFT COLUMN (Col 7) -->
            <div class="lg:col-span-7 space-y-8">
                
                <!-- AI report summarizer -->
                <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-4">
                    <h3 class="text-slate-800 dark:text-slate-200 font-bold text-sm">AI Briefing Summarization</h3>
                    <p class="text-[10px] text-slate-400">Select any filed briefing from the archives to generate key highlights and action points.</p>

                    <form method="POST" action="" class="flex gap-4">
                        <select name="report_id" required
                                class="flex-grow px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                            <option value="">-- Choose Report Briefing --</option>
                            <?php foreach ($reports as $r): ?>
                                <option value="<?php echo $r['id']; ?>"><?php echo htmlspecialchars($r['title']); ?></option>
                            <?php endforeach; ?>
                        </select>
                        <input type="hidden" name="action" value="summarize_report">
                        <button type="submit" class="py-2 px-5 bg-bushgreen hover:bg-bushgreen-light text-white text-xs font-bold rounded-lg transition shadow-md">
                            Summarize Briefing
                        </button>
                    </form>

                    <?php if ($summarized_report): ?>
                        <div class="p-4 bg-slate-50 dark:bg-slate-900/50 rounded-2xl border border-slate-100 dark:border-slate-850 space-y-3 text-xs leading-relaxed">
                            <h4 class="font-bold text-slate-800 dark:text-slate-200">AI Summary: <?php echo htmlspecialchars($summarized_report['title']); ?></h4>
                            <ul class="list-disc pl-4 space-y-1 text-slate-600 dark:text-slate-400 font-light">
                                <li><strong>Primary Action:</strong> Grassroots advocate completed digital literacy mobilization.</li>
                                <li><strong>Participants:</strong> Community youth chapter engaged in coding/AI orientation.</li>
                                <li><strong>Assessment:</strong> High success rate with immediate LGA coordinator certificate approval recommended.</li>
                            </ul>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- AI content suggestions -->
                <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-4"
                     x-data="{ category: 'tech', suggestions: [], loading: false,
                         generate() {
                             this.loading = true;
                             setTimeout(() => {
                                 if (this.category === 'tech') {
                                     this.suggestions = [
                                         'Smart Nation Code Academy: LGA Digital Roadmap',
                                         'Local Innovation Hubs: Building Infrastructure for Tech Growth',
                                         'Advocacy Playbook: Engaging Local Youths in Code Mobilization'
                                     ];
                                 } else {
                                     this.suggestions = [
                                         'AI and E-Commerce: Tools for Local Market Cooperatives',
                                         'Demystifying Algorithms: Workshops for Small Businesses',
                                         'Empowering Women in Tech: Zonal AI Sensitization Initiatives'
                                     ];
                                 }
                                 this.loading = false;
                             }, 800);
                         }
                     }">
                    <h3 class="text-slate-800 dark:text-slate-200 font-bold text-sm">AI Content & Title Generator</h3>
                    <p class="text-[10px] text-slate-400">Generate outlines, blog post topics, and campaign titles in real-time.</p>

                    <div class="flex gap-4">
                        <select x-model="category"
                                class="flex-grow px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                            <option value="tech">Tech Sensitization</option>
                            <option value="ai">AI & Innovations</option>
                        </select>
                        <button @click="generate()" class="py-2 px-5 bg-bushgreen hover:bg-bushgreen-light text-white text-xs font-bold rounded-lg transition shadow-md">
                            Generate Ideas
                        </button>
                    </div>

                    <div x-show="loading" class="text-xs text-slate-500 italic py-4">Drafting suggestions...</div>
                    <div x-show="!loading && suggestions.length > 0" class="space-y-2.5">
                        <template x-for="item in suggestions">
                            <div class="p-3 bg-slate-50 dark:bg-slate-900/50 rounded-xl border border-slate-100 dark:border-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-300" x-text="item"></div>
                        </template>
                    </div>
                </div>

            </div>

            <!-- RIGHT COLUMN (Col 5) -->
            <div class="lg:col-span-5 space-y-6">
                <!-- Trend Detection -->
                <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-4">
                    <h3 class="text-slate-800 dark:text-slate-200 font-bold text-sm">Trending Advocacy Topics</h3>
                    <div class="flex flex-wrap gap-2">
                        <span class="px-2.5 py-1 bg-bushgreen/5 dark:bg-white/5 border border-slate-150 dark:border-slate-700 text-[10px] rounded-full font-bold text-bushgreen dark:text-gold">#broadband-advocacy</span>
                        <span class="px-2.5 py-1 bg-bushgreen/5 dark:bg-white/5 border border-slate-150 dark:border-slate-700 text-[10px] rounded-full font-bold text-bushgreen dark:text-gold">#cashless-cooperatives</span>
                        <span class="px-2.5 py-1 bg-bushgreen/5 dark:bg-white/5 border border-slate-150 dark:border-slate-700 text-[10px] rounded-full font-bold text-bushgreen dark:text-gold">#youth-coding-bootcamps</span>
                        <span class="px-2.5 py-1 bg-bushgreen/5 dark:bg-white/5 border border-slate-150 dark:border-slate-700 text-[10px] rounded-full font-bold text-bushgreen dark:text-gold">#ai-sensitization</span>
                        <span class="px-2.5 py-1 bg-bushgreen/5 dark:bg-white/5 border border-slate-150 dark:border-slate-700 text-[10px] rounded-full font-bold text-bushgreen dark:text-gold">#smart-hubs</span>
                    </div>
                </div>

                <!-- Engagement Predictions -->
                <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-4">
                    <h3 class="text-slate-800 dark:text-slate-200 font-bold text-sm">Predictive Chapter Growth</h3>
                    <p class="text-[10px] text-slate-400">Forecasting State chapter enrollment growth based on campaign density indices.</p>

                    <div class="space-y-3 text-xs leading-normal">
                        <div class="pb-2 border-b border-slate-100 dark:border-slate-700 flex justify-between">
                            <div>
                                <span class="font-bold text-slate-800 dark:text-slate-200">Lagos State</span>
                                <p class="text-[9px] text-slate-400 font-light">Growth due to Awareness week</p>
                            </div>
                            <span class="text-emerald-500 font-bold font-mono">+28% Growth</span>
                        </div>
                        <div class="pb-2 border-b border-slate-100 dark:border-slate-700 flex justify-between">
                            <div>
                                <span class="font-bold text-slate-800 dark:text-slate-200">FCT Abuja</span>
                                <p class="text-[9px] text-slate-400 font-light">Growth due to AI Education</p>
                            </div>
                            <span class="text-emerald-500 font-bold font-mono">+19% Growth</span>
                        </div>
                        <div class="flex justify-between">
                            <div>
                                <span class="font-bold text-slate-800 dark:text-slate-200">Rivers State</span>
                                <p class="text-[9px] text-slate-400 font-light">Moderate local campaign density</p>
                            </div>
                            <span class="text-amber-500 font-bold font-mono">+12% Growth</span>
                        </div>
                    </div>
                </div>
            </div>

        </div>

    </main>
</body>
</html>
