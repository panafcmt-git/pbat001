<?php
/**
 * PBAT Smart Nation Initiative - QR & Credential Verification System
 * Operational gate to check ambassador status, log event check-ins, and inspect anti-fraud scan logs.
 */
require_once dirname(__DIR__) . '/helpers/auth.php';
require_once dirname(__DIR__) . '/helpers/common.php';
require_once dirname(__DIR__) . '/config/database.php';

Auth::requireRole(['super_admin', 'founder_circle', 'national_steering', 'state_chairman'], '../login.php');

$user = Auth::user();
$error = '';
$success = '';
$scanned_member = null;
$logs = [];

try {
    $db = Database::connect();

    // 1. Handle Verification Check
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'verify_uuid') {
        if (!Auth::validateCsrf($_POST['csrf_token'] ?? '')) {
            $error = "CSRF Token validation failed.";
        } else {
            $uuid = trim($_POST['uuid']);
            if (empty($uuid)) {
                $error = "Please provide a valid Member UUID, Membership Code or QR Hash.";
            } else {
                // Fetch member details (supporting all roles via LEFT JOIN)
                $stmt = $db->prepare("
                    SELECT u.id as user_id, u.name, u.email, u.phone, u.avatar, u.status, u.membership_code, r.display_name as role_name, u.role_id,
                           a.id as ambassador_id, a.uuid, a.impact_score, a.is_verified, a.qr_code_hash,
                           COALESCE(s.name, s_l.name) as state_name,
                           COALESCE(l.name, l_l.name) as lga_name
                    FROM `users` u
                    JOIN `roles` r ON u.role_id = r.id
                    LEFT JOIN `ambassadors` a ON u.id = a.user_id 
                    LEFT JOIN `states` s ON a.state_id = s.id 
                    LEFT JOIN `lgas` l ON a.lga_id = l.id 
                    LEFT JOIN `user_leadership` ul ON u.id = ul.user_id
                    LEFT JOIN `states` s_l ON ul.state_id = s_l.id
                    LEFT JOIN `lgas` l_l ON ul.lga_id = l_l.id
                    WHERE u.membership_code = ? OR a.uuid = ? OR a.qr_code_hash = ?
                    LIMIT 1
                ");
                $stmt->execute([$uuid, $uuid, $uuid]);
                $scanned_member = $stmt->fetch();

                if (!$scanned_member) {
                    $error = "Verification Failed: Invalid credentials or unregistered code hash.";
                    // Log fail verification attempt
                    $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
                    $stmt_log = $db->prepare("INSERT INTO `qr_verifications` (`qr_hash`, `ip_address`, `status`) VALUES (?, ?, 'failed')");
                    $stmt_log->execute([substr($uuid, 0, 64), $ip]);
                } else {
                    $qr_hash = !empty($scanned_member['qr_code_hash']) ? $scanned_member['qr_code_hash'] : (!empty($scanned_member['membership_code']) ? $scanned_member['membership_code'] : ($scanned_member['uuid'] ?? ''));
                    
                    if ($scanned_member['status'] !== 'active') {
                        $role_label = strtolower($scanned_member['role_name'] ?? 'member');
                        $error = "Flagged: Scanned credentials belong to a SUSPENDED {$role_label} account.";
                        $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
                        $stmt_log = $db->prepare("INSERT INTO `qr_verifications` (`qr_hash`, `ip_address`, `status`) VALUES (?, ?, 'suspended')");
                        $stmt_log->execute([$qr_hash, $ip]);
                    } else {
                        $success = "Verification Successful: " . htmlspecialchars($scanned_member['name']) . " is active.";
                        
                        // Increment impact score on scan (only if they are an ambassador)
                        if (!empty($scanned_member['ambassador_id'])) {
                            $stmt_score = $db->prepare("UPDATE `ambassadors` SET `impact_score` = `impact_score` + 5 WHERE `id` = ?");
                            $stmt_score->execute([$scanned_member['ambassador_id']]);
                        }

                        // Add check-in audit log
                        $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
                        $stmt_log = $db->prepare("INSERT INTO `qr_verifications` (`qr_hash`, `ip_address`, `status`) VALUES (?, ?, 'success')");
                        $stmt_log->execute([$qr_hash, $ip]);
                    }
                }
            }
        }
    }

    // 2. Fetch verification logs
    $stmt = $db->query("
        SELECT qv.*, COALESCE(a.uuid, u.membership_code) as uuid, u.name 
        FROM qr_verifications qv
        LEFT JOIN ambassadors a ON qv.qr_hash = a.qr_code_hash
        LEFT JOIN users u ON (u.id = a.user_id OR qv.qr_hash = u.membership_code)
        ORDER BY qv.verified_at DESC
        LIMIT 15
    ");
    $logs = $stmt->fetchAll();

} catch (Exception $e) {
    $error = "QR Validation System Error: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QR Verification Gate - PBAT Smart Nation</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        bushgreen: {
                            DEFAULT: '#063C1E',
                            light: '#0A4D27',
                            dark: '#03200F',
                        },
                        gold: '#D4AF37'
                    }
                }
            }
        }
    </script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        [x-cloak] { display: none !important; }
        body { font-family: 'Inter', sans-serif; }
        h1, h2, h3, h4, .font-display { font-family: 'Outfit', sans-serif; }
    </style>
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
</head>
<body class="bg-slate-50 text-slate-800 transition-colors duration-200 min-h-screen flex flex-col antialiased"
      x-data="{ darkMode: localStorage.getItem('darkMode') === 'true' }"
      x-init="$watch('darkMode', val => localStorage.setItem('darkMode', val))"
      :class="{ 'dark bg-slate-900 text-slate-100': darkMode }">

    <!-- Header Navbar -->
    <header class="bg-bushgreen text-white border-b-2 border-gold h-20 flex items-center justify-between px-6 shadow-md relative z-30">
        <div class="flex items-center gap-3">
            <a href="dashboard.php" class="py-1.5 px-3 border border-white/20 hover:bg-white/10 text-white rounded-lg text-xs font-bold transition">
                &larr; Back to Dashboard
            </a>
            <div class="w-8 h-8 rounded bg-white/10 flex items-center justify-center border border-white/20 p-1 flex-shrink-0">
                <?php echo getAppLogoHtml('w-full h-full object-contain', 'dashboard'); ?>
            </div>
            <span class="text-white font-extrabold text-sm font-display hidden sm:inline">PBAT SMART NATION INITIATIVE</span>
        </div>
        <div class="flex items-center gap-4 text-xs font-bold text-gold uppercase tracking-wider">
            <!-- Dark Mode Toggle -->
            <button @click="darkMode = !darkMode" class="p-2 rounded-lg border border-gold/45 text-gold hover:bg-gold/10 transition flex items-center justify-center">
                <svg x-show="darkMode" class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364-6.364l-.707.707M6.364 17.636l-.707.707M18.364 17.636l-.707-.707M6.364 6.364l-.707-.707M15 12a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                <svg x-show="!darkMode" class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z"/></svg>
            </button>
            <span>QR Verification Gate</span>
        </div>
    </header>

    <main class="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-10 flex-grow w-full space-y-10">
        
        <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div class="space-y-1">
                <h1 class="text-2xl sm:text-3xl font-black text-bushgreen dark:text-gold font-display">QR Code Verification System</h1>
                <p class="text-slate-500 dark:text-slate-400 text-xs font-light">Validate credentials, mark event attendance, and track real-time anti-fraud check-ins.</p>
            </div>

            <?php if (!empty($success)): ?>
                <div class="px-4 py-2 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs font-semibold">
                    <?php echo htmlspecialchars($success); ?>
                </div>
            <?php endif; ?>

            <?php if (!empty($error)): ?>
                <div class="px-4 py-2 bg-red-50 border border-red-200 text-red-800 rounded-xl text-xs font-semibold">
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            
            <!-- CHECK-IN SCANNER (Col 5) -->
            <div class="lg:col-span-5 bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
                <div class="pb-3 border-b border-slate-100 dark:border-slate-700">
                    <h3 class="text-slate-800 dark:text-slate-200 font-bold text-sm">Validate Credentials</h3>
                    <p class="text-[10px] text-slate-400">Scan or type the UUID/hash written on the back of the credential card.</p>
                </div>

                <form method="POST" action="" class="space-y-4">
                    <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                    <input type="hidden" name="action" value="verify_uuid">

                    <div>
                        <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1.5" for="uuid">Credential UUID / Scan Code *</label>
                        <input type="text" name="uuid" id="uuid" required placeholder="e.g. AMB-6A3B91-3829"
                               class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-mono uppercase tracking-wide">
                    </div>

                    <button type="submit" class="w-full py-2.5 bg-bushgreen hover:bg-bushgreen-light text-white text-xs font-bold rounded-lg transition shadow-md shadow-bushgreen/10">
                        Check-in & Verify
                    </button>
                </form>

                <!-- Scanned Result Card Details -->
                <?php if ($scanned_member): ?>
                    <div class="p-4 bg-slate-50 dark:bg-slate-900/50 rounded-2xl border border-slate-100 dark:border-slate-750 text-xs space-y-3">
                        <div class="flex items-center gap-3">
                            <img src="<?php echo htmlspecialchars(getUserAvatarUrl($scanned_member['avatar'] ?? '')); ?>" class="w-10 h-10 rounded-full object-cover">
                            <div>
                                <h4 class="font-bold text-slate-800 dark:text-slate-200"><?php echo htmlspecialchars($scanned_member['name']); ?></h4>
                                <span class="text-[9px] text-slate-400 font-mono"><?php echo htmlspecialchars($scanned_member['uuid'] ?: $scanned_member['membership_code']); ?></span>
                            </div>
                        </div>
                        <div class="grid grid-cols-2 gap-2 text-[10px] text-slate-500 pt-2 border-t border-white/5">
                            <div><strong>State:</strong> <?php echo htmlspecialchars($scanned_member['state_name'] ?: 'National'); ?></div>
                            <div><strong>LGA:</strong> <?php echo htmlspecialchars($scanned_member['lga_name'] ?: 'Not Applicable'); ?></div>
                            <div><strong>Units:</strong> <?php echo $scanned_member['impact_score'] !== null ? $scanned_member['impact_score'] : 0; ?> pts</div>
                            <div><strong>Status:</strong> <span class="text-emerald-500 font-bold">Active</span></div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>

            <!-- LOGS TABLE (Col 7) -->
            <div class="lg:col-span-7 bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-4">
                <h3 class="text-slate-800 dark:text-slate-200 font-bold text-sm">Live Check-in & Scanner Audit Trail</h3>
                
                <div class="overflow-x-auto">
                    <table class="w-full text-xs text-left text-slate-500 dark:text-slate-400">
                        <thead class="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase border-b border-slate-100 dark:border-slate-700">
                            <tr>
                                <th class="pb-3">Member</th>
                                <th class="pb-3">Scan IP</th>
                                <th class="pb-3">Status</th>
                                <th class="pb-3 text-right">Scanned Date</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-50 dark:divide-slate-700">
                            <?php if (empty($logs)): ?>
                                <tr>
                                    <td colspan="4" class="py-6 text-center text-slate-400 italic">No check-in operations recorded.</td>
                                </tr>
                            <?php endif; ?>
                            <?php foreach ($logs as $log): ?>
                                <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-700/50">
                                    <td class="py-3 pr-2">
                                        <span class="font-semibold text-slate-800 dark:text-slate-200 block"><?php echo htmlspecialchars($log['name'] ?? 'Unknown Code'); ?></span>
                                        <span class="text-[10px] text-slate-400 font-mono"><?php echo htmlspecialchars($log['qr_hash'] ?: $log['uuid']); ?></span>
                                    </td>
                                    <td class="py-3 font-mono"><?php echo htmlspecialchars($log['ip_address']); ?></td>
                                    <td class="py-3">
                                        <span class="px-2 py-0.5 rounded-full text-[9px] font-bold uppercase
                                            <?php echo $log['status'] === 'success' ? 'bg-emerald-50 text-emerald-800 dark:bg-emerald-500/10 dark:text-emerald-400' : 'bg-red-50 text-red-800 dark:bg-red-500/10 dark:text-red-400'; ?>">
                                            <?php echo htmlspecialchars($log['status']); ?>
                                        </span>
                                    </td>
                                    <td class="py-3 text-right text-slate-400 dark:text-slate-500"><?php echo date('Y-m-d H:i', strtotime($log['verified_at'])); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>

    </main>
</body>
</html>
