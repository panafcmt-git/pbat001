<?php
/**
 * PBAT Smart Nation Initiative - State & Zonal Management
 * Allows managing geopolitical zones, states, LGAs, and monitoring regional activity metrics.
 */
require_once dirname(__DIR__) . '/helpers/auth.php';
require_once dirname(__DIR__) . '/helpers/common.php';
require_once dirname(__DIR__) . '/config/database.php';

Auth::requireRole(['super_admin', 'founder_circle', 'national_steering'], '../login.php');

$user = Auth::user();
$error = '';
$success = '';

try {
    $db = Database::connect();

    // 1. Handle Add LGA Form
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add_lga') {
        if (!Auth::validateCsrf($_POST['csrf_token'] ?? '')) {
            $error = "CSRF verification failed.";
        } else {
            $lga_name = trim($_POST['lga_name']);
            $state_id = (int)$_POST['state_id'];

            if (empty($lga_name) || $state_id <= 0) {
                $error = "LGA name and state classification are required.";
            } else {
                $stmt = $db->prepare("INSERT INTO `lgas` (`state_id`, `name`) VALUES (?, ?)");
                $stmt->execute([$state_id, $lga_name]);

                Auth::logAction($user['id'], 'LGA_CREATE', "Added LGA '{$lga_name}' to State ID {$state_id}");
                $success = "Local Government Area (LGA) successfully added!";
            }
        }
    }

    // 2. Fetch States list with coordinator count & LGA counts
    $stmt = $db->query("
        SELECT s.*, 
               (SELECT COUNT(1) FROM lgas WHERE state_id = s.id) as lga_count,
               (SELECT COUNT(1) FROM ambassadors WHERE state_id = s.id) as ambassador_count,
               (SELECT u.name FROM users u JOIN user_leadership ul ON u.id = ul.user_id WHERE ul.state_id = s.id AND u.role_id = 5 LIMIT 1) as chairman_name
        FROM states s
        ORDER BY s.name ASC
    ");
    $regional_states = $stmt->fetchAll();

    // 3. Fetch geopolitical zones summary counts
    $zones_summary = $db->query("
        SELECT zone, COUNT(id) as state_count, 
               (SELECT COUNT(1) FROM ambassadors a JOIN states st ON a.state_id = st.id WHERE st.zone = states.zone) as amb_count
        FROM states
        GROUP BY zone
        ORDER BY zone ASC
    ")->fetchAll();

} catch (Exception $e) {
    $error = "Regions DB Error: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Regions & Zonal Hub - PBAT Smart Nation</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        bushgreen: {
                            DEFAULT: '#063C1E',
                            light: '#0A4D27',
                            dark: '#03200F',
                        },
                        gold: '#D4AF37'
                    }
                }
            }
        }
    </script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        [x-cloak] { display: none !important; }
        body { font-family: 'Inter', sans-serif; }
        h1, h2, h3, h4, .font-display { font-family: 'Outfit', sans-serif; }
    </style>
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
</head>
<body class="bg-slate-50 text-slate-800 transition-colors duration-200 min-h-screen flex flex-col antialiased"
      x-data="{ darkMode: localStorage.getItem('darkMode') === 'true' }"
      x-init="$watch('darkMode', val => localStorage.setItem('darkMode', val))"
      :class="{ 'dark bg-slate-900 text-slate-100': darkMode }">

    <!-- Header Navbar -->
    <header class="bg-bushgreen text-white border-b-2 border-gold h-20 flex items-center justify-between px-6 shadow-md relative z-30">
        <div class="flex items-center gap-3">
            <a href="dashboard.php" class="py-1.5 px-3 border border-white/20 hover:bg-white/10 text-white rounded-lg text-xs font-bold transition">
                &larr; Back to Dashboard
            </a>
            <div class="w-8 h-8 rounded bg-white/10 flex items-center justify-center border border-white/20 p-1 flex-shrink-0">
                <?php echo getAppLogoHtml('w-full h-full object-contain', 'dashboard'); ?>
            </div>
            <span class="text-white font-extrabold text-sm font-display hidden sm:inline">PBAT SMART NATION INITIATIVE</span>
        </div>
        <div class="flex items-center gap-4 text-xs font-bold text-gold uppercase tracking-wider">
            <!-- Dark Mode Toggle -->
            <button @click="darkMode = !darkMode" class="p-2 rounded-lg border border-gold/45 text-gold hover:bg-gold/10 transition flex items-center justify-center">
                <svg x-show="darkMode" class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364-6.364l-.707.707M6.364 17.636l-.707.707M18.364 17.636l-.707-.707M6.364 6.364l-.707-.707M15 12a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                <svg x-show="!darkMode" class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z"/></svg>
            </button>
            <span>State & Zonal Hub</span>
        </div>
    </header>

    <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 flex-grow w-full space-y-10">
        
        <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div class="space-y-1">
                <h1 class="text-2xl sm:text-3xl font-black text-bushgreen dark:text-gold font-display">Geopolitical Zonal & State Hub</h1>
                <p class="text-slate-500 dark:text-slate-400 text-xs font-light">Add districts, track regional registrations, and inspect active state command chains.</p>
            </div>

            <?php if (!empty($success)): ?>
                <div class="px-4 py-2 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs font-semibold">
                    <?php echo htmlspecialchars($success); ?>
                </div>
            <?php endif; ?>

            <?php if (!empty($error)): ?>
                <div class="px-4 py-2 bg-red-50 border border-red-200 text-red-800 rounded-xl text-xs font-semibold">
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>
        </div>

        <!-- Zones summary boxes -->
        <div class="grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-6 gap-6">
            <?php foreach ($zones_summary as $zs): ?>
                <div class="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-100 dark:border-slate-700 shadow-sm text-center">
                    <span class="text-gold font-bold text-[9px] uppercase tracking-wider block"><?php echo htmlspecialchars($zs['zone']); ?></span>
                    <div class="text-xl font-extrabold text-bushgreen dark:text-gold font-display mt-1"><?php echo $zs['amb_count']; ?></div>
                    <span class="text-[8px] text-slate-400 block mt-0.5"><?php echo $zs['state_count']; ?> States Registered</span>
                </div>
            <?php endforeach; ?>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            
            <!-- STATE LIST TABLE (Col 8) -->
            <div class="lg:col-span-8 bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-4">
                <h3 class="text-slate-800 dark:text-slate-200 font-bold text-sm">State & Zonal Performance Directory</h3>
                
                <div class="overflow-x-auto">
                    <table class="w-full text-xs text-left text-slate-500 dark:text-slate-400">
                        <thead class="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase border-b border-slate-100 dark:border-slate-700">
                            <tr>
                                <th class="pb-3">State Name</th>
                                <th class="pb-3">Zone</th>
                                <th class="pb-3 text-center">LGAs</th>
                                <th class="pb-3 text-center">Ambassadors</th>
                                <th class="pb-3 text-right">State Chairman</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-50 dark:divide-slate-700">
                            <?php foreach ($regional_states as $rs): ?>
                                <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-700/50">
                                    <td class="py-3 font-semibold text-slate-800 dark:text-slate-200"><?php echo htmlspecialchars($rs['name']); ?> State</td>
                                    <td class="py-3 font-mono"><?php echo htmlspecialchars($rs['zone']); ?></td>
                                    <td class="py-3 text-center"><?php echo $rs['lga_count']; ?></td>
                                    <td class="py-3 text-center"><?php echo $rs['ambassador_count']; ?></td>
                                    <td class="py-3 text-right text-gold font-semibold"><?php echo htmlspecialchars($rs['chairman_name'] ?? 'Not Appointed'); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- ADD LGA FORM (Col 4) -->
            <div class="lg:col-span-4 bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-4">
                <div class="pb-2 border-b border-slate-100 dark:border-slate-700">
                    <h3 class="text-slate-800 dark:text-slate-200 font-bold text-sm">Add Local Government (LGA)</h3>
                    <p class="text-[10px] text-slate-400">Add local districts to structure cascading registration options.</p>
                </div>

                <form method="POST" action="" class="space-y-4">
                    <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                    <input type="hidden" name="action" value="add_lga">

                    <div>
                        <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1.5" for="state_id">Assign State Jurisdiction *</label>
                        <select name="state_id" id="state_id" required
                                class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                            <option value="">-- Choose State --</option>
                            <?php foreach ($regional_states as $s): ?>
                                <option value="<?php echo $s['id']; ?>"><?php echo htmlspecialchars($s['name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div>
                        <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1.5" for="lga_name">LGA Name *</label>
                        <input type="text" name="lga_name" id="lga_name" required placeholder="e.g. Surulere"
                               class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                    </div>

                    <button type="submit" class="w-full py-2.5 bg-bushgreen hover:bg-bushgreen-light text-white text-xs font-bold rounded-lg transition shadow-md">
                        Create Local LGA Node
                    </button>
                </form>
            </div>

        </div>

    </main>
</body>
</html>
