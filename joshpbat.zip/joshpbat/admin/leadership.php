<?php
/**
 * PBAT Smart Nation Initiative - Leadership Management
 * Tracks appoints, performance scores, activity counts, and regional metrics.
 */
require_once dirname(__DIR__) . '/helpers/auth.php';
require_once dirname(__DIR__) . '/helpers/common.php';
require_once dirname(__DIR__) . '/config/database.php';

Auth::requireRole(['super_admin', 'founder_circle', 'national_steering'], '../login.php');

$user = Auth::user();
$error = '';
$success = '';

try {
    $db = Database::connect();

    // 1. Handle Leadership Level Promotions
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'promote_leader') {
        if (!Auth::validateCsrf($_POST['csrf_token'] ?? '')) {
            $error = "Security token expired.";
        } else {
            $target_user_id = (int)$_POST['target_user_id'];
            $tier_id = (int)$_POST['tier_id'];
            $zone = trim($_POST['zone'] ?? '');
            $state_id = !empty($_POST['state_id']) ? (int)$_POST['state_id'] : null;
            $lga_id = !empty($_POST['lga_id']) ? (int)$_POST['lga_id'] : null;

            $db->beginTransaction();

            // Insert mapping
            $stmt = $db->prepare("
                INSERT INTO `user_leadership` (`user_id`, `tier_id`, `zone`, `state_id`, `lga_id`, `appointed_by`)
                VALUES (?, ?, ?, ?, ?, ?)
                ON DUPLICATE KEY UPDATE `tier_id` = ?, `zone` = ?, `state_id` = ?, `lga_id` = ?, `appointed_by` = ?
            ");
            $stmt->execute([
                $target_user_id, $tier_id, $zone, $state_id, $lga_id, $user['id'],
                $tier_id, $zone, $state_id, $lga_id, $user['id']
            ]);

            // Promote role ID matching
            $role_id = 7; // Default ambassador
            if ($tier_id === 1) $role_id = 2; // Founder Circle
            if ($tier_id === 2) $role_id = 3; // National Steering
            if ($tier_id === 3) $role_id = 4; // Zonal
            if ($tier_id === 4) $role_id = 5; // State
            if ($tier_id === 5) $role_id = 6; // LGA Coordinator

            $stmt = $db->prepare("UPDATE `users` SET `role_id` = ? WHERE `id` = ?");
            $stmt->execute([$role_id, $target_user_id]);

            // Fetch target user for notification and log
            $stmt_target = $db->prepare("SELECT `name`, `email` FROM `users` WHERE `id` = ?");
            $stmt_target->execute([$target_user_id]);
            $target_user = $stmt_target->fetch();

            if ($target_user) {
                require_once dirname(__DIR__) . '/helpers/notifications.php';
                $role_title = Auth::getRoleNameById($role_id);
                NotificationEmail::sendAppointment($target_user['email'], $target_user['name'], $role_title, $user['name']);
            }

            Auth::logAction($user['id'], 'LEADERSHIP_APPOINT', "Appointed user ID {$target_user_id} to Leadership Tier {$tier_id}");
            $db->commit();
            $success = "Leadership appointment successfully saved!";
        }
    }

    // Fetch leadership tiers
    $stmt = $db->query("SELECT * FROM `leadership_tiers` ORDER BY `level` ASC");
    $tiers = $stmt->fetchAll();

    // Fetch active leaders list with metrics
    $stmt = $db->query("
        SELECT u.id, u.name, u.email, r.display_name as role_name, ul.zone, s.name as state_name, l.name as lga_name,
               COALESCE(a.impact_score, 100) as score,
               (SELECT COUNT(1) FROM audit_logs WHERE user_id = u.id) as activity_count
        FROM users u
        JOIN roles r ON u.role_id = r.id
        LEFT JOIN user_leadership ul ON u.id = ul.user_id
        LEFT JOIN states s ON ul.state_id = s.id
        LEFT JOIN lgas l ON ul.lga_id = l.id
        LEFT JOIN ambassadors a ON u.id = a.user_id
        WHERE u.role_id < 7
        ORDER BY u.role_id ASC, score DESC
    ");
    $leaders = $stmt->fetchAll();

    // Fetch eligible users for promotion
    $stmt = $db->query("SELECT id, name, email FROM users ORDER BY name ASC");
    $all_users = $stmt->fetchAll();

    // Fetch States
    $stmt = $db->query("SELECT id, name FROM states ORDER BY name ASC");
    $states = $stmt->fetchAll();

} catch (Exception $e) {
    $error = "System Database Error: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Leadership Directory - PBAT Smart Nation</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        bushgreen: {
                            DEFAULT: '#063C1E',
                            light: '#0A4D27',
                            dark: '#03200F',
                        },
                        gold: '#D4AF37'
                    }
                }
            }
        }
    </script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Outfit', sans-serif; }
    </style>
</head>
<body class="bg-slate-50 min-h-screen flex flex-col antialiased">

    <!-- Header Navbar -->
    <header class="bg-bushgreen text-white border-b-2 border-gold h-20 flex items-center justify-between px-6 shadow-md relative z-30">
        <div class="flex items-center gap-3">
            <a href="dashboard.php" class="py-1.5 px-3 border border-white/20 hover:bg-white/10 text-white rounded-lg text-xs font-bold transition">
                &larr; Back to Dashboard
            </a>
            <div class="w-8 h-8 rounded bg-white/10 flex items-center justify-center border border-white/20 p-1 flex-shrink-0">
                <?php echo getAppLogoHtml('w-full h-full object-contain', 'dashboard'); ?>
            </div>
            <span class="text-white font-extrabold text-sm font-display hidden sm:inline">PBAT SMART NATION INITIATIVE</span>
        </div>
        <div class="flex items-center gap-3 text-xs font-bold text-gold uppercase tracking-wider">
            Leadership Command Center
        </div>
    </header>

    <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 flex-grow w-full space-y-10">
        
        <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div class="space-y-1">
                <h1 class="text-2xl sm:text-3xl font-black text-bushgreen font-display">Leadership Hierarchy & Performance</h1>
                <p class="text-slate-500 text-xs font-light">Appoint leaders to strategic committees, assign regional jurisdictions, and monitor structural performance logs.</p>
            </div>

            <?php if (!empty($success)): ?>
                <div class="px-4 py-2 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs font-semibold">
                    <?php echo htmlspecialchars($success); ?>
                </div>
            <?php endif; ?>

            <?php if (!empty($error)): ?>
                <div class="px-4 py-2 bg-red-50 border border-red-200 text-red-800 rounded-xl text-xs font-semibold">
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            
            <!-- DIRECTORY LIST (Col 8) -->
            <div class="lg:col-span-8 bg-white rounded-2xl border border-slate-100 p-6 shadow-sm space-y-6">
                <div>
                    <h3 class="text-slate-800 font-bold text-sm">Appointed Officers & Steering Councils</h3>
                    <p class="text-[10px] text-slate-400 font-light">Comprehensive roster of administrators, chairmen, and coordinators.</p>
                </div>

                <div class="overflow-x-auto">
                    <table class="w-full text-xs text-left text-slate-500">
                        <thead class="text-[10px] text-slate-400 font-bold uppercase tracking-wider border-b border-slate-100">
                            <tr>
                                <th class="pb-3">Officer</th>
                                <th class="pb-3">Designation</th>
                                <th class="pb-3">Jurisdiction</th>
                                <th class="pb-3 text-center">Performance Score</th>
                                <th class="pb-3 text-center">Activity Logs</th>
                                <th class="pb-3 text-right">Attendance</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-50">
                            <?php foreach ($leaders as $row): 
                                $attendance = $row['score'] > 80 ? '98%' : ($row['score'] > 50 ? '85%' : '60%');
                            ?>
                                <tr class="hover:bg-slate-50/50">
                                    <td class="py-3.5 pr-4">
                                        <span class="font-bold text-slate-800 block"><?php echo htmlspecialchars($row['name']); ?></span>
                                        <span class="text-[10px] text-slate-400 font-mono"><?php echo htmlspecialchars($row['email']); ?></span>
                                    </td>
                                    <td class="py-3.5">
                                        <span class="px-2.5 py-0.5 rounded bg-bushgreen text-white text-[9px] font-bold uppercase tracking-wide">
                                            <?php echo htmlspecialchars($row['role_name']); ?>
                                        </span>
                                    </td>
                                    <td class="py-3.5 font-medium text-slate-600">
                                        <?php 
                                        if ($row['state_name']) echo htmlspecialchars($row['state_name']) . ' State';
                                        elseif ($row['zone']) echo htmlspecialchars($row['zone']) . ' Zone';
                                        else echo 'National';
                                        ?>
                                    </td>
                                    <td class="py-3.5 text-center font-bold text-gold font-mono"><?php echo $row['score']; ?> pts</td>
                                    <td class="py-3.5 text-center font-mono text-slate-600"><?php echo $row['activity_count']; ?> logs</td>
                                    <td class="py-3.5 text-right font-bold text-emerald-600"><?php echo $attendance; ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- APPOINTMENT WRAPPER (Col 4) -->
            <div class="lg:col-span-4 bg-white rounded-2xl border border-slate-100 p-6 shadow-sm space-y-6">
                <div class="pb-3 border-b border-slate-100">
                    <h3 class="text-slate-800 font-bold text-sm">Appoint Leader</h3>
                    <p class="text-[10px] text-slate-400 font-light">Promote accounts and set regional/zonal jurisdictions.</p>
                </div>

                <form method="POST" action="" class="space-y-4">
                    <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                    <input type="hidden" name="action" value="promote_leader">

                    <div>
                        <label class="block text-slate-600 text-xs font-semibold mb-1.5" for="target_user_id">Select Target User *</label>
                        <select name="target_user_id" id="target_user_id" required
                                class="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                            <option value="">-- Choose User --</option>
                            <?php foreach ($all_users as $u): ?>
                                <option value="<?php echo $u['id']; ?>"><?php echo htmlspecialchars($u['name']); ?> (<?php echo htmlspecialchars($u['email']); ?>)</option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div>
                        <label class="block text-slate-600 text-xs font-semibold mb-1.5" for="tier_id">Leadership Committee Level *</label>
                        <select name="tier_id" id="tier_id" required
                                class="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                            <option value="">-- Choose Committee --</option>
                            <?php foreach ($tiers as $t): ?>
                                <option value="<?php echo $t['id']; ?>"><?php echo htmlspecialchars($t['name']); ?> (Level <?php echo $t['level']; ?>)</option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div>
                        <label class="block text-slate-600 text-xs font-semibold mb-1.5" for="zone">Geopolitical Zone (If Zonal)</label>
                        <select name="zone" id="zone"
                                class="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                            <option value="">-- Not Applicable --</option>
                            <option value="South-West">South-West</option>
                            <option value="North-Central">North-Central</option>
                            <option value="South-South">South-South</option>
                            <option value="North-West">North-West</option>
                            <option value="South-East">South-East</option>
                            <option value="North-East">North-East</option>
                        </select>
                    </div>

                    <div>
                        <label class="block text-slate-600 text-xs font-semibold mb-1.5" for="state_id">State Chapter (If State/LGA)</label>
                        <select name="state_id" id="state_id"
                                class="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                            <option value="">-- Not Applicable --</option>
                            <?php foreach ($states as $s): ?>
                                <option value="<?php echo $s['id']; ?>"><?php echo htmlspecialchars($s['name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <button type="submit" class="w-full py-2.5 bg-bushgreen hover:bg-bushgreen-light text-white text-xs font-bold rounded-lg transition shadow-md shadow-bushgreen/10">
                        Commit Leadership Promotion
                    </button>
                </form>
            </div>

        </div>

    </main>
</body>
</html>
