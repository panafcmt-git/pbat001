<?php
/**
 * PBAT Smart Nation Initiative - Secure Document Upload Controller
 * Validates file sizes, mime types, sanitizes names, and records database uploads.
 */
require_once dirname(__DIR__) . '/helpers/auth.php';
require_once dirname(__DIR__) . '/helpers/common.php';
require_once dirname(__DIR__) . '/config/database.php';

if (!Auth::isLoggedIn()) {
    header("Location: ../login.php");
    exit;
}

$user = Auth::user();
$user_id = $user['id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 1. CSRF validation
    if (!Auth::validateCsrf($_POST['csrf_token'] ?? '')) {
        $_SESSION['auth_error'] = "Security validation expired. Document upload aborted.";
        header("Location: dashboard.php");
        exit;
    }

    $title = sanitize($_POST['title']);
    $description = sanitize($_POST['description']);
    $state_id = (int)$_POST['state_id'];

    // 2. Validate File upload element
    if (!isset($_FILES['doc_upload']) || $_FILES['doc_upload']['error'] !== UPLOAD_ERR_OK) {
        $_SESSION['auth_error'] = "File upload failed. No document selected or uploaded.";
        header("Location: dashboard.php");
        exit;
    }

    $file = $_FILES['doc_upload'];
    $file_size = $file['size'];
    $file_tmp = $file['tmp_name'];
    $file_name = basename($file['name']);
    $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

    $allowed_extensions = ['pdf', 'jpg', 'jpeg', 'png'];
    $allowed_mimes = ['application/pdf', 'image/jpeg', 'image/png'];

    // Secure verification
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime_type = finfo_file($finfo, $file_tmp);
    finfo_close($finfo);

    if (!in_array($file_ext, $allowed_extensions) || !in_array($mime_type, $allowed_mimes)) {
        $_SESSION['auth_error'] = "Invalid file type. Only PDF and JPG/PNG images are authorized.";
        header("Location: dashboard.php");
        exit;
    }

    if ($file_size > 5242880) { // 5MB limit
        $_SESSION['auth_error'] = "File size exceeded. Maximum authorized document size is 5MB.";
        header("Location: dashboard.php");
        exit;
    }

    // 3. Prepare target upload path
    $upload_dir = dirname(__DIR__) . '/uploads/';
    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0755, true);
    }

    // Generate unique file name to avoid namespace collision
    $new_file_name = uniqid('DOC-', true) . '.' . $file_ext;
    $target_file = $upload_dir . $new_file_name;
    $db_save_path = 'uploads/' . $new_file_name;

    if (move_uploaded_file($file_tmp, $target_file)) {
        try {
            $db = Database::connect();
            $db->beginTransaction();

            // 1. Save upload file details in media_uploads
            $stmt = $db->prepare("INSERT INTO `media_uploads` (`user_id`, `title`, `file_path`, `file_type`) VALUES (?, ?, ?, ?)");
            $stmt->execute([$user_id, $file_name, $db_save_path, $mime_type]);

            // 2. Save briefing report linked to this file
            $stmt = $db->prepare("INSERT INTO `reports` (`user_id`, `title`, `description`, `file_path`, `state_id`, `status`) VALUES (?, ?, ?, ?, ?, 'submitted')");
            $stmt->execute([$user_id, $title, $description, $db_save_path, $state_id]);

            // 3. Log administrative audit log
            Auth::logAction($user_id, 'DOC_UPLOAD', "Uploaded file: '{$file_name}' and filed briefing report.");

            // Update state analytics summary
            $db->exec("UPDATE `analytics_summary` SET `reports_filed` = `reports_filed` + 1, `impact_score` = `impact_score` + 75 WHERE `state_id` = {$state_id}");

            $db->commit();
            $_SESSION['success_msg'] = "Field Briefing report and document uploaded successfully!";

        } catch (Exception $e) {
            if (isset($db) && $db->inTransaction()) {
                $db->rollBack();
            }
            $_SESSION['auth_error'] = "System Database Exception: " . $e->getMessage();
        }
    } else {
        $_SESSION['auth_error'] = "Failed to write uploaded file to destination storage directories.";
    }

    header("Location: dashboard.php");
    exit;
}
?>
