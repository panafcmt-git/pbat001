<?php
/**
 * PBAT Smart Nation Initiative - Homepage & Sub-Page CMS Editor
 * Allows Super Admin to modify system settings, landing banners, copy texts, and image uploads.
 */
require_once dirname(__DIR__) . '/helpers/auth.php';
require_once dirname(__DIR__) . '/helpers/common.php';
require_once dirname(__DIR__) . '/config/database.php';

Auth::requireRole(['super_admin', 'founder_circle'], '../login.php');

$user = Auth::user();
$error = '';
$success = '';

try {
    $db = Database::connect();

    // 1. Handle Reset Actions
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
        if (!Auth::validateCsrf($_POST['csrf_token'] ?? '')) {
            $error = "CSRF Token validation failed.";
        } else {
            if ($_POST['action'] === 'reset_logo') {
                $db->prepare("UPDATE `system_settings` SET `setting_value` = '' WHERE `setting_key` = 'logo_url'")->execute();
                Auth::logAction($user['id'], 'CMS_LOGO_RESET', "Reset brand logo to default.");
                $success = "Brand logo reset to default successfully!";
            } elseif ($_POST['action'] === 'reset_hero_image') {
                $db->prepare("UPDATE `system_settings` SET `setting_value` = 'uploads/pbat_hero.jpg' WHERE `setting_key` = 'hero_image_url'")->execute();
                Auth::logAction($user['id'], 'CMS_HERO_RESET', "Reset Hero image to default.");
                $success = "Hero image reset to default successfully!";
            } elseif ($_POST['action'] === 'reset_about_image') {
                $db->prepare("UPDATE `system_settings` SET `setting_value` = 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=500&q=80' WHERE `setting_key` = 'about_image_url'")->execute();
                Auth::logAction($user['id'], 'CMS_ABOUT_RESET', "Reset About image to default.");
                $success = "About image reset to default successfully!";
            }
        }
    }

    // 2. Handle Settings Update
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_settings') {
        if (!Auth::validateCsrf($_POST['csrf_token'] ?? '')) {
            $error = "CSRF Token validation failed.";
        } else {
            // Retrieve existing values first to avoid overwriting files if not uploaded
            $stmt = $db->query("SELECT * FROM `system_settings`");
            $existing_settings = [];
            foreach ($stmt->fetchAll() as $row) {
                $existing_settings[$row['setting_key']] = $row['setting_value'];
            }

            $logo_url = trim($_POST['logo_url'] ?? $existing_settings['logo_url'] ?? '');
            $hero_image_url = trim($_POST['hero_image_url'] ?? $existing_settings['hero_image_url'] ?? 'uploads/pbat_hero.jpg');
            $about_image_url = trim($_POST['about_image_url'] ?? $existing_settings['about_image_url'] ?? 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=500&q=80');

            $upload_dir = dirname(__DIR__) . '/uploads/';
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0755, true);
            }

            // Handle Logo file upload
            if (isset($_FILES['logo_upload']) && $_FILES['logo_upload']['error'] === UPLOAD_ERR_OK) {
                $file = $_FILES['logo_upload'];
                $file_name = basename($file['name']);
                $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
                if (in_array($file_ext, ['jpg', 'jpeg', 'png', 'gif', 'svg', 'webp'])) {
                    if ($file['size'] <= 2097152) { // 2MB
                        $new_file_name = 'logo_' . time() . '.' . $file_ext;
                        if (move_uploaded_file($file['tmp_name'], $upload_dir . $new_file_name)) {
                            $logo_url = 'uploads/' . $new_file_name;
                        } else {
                            $error = "Failed to write logo to destination folder.";
                        }
                    } else {
                        $error = "Logo size exceeds 2MB limit.";
                    }
                } else {
                    $error = "Invalid logo file extension.";
                }
            }

            // Handle Hero Image file upload
            if (empty($error) && isset($_FILES['hero_image_upload']) && $_FILES['hero_image_upload']['error'] === UPLOAD_ERR_OK) {
                $file = $_FILES['hero_image_upload'];
                $file_name = basename($file['name']);
                $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
                if (in_array($file_ext, ['jpg', 'jpeg', 'png', 'gif', 'svg', 'webp'])) {
                    if ($file['size'] <= 4194304) { // 4MB
                        $new_file_name = 'hero_' . time() . '.' . $file_ext;
                        if (move_uploaded_file($file['tmp_name'], $upload_dir . $new_file_name)) {
                            $hero_image_url = 'uploads/' . $new_file_name;
                        } else {
                            $error = "Failed to write hero image to destination folder.";
                        }
                    } else {
                        $error = "Hero image size exceeds 4MB limit.";
                    }
                } else {
                    $error = "Invalid hero image file extension.";
                }
            }

            // Handle About Image file upload
            if (empty($error) && isset($_FILES['about_image_upload']) && $_FILES['about_image_upload']['error'] === UPLOAD_ERR_OK) {
                $file = $_FILES['about_image_upload'];
                $file_name = basename($file['name']);
                $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
                if (in_array($file_ext, ['jpg', 'jpeg', 'png', 'gif', 'svg', 'webp'])) {
                    if ($file['size'] <= 4194304) { // 4MB
                        $new_file_name = 'about_' . time() . '.' . $file_ext;
                        if (move_uploaded_file($file['tmp_name'], $upload_dir . $new_file_name)) {
                            $about_image_url = 'uploads/' . $new_file_name;
                        } else {
                            $error = "Failed to write about image to destination folder.";
                        }
                    } else {
                        $error = "About image size exceeds 4MB limit.";
                    }
                } else {
                    $error = "Invalid about image file extension.";
                }
            }

            if (empty($error)) {
                $settings = [
                    'site_name' => trim($_POST['site_name'] ?? ''),
                    'logo_size' => trim($_POST['logo_size'] ?? '40'),
                    'footer_copyright' => trim($_POST['footer_copyright'] ?? ''),
                    'contact_email' => trim($_POST['contact_email'] ?? ''),
                    'contact_phone' => trim($_POST['contact_phone'] ?? ''),
                    'seo_meta_keywords' => trim($_POST['seo_meta_keywords'] ?? ''),
                    'seo_meta_description' => trim($_POST['seo_meta_description'] ?? ''),
                    'logo_url' => $logo_url,
                    
                    // Hero Section
                    'hero_badge' => trim($_POST['hero_badge'] ?? ''),
                    'hero_title' => trim($_POST['hero_title'] ?? ''),
                    'hero_desc' => trim($_POST['hero_desc'] ?? ''),
                    'hero_btn1_text' => trim($_POST['hero_btn1_text'] ?? ''),
                    'hero_btn1_url' => trim($_POST['hero_btn1_url'] ?? ''),
                    'hero_btn2_text' => trim($_POST['hero_btn2_text'] ?? ''),
                    'hero_btn2_url' => trim($_POST['hero_btn2_url'] ?? ''),
                    'hero_image_url' => $hero_image_url,
                    'hero_patron_name' => trim($_POST['hero_patron_name'] ?? ''),
                    'hero_patron_tag' => trim($_POST['hero_patron_tag'] ?? ''),
                    'hero_widget_label' => trim($_POST['hero_widget_label'] ?? ''),
                    'hero_widget_val' => trim($_POST['hero_widget_val'] ?? ''),
                    
                    // Homepage Sections
                    'about_image_url' => $about_image_url,
                    'about_badge' => trim($_POST['about_badge'] ?? ''),
                    'about_heading' => trim($_POST['about_heading'] ?? ''),
                    'about_content' => trim($_POST['about_content'] ?? ''),
                    'about_val1_title' => trim($_POST['about_val1_title'] ?? ''),
                    'about_val1_text' => trim($_POST['about_val1_text'] ?? ''),
                    'about_val2_title' => trim($_POST['about_val2_title'] ?? ''),
                    'about_val2_text' => trim($_POST['about_val2_text'] ?? ''),
                    'about_val3_title' => trim($_POST['about_val3_title'] ?? ''),
                    'about_val3_text' => trim($_POST['about_val3_text'] ?? ''),
                    'banner_badge' => trim($_POST['banner_badge'] ?? ''),
                    'banner_title' => trim($_POST['banner_title'] ?? ''),
                    'banner_subtitle' => trim($_POST['banner_subtitle'] ?? ''),
                    'banner_btn_text' => trim($_POST['banner_btn_text'] ?? ''),
                    'banner_btn_url' => trim($_POST['banner_btn_url'] ?? ''),
                    'pillars_badge' => trim($_POST['pillars_badge'] ?? ''),
                    'pillars_heading' => trim($_POST['pillars_heading'] ?? ''),
                    'pillars_subtitle' => trim($_POST['pillars_subtitle'] ?? ''),
                    'pillars_intro_title' => trim($_POST['pillars_intro_title'] ?? ''),
                    'pillars_intro_desc1' => trim($_POST['pillars_intro_desc1'] ?? ''),
                    'pillars_intro_desc2' => trim($_POST['pillars_intro_desc2'] ?? ''),
                    
                    // Sub-Pages Content
                    'page_about_banner_badge' => trim($_POST['page_about_banner_badge'] ?? ''),
                    'page_about_banner_title' => trim($_POST['page_about_banner_title'] ?? ''),
                    'page_about_banner_desc' => trim($_POST['page_about_banner_desc'] ?? ''),
                    'page_about_vision_title' => trim($_POST['page_about_vision_title'] ?? ''),
                    'page_about_vision_desc' => trim($_POST['page_about_vision_desc'] ?? ''),
                    'page_about_mission_title' => trim($_POST['page_about_mission_title'] ?? ''),
                    'page_about_mission_desc' => trim($_POST['page_about_mission_desc'] ?? ''),
                    'page_about_org_title' => trim($_POST['page_about_org_title'] ?? ''),
                    'page_about_org_desc' => trim($_POST['page_about_org_desc'] ?? ''),
                    'page_about_charter_title' => trim($_POST['page_about_charter_title'] ?? ''),
                    'page_about_charter_desc' => trim($_POST['page_about_charter_desc'] ?? ''),
                    'page_pillars_banner_badge' => trim($_POST['page_pillars_banner_badge'] ?? ''),
                    'page_pillars_banner_title' => trim($_POST['page_pillars_banner_title'] ?? ''),
                    'page_pillars_banner_desc' => trim($_POST['page_pillars_banner_desc'] ?? ''),
                    'page_pillars_intro_desc1' => trim($_POST['page_pillars_intro_desc1'] ?? ''),
                    'page_pillars_intro_desc2' => trim($_POST['page_pillars_intro_desc2'] ?? ''),
                    'page_pillars_intro_desc3' => trim($_POST['page_pillars_intro_desc3'] ?? ''),
                    'page_pillars_intro_desc4' => trim($_POST['page_pillars_intro_desc4'] ?? ''),
                    'page_courses_banner_badge' => trim($_POST['page_courses_banner_badge'] ?? ''),
                    'page_courses_banner_title' => trim($_POST['page_courses_banner_title'] ?? ''),
                    'page_courses_banner_desc' => trim($_POST['page_courses_banner_desc'] ?? '')
                ];

                $stmt = $db->prepare("INSERT INTO `system_settings` (`setting_key`, `setting_value`) VALUES (?, ?) ON DUPLICATE KEY UPDATE `setting_value` = ?");
                foreach ($settings as $key => $value) {
                    $stmt->execute([$key, $value, $value]);
                }

                Auth::logAction($user['id'], 'CMS_SETTINGS_UPDATE', "Updated landing page, sub-pages, and image configurations.");
                $success = "CMS and website settings updated successfully!";
            }
        }
    }

    // 3. Fetch all system settings
    $stmt = $db->query("SELECT * FROM `system_settings`");
    $settings_rows = $stmt->fetchAll();
    $settings = [];
    foreach ($settings_rows as $row) {
        $settings[$row['setting_key']] = $row['setting_value'];
    }

    // Fallbacks
    $site_name = $settings['site_name'] ?? 'PBAT Smart Nation Initiative';
    $logo_url = $settings['logo_url'] ?? '';
    $logo_size = $settings['logo_size'] ?? '40';
    $footer_copyright = $settings['footer_copyright'] ?? '&copy; 2026 PBAT Smart Nation Initiative.';
    $contact_email = $settings['contact_email'] ?? 'info@pbat-smartnation.ng';
    $contact_phone = $settings['contact_phone'] ?? '+2348030000001';
    $seo_keywords = $settings['seo_meta_keywords'] ?? 'smart nation, tech advocacy, coding initiative';
    $seo_desc = $settings['seo_meta_description'] ?? 'Independent advocacy driving technology leadership across Nigeria.';

    // Hero Section
    $hero_badge = $settings['hero_badge'] ?? "Nigeria's Smart Evolution";
    $hero_title = $settings['hero_title'] ?? "PBAT SMART \r\nNATION INITIATIVE";
    $hero_desc = $settings['hero_desc'] ?? "An independent, high-impact advocacy platform driving youth tech capacity building, AI sensitization, localized innovation hubs, and community technology leadership templates.";
    $hero_btn1_text = $settings['hero_btn1_text'] ?? "JOIN ADVOCATES";
    $hero_btn1_url = $settings['hero_btn1_url'] ?? "register.php";
    $hero_btn2_text = $settings['hero_btn2_text'] ?? "READ OUR CHARTER";
    $hero_btn2_url = $settings['hero_btn2_url'] ?? "#about";
    $hero_image_url = $settings['hero_image_url'] ?? "uploads/pbat_hero.jpg";
    $hero_patron_name = $settings['hero_patron_name'] ?? "PRESIDENT BOLA AHMED TINUBU";
    $hero_patron_tag = $settings['hero_patron_tag'] ?? "Patron";
    $hero_widget_label = $settings['hero_widget_label'] ?? "Digital Literacy Campaign";
    $hero_widget_val = $settings['hero_widget_val'] ?? "36 States + FCT";

    // Homepage Sections
    $about_image_url = $settings['about_image_url'] ?? "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=500&q=80";
    $about_badge = $settings['about_badge'] ?? "Strategic Mandate";
    $about_heading = $settings['about_heading'] ?? "As an Advocacy Group, our vision is to work with the Presidency, the States, Local Governments, Communities and Private Investors in Empowering Every Citizen Through Digital Excellence.";
    $about_content = $settings['about_content'] ?? "The PBAT Smart Nation Initiative functions as a catalyst. We are dedicated to ensuring that digital technologies are not localized inside financial hubs alone, but integrated thoroughly into agricultural sectors, state primary education programs, and municipal workflows.";
    $about_val1_title = $settings['about_val1_title'] ?? "PUBLIC TRUST";
    $about_val1_text = $settings['about_val1_text'] ?? "Ensuring clear, unbiased, state-level monitoring and performance indexes.";
    $about_val2_title = $settings['about_val2_title'] ?? "CAPACITY BUILDING";
    $about_val2_text = $settings['about_val2_text'] ?? "Standardizing coding bootcamps and tech skill classes for local youths.";
    $about_val3_title = $settings['about_val3_title'] ?? "INCLUSIVE GROWTH";
    $about_val3_text = $settings['about_val3_text'] ?? "Targeting underserved LGAs and giving direct access to software pathways.";
    
    $banner_badge = $settings['banner_badge'] ?? "National Core Ideology";
    $banner_title = $settings['banner_title'] ?? "\"BUILDING A SMART, UNITED NIGERIA\"";
    $banner_subtitle = $settings['banner_subtitle'] ?? "Our initiative envisions a tech-driven nation where innovation drives prosperity, administration guarantees seamless transparency, and communities unified through digital access.";
    $banner_btn_text = $settings['banner_btn_text'] ?? "Register as Grassroots Ambassador";
    $banner_btn_url = $settings['banner_btn_url'] ?? "register.php";
    
    $pillars_badge = $settings['pillars_badge'] ?? "Development Pillars";
    $pillars_heading = $settings['pillars_heading'] ?? "Our Key Pillars";
    $pillars_subtitle = $settings['pillars_subtitle'] ?? "Focus areas driving national digital transformation awareness and skills training.";
    $pillars_intro_title = $settings['pillars_intro_title'] ?? "Building Nigeria's Digital Future";
    $pillars_intro_desc1 = $settings['pillars_intro_desc1'] ?? "The PBAT Smart Nation Initiative is anchored on a vision of technological empowerment, civic transparency, and sustainable development. By dividing our focus into five specialized strategic pillars, we ensure that every community, local business, and public department gets custom advocacy, sensitization, and practical digital training.";
    $pillars_intro_desc2 = $settings['pillars_intro_desc2'] ?? "Explore each pillar below to understand how we are coordinating grassroots ambassadors, deploying community coding hubs, advocating for fiber-optic expansion, and promoting telehealth and digital security awareness across Nigeria.";

    // Sub-Pages
    $page_about_banner_badge = $settings['page_about_banner_badge'] ?? "Advocacy Identity";
    $page_about_banner_title = $settings['page_about_banner_title'] ?? "Who We Are";
    $page_about_banner_desc = $settings['page_about_banner_desc'] ?? "Understanding the structural mandate, vision guidelines, and national coordinator network driving inclusive digital evolution.";
    $page_about_vision_title = $settings['page_about_vision_title'] ?? "Our Strategic Vision";
    $page_about_vision_desc = $settings['page_about_vision_desc'] ?? "To serve as a premier non-governmental technology sensitizer across Nigeria, actively bridging connectivity gaps, fostering data intelligence literacy, and establishing active technology centers within rural local government areas.";
    $page_about_mission_title = $settings['page_about_mission_title'] ?? "Our Core Mission";
    $page_about_mission_desc = $settings['page_about_mission_desc'] ?? "We are structured to design regional educational templates, provision certified digital skill paths for youth organizations, and partner with private capital entities to enable robust, inclusive digital transformations.";
    $page_about_org_title = $settings['page_about_org_title'] ?? "Organizational Structure";
    $page_about_org_desc = $settings['page_about_org_desc'] ?? "PBAT Smart Nation operates a disciplined multi-tiered network coordinating digital awareness across geo-political zones.";
    $page_about_charter_title = $settings['page_about_charter_title'] ?? "Our Independence Charter";
    $page_about_charter_desc = $settings['page_about_charter_desc'] ?? "Important Security & Scope Announcement: The PBAT Smart Nation Initiative is a 100% independent, non-governmental public advocacy movement. We function strictly to sensitize citizens on digital policy parameters and empower local youths.";
    
    $page_pillars_banner_badge = $settings['page_pillars_banner_badge'] ?? "Development Vectors";
    $page_pillars_banner_title = $settings['page_pillars_banner_title'] ?? "Our Key Pillars";
    $page_pillars_banner_desc = $settings['page_pillars_banner_desc'] ?? "Exploring the structural parameters driving open administration, cashless trading, and broadband accessibility.";
    $page_pillars_intro_desc1 = $settings['page_pillars_intro_desc1'] ?? "Our Key Pillars represent the core values and strategic focus areas that drive our vision for growth, innovation, and sustainable impact. They serve as the foundation for every initiative, program, and partnership we undertake, ensuring that our efforts remain aligned with our mission to empower people, strengthen communities, and create lasting transformation.";
    $page_pillars_intro_desc2 = $settings['page_pillars_intro_desc2'] ?? "Through these pillars, we are committed to advancing opportunities in education, technology, entrepreneurship, leadership, and social development. Each pillar is carefully designed to address critical challenges, encourage innovation, and promote inclusive progress across different sectors and communities.";
    $page_pillars_intro_desc3 = $settings['page_pillars_intro_desc3'] ?? "We believe that meaningful development is achieved through collaboration, creativity, and consistent investment in people and ideas. By focusing on these essential areas, we create pathways for individuals and organizations to grow, thrive, and contribute positively to society.";
    $page_pillars_intro_desc4 = $settings['page_pillars_intro_desc4'] ?? "Our Key Pillars are more than just areas of focus — they are a reflection of our commitment to building a future driven by knowledge, empowerment, sustainability, and measurable impact. Together, they guide our journey toward creating innovative solutions and transformative opportunities for generations to come.";
    
    $page_courses_banner_badge = $settings['page_courses_banner_badge'] ?? "Smart Academy";
    $page_courses_banner_title = $settings['page_courses_banner_title'] ?? "Digital Skills & Innovation";
    $page_courses_banner_desc = $settings['page_courses_banner_desc'] ?? "Free verified courses and educational pathways created to sensitize Nigerian youths and local representatives on emerging technologies, smart city developments, and AI solutions.";

    // Fetch counts
    $blog_count = $db->query("SELECT COUNT(1) FROM `blog_posts`")->fetchColumn();
    $media_count = $db->query("SELECT COUNT(1) FROM `media_uploads`")->fetchColumn();

} catch (Exception $e) {
    $error = "CMS Settings Error: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CMS Portal Editor - PBAT Smart Nation</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        bushgreen: {
                            DEFAULT: '#063C1E',
                            light: '#0A4D27',
                            dark: '#03200F',
                        },
                        gold: '#D4AF37'
                    }
                }
            }
        }
    </script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        [x-cloak] { display: none !important; }
        body { font-family: 'Inter', sans-serif; }
        h1, h2, h3, h4, .font-display { font-family: 'Outfit', sans-serif; }
    </style>
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
</head>
<body class="bg-slate-50 text-slate-800 transition-colors duration-200 min-h-screen flex flex-col antialiased"
      x-data="{ darkMode: localStorage.getItem('darkMode') === 'true', activeTab: 'global' }"
      x-init="$watch('darkMode', val => localStorage.setItem('darkMode', val))"
      :class="{ 'dark bg-slate-900 text-slate-100': darkMode }">

    <!-- Header Navbar -->
    <header class="bg-bushgreen text-white border-b-2 border-gold h-20 flex items-center justify-between px-6 shadow-md relative z-30">
        <div class="flex items-center gap-3">
            <a href="dashboard.php" class="py-1.5 px-3 border border-white/20 hover:bg-white/10 text-white rounded-lg text-xs font-bold transition">
                &larr; Back to Dashboard
            </a>
            <div class="w-8 h-8 rounded bg-white/10 flex items-center justify-center border border-white/20 p-1 flex-shrink-0">
                <?php echo getAppLogoHtml('w-full h-full object-contain', 'dashboard'); ?>
            </div>
            <span class="text-white font-extrabold text-sm font-display hidden sm:inline">PBAT SMART NATION INITIATIVE</span>
        </div>
        <div class="flex items-center gap-4 text-xs font-bold text-gold uppercase tracking-wider">
            <!-- Dark Mode Toggle -->
            <button @click="darkMode = !darkMode" class="p-2 rounded-lg border border-gold/45 text-gold hover:bg-gold/10 transition flex items-center justify-center">
                <svg x-show="darkMode" class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364-6.364l-.707.707M6.364 17.636l-.707.707M18.364 17.636l-.707-.707M6.364 6.364l-.707-.707M15 12a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                <svg x-show="!darkMode" class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z"/></svg>
            </button>
            <span>CMS Portal Settings Gate</span>
        </div>
    </header>

    <main class="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-10 flex-grow w-full space-y-8">
        
        <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div class="space-y-1">
                <h1 class="text-2xl sm:text-3xl font-black text-bushgreen dark:text-gold font-display">Content Management System (CMS)</h1>
                <p class="text-slate-500 dark:text-slate-400 text-xs font-light">Control landing page configurations, banner titles, SEO variables, and visual layouts.</p>
            </div>

            <div class="flex flex-col gap-2">
                <?php if (!empty($success)): ?>
                    <div class="px-4 py-2 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs font-semibold">
                        <?php echo htmlspecialchars($success); ?>
                    </div>
                <?php endif; ?>
                <?php if (!empty($error)): ?>
                    <div class="px-4 py-2 bg-red-50 border border-red-200 text-red-800 rounded-xl text-xs font-semibold">
                        <?php echo htmlspecialchars($error); ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Navigation Tabs -->
        <div class="flex border-b border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 p-2 rounded-xl shadow-sm overflow-x-auto gap-2">
            <button @click="activeTab = 'global'" :class="activeTab === 'global' ? 'bg-bushgreen text-white dark:bg-gold dark:text-slate-900 font-bold shadow' : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700'" class="px-4 py-2 rounded-lg text-xs transition whitespace-nowrap">
                Global Branding & Contacts
            </button>
            <button @click="activeTab = 'hero'" :class="activeTab === 'hero' ? 'bg-bushgreen text-white dark:bg-gold dark:text-slate-900 font-bold shadow' : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700'" class="px-4 py-2 rounded-lg text-xs transition whitespace-nowrap">
                Hero Section Control
            </button>
            <button @click="activeTab = 'homepage'" :class="activeTab === 'homepage' ? 'bg-bushgreen text-white dark:bg-gold dark:text-slate-900 font-bold shadow' : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700'" class="px-4 py-2 rounded-lg text-xs transition whitespace-nowrap">
                Homepage Sections
            </button>
            <button @click="activeTab = 'subpages'" :class="activeTab === 'subpages' ? 'bg-bushgreen text-white dark:bg-gold dark:text-slate-900 font-bold shadow' : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700'" class="px-4 py-2 rounded-lg text-xs transition whitespace-nowrap">
                Sub-Pages Management
            </button>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            
            <!-- FORM COLUMN (Col 8) -->
            <form method="POST" action="" enctype="multipart/form-data" class="lg:col-span-8 bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
                <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                <input type="hidden" name="action" value="update_settings">

                <!-- 1. Global Branding Settings -->
                <div x-show="activeTab === 'global'" class="space-y-6">
                    <div class="pb-3 border-b border-slate-100 dark:border-slate-700">
                        <h3 class="text-slate-800 dark:text-slate-200 font-bold text-sm">Global Branding & Contact Info</h3>
                        <p class="text-[10px] text-slate-400">Manage site logos, contact variables, and generic metadata properties.</p>
                    </div>

                    <!-- Logo System Management Row -->
                    <div class="grid grid-cols-1 md:grid-cols-12 gap-6 p-5 bg-slate-50 dark:bg-slate-900/50 rounded-2xl border border-slate-100 dark:border-slate-750">
                        <div class="md:col-span-4 flex flex-col items-center justify-center text-center space-y-2 border-r border-slate-200/50 dark:border-slate-700/50 pr-4">
                            <span class="text-slate-400 text-[10px] font-bold uppercase tracking-wider block">Current Brand Logo</span>
                            <div class="w-24 h-24 bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 flex items-center justify-center p-3 shadow-inner overflow-hidden">
                                <?php if (!empty($logo_url)): ?>
                                    <img src="../<?php echo htmlspecialchars($logo_url); ?>" alt="App Logo" class="max-w-full max-h-full object-contain">
                                <?php else: ?>
                                    <div class="text-slate-300 dark:text-slate-650 text-center">
                                        <svg class="w-10 h-10 mx-auto mb-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
                                        <span class="text-[9px] uppercase tracking-wide font-bold">Default SVG</span>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="md:col-span-8 space-y-4">
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div>
                                    <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="site_name">Site Name *</label>
                                    <input type="text" name="site_name" id="site_name" required value="<?php echo htmlspecialchars($site_name); ?>"
                                           class="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                                </div>
                                <div>
                                    <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="logo_size">Logo Height (px)</label>
                                    <input type="number" name="logo_size" id="logo_size" value="<?php echo htmlspecialchars($logo_size); ?>" min="20" max="150"
                                           class="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                                </div>
                            </div>
                            <div>
                                <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="logo_url">Custom Logo Path</label>
                                <input type="text" name="logo_url" id="logo_url_input" value="<?php echo htmlspecialchars($logo_url); ?>" placeholder="uploads/logo_xxx.png"
                                       class="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-mono">
                            </div>
                            <div>
                                <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1.5">Upload New Logo Image</label>
                                <input type="file" name="logo_upload" accept="image/*" class="w-full text-xs text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-xs file:font-semibold file:bg-bushgreen/10 file:text-bushgreen dark:file:bg-gold/10 dark:file:text-gold hover:file:bg-bushgreen/20" onchange="document.getElementById('logo_url_input').value = 'uploads/' + this.files[0].name;" />
                            </div>
                        </div>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1.5" for="contact_email">Contact Support Email *</label>
                            <input type="email" name="contact_email" id="contact_email" required value="<?php echo htmlspecialchars($contact_email); ?>"
                                   class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-mono">
                        </div>
                        <div>
                            <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1.5" for="contact_phone">Contact Support Phone *</label>
                            <input type="text" name="contact_phone" id="contact_phone" required value="<?php echo htmlspecialchars($contact_phone); ?>"
                                   class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-mono">
                        </div>
                    </div>

                    <div>
                        <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1.5" for="footer_copyright">Footer Copyright Label *</label>
                        <input type="text" name="footer_copyright" id="footer_copyright" required value="<?php echo htmlspecialchars($footer_copyright); ?>"
                               class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                    </div>

                    <div class="pb-3 border-b border-slate-100 dark:border-slate-700 pt-4">
                        <h3 class="text-slate-800 dark:text-slate-200 font-bold text-sm">SEO Tags & Index Metadata</h3>
                        <p class="text-[10px] text-slate-400">Configure global metadata to rank higher on search engines.</p>
                    </div>

                    <div>
                        <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1.5" for="seo_meta_keywords">SEO Keywords (Comma Separated)</label>
                        <input type="text" name="seo_meta_keywords" id="seo_meta_keywords" value="<?php echo htmlspecialchars($seo_keywords); ?>" placeholder="advocacy, tech hubs, innovation, nigeria"
                               class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                    </div>

                    <div>
                        <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1.5" for="seo_meta_description">SEO Meta Description</label>
                        <textarea name="seo_meta_description" id="seo_meta_description" rows="3"
                                  class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-light leading-relaxed"><?php echo htmlspecialchars($seo_desc); ?></textarea>
                    </div>
                </div>

                <!-- 2. Hero Section Control Tab -->
                <div x-show="activeTab === 'hero'" class="space-y-6">
                    <div class="pb-3 border-b border-slate-100 dark:border-slate-700">
                        <h3 class="text-slate-800 dark:text-slate-200 font-bold text-sm">Hero Section Content & Graphic Control</h3>
                        <p class="text-[10px] text-slate-400">Manage titles, description copy, button paths, widget settings, and the hero image upload.</p>
                    </div>

                    <!-- Hero Image Management Row -->
                    <div class="grid grid-cols-1 md:grid-cols-12 gap-6 p-5 bg-slate-50 dark:bg-slate-900/50 rounded-2xl border border-slate-100 dark:border-slate-750">
                        <div class="md:col-span-4 flex flex-col items-center justify-center text-center space-y-2 border-r border-slate-200/50 dark:border-slate-700/50 pr-4">
                            <span class="text-slate-400 text-[10px] font-bold uppercase tracking-wider block">Hero Mockup Image</span>
                            <div class="w-32 h-24 bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 flex items-center justify-center shadow-inner overflow-hidden relative">
                                <img src="../<?php echo htmlspecialchars($hero_image_url); ?>" alt="Hero Section image" class="w-full h-full object-cover">
                            </div>
                        </div>
                        <div class="md:col-span-8 space-y-4">
                            <div>
                                <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="hero_image_url">Hero Image Path</label>
                                <input type="text" name="hero_image_url" id="hero_image_url_input" value="<?php echo htmlspecialchars($hero_image_url); ?>"
                                       class="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-mono">
                            </div>
                            <div>
                                <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1.5">Upload New Hero Image</label>
                                <input type="file" name="hero_image_upload" accept="image/*" class="w-full text-xs text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-xs file:font-semibold file:bg-bushgreen/10 file:text-bushgreen dark:file:bg-gold/10 dark:file:text-gold hover:file:bg-bushgreen/20" onchange="document.getElementById('hero_image_url_input').value = 'uploads/' + this.files[0].name;" />
                            </div>
                        </div>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="hero_badge">Hero Badge Label</label>
                            <input type="text" name="hero_badge" id="hero_badge" value="<?php echo htmlspecialchars($hero_badge); ?>"
                                   class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                        </div>
                        <div>
                            <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="hero_title">Hero Title (Use newline to separate lines)</label>
                            <textarea name="hero_title" id="hero_title" rows="2"
                                      class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen"><?php echo htmlspecialchars($hero_title); ?></textarea>
                        </div>
                    </div>

                    <div>
                        <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="hero_desc">Hero Description Copy</label>
                        <textarea name="hero_desc" id="hero_desc" rows="3"
                                  class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-light leading-relaxed"><?php echo htmlspecialchars($hero_desc); ?></textarea>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="hero_btn1_text">Primary Button Text</label>
                            <input type="text" name="hero_btn1_text" id="hero_btn1_text" value="<?php echo htmlspecialchars($hero_btn1_text); ?>"
                                   class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                        </div>
                        <div>
                            <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="hero_btn1_url">Primary Button URL</label>
                            <input type="text" name="hero_btn1_url" id="hero_btn1_url" value="<?php echo htmlspecialchars($hero_btn1_url); ?>"
                                   class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-mono">
                        </div>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="hero_btn2_text">Secondary Button Text</label>
                            <input type="text" name="hero_btn2_text" id="hero_btn2_text" value="<?php echo htmlspecialchars($hero_btn2_text); ?>"
                                   class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                        </div>
                        <div>
                            <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="hero_btn2_url">Secondary Button URL</label>
                            <input type="text" name="hero_btn2_url" id="hero_btn2_url" value="<?php echo htmlspecialchars($hero_btn2_url); ?>"
                                   class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-mono">
                        </div>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="hero_patron_name">Patron Name</label>
                            <input type="text" name="hero_patron_name" id="hero_patron_name" value="<?php echo htmlspecialchars($hero_patron_name); ?>"
                                   class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                        </div>
                        <div>
                            <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="hero_patron_tag">Patron Tag Role</label>
                            <input type="text" name="hero_patron_tag" id="hero_patron_tag" value="<?php echo htmlspecialchars($hero_patron_tag); ?>"
                                   class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                        </div>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="hero_widget_label">Widget Info Title</label>
                            <input type="text" name="hero_widget_label" id="hero_widget_label" value="<?php echo htmlspecialchars($hero_widget_label); ?>"
                                   class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                        </div>
                        <div>
                            <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="hero_widget_val">Widget Info Value</label>
                            <input type="text" name="hero_widget_val" id="hero_widget_val" value="<?php echo htmlspecialchars($hero_widget_val); ?>"
                                   class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-bold">
                        </div>
                    </div>
                </div>

                <!-- 3. Homepage Sections Tab -->
                <div x-show="activeTab === 'homepage'" class="space-y-6">
                    <div class="pb-3 border-b border-slate-100 dark:border-slate-700">
                        <h3 class="text-slate-800 dark:text-slate-200 font-bold text-sm">About Section & Separating Banner Controls</h3>
                        <p class="text-[10px] text-slate-400">Manage About visual maps, Strategic vision cards, Ideology banner text, and development pillars introductory copy.</p>
                    </div>

                    <!-- About Section Image Row -->
                    <div class="grid grid-cols-1 md:grid-cols-12 gap-6 p-5 bg-slate-50 dark:bg-slate-900/50 rounded-2xl border border-slate-100 dark:border-slate-750">
                        <div class="md:col-span-4 flex flex-col items-center justify-center text-center space-y-2 border-r border-slate-200/50 dark:border-slate-700/50 pr-4">
                            <span class="text-slate-400 text-[10px] font-bold uppercase tracking-wider block">About Map Image</span>
                            <div class="w-32 h-24 bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 flex items-center justify-center shadow-inner overflow-hidden">
                                <img src="<?php echo preg_match('/^(http|https)/', $about_image_url) ? htmlspecialchars($about_image_url) : '../' . htmlspecialchars($about_image_url); ?>" alt="About Section Image" class="w-full h-full object-cover">
                            </div>
                        </div>
                        <div class="md:col-span-8 space-y-4">
                            <div>
                                <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="about_image_url">About Image Path / Network URL</label>
                                <input type="text" name="about_image_url" id="about_image_url_input" value="<?php echo htmlspecialchars($about_image_url); ?>"
                                       class="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-mono">
                            </div>
                            <div>
                                <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1.5">Upload New About Image</label>
                                <input type="file" name="about_image_upload" accept="image/*" class="w-full text-xs text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-xs file:font-semibold file:bg-bushgreen/10 file:text-bushgreen dark:file:bg-gold/10 dark:file:text-gold hover:file:bg-bushgreen/20" onchange="document.getElementById('about_image_url_input').value = 'uploads/' + this.files[0].name;" />
                            </div>
                        </div>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="about_badge">About Section Badge</label>
                            <input type="text" name="about_badge" id="about_badge" value="<?php echo htmlspecialchars($about_badge); ?>"
                                   class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-semibold">
                        </div>
                        <div>
                            <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="about_heading">About Main Heading Text</label>
                            <textarea name="about_heading" id="about_heading" rows="2"
                                      class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen"><?php echo htmlspecialchars($about_heading); ?></textarea>
                        </div>
                    </div>

                    <div>
                        <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="about_content">About Paragraph copy</label>
                        <textarea name="about_content" id="about_content" rows="3"
                                  class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-light leading-relaxed"><?php echo htmlspecialchars($about_content); ?></textarea>
                    </div>

                    <!-- Core Value Cards Details -->
                    <div class="p-4 bg-slate-50 dark:bg-slate-900/40 rounded-xl space-y-4 border border-slate-200/50 dark:border-slate-750">
                        <span class="text-xs font-bold text-bushgreen dark:text-gold block uppercase tracking-wider">Strategic core Values</span>
                        
                        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div>
                                <label class="block text-slate-500 text-[10px] uppercase font-bold mb-1" for="about_val1_title">Value 1 Title</label>
                                <input type="text" name="about_val1_title" id="about_val1_title" value="<?php echo htmlspecialchars($about_val1_title); ?>" class="w-full px-2 py-1.5 bg-white dark:bg-slate-800 border rounded text-xs">
                                <label class="block text-slate-500 text-[9px] font-medium mt-1 mb-1" for="about_val1_text">Value 1 description</label>
                                <textarea name="about_val1_text" id="about_val1_text" rows="2" class="w-full p-2 bg-white dark:bg-slate-800 border rounded text-[11px] font-light leading-snug"><?php echo htmlspecialchars($about_val1_text); ?></textarea>
                            </div>
                            <div>
                                <label class="block text-slate-500 text-[10px] uppercase font-bold mb-1" for="about_val2_title">Value 2 Title</label>
                                <input type="text" name="about_val2_title" id="about_val2_title" value="<?php echo htmlspecialchars($about_val2_title); ?>" class="w-full px-2 py-1.5 bg-white dark:bg-slate-800 border rounded text-xs">
                                <label class="block text-slate-500 text-[9px] font-medium mt-1 mb-1" for="about_val2_text">Value 2 description</label>
                                <textarea name="about_val2_text" id="about_val2_text" rows="2" class="w-full p-2 bg-white dark:bg-slate-800 border rounded text-[11px] font-light leading-snug"><?php echo htmlspecialchars($about_val2_text); ?></textarea>
                            </div>
                            <div>
                                <label class="block text-slate-500 text-[10px] uppercase font-bold mb-1" for="about_val3_title">Value 3 Title</label>
                                <input type="text" name="about_val3_title" id="about_val3_title" value="<?php echo htmlspecialchars($about_val3_title); ?>" class="w-full px-2 py-1.5 bg-white dark:bg-slate-800 border rounded text-xs">
                                <label class="block text-slate-500 text-[9px] font-medium mt-1 mb-1" for="about_val3_text">Value 3 description</label>
                                <textarea name="about_val3_text" id="about_val3_text" rows="2" class="w-full p-2 bg-white dark:bg-slate-800 border rounded text-[11px] font-light leading-snug"><?php echo htmlspecialchars($about_val3_text); ?></textarea>
                            </div>
                        </div>
                    </div>

                    <!-- separating Banner -->
                    <div class="pb-3 border-b border-slate-100 dark:border-slate-700 pt-2">
                        <h4 class="text-slate-800 dark:text-slate-200 font-bold text-xs tracking-wide">Middle Separator Banner</h4>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="banner_badge">Banner Badge Text</label>
                            <input type="text" name="banner_badge" id="banner_badge" value="<?php echo htmlspecialchars($banner_badge); ?>"
                                   class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                        </div>
                        <div>
                            <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="banner_title">Banner Title</label>
                            <input type="text" name="banner_title" id="banner_title" value="<?php echo htmlspecialchars($banner_title); ?>"
                                   class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                        </div>
                    </div>

                    <div>
                        <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="banner_subtitle">Banner Subtitle / Statement</label>
                        <textarea name="banner_subtitle" id="banner_subtitle" rows="2"
                                  class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-light"><?php echo htmlspecialchars($banner_subtitle); ?></textarea>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="banner_btn_text">Banner Button Text</label>
                            <input type="text" name="banner_btn_text" id="banner_btn_text" value="<?php echo htmlspecialchars($banner_btn_text); ?>"
                                   class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                        </div>
                        <div>
                            <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="banner_btn_url">Banner Button Action URL</label>
                            <input type="text" name="banner_btn_url" id="banner_btn_url" value="<?php echo htmlspecialchars($banner_btn_url); ?>"
                                   class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-mono">
                        </div>
                    </div>

                    <!-- Key Pillars section details -->
                    <div class="pb-3 border-b border-slate-100 dark:border-slate-700 pt-2">
                        <h4 class="text-slate-800 dark:text-slate-200 font-bold text-xs tracking-wide">Pillars introductory Section</h4>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div>
                            <label class="block text-slate-600 dark:text-slate-400 text-[10px] uppercase font-bold mb-1" for="pillars_badge">Pillars Section Badge</label>
                            <input type="text" name="pillars_badge" id="pillars_badge" value="<?php echo htmlspecialchars($pillars_badge); ?>" class="w-full px-2 py-1.5 bg-slate-50 dark:bg-slate-900 border rounded text-xs">
                        </div>
                        <div>
                            <label class="block text-slate-600 dark:text-slate-400 text-[10px] uppercase font-bold mb-1" for="pillars_heading">Pillars Section Title</label>
                            <input type="text" name="pillars_heading" id="pillars_heading" value="<?php echo htmlspecialchars($pillars_heading); ?>" class="w-full px-2 py-1.5 bg-slate-50 dark:bg-slate-900 border rounded text-xs">
                        </div>
                        <div>
                            <label class="block text-slate-600 dark:text-slate-400 text-[10px] uppercase font-bold mb-1" for="pillars_subtitle">Pillars Subtitle</label>
                            <input type="text" name="pillars_subtitle" id="pillars_subtitle" value="<?php echo htmlspecialchars($pillars_subtitle); ?>" class="w-full px-2 py-1.5 bg-slate-50 dark:bg-slate-900 border rounded text-xs">
                        </div>
                    </div>

                    <div>
                        <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="pillars_intro_title">Pillars Intro Card Title</label>
                        <input type="text" name="pillars_intro_title" id="pillars_intro_title" value="<?php echo htmlspecialchars($pillars_intro_title); ?>"
                               class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-slate-600 dark:text-slate-400 text-[10px] uppercase font-bold mb-1" for="pillars_intro_desc1">Pillars Description Paragraph 1</label>
                            <textarea name="pillars_intro_desc1" id="pillars_intro_desc1" rows="3" class="w-full p-2 bg-slate-50 dark:bg-slate-900 border rounded text-xs font-light leading-relaxed"><?php echo htmlspecialchars($pillars_intro_desc1); ?></textarea>
                        </div>
                        <div>
                            <label class="block text-slate-600 dark:text-slate-400 text-[10px] uppercase font-bold mb-1" for="pillars_intro_desc2">Pillars Description Paragraph 2</label>
                            <textarea name="pillars_intro_desc2" id="pillars_intro_desc2" rows="3" class="w-full p-2 bg-slate-50 dark:bg-slate-900 border rounded text-xs font-light leading-relaxed"><?php echo htmlspecialchars($pillars_intro_desc2); ?></textarea>
                        </div>
                    </div>
                </div>

                <!-- 4. Sub-Pages Content Management Tab -->
                <div x-show="activeTab === 'subpages'" class="space-y-6">
                    <div class="pb-3 border-b border-slate-100 dark:border-slate-700">
                        <h3 class="text-slate-800 dark:text-slate-200 font-bold text-sm">Sub-Page Content Layouts</h3>
                        <p class="text-[10px] text-slate-400">Configure headings, subheadings, vision/mission statements, and announcement rules for other pages.</p>
                    </div>

                    <!-- Who We Are Sub-Page Details -->
                    <div class="p-4 bg-slate-50 dark:bg-slate-900/40 rounded-xl space-y-4 border border-slate-200/50 dark:border-slate-755">
                        <span class="text-xs font-bold text-bushgreen dark:text-gold block uppercase tracking-wider">Sub-Page: "Who We Are" (about.php)</span>
                        
                        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div>
                                <label class="block text-slate-500 text-[10px] uppercase font-bold mb-1" for="page_about_banner_badge">Banner Badge</label>
                                <input type="text" name="page_about_banner_badge" id="page_about_banner_badge" value="<?php echo htmlspecialchars($page_about_banner_badge); ?>" class="w-full px-2 py-1 bg-white dark:bg-slate-800 border rounded text-[11px]">
                            </div>
                            <div>
                                <label class="block text-slate-500 text-[10px] uppercase font-bold mb-1" for="page_about_banner_title">Banner Title</label>
                                <input type="text" name="page_about_banner_title" id="page_about_banner_title" value="<?php echo htmlspecialchars($page_about_banner_title); ?>" class="w-full px-2 py-1 bg-white dark:bg-slate-800 border rounded text-[11px]">
                            </div>
                            <div>
                                <label class="block text-slate-500 text-[10px] uppercase font-bold mb-1" for="page_about_banner_desc">Banner Subtitle</label>
                                <input type="text" name="page_about_banner_desc" id="page_about_banner_desc" value="<?php echo htmlspecialchars($page_about_banner_desc); ?>" class="w-full px-2 py-1 bg-white dark:bg-slate-800 border rounded text-[11px]">
                            </div>
                        </div>

                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
                            <div>
                                <label class="block text-slate-500 text-[10px] uppercase font-bold mb-1" for="page_about_vision_title">Vision Card Title</label>
                                <input type="text" name="page_about_vision_title" id="page_about_vision_title" value="<?php echo htmlspecialchars($page_about_vision_title); ?>" class="w-full px-2 py-1.5 bg-white dark:bg-slate-800 border rounded text-xs mb-1">
                                <label class="block text-slate-500 text-[9px] font-medium mb-1" for="page_about_vision_desc">Vision Card Copy</label>
                                <textarea name="page_about_vision_desc" id="page_about_vision_desc" rows="3" class="w-full p-2 bg-white dark:bg-slate-800 border rounded text-[11px] font-light leading-relaxed"><?php echo htmlspecialchars($page_about_vision_desc); ?></textarea>
                            </div>
                            <div>
                                <label class="block text-slate-500 text-[10px] uppercase font-bold mb-1" for="page_about_mission_title">Mission Card Title</label>
                                <input type="text" name="page_about_mission_title" id="page_about_mission_title" value="<?php echo htmlspecialchars($page_about_mission_title); ?>" class="w-full px-2 py-1.5 bg-white dark:bg-slate-800 border rounded text-xs mb-1">
                                <label class="block text-slate-500 text-[9px] font-medium mb-1" for="page_about_mission_desc">Mission Card Copy</label>
                                <textarea name="page_about_mission_desc" id="page_about_mission_desc" rows="3" class="w-full p-2 bg-white dark:bg-slate-800 border rounded text-[11px] font-light leading-relaxed"><?php echo htmlspecialchars($page_about_mission_desc); ?></textarea>
                            </div>
                        </div>

                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2 border-t border-slate-200/50 dark:border-slate-700/50">
                            <div>
                                <label class="block text-slate-500 text-[10px] uppercase font-bold mb-1" for="page_about_org_title">Org Section Title</label>
                                <input type="text" name="page_about_org_title" id="page_about_org_title" value="<?php echo htmlspecialchars($page_about_org_title); ?>" class="w-full px-2 py-1.5 bg-white dark:bg-slate-800 border rounded text-xs mb-1">
                                <label class="block text-slate-500 text-[9px] font-medium mb-1" for="page_about_org_desc">Org Section Subtitle</label>
                                <textarea name="page_about_org_desc" id="page_about_org_desc" rows="2" class="w-full p-2 bg-white dark:bg-slate-800 border rounded text-[11px] font-light"><?php echo htmlspecialchars($page_about_org_desc); ?></textarea>
                            </div>
                            <div>
                                <label class="block text-slate-500 text-[10px] uppercase font-bold mb-1" for="page_about_charter_title">Charter Title</label>
                                <input type="text" name="page_about_charter_title" id="page_about_charter_title" value="<?php echo htmlspecialchars($page_about_charter_title); ?>" class="w-full px-2 py-1.5 bg-white dark:bg-slate-800 border rounded text-xs mb-1">
                                <label class="block text-slate-500 text-[9px] font-medium mb-1" for="page_about_charter_desc">Charter Statement</label>
                                <textarea name="page_about_charter_desc" id="page_about_charter_desc" rows="2" class="w-full p-2 bg-white dark:bg-slate-800 border rounded text-[11px] font-light leading-relaxed"><?php echo htmlspecialchars($page_about_charter_desc); ?></textarea>
                            </div>
                        </div>
                    </div>

                    <!-- Key Pillars Sub-Page Details -->
                    <div class="p-4 bg-slate-50 dark:bg-slate-900/40 rounded-xl space-y-4 border border-slate-200/50 dark:border-slate-755">
                        <span class="text-xs font-bold text-bushgreen dark:text-gold block uppercase tracking-wider">Sub-Page: "Key Pillars" (pillars.php)</span>
                        
                        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div>
                                <label class="block text-slate-500 text-[10px] uppercase font-bold mb-1" for="page_pillars_banner_badge">Pillars Badge</label>
                                <input type="text" name="page_pillars_banner_badge" id="page_pillars_banner_badge" value="<?php echo htmlspecialchars($page_pillars_banner_badge); ?>" class="w-full px-2 py-1 bg-white dark:bg-slate-800 border rounded text-[11px]">
                            </div>
                            <div>
                                <label class="block text-slate-500 text-[10px] uppercase font-bold mb-1" for="page_pillars_banner_title">Pillars Title</label>
                                <input type="text" name="page_pillars_banner_title" id="page_pillars_banner_title" value="<?php echo htmlspecialchars($page_pillars_banner_title); ?>" class="w-full px-2 py-1 bg-white dark:bg-slate-800 border rounded text-[11px]">
                            </div>
                            <div>
                                <label class="block text-slate-500 text-[10px] uppercase font-bold mb-1" for="page_pillars_banner_desc">Pillars Subtitle</label>
                                <input type="text" name="page_pillars_banner_desc" id="page_pillars_banner_desc" value="<?php echo htmlspecialchars($page_pillars_banner_desc); ?>" class="w-full px-2 py-1 bg-white dark:bg-slate-800 border rounded text-[11px]">
                            </div>
                        </div>

                        <div class="space-y-3 pt-2">
                            <span class="text-[10px] uppercase font-extrabold text-slate-400 block tracking-wider">Introductory Paragraphs (Max 4)</span>
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div>
                                    <label class="block text-slate-500 text-[9px] mb-1" for="page_pillars_intro_desc1">Intro Paragraph 1</label>
                                    <textarea name="page_pillars_intro_desc1" id="page_pillars_intro_desc1" rows="3" class="w-full p-2 bg-white dark:bg-slate-800 border rounded text-[11px] font-light leading-relaxed"><?php echo htmlspecialchars($page_pillars_intro_desc1); ?></textarea>
                                </div>
                                <div>
                                    <label class="block text-slate-500 text-[9px] mb-1" for="page_pillars_intro_desc2">Intro Paragraph 2</label>
                                    <textarea name="page_pillars_intro_desc2" id="page_pillars_intro_desc2" rows="3" class="w-full p-2 bg-white dark:bg-slate-800 border rounded text-[11px] font-light leading-relaxed"><?php echo htmlspecialchars($page_pillars_intro_desc2); ?></textarea>
                                </div>
                            </div>
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 pt-1">
                                <div>
                                    <label class="block text-slate-500 text-[9px] mb-1" for="page_pillars_intro_desc3">Intro Paragraph 3</label>
                                    <textarea name="page_pillars_intro_desc3" id="page_pillars_intro_desc3" rows="3" class="w-full p-2 bg-white dark:bg-slate-800 border rounded text-[11px] font-light leading-relaxed"><?php echo htmlspecialchars($page_pillars_intro_desc3); ?></textarea>
                                </div>
                                <div>
                                    <label class="block text-slate-500 text-[9px] mb-1" for="page_pillars_intro_desc4">Intro Paragraph 4</label>
                                    <textarea name="page_pillars_intro_desc4" id="page_pillars_intro_desc4" rows="3" class="w-full p-2 bg-white dark:bg-slate-800 border rounded text-[11px] font-light leading-relaxed"><?php echo htmlspecialchars($page_pillars_intro_desc4); ?></textarea>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Courses Academy Sub-Page Details -->
                    <div class="p-4 bg-slate-50 dark:bg-slate-900/40 rounded-xl space-y-4 border border-slate-200/50 dark:border-slate-755">
                        <span class="text-xs font-bold text-bushgreen dark:text-gold block uppercase tracking-wider">Sub-Page: "Smart Academy" (courses.php)</span>
                        
                        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div>
                                <label class="block text-slate-500 text-[10px] uppercase font-bold mb-1" for="page_courses_banner_badge">Academy Badge</label>
                                <input type="text" name="page_courses_banner_badge" id="page_courses_banner_badge" value="<?php echo htmlspecialchars($page_courses_banner_badge); ?>" class="w-full px-2 py-1 bg-white dark:bg-slate-800 border rounded text-[11px]">
                            </div>
                            <div>
                                <label class="block text-slate-500 text-[10px] uppercase font-bold mb-1" for="page_courses_banner_title">Academy Title</label>
                                <input type="text" name="page_courses_banner_title" id="page_courses_banner_title" value="<?php echo htmlspecialchars($page_courses_banner_title); ?>" class="w-full px-2 py-1 bg-white dark:bg-slate-800 border rounded text-[11px]">
                            </div>
                            <div>
                                <label class="block text-slate-500 text-[10px] uppercase font-bold mb-1" for="page_courses_banner_desc">Academy Subtitle</label>
                                <input type="text" name="page_courses_banner_desc" id="page_courses_banner_desc" value="<?php echo htmlspecialchars($page_courses_banner_desc); ?>" class="w-full px-2 py-1 bg-white dark:bg-slate-800 border rounded text-[11px]">
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Footer Action Buttons -->
                <div class="pt-4 border-t border-slate-100 dark:border-slate-700 flex justify-between items-center">
                    <span class="text-[10px] text-slate-400 dark:text-slate-500 italic">Be sure to save updates on each tab before leaving.</span>
                    <button type="submit" class="py-2.5 px-6 bg-bushgreen hover:bg-bushgreen-light text-white text-xs font-bold rounded-lg transition shadow-md shadow-bushgreen/10">
                        Commit CMS Changes
                    </button>
                </div>
            </form>

            <!-- STATS / RESET UTILITIES COLUMN (Col 4) -->
            <div class="lg:col-span-4 space-y-6">
                
                <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-4">
                    <h3 class="text-slate-800 dark:text-slate-200 font-bold text-sm tracking-wide">CMS Assets Catalog</h3>
                    
                    <div class="space-y-3">
                        <div class="p-3 bg-slate-50 dark:bg-slate-900/50 border border-slate-100 dark:border-slate-800 rounded-xl flex items-center justify-between text-xs">
                            <span class="text-slate-500">News Blog Posts</span>
                            <span class="font-bold text-bushgreen dark:text-gold"><?php echo $blog_count; ?> articles</span>
                        </div>
                        <div class="p-3 bg-slate-50 dark:bg-slate-900/50 border border-slate-100 dark:border-slate-800 rounded-xl flex items-center justify-between text-xs">
                            <span class="text-slate-500">Uploaded Media files</span>
                            <span class="font-bold text-bushgreen dark:text-gold"><?php echo $media_count; ?> assets</span>
                        </div>
                    </div>

                    <div class="pt-2 flex flex-col gap-2">
                        <a href="blog.php" class="w-full py-2 bg-bushgreen text-white text-xs font-bold rounded-lg text-center hover:bg-bushgreen-light transition">
                            Open News / Blog Manager &rarr;
                        </a>
                        <a href="media.php" class="w-full py-2 border border-slate-200 dark:border-slate-700 hover:border-gold hover:text-gold text-slate-700 dark:text-slate-300 text-xs font-bold rounded-lg text-center transition">
                            Open Media Folder
                        </a>
                    </div>
                </div>

                <!-- Asset Resets Panel -->
                <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-4">
                    <h3 class="text-slate-800 dark:text-slate-200 font-bold text-sm tracking-wide">CMS System Resets</h3>
                    <p class="text-[10px] text-slate-400 leading-relaxed">Restore original design system paths and default mock assets instantly.</p>
                    
                    <div class="space-y-3">
                        <!-- Reset Logo -->
                        <div class="p-3 bg-slate-50 dark:bg-slate-900/30 rounded-xl border border-slate-100 dark:border-slate-750 flex flex-col gap-2">
                            <div class="flex justify-between items-center">
                                <span class="text-[11px] font-bold text-slate-700 dark:text-slate-300">Brand Logo</span>
                                <span class="text-[9px] text-slate-400 font-mono">logo_url</span>
                            </div>
                            <form method="POST" action="" class="w-full">
                                <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                                <input type="hidden" name="action" value="reset_logo">
                                <button type="submit" class="w-full py-1 px-3 bg-red-50 hover:bg-red-100 text-red-650 rounded-lg text-[10px] font-bold transition flex items-center justify-center gap-1">
                                    Restore Default Brand Logo
                                </button>
                            </form>
                        </div>

                        <!-- Reset Hero Image -->
                        <div class="p-3 bg-slate-50 dark:bg-slate-900/30 rounded-xl border border-slate-100 dark:border-slate-750 flex flex-col gap-2">
                            <div class="flex justify-between items-center">
                                <span class="text-[11px] font-bold text-slate-700 dark:text-slate-300">Hero Section Graphics</span>
                                <span class="text-[9px] text-slate-400 font-mono">hero_image_url</span>
                            </div>
                            <form method="POST" action="" class="w-full">
                                <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                                <input type="hidden" name="action" value="reset_hero_image">
                                <button type="submit" class="w-full py-1 px-3 bg-red-50 hover:bg-red-100 text-red-650 rounded-lg text-[10px] font-bold transition flex items-center justify-center gap-1">
                                    Restore Default Hero Image
                                </button>
                            </form>
                        </div>

                        <!-- Reset About Image -->
                        <div class="p-3 bg-slate-50 dark:bg-slate-900/30 rounded-xl border border-slate-100 dark:border-slate-750 flex flex-col gap-2">
                            <div class="flex justify-between items-center">
                                <span class="text-[11px] font-bold text-slate-700 dark:text-slate-300">About Map Graphic</span>
                                <span class="text-[9px] text-slate-400 font-mono">about_image_url</span>
                            </div>
                            <form method="POST" action="" class="w-full">
                                <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                                <input type="hidden" name="action" value="reset_about_image">
                                <button type="submit" class="w-full py-1 px-3 bg-red-50 hover:bg-red-100 text-red-650 rounded-lg text-[10px] font-bold transition flex items-center justify-center gap-1">
                                    Restore Default About Image
                                </button>
                            </form>
                        </div>
                    </div>
                </div>

                <div class="bg-bushgreen text-white rounded-2xl border border-gold/30 p-6 shadow-sm space-y-3 relative overflow-hidden">
                    <div class="absolute inset-0 bg-cover bg-center opacity-10 bg-[url('https://images.unsplash.com/photo-1542831371-29b0f74f9713?auto=format&fit=crop&w=400&q=80')]"></div>
                    <div class="relative z-10 space-y-2">
                        <span class="text-gold font-bold text-[9px] uppercase tracking-widest block leading-none">Aesthetics Control</span>
                        <h4 class="font-bold text-sm text-white">Dynamic Site Rendering</h4>
                        <p class="text-[10px] text-slate-300 leading-normal font-light">
                            Updating settings here updates the global variables fetched by header scripts. SEO tags are injected directly inside page headers to facilitate immediate web crawler indexation.
                        </p>
                    </div>
                </div>
            </div>

        </div>

    </main>
</body>
</html>
