<?php
/**
 * PBAT Smart Nation Initiative - User Profile & KYC Editor
 * Restricted to Super Admin. Full editing control over member coordinates,
 * profile photos, extended KYC documents, status, and jurisdictions.
 */
require_once dirname(__DIR__) . '/helpers/auth.php';
require_once dirname(__DIR__) . '/helpers/common.php';
require_once dirname(__DIR__) . '/config/database.php';

Auth::requireRole(['super_admin'], '../login.php');

$user = Auth::user();
$error = '';
$success = '';
$target_user = null;
$target_kyc = null;
$target_geo = null;
$target_id = (int)($_GET['id'] ?? 0);

try {
    $db = Database::connect();

    // Fetch Roles, States, LGAs lists
    $roles_list = $db->query("SELECT * FROM `roles` ORDER BY `id` ASC")->fetchAll();
    $states_list = $db->query("SELECT `id`, `name`, `code`, `zone` FROM `states` ORDER BY `name` ASC")->fetchAll(PDO::FETCH_ASSOC);
    $lgas_list = $db->query("SELECT `id`, `name`, `state_id` FROM `lgas` ORDER BY `name` ASC")->fetchAll(PDO::FETCH_ASSOC);

    $state_zones = [];
    foreach ($states_list as $s) {
        $state_zones[$s['id']] = $s['zone'];
    }

    $lgas_by_state = [];
    foreach ($lgas_list as $lga) {
        $lgas_by_state[$lga['state_id']][] = [
            'id' => (int)$lga['id'],
            'name' => $lga['name']
        ];
    }

    // Handle profile update form submission
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_profile') {
        if (!Auth::validateCsrf($_POST['csrf_token'] ?? '')) {
            $error = "CSRF Token validation failed.";
        } else {
            // Transaction start
            $db->beginTransaction();

            try {
                // Fetch target user inside transaction to lock
                $stmt_lock = $db->prepare("SELECT * FROM `users` WHERE `id` = ? FOR UPDATE");
                $stmt_lock->execute([$target_id]);
                $orig_user = $stmt_lock->fetch();

                if (!$orig_user) {
                    throw new Exception("User not found.");
                }

                // 1. Handle profile avatar upload
                $avatar_path = $orig_user['avatar'];
                $upload_dir = dirname(__DIR__) . '/uploads/';
                if (!is_dir($upload_dir)) {
                    mkdir($upload_dir, 0755, true);
                }

                if (isset($_FILES['profile_photo']) && $_FILES['profile_photo']['error'] === UPLOAD_ERR_OK) {
                    $tmp_name = $_FILES['profile_photo']['tmp_name'];
                    $file_ext = pathinfo($_FILES['profile_photo']['name'], PATHINFO_EXTENSION);
                    $file_name = time() . '_admin_avatar_' . $target_id . '.' . $file_ext;
                    if (move_uploaded_file($tmp_name, $upload_dir . $file_name)) {
                        $avatar_path = 'uploads/' . $file_name;
                    }
                }

                // 2. Extract and Sanitize fields
                $name = trim($_POST['name'] ?? '');
                $email = trim($_POST['email'] ?? '');
                $phone = trim($_POST['phone'] ?? '');
                $role_id = (int)($_POST['role_id'] ?? $orig_user['role_id']);
                $status = trim($_POST['status'] ?? $orig_user['status']);
                $email_verified = isset($_POST['email_verified']) ? 1 : 0;
                $address = trim($_POST['address'] ?? '');
                $age = !empty($_POST['age']) ? (int)$_POST['age'] : null;
                $gender = trim($_POST['gender'] ?? '');
                $occupation = trim($_POST['occupation'] ?? '');
                $kyc_status = trim($_POST['kyc_status'] ?? 'pending_review');
                $membership_code = trim($_POST['membership_code'] ?? '');
                if (empty($membership_code)) {
                    $membership_code = !empty($orig_user['membership_code']) ? $orig_user['membership_code'] : null;
                }
                
                // Auto-generate membership code if still empty and KYC is completed/approved
                if (empty($membership_code) && in_array($kyc_status, ['approved', 'pending_review'])) {
                    $roles_prefix = [
                        1 => 'ADM',
                        2 => 'FND',
                        3 => 'NSC',
                        4 => 'ZON',
                        5 => 'STA',
                        6 => 'LGA',
                        7 => 'AMB'
                    ];
                    $prefix = $roles_prefix[$role_id] ?? 'MEM';
                    $unique_hex = strtoupper(substr(md5($target_id . 'salt_pbat_nation'), 0, 6));
                    $membership_code = 'SN-' . $prefix . '-' . $unique_hex . '-2026';
                }

                if (empty($name) || empty($email)) {
                    throw new Exception("Full Name and Email are mandatory fields.");
                }

                // Update users table
                $stmt_up = $db->prepare("
                    UPDATE `users` 
                    SET `name` = ?, `email` = ?, `phone` = ?, `role_id` = ?, `status` = ?, 
                        `email_verified` = ?, `address` = ?, `age` = ?, `gender` = ?, 
                        `occupation` = ?, `membership_code` = ?, `avatar` = ?
                    WHERE `id` = ?
                ");
                $stmt_up->execute([
                    $name, $email, $phone, $role_id, $status, 
                    $email_verified, $address, $age, $gender, 
                    $occupation, $membership_code, $avatar_path, $target_id
                ]);

                // 3. Update / Insert Extended KYC table
                $stmt_check_kyc = $db->prepare("SELECT COUNT(1) FROM `user_kyc_extended` WHERE `user_id` = ?");
                $stmt_check_kyc->execute([$target_id]);
                if ($stmt_check_kyc->fetchColumn() == 0) {
                    $db->prepare("INSERT INTO `user_kyc_extended` (`user_id`) VALUES (?)")->execute([$target_id]);
                }

                // Gather kyc fields
                $username_val = trim($_POST['username_val'] ?? '');
                $dob = !empty($_POST['dob']) ? $_POST['dob'] : null;
                $nationality = trim($_POST['nationality'] ?? 'Nigerian');
                $state_of_origin = trim($_POST['state_of_origin'] ?? '');
                $state_of_residence = trim($_POST['state_of_residence'] ?? '');
                $whatsapp_number = trim($_POST['whatsapp_number'] ?? '');
                $telegram_username = trim($_POST['telegram_username'] ?? '');
                $x_handle = trim($_POST['x_handle'] ?? '');
                $facebook_profile = trim($_POST['facebook_profile'] ?? '');
                $instagram_username = trim($_POST['instagram_username'] ?? '');
                $linkedin_profile = trim($_POST['linkedin_profile'] ?? '');
                $highest_qualification = trim($_POST['highest_qualification'] ?? '');
                $institution = trim($_POST['institution'] ?? '');
                $course_of_study = trim($_POST['course_of_study'] ?? '');
                $graduation_year = !empty($_POST['graduation_year']) ? (int)$_POST['graduation_year'] : null;
                $employer = trim($_POST['employer'] ?? '');
                $industry = trim($_POST['industry'] ?? '');
                $skills_expertise = trim($_POST['skills_expertise'] ?? '');
                $ai_knowledge_level = trim($_POST['ai_knowledge_level'] ?? '');
                $why_join = trim($_POST['why_join'] ?? '');
                $preferred_role = trim($_POST['preferred_role'] ?? '');
                $volunteer_availability = trim($_POST['volunteer_availability'] ?? '');
                $outreach_experience = trim($_POST['outreach_experience'] ?? '');
                $leadership_experience = trim($_POST['leadership_experience'] ?? '');
                $community_engagement = trim($_POST['community_engagement'] ?? '');
                $kyc_status = trim($_POST['kyc_status'] ?? 'pending_review');
                $kyc_status_message = trim($_POST['kyc_status_message'] ?? '');

                $stmt_up_kyc = $db->prepare("
                    UPDATE `user_kyc_extended`
                    SET `username` = ?, `dob` = ?, `nationality` = ?, `state_of_origin` = ?, `state_of_residence` = ?,
                        `whatsapp_number` = ?, `telegram_username` = ?, `x_handle` = ?, `facebook_profile` = ?, `instagram_username` = ?, `linkedin_profile` = ?,
                        `highest_qualification` = ?, `institution` = ?, `course_of_study` = ?, `graduation_year` = ?, `employer` = ?, `industry` = ?, `skills_expertise` = ?,
                        `ai_knowledge_level` = ?, `why_join` = ?, `preferred_role` = ?, `volunteer_availability` = ?, `outreach_experience` = ?, `leadership_experience` = ?, 
                        `community_engagement` = ?, `kyc_status` = ?, `kyc_status_message` = ?
                    WHERE `user_id` = ?
                ");
                $stmt_up_kyc->execute([
                    $username_val, $dob, $nationality, $state_of_origin, $state_of_residence,
                    $whatsapp_number, $telegram_username, $x_handle, $facebook_profile, $instagram_username, $linkedin_profile,
                    $highest_qualification, $institution, $course_of_study, $graduation_year, $employer, $industry, $skills_expertise,
                    $ai_knowledge_level, $why_join, $preferred_role, $volunteer_availability, $outreach_experience, $leadership_experience,
                    $community_engagement, $kyc_status, $kyc_status_message, $target_id
                ]);

                // 4. Update jurisdictions
                $state_id = !empty($_POST['state_id']) ? (int)$_POST['state_id'] : null;
                $lga_id = !empty($_POST['lga_id']) ? (int)$_POST['lga_id'] : null;
                $ward_id = !empty($_POST['ward_id']) ? (int)$_POST['ward_id'] : null;
                $zone = !empty($_POST['zone']) ? trim($_POST['zone']) : null;

                // Resolve zone from state if state is set
                if (!empty($state_id) && empty($zone)) {
                    $zone = $state_zones[$state_id] ?? null;
                }

                // Clear previous mappings
                $db->prepare("DELETE FROM `ambassadors` WHERE `user_id` = ?")->execute([$target_id]);
                $db->prepare("DELETE FROM `user_leadership` WHERE `user_id` = ?")->execute([$target_id]);

                if ($role_id == 7) {
                    // Re-enlist as Ambassador
                    $uuid = generateUuid('AMB-');
                    $hash_qr = hash('sha256', $uuid . time());
                    $stmt_amb = $db->prepare("
                        INSERT INTO `ambassadors` (`user_id`, `uuid`, `state_id`, `lga_id`, `ward_id`, `qr_code_hash`, `is_verified`)
                        VALUES (?, ?, ?, ?, ?, ?, 1)
                    ");
                    $stmt_amb->execute([$target_id, $uuid, $state_id, $lga_id, $ward_id, $hash_qr]);
                } elseif (in_array($role_id, [3, 4, 5, 6])) {
                    // Re-enlist as Leadership
                    $tier_id = 1; // NSC
                    if ($role_id == 4) $tier_id = 2; // Zonal
                    elseif ($role_id == 5) $tier_id = 3; // State
                    elseif ($role_id == 6) $tier_id = 4; // LGA

                    $stmt_lead = $db->prepare("
                        INSERT INTO `user_leadership` (`user_id`, `tier_id`, `zone`, `state_id`, `lga_id`, `appointed_by`)
                        VALUES (?, ?, ?, ?, ?, ?)
                    ");
                    $stmt_lead->execute([$target_id, $tier_id, $zone, $state_id, $lga_id, $user['id']]);
                }

                $db->commit();
                
                Auth::logAction($user['id'], 'USER_PROFILE_ADMIN_EDIT', "Super Admin updated credentials and profile details for: {$email} (ID {$target_id})");
                
                $_SESSION['success_msg'] = "User credentials and profile modifications saved successfully!";
                header("Location: user-details.php?id=" . $target_id);
                exit;

            } catch (Exception $ex) {
                $db->rollBack();
                $error = "Save Failed: " . $ex->getMessage();
            }
        }
    }

    // Load user coordinates
    $stmt = $db->prepare("SELECT * FROM `users` WHERE `id` = ? LIMIT 1");
    $stmt->execute([$target_id]);
    $target_user = $stmt->fetch();

    if (!$target_user) {
        $error = "The requested user account does not exist.";
    } else {
        $stmt_kyc = $db->prepare("SELECT * FROM `user_kyc_extended` WHERE `user_id` = ? LIMIT 1");
        $stmt_kyc->execute([$target_id]);
        $target_kyc = $stmt_kyc->fetch() ?: [];

        // Load geo details
        if ((int)$target_user['role_id'] === 7) {
            $stmt_geo = $db->prepare("SELECT * FROM `ambassadors` WHERE `user_id` = ? LIMIT 1");
            $stmt_geo->execute([$target_id]);
            $target_geo = $stmt_geo->fetch() ?: [];
        } else {
            $stmt_geo = $db->prepare("SELECT * FROM `user_leadership` WHERE `user_id` = ? LIMIT 1");
            $stmt_geo->execute([$target_id]);
            $target_geo = $stmt_geo->fetch() ?: [];
        }
    }

} catch (Exception $e) {
    $error = "Initialization Error: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Member Coordinates - PBAT Smart Nation</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        bushgreen: {
                            DEFAULT: '#063C1E',
                            light: '#0A4D27',
                            dark: '#03200F',
                        },
                        gold: '#D4AF37'
                    }
                }
            }
        }
    </script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; }
        h1, h2, h3, h4, .font-display { font-family: 'Outfit', sans-serif; }
        [x-cloak] { display: none !important; }
    </style>
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
</head>
<body class="bg-slate-50 text-slate-800 transition-colors duration-200 min-h-screen flex flex-col antialiased"
      x-data="{ 
          darkMode: localStorage.getItem('darkMode') === 'true',
          selectedRole: '<?php echo htmlspecialchars($target_user['role_id'] ?? ''); ?>',
          selectedState: '<?php echo htmlspecialchars($target_geo['state_id'] ?? ''); ?>',
          selectedLga: '<?php echo htmlspecialchars($target_geo['lga_id'] ?? ''); ?>',
          selectedWard: '<?php echo htmlspecialchars($target_geo['ward_id'] ?? ''); ?>',
          selectedZone: '<?php echo htmlspecialchars($target_geo['zone'] ?? ''); ?>',
          lgas: <?php echo htmlspecialchars(json_encode($lgas_by_state), ENT_QUOTES, 'UTF-8'); ?>,
          stateZones: <?php echo htmlspecialchars(json_encode($state_zones), ENT_QUOTES, 'UTF-8'); ?>,
          wards: [],
          loadingWards: false,
          fetchWards() {
              if (!this.selectedLga) {
                  this.wards = [];
                  this.selectedWard = '';
                  return;
              }
              this.loadingWards = true;
              fetch('../api/wards.php?lga_id=' + this.selectedLga)
                  .then(res => res.json())
                  .then(data => {
                      this.wards = data;
                      this.loadingWards = false;
                  })
                  .catch(err => {
                      console.error('Error fetching wards:', err);
                      this.loadingWards = false;
                  });
          }
      }"
      x-init="$watch('darkMode', val => localStorage.setItem('darkMode', val)); if (selectedLga) { fetchWards(); }"
      :class="{ 'dark bg-slate-900 text-slate-100': darkMode }">

    <!-- Header Navbar -->
    <header class="bg-bushgreen text-white border-b-2 border-gold h-20 flex items-center justify-between px-6 shadow-md relative z-30">
        <div class="flex items-center gap-3">
            <a href="user-details.php?id=<?php echo $target_id; ?>" class="py-1.5 px-3 border border-white/20 hover:bg-white/10 text-white rounded-lg text-xs font-bold transition">
                &larr; Back to Details
            </a>
            <div class="w-8 h-8 rounded bg-white/10 flex items-center justify-center border border-white/20 p-1 flex-shrink-0">
                <?php echo getAppLogoHtml('w-full h-full object-contain', 'dashboard'); ?>
            </div>
            <span class="text-white font-extrabold text-sm font-display hidden sm:inline">PBAT SMART NATION INITIATIVE</span>
        </div>
        <div class="flex items-center gap-4 text-xs font-bold text-gold uppercase tracking-wider">
            <button @click="darkMode = !darkMode" class="p-2 rounded-lg border border-gold/45 text-gold hover:bg-gold/10 transition flex items-center justify-center">
                <svg x-show="darkMode" class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364-6.364l-.707.707M6.364 17.636l-.707.707M18.364 17.636l-.707-.707M6.364 6.364l-.707-.707M15 12a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                <svg x-show="!darkMode" class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z"/></svg>
            </button>
            <span>Dossier Editor</span>
        </div>
    </header>

    <main class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-10 flex-grow w-full space-y-8">
        
        <div class="space-y-1">
            <h1 class="text-2xl sm:text-3xl font-black text-bushgreen dark:text-gold font-display">Edit User Coordinates</h1>
            <p class="text-slate-500 dark:text-slate-400 text-xs font-light">Super Admin control panel for modifying profile attributes, photos, and compliance registrations.</p>
        </div>

        <?php if (!empty($error)): ?>
            <div class="p-4 bg-red-50 dark:bg-red-500/10 border border-red-200 dark:border-red-500/20 text-red-800 dark:text-red-400 rounded-2xl text-xs font-semibold">
                <?php echo $error; ?>
            </div>
        <?php endif; ?>

        <?php if ($target_user): ?>
            <form method="POST" action="" enctype="multipart/form-data" class="grid grid-cols-1 lg:grid-cols-12 gap-8">
                <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                <input type="hidden" name="action" value="update_profile">

                <!-- SIDEBAR CARD: PHOTO & KEY DETAILS (Col 4) -->
                <div class="lg:col-span-4 space-y-6">
                    <div class="bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm flex flex-col items-center text-center space-y-4">
                        <div class="relative group">
                            <img src="<?php echo htmlspecialchars(!empty($target_user['avatar']) ? '../' . $target_user['avatar'] : '../assets/img/default-avatar.png'); ?>" 
                                 alt="Avatar Preview" 
                                 id="avatar_preview"
                                 class="w-32 h-32 rounded-full border-4 border-gold/40 object-cover shadow shadow-slate-300 dark:shadow-black">
                        </div>

                        <div>
                            <h3 class="text-slate-800 dark:text-white font-bold text-base"><?php echo htmlspecialchars($target_user['name']); ?></h3>
                            <span class="text-[9px] px-2 py-0.5 rounded bg-bushgreen/10 text-bushgreen dark:bg-gold/10 dark:text-gold uppercase font-bold tracking-wider"><?php echo htmlspecialchars($target_user['email']); ?></span>
                        </div>

                        <div class="w-full pt-4 border-t border-slate-100 dark:border-slate-700 space-y-3">
                            <label class="block text-slate-600 dark:text-slate-400 text-xs font-bold text-left mb-1">Upload New Photo</label>
                            <input type="file" name="profile_photo" accept="image/*" 
                                   class="w-full text-xs text-slate-500 file:mr-3 file:py-1.5 file:px-3 file:rounded-xl file:border-0 file:bg-bushgreen/10 file:text-bushgreen file:font-semibold"
                                   onchange="document.getElementById('avatar_preview').src = URL.createObjectURL(this.files[0])">
                        </div>
                    </div>

                    <!-- Account Core Status -->
                    <div class="bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-4">
                        <h4 class="text-slate-800 dark:text-white font-bold text-xs font-display uppercase tracking-wider border-b border-slate-50 dark:border-slate-700 pb-2">Status & Verification</h4>
                        
                        <div class="space-y-4 text-xs">
                            <div>
                                <label class="block text-slate-600 dark:text-slate-400 text-[10px] font-semibold mb-1">Account Status</label>
                                <select name="status" class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                                    <option value="pending" <?php echo $target_user['status'] === 'pending' ? 'selected' : ''; ?>>Pending</option>
                                    <option value="active" <?php echo $target_user['status'] === 'active' ? 'selected' : ''; ?>>Active</option>
                                    <option value="suspended" <?php echo $target_user['status'] === 'suspended' ? 'selected' : ''; ?>>Suspended</option>
                                </select>
                            </div>

                            <div class="flex items-center justify-between">
                                <span class="text-slate-600 dark:text-slate-400 font-semibold text-[10px]">Email Address Verified?</span>
                                <label class="relative inline-flex items-center cursor-pointer">
                                    <input type="checkbox" name="email_verified" value="1" <?php echo (int)$target_user['email_verified'] === 1 ? 'checked' : ''; ?> class="sr-only peer">
                                    <div class="w-9 h-5 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-bushgreen"></div>
                                </label>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- MAIN FORM FIELDS (Col 8) -->
                <div class="lg:col-span-8 space-y-6">
                    
                    <!-- Form Tab 1: Core Credentials & Details -->
                    <div class="bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-4">
                        <h3 class="text-slate-800 dark:text-white font-bold text-sm font-display border-b border-slate-50 dark:border-slate-700 pb-2">🔑 Core Registration Details</h3>
                        
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                            <div>
                                <label class="block text-slate-600 dark:text-slate-400 text-[10px] font-semibold mb-1">Full Name *</label>
                                <input type="text" name="name" required value="<?php echo htmlspecialchars($target_user['name']); ?>" class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                            </div>
                            <div>
                                <label class="block text-slate-600 dark:text-slate-400 text-[10px] font-semibold mb-1">Email Address *</label>
                                <input type="email" name="email" required value="<?php echo htmlspecialchars($target_user['email']); ?>" class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-mono">
                            </div>
                            <div>
                                <label class="block text-slate-600 dark:text-slate-400 text-[10px] font-semibold mb-1">Phone Number</label>
                                <input type="text" name="phone" value="<?php echo htmlspecialchars($target_user['phone']); ?>" class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-mono">
                            </div>
                            <div>
                                <label class="block text-slate-600 dark:text-slate-400 text-[10px] font-semibold mb-1">Membership Code</label>
                                <input type="text" name="membership_code" value="<?php echo htmlspecialchars($target_user['membership_code']); ?>" class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-mono">
                            </div>
                            <div>
                                <label class="block text-slate-600 dark:text-slate-400 text-[10px] font-semibold mb-1">Residential Address</label>
                                <input type="text" name="address" value="<?php echo htmlspecialchars($target_user['address']); ?>" class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                            </div>
                            <div>
                                <label class="block text-slate-600 dark:text-slate-400 text-[10px] font-semibold mb-1">Occupation</label>
                                <input type="text" name="occupation" value="<?php echo htmlspecialchars($target_user['occupation']); ?>" class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                            </div>
                            <div>
                                <label class="block text-slate-600 dark:text-slate-400 text-[10px] font-semibold mb-1">Gender</label>
                                <select name="gender" class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                                    <option value="" <?php echo empty($target_user['gender']) ? 'selected' : ''; ?>>-- Select Gender --</option>
                                    <option value="Male" <?php echo $target_user['gender'] === 'Male' ? 'selected' : ''; ?>>Male</option>
                                    <option value="Female" <?php echo $target_user['gender'] === 'Female' ? 'selected' : ''; ?>>Female</option>
                                </select>
                            </div>
                            <div>
                                <label class="block text-slate-600 dark:text-slate-400 text-[10px] font-semibold mb-1">Age</label>
                                <input type="number" name="age" value="<?php echo htmlspecialchars($target_user['age']); ?>" class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                            </div>
                        </div>
                    </div>

                    <!-- Geopolitical Jurisdictions -->
                    <div class="bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-4">
                        <h3 class="text-slate-800 dark:text-white font-bold text-sm font-display border-b border-slate-50 dark:border-slate-700 pb-2">🗺️ Geopolitical Jurisdiction</h3>
                        
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                            <div>
                                <label class="block text-slate-600 dark:text-slate-400 text-[10px] font-semibold mb-1">Designated Role *</label>
                                <select name="role_id" required x-model="selectedRole" @change="selectedState = ''; selectedLga = ''; selectedWard = ''; selectedZone = ''; wards = [];" class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                                    <?php foreach ($roles_list as $ro): ?>
                                        <option value="<?php echo $ro['id']; ?>"><?php echo htmlspecialchars($ro['display_name']); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <!-- Zonal Zone -->
                            <div x-show="selectedRole == 4" x-transition x-cloak>
                                <label class="block text-slate-600 dark:text-slate-400 text-[10px] font-semibold mb-1">Zone Assignment *</label>
                                <select name="zone" :required="selectedRole == 4" x-model="selectedZone" class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                                    <option value="">-- Choose Zone --</option>
                                    <option value="South-West">South-West</option>
                                    <option value="North-Central">North-Central</option>
                                    <option value="South-South">South-South</option>
                                    <option value="North-West">North-West</option>
                                    <option value="South-East">South-East</option>
                                    <option value="North-East">North-East</option>
                                </select>
                            </div>

                            <!-- State (State, LGA, Ambassador) -->
                            <div x-show="[5, 6, 7].includes(parseInt(selectedRole))" x-transition x-cloak>
                                <label class="block text-slate-600 dark:text-slate-400 text-[10px] font-semibold mb-1">State Assignment *</label>
                                <select name="state_id" :required="[5, 6, 7].includes(parseInt(selectedRole))" x-model="selectedState" @change="selectedLga = ''; selectedWard = ''; wards = [];" class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                                    <option value="">-- Choose State --</option>
                                    <?php foreach ($states_list as $state): ?>
                                        <option value="<?php echo $state['id']; ?>"><?php echo htmlspecialchars($state['name']); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <!-- LGA (LGA, Ambassador) -->
                            <div x-show="[6, 7].includes(parseInt(selectedRole))" x-transition x-cloak>
                                <label class="block text-slate-600 dark:text-slate-400 text-[10px] font-semibold mb-1">LGA Assignment *</label>
                                <select name="lga_id" :required="[6, 7].includes(parseInt(selectedRole))" x-model="selectedLga" @change="fetchWards()" class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                                    <option value="">-- Choose LGA --</option>
                                    <template x-if="selectedState && lgas[selectedState]">
                                        <template x-for="lga in lgas[selectedState]" :key="lga.id">
                                            <option :value="lga.id" x-text="lga.name" :selected="lga.id == selectedLga"></option>
                                        </template>
                                    </template>
                                </select>
                            </div>

                            <!-- Ward (Ambassador only) -->
                            <div x-show="selectedRole == 7" x-transition x-cloak>
                                <label class="block text-slate-600 dark:text-slate-400 text-[10px] font-semibold mb-1">Ward Assignment *</label>
                                <div class="relative">
                                    <select name="ward_id" :required="selectedRole == 7" x-model="selectedWard" :disabled="loadingWards || !selectedLga" class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen disabled:opacity-60">
                                        <option value="">-- Choose Ward --</option>
                                        <template x-for="ward in wards" :key="ward.id">
                                            <option :value="ward.id" x-text="ward.name" :selected="ward.id == selectedWard"></option>
                                        </template>
                                    </select>
                                    <div x-show="loadingWards" class="absolute right-3 top-2 flex items-center gap-1 text-[9px] text-slate-400 font-medium">
                                        <span class="w-1.5 h-1.5 rounded-full bg-gold animate-ping"></span>
                                        <span>loading...</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Accordion Section: Extended KYC Parameters -->
                    <div class="bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-4" x-data="{ openKyc: false }">
                        <div class="flex justify-between items-center border-b border-slate-50 dark:border-slate-700 pb-2 cursor-pointer" @click="openKyc = !openKyc">
                            <h3 class="text-slate-800 dark:text-white font-bold text-sm font-display flex items-center gap-2">
                                <span>📋 Extended KYC & Demographic Parameters</span>
                                <span class="text-[9px] px-2 py-0.5 bg-gold/10 text-gold rounded font-semibold uppercase">Optional</span>
                            </h3>
                            <span class="text-slate-400 font-bold" x-text="openKyc ? '▲' : '▼'"></span>
                        </div>

                        <div class="space-y-6 text-xs pt-2" x-show="openKyc" x-transition x-cloak>
                            <!-- Personal & Demographics -->
                            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                                <div>
                                    <label class="block text-slate-500 dark:text-slate-400 mb-1">Username Override</label>
                                    <input type="text" name="username_val" value="<?php echo htmlspecialchars($target_kyc['username'] ?? ''); ?>" class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none">
                                </div>
                                <div>
                                    <label class="block text-slate-500 dark:text-slate-400 mb-1">Date of Birth</label>
                                    <input type="date" name="dob" value="<?php echo htmlspecialchars($target_kyc['dob'] ?? ''); ?>" class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none">
                                </div>
                                <div>
                                    <label class="block text-slate-500 dark:text-slate-400 mb-1">Nationality</label>
                                    <input type="text" name="nationality" value="<?php echo htmlspecialchars($target_kyc['nationality'] ?? 'Nigerian'); ?>" class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none">
                                </div>
                                <div>
                                    <label class="block text-slate-500 dark:text-slate-400 mb-1">State of Origin</label>
                                    <input type="text" name="state_of_origin" value="<?php echo htmlspecialchars($target_kyc['state_of_origin'] ?? ''); ?>" class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none">
                                </div>
                                <div>
                                    <label class="block text-slate-500 dark:text-slate-400 mb-1">State of Residence</label>
                                    <input type="text" name="state_of_residence" value="<?php echo htmlspecialchars($target_kyc['state_of_residence'] ?? ''); ?>" class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none">
                                </div>
                            </div>

                            <!-- Social Details -->
                            <div class="border-t border-slate-100 dark:border-slate-700 pt-4 space-y-3">
                                <h5 class="font-bold text-slate-700 dark:text-slate-350">Social & Chat Handles</h5>
                                <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                                    <div>
                                        <label class="block text-slate-500 mb-1">WhatsApp Number</label>
                                        <input type="text" name="whatsapp_number" value="<?php echo htmlspecialchars($target_kyc['whatsapp_number'] ?? ''); ?>" class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg">
                                    </div>
                                    <div>
                                        <label class="block text-slate-500 mb-1">Telegram Username</label>
                                        <input type="text" name="telegram_username" value="<?php echo htmlspecialchars($target_kyc['telegram_username'] ?? ''); ?>" class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg">
                                    </div>
                                    <div>
                                        <label class="block text-slate-500 mb-1">X (Twitter) Handle</label>
                                        <input type="text" name="x_handle" value="<?php echo htmlspecialchars($target_kyc['x_handle'] ?? ''); ?>" class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg">
                                    </div>
                                    <div>
                                        <label class="block text-slate-500 mb-1">Facebook Profile</label>
                                        <input type="text" name="facebook_profile" value="<?php echo htmlspecialchars($target_kyc['facebook_profile'] ?? ''); ?>" class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg">
                                    </div>
                                    <div>
                                        <label class="block text-slate-500 mb-1">Instagram Username</label>
                                        <input type="text" name="instagram_username" value="<?php echo htmlspecialchars($target_kyc['instagram_username'] ?? ''); ?>" class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg">
                                    </div>
                                    <div>
                                        <label class="block text-slate-500 mb-1">LinkedIn Profile</label>
                                        <input type="text" name="linkedin_profile" value="<?php echo htmlspecialchars($target_kyc['linkedin_profile'] ?? ''); ?>" class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg">
                                    </div>
                                </div>
                            </div>

                            <!-- Education & Employment -->
                            <div class="border-t border-slate-100 dark:border-slate-700 pt-4 space-y-3">
                                <h5 class="font-bold text-slate-700 dark:text-slate-350">Academic & Professional Background</h5>
                                <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                                    <div>
                                        <label class="block text-slate-500 mb-1">Highest Qualification</label>
                                        <input type="text" name="highest_qualification" value="<?php echo htmlspecialchars($target_kyc['highest_qualification'] ?? ''); ?>" class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg">
                                    </div>
                                    <div>
                                        <label class="block text-slate-500 mb-1">Institution</label>
                                        <input type="text" name="institution" value="<?php echo htmlspecialchars($target_kyc['institution'] ?? ''); ?>" class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg">
                                    </div>
                                    <div>
                                        <label class="block text-slate-500 mb-1">Course of Study</label>
                                        <input type="text" name="course_of_study" value="<?php echo htmlspecialchars($target_kyc['course_of_study'] ?? ''); ?>" class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg">
                                    </div>
                                    <div>
                                        <label class="block text-slate-500 mb-1">Graduation Year</label>
                                        <input type="number" name="graduation_year" value="<?php echo htmlspecialchars($target_kyc['graduation_year'] ?? ''); ?>" class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg">
                                    </div>
                                    <div>
                                        <label class="block text-slate-500 mb-1">Current Employer</label>
                                        <input type="text" name="employer" value="<?php echo htmlspecialchars($target_kyc['employer'] ?? ''); ?>" class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg">
                                    </div>
                                    <div>
                                        <label class="block text-slate-500 mb-1">Industry Sector</label>
                                        <input type="text" name="industry" value="<?php echo htmlspecialchars($target_kyc['industry'] ?? ''); ?>" class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg">
                                    </div>
                                </div>
                            </div>

                            <!-- Skills & Expertise -->
                            <div class="border-t border-slate-100 dark:border-slate-700 pt-4 space-y-4">
                                <h5 class="font-bold text-slate-700 dark:text-slate-350">Advocacy & Technical Expertise</h5>
                                
                                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <div>
                                        <label class="block text-slate-500 mb-1">Technical Skills & Expertise</label>
                                        <textarea name="skills_expertise" rows="2" class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg"><?php echo htmlspecialchars($target_kyc['skills_expertise'] ?? ''); ?></textarea>
                                    </div>
                                    <div>
                                        <label class="block text-slate-500 mb-1">AI/Digital Knowledge Level</label>
                                        <input type="text" name="ai_knowledge_level" value="<?php echo htmlspecialchars($target_kyc['ai_knowledge_level'] ?? ''); ?>" class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg">
                                    </div>
                                    <div>
                                        <label class="block text-slate-500 mb-1">Why Join / Core Motivation</label>
                                        <textarea name="why_join" rows="2" class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg"><?php echo htmlspecialchars($target_kyc['why_join'] ?? ''); ?></textarea>
                                    </div>
                                    <div>
                                        <label class="block text-slate-500 mb-1">Preferred Advocacy Role</label>
                                        <input type="text" name="preferred_role" value="<?php echo htmlspecialchars($target_kyc['preferred_role'] ?? ''); ?>" class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg">
                                    </div>
                                    <div>
                                        <label class="block text-slate-500 mb-1">Volunteer Availability</label>
                                        <input type="text" name="volunteer_availability" value="<?php echo htmlspecialchars($target_kyc['volunteer_availability'] ?? ''); ?>" class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg">
                                    </div>
                                    <div>
                                        <label class="block text-slate-500 mb-1">Community Engagement History</label>
                                        <textarea name="community_engagement" rows="2" class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg"><?php echo htmlspecialchars($target_kyc['community_engagement'] ?? ''); ?></textarea>
                                    </div>
                                    <div>
                                        <label class="block text-slate-500 mb-1">Outreach Experience</label>
                                        <textarea name="outreach_experience" rows="2" class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg"><?php echo htmlspecialchars($target_kyc['outreach_experience'] ?? ''); ?></textarea>
                                    </div>
                                    <div>
                                        <label class="block text-slate-500 mb-1">Leadership Experience</label>
                                        <textarea name="leadership_experience" rows="2" class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg"><?php echo htmlspecialchars($target_kyc['leadership_experience'] ?? ''); ?></textarea>
                                    </div>
                                </div>
                            </div>

                            <!-- Moderation Compliance -->
                            <div class="border-t border-slate-100 dark:border-slate-700 pt-4 space-y-3">
                                <h5 class="font-bold text-slate-700 dark:text-slate-350">KYC Status Moderation</h5>
                                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <div>
                                        <label class="block text-slate-500 mb-1">KYC Status</label>
                                        <select name="kyc_status" class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none">
                                            <option value="draft" <?php echo ($target_kyc['kyc_status'] ?? '') === 'draft' ? 'selected' : ''; ?>>Draft</option>
                                            <option value="pending_review" <?php echo ($target_kyc['kyc_status'] ?? '') === 'pending_review' ? 'selected' : ''; ?>>Pending Review</option>
                                            <option value="approved" <?php echo ($target_kyc['kyc_status'] ?? '') === 'approved' ? 'selected' : ''; ?>>Approved</option>
                                            <option value="rejected" <?php echo ($target_kyc['kyc_status'] ?? '') === 'rejected' ? 'selected' : ''; ?>>Rejected</option>
                                        </select>
                                    </div>
                                    <div>
                                        <label class="block text-slate-500 mb-1">KYC Status Moderation Feedback Message</label>
                                        <input type="text" name="kyc_status_message" value="<?php echo htmlspecialchars($target_kyc['kyc_status_message'] ?? ''); ?>" class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Submit Buttons -->
                    <div class="flex justify-end gap-3 pt-4 border-t border-slate-100 dark:border-slate-700">
                        <a href="user-details.php?id=<?php echo $target_id; ?>" class="py-2.5 px-6 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-xs font-bold rounded-xl hover:bg-slate-50 dark:hover:bg-slate-900 transition">
                            Cancel
                        </a>
                        <button type="submit" class="py-2.5 px-8 bg-bushgreen hover:bg-bushgreen-light text-white text-xs font-bold rounded-xl transition shadow-md">
                            Save Account Coordinates
                        </button>
                    </div>

                </div>

            </form>
        <?php else: ?>
            <div class="text-center py-20 bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 space-y-4">
                <p class="text-slate-400 text-sm font-light">No member profile coordinates loaded. Please return to the management screen.</p>
                <a href="users.php" class="inline-block py-2 px-6 bg-bushgreen text-white rounded-xl text-xs font-bold">
                    Return to User Management
                </a>
            </div>
        <?php endif; ?>

    </main>
</body>
</html>
