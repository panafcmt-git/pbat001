<?php
/**
 * PBAT Smart Nation Initiative - Notification Broadcast Center
 * Dispatches emails, SMS log mocks, and local dashboard alerts by role, state, or globally.
 */
require_once dirname(__DIR__) . '/helpers/auth.php';
require_once dirname(__DIR__) . '/helpers/common.php';
require_once dirname(__DIR__) . '/helpers/notifications.php';
require_once dirname(__DIR__) . '/config/database.php';

Auth::requireRole(['super_admin', 'founder_circle', 'national_steering'], '../login.php');

$user = Auth::user();
$error = '';
$success = '';

try {
    $db = Database::connect();

    // Fetch States and Roles for selector options
    $states = $db->query("SELECT * FROM states ORDER BY name ASC")->fetchAll();
    $roles = $db->query("SELECT * FROM roles ORDER BY id ASC")->fetchAll();

    // Fetch LGAs grouped by State
    $stmt_lgas = $db->query("SELECT id, state_id, name FROM lgas ORDER BY name ASC");
    $all_lgas = $stmt_lgas->fetchAll();
    $lgas_by_state = [];
    foreach ($all_lgas as $lga) {
        $lgas_by_state[$lga['state_id']][] = [
            'id' => $lga['id'],
            'name' => $lga['name']
        ];
    }

    // Handle Dispatch
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (!Auth::validateCsrf($_POST['csrf_token'] ?? '')) {
            $error = "CSRF security check failed.";
        } else {
            $subject = trim($_POST['subject']);
            $body = trim($_POST['body']);
            $target = trim($_POST['target']);
            $target_state = !empty($_POST['target_state_id']) ? (int)$_POST['target_state_id'] : null;
            $target_role = !empty($_POST['target_role_id']) ? (int)$_POST['target_role_id'] : null;
            $target_lga = !empty($_POST['target_lga_id']) ? (int)$_POST['target_lga_id'] : null;
            $target_ward = !empty($_POST['target_ward_id']) ? (int)$_POST['target_ward_id'] : null;
            $channels = $_POST['channels'] ?? [];

            if (empty($subject) || empty($body)) {
                $error = "Subject and announcement content are required.";
            } else {
                $db->beginTransaction();

                // Select target users
                $query = "SELECT u.id, u.name, u.email FROM users u WHERE u.status = 'active'";
                $params = [];

                if ($target === 'state' && $target_state) {
                    // Fetch ambassadors in state and leaders in state
                    $query = "
                        SELECT u.id, u.name, u.email 
                        FROM users u 
                        LEFT JOIN ambassadors a ON u.id = a.user_id 
                        LEFT JOIN user_leadership ul ON u.id = ul.user_id
                        WHERE u.status = 'active' AND (a.state_id = ? OR ul.state_id = ?)
                    ";
                    $params = [$target_state, $target_state];
                } elseif ($target === 'lga' && $target_lga) {
                    $query = "
                        SELECT u.id, u.name, u.email 
                        FROM users u 
                        LEFT JOIN ambassadors a ON u.id = a.user_id 
                        LEFT JOIN user_leadership ul ON u.id = ul.user_id
                        WHERE u.status = 'active' AND (a.lga_id = ? OR ul.lga_id = ?)
                    ";
                    $params = [$target_lga, $target_lga];
                } elseif ($target === 'ward' && $target_ward) {
                    $query = "
                        SELECT u.id, u.name, u.email 
                        FROM users u 
                        LEFT JOIN ambassadors a ON u.id = a.user_id 
                        LEFT JOIN user_leadership ul ON u.id = ul.user_id
                        WHERE u.status = 'active' AND (a.ward_id = ? OR ul.ward_id = ?)
                    ";
                    $params = [$target_ward, $target_ward];
                } elseif ($target === 'role' && $target_role) {
                    $query = "SELECT u.id, u.name, u.email FROM users u WHERE u.status = 'active' AND u.role_id = ?";
                    $params = [$target_role];
                }

                $stmt_users = $db->prepare($query);
                $stmt_users->execute($params);
                $recipients = $stmt_users->fetchAll();

                if (empty($recipients)) {
                    $error = "Target filter returned zero active recipients.";
                    $db->rollBack();
                } else {
                    // Send alerts
                    $sent_count = 0;
                    $stmt_notify = $db->prepare("INSERT INTO `notifications` (`user_id`, `message`, `type`) VALUES (?, ?, 'general')");
                    
                    foreach ($recipients as $recipient) {
                        // 1. Database dashboard notification
                        $stmt_notify->execute([$recipient['id'], $subject]);

                        // 2. Email Delivery (optional toggle)
                        if (in_array('email', $channels)) {
                            $html_email = getEmailTemplate(
                                "Circular Circular - PBAT Smart Nation",
                                "Strategic Policy Circular",
                                htmlspecialchars($subject),
                                "<p>" . nl2br(htmlspecialchars($body)) . "</p>",
                                "login.php",
                                "Log In to Portal"
                            );
                            sendMail($recipient['email'], $subject, $html_email);
                        }
                        $sent_count++;
                    }

                    // Audit Log
                    Auth::logAction($user['id'], 'NOTIFICATION_BROADCAST', "Dispatched '{$subject}' to {$sent_count} members.");
                    $db->commit();
                    $success = "Broadcast successfully dispatched to {$sent_count} active portal members!";
                }
            }
        }
    }

    // Fetch last 10 audit logs of broadcasts
    $broadcasts = $db->query("
        SELECT a.*, u.name as admin_name 
        FROM audit_logs a 
        JOIN users u ON a.user_id = u.id 
        WHERE a.action = 'NOTIFICATION_BROADCAST' 
        ORDER BY a.created_at DESC 
        LIMIT 8
    ")->fetchAll();

} catch (Exception $e) {
    $error = "Broadcast Dispatch Error: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notification Broadcast outbox - PBAT Smart Nation</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        bushgreen: {
                            DEFAULT: '#063C1E',
                            light: '#0A4D27',
                            dark: '#03200F',
                        },
                        gold: '#D4AF37'
                    }
                }
            }
        }
    </script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        [x-cloak] { display: none !important; }
        body { font-family: 'Inter', sans-serif; }
        h1, h2, h3, h4, .font-display { font-family: 'Outfit', sans-serif; }
    </style>
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
</head>
<body class="bg-slate-50 text-slate-800 transition-colors duration-200 min-h-screen flex flex-col antialiased"
      x-data="{ darkMode: localStorage.getItem('darkMode') === 'true' }"
      x-init="$watch('darkMode', val => localStorage.setItem('darkMode', val))"
      :class="{ 'dark bg-slate-900 text-slate-100': darkMode }">

    <!-- Header Navbar -->
    <header class="bg-bushgreen text-white border-b-2 border-gold h-20 flex items-center justify-between px-6 shadow-md relative z-30">
        <div class="flex items-center gap-3">
            <a href="dashboard.php" class="py-1.5 px-3 border border-white/20 hover:bg-white/10 text-white rounded-lg text-xs font-bold transition">
                &larr; Back to Dashboard
            </a>
            <div class="w-8 h-8 rounded bg-white/10 flex items-center justify-center border border-white/20 p-1 flex-shrink-0">
                <?php echo getAppLogoHtml('w-full h-full object-contain', 'dashboard'); ?>
            </div>
            <span class="text-white font-extrabold text-sm font-display hidden sm:inline">PBAT SMART NATION INITIATIVE</span>
        </div>
        <div class="flex items-center gap-4 text-xs font-bold text-gold uppercase tracking-wider">
            <!-- Dark Mode Toggle -->
            <button @click="darkMode = !darkMode" class="p-2 rounded-lg border border-gold/45 text-gold hover:bg-gold/10 transition flex items-center justify-center">
                <svg x-show="darkMode" class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364-6.364l-.707.707M6.364 17.636l-.707.707M18.364 17.636l-.707-.707M6.364 6.364l-.707-.707M15 12a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                <svg x-show="!darkMode" class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z"/></svg>
            </button>
            <span>Broadcast Command Center</span>
        </div>
    </header>

    <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 flex-grow w-full space-y-10">
        
        <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div class="space-y-1">
                <h1 class="text-2xl sm:text-3xl font-black text-bushgreen dark:text-gold font-display">Notification Broadcast Center</h1>
                <p class="text-slate-500 dark:text-slate-400 text-xs font-light">Formulate strategic global circulars, filter recipient segments, and send multi-channel alerts.</p>
            </div>

            <?php if (!empty($success)): ?>
                <div class="px-4 py-2 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs font-semibold">
                    <?php echo htmlspecialchars($success); ?>
                </div>
            <?php endif; ?>

            <?php if (!empty($error)): ?>
                <div class="px-4 py-2 bg-red-50 border border-red-200 text-red-800 rounded-xl text-xs font-semibold">
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            
            <!-- BROADCASTER FORM (Col 7) -->
            <form method="POST" action="" class="lg:col-span-7 bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6"
                  x-data="{ 
                      targetType: 'all', 
                      selectedState: '', 
                      selectedLga: '', 
                      selectedWard: '', 
                      lgas: <?php echo htmlspecialchars(json_encode($lgas_by_state), ENT_QUOTES, 'UTF-8'); ?>, 
                      wards: [], 
                      async fetchWards() {
                          if (!this.selectedLga) {
                              this.wards = [];
                              return;
                          }
                          try {
                              const res = await fetch('../api/wards.php?lga_id=' + this.selectedLga);
                              this.wards = await res.json();
                          } catch (e) {
                              console.error(e);
                          }
                      }
                  }">
                <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">

                <div class="pb-3 border-b border-slate-100 dark:border-slate-700">
                    <h3 class="text-slate-800 dark:text-slate-200 font-bold text-sm">Compose Strategic Alert</h3>
                    <p class="text-[10px] text-slate-400">Target segments by physical geopolitical chapter or systemic role hierarchy.</p>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                        <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1.5" for="target">Target Group *</label>
                        <select name="target" id="target" x-model="targetType" required
                                @change="selectedState = ''; selectedLga = ''; selectedWard = ''; wards = []"
                                class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                            <option value="all">Global (All Active)</option>
                            <option value="role">System Leadership Tier</option>
                            <option value="state">Geopolitical State Chapter</option>
                            <option value="lga">Local Government Area (LGA)</option>
                            <option value="ward">Ward Chapter</option>
                        </select>
                    </div>

                    <div x-show="targetType === 'role'">
                        <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1.5" for="target_role_id">Select Role Tier</label>
                        <select name="target_role_id" id="target_role_id"
                                class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                            <option value="">-- Choose Role --</option>
                            <?php foreach ($roles as $ro): ?>
                                <option value="<?php echo $ro['id']; ?>"><?php echo htmlspecialchars($ro['display_name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div x-show="['state', 'lga', 'ward'].includes(targetType)">
                        <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1.5" for="target_state_id">Select State Chapter</label>
                        <select name="target_state_id" id="target_state_id" x-model="selectedState" @change="selectedLga = ''; selectedWard = ''; wards = []"
                                class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                            <option value="">-- Choose State --</option>
                            <?php foreach ($states as $st): ?>
                                <option value="<?php echo $st['id']; ?>"><?php echo htmlspecialchars($st['name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <!-- LGA & Ward selectors (shown when targetType is lga or ward) -->
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4" x-show="['lga', 'ward'].includes(targetType)" x-transition>
                    <div>
                        <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1.5" for="target_lga_id">Select LGA</label>
                        <select name="target_lga_id" id="target_lga_id" x-model="selectedLga" @change="selectedWard = ''; fetchWards()"
                                class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                            <option value="">-- Choose LGA --</option>
                            <template x-if="selectedState && lgas[selectedState]">
                                <template x-for="lga in lgas[selectedState]" :key="lga.id">
                                    <option :value="lga.id" x-text="lga.name"></option>
                                </template>
                            </template>
                        </select>
                    </div>

                    <div x-show="targetType === 'ward'" x-transition>
                        <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1.5" for="target_ward_id">Select Ward</label>
                        <select name="target_ward_id" id="target_ward_id" x-model="selectedWard"
                                class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                            <option value="">-- Choose Ward --</option>
                            <template x-for="wd in wards" :key="wd.id">
                                <option :value="wd.id" x-text="wd.name"></option>
                            </template>
                        </select>
                    </div>
                </div>

                <div>
                    <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1.5" for="subject">Announcement Subject *</label>
                    <input type="text" name="subject" id="subject" required placeholder="e.g. Scheduled System Security Updates"
                           class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                </div>

                <div>
                    <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1.5" for="body">Alert Content Body *</label>
                    <textarea name="body" id="body" required rows="6" placeholder="Provide detailed circular information..."
                              class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-light leading-relaxed"></textarea>
                </div>

                <div class="space-y-2">
                    <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold">Delivery Channels</label>
                    <div class="flex gap-4">
                        <label class="inline-flex items-center gap-1.5 text-xs text-slate-600 dark:text-slate-400 select-none">
                            <input type="checkbox" name="channels[]" value="email" checked class="w-4 h-4 text-bushgreen rounded focus:ring-bushgreen">
                            Secure SMTP Email
                        </label>
                        <label class="inline-flex items-center gap-1.5 text-xs text-slate-600 dark:text-slate-400 select-none">
                            <input type="checkbox" name="channels[]" value="dashboard" checked disabled class="w-4 h-4 text-bushgreen rounded focus:ring-bushgreen">
                            Dashboard Notification (Mandatory)
                        </label>
                        <label class="inline-flex items-center gap-1.5 text-xs text-slate-600 dark:text-slate-400 select-none">
                            <input type="checkbox" name="channels[]" value="sms" class="w-4 h-4 text-bushgreen rounded focus:ring-bushgreen">
                            SMS (Mock simulation)
                        </label>
                    </div>
                </div>

                <button type="submit" class="w-full py-2.5 bg-bushgreen hover:bg-bushgreen-light text-white text-xs font-bold rounded-lg transition shadow-md shadow-bushgreen/10">
                    Dispatch Segments Circular Alert
                </button>
            </form>

            <!-- OUTBOX AUDIT LOGS (Col 5) -->
            <div class="lg:col-span-5 bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-4">
                <h3 class="text-slate-800 dark:text-slate-200 font-bold text-sm">Dispatched Outbox History</h3>
                
                <div class="space-y-4">
                    <?php if (empty($broadcasts)): ?>
                        <div class="text-slate-400 italic text-xs py-8 text-center">No segments alerts dispatched in session.</div>
                    <?php endif; ?>
                    <?php foreach ($broadcasts as $bc): ?>
                        <div class="p-3 bg-slate-50 dark:bg-slate-900/50 rounded-xl border border-slate-100 dark:border-slate-800 text-[11px] space-y-1.5">
                            <div class="flex justify-between items-center text-slate-400">
                                <strong>Admin: <?php echo htmlspecialchars($bc['admin_name']); ?></strong>
                                <span><?php echo date('Y-m-d H:i', strtotime($bc['created_at'])); ?></span>
                            </div>
                            <p class="text-slate-700 dark:text-slate-300 font-medium"><?php echo htmlspecialchars($bc['details']); ?></p>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

        </div>

    </main>
</body>
</html>
