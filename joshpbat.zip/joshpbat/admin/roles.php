<?php
/**
 * PBAT Smart Nation Initiative - Role & Permission Management
 * Features a Permission Matrix Editor for RBAC configuration.
 */
require_once dirname(__DIR__) . '/helpers/auth.php';
require_once dirname(__DIR__) . '/helpers/common.php';
require_once dirname(__DIR__) . '/config/database.php';

Auth::requireRole(['super_admin'], '../login.php');

$user = Auth::user();
$error = '';
$success = '';

try {
    $db = Database::connect();

    // 1. Handle Role Creation
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'create_role') {
        if (!Auth::validateCsrf($_POST['csrf_token'] ?? '')) {
            $error = "Security validation expired.";
        } else {
            $role_name = strtolower(preg_replace('/[^a-zA-Z0-9_]/', '', trim($_POST['role_name'])));
            $display_name = trim($_POST['display_name']);
            $description = trim($_POST['description']);

            if (empty($role_name) || empty($display_name)) {
                $error = "Role reference name and display label are required.";
            } else {
                $stmt = $db->prepare("INSERT INTO `roles` (`name`, `display_name`, `description`) VALUES (?, ?, ?)");
                $stmt->execute([$role_name, $display_name, $description]);
                
                Auth::logAction($user['id'], 'ROLE_CREATE', "Created custom role '{$display_name}'");
                $success = "Custom role created successfully!";
            }
        }
    }

    // 2. Handle Permission Update Matrix
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_matrix') {
        if (!Auth::validateCsrf($_POST['csrf_token'] ?? '')) {
            $error = "Security validation expired.";
        } else {
            $db->beginTransaction();
            // Clear existing role permissions
            $db->exec("DELETE FROM `role_permissions`");

            // Re-insert based on checked options
            $stmt = $db->prepare("INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES (?, ?)");
            $matrix = $_POST['matrix'] ?? [];
            foreach ($matrix as $role_id => $perms) {
                foreach ($perms as $perm_id => $val) {
                    $stmt->execute([(int)$role_id, (int)$perm_id]);
                }
            }

            Auth::logAction($user['id'], 'PERMISSION_MATRIX_UPDATE', "Reconfigured role permission mappings.");
            $db->commit();
            $success = "Permission matrix updated successfully!";
        }
    }

    // Fetch Roles
    $stmt = $db->query("SELECT * FROM `roles` ORDER BY `id` ASC");
    $roles = $stmt->fetchAll();

    // Fetch Permissions
    $stmt = $db->query("SELECT * FROM `permissions` ORDER BY `id` ASC");
    $permissions = $stmt->fetchAll();

    // Fetch active mappings
    $stmt = $db->query("SELECT * FROM `role_permissions`");
    $mappings_raw = $stmt->fetchAll();
    $mappings = [];
    foreach ($mappings_raw as $m) {
        $mappings[$m['role_id']][$m['permission_id']] = true;
    }

} catch (Exception $e) {
    $error = "System Matrix Error: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Roles & Permissions - PBAT Smart Nation</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        bushgreen: {
                            DEFAULT: '#063C1E',
                            light: '#0A4D27',
                            dark: '#03200F',
                        },
                        gold: '#D4AF37'
                    }
                }
            }
        }
    </script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Outfit', sans-serif; }
    </style>
</head>
<body class="bg-slate-50 min-h-screen flex flex-col antialiased">

    <!-- Header Navbar -->
    <header class="bg-bushgreen text-white border-b-2 border-gold h-20 flex items-center justify-between px-6 shadow-md relative z-30">
        <div class="flex items-center gap-3">
            <a href="dashboard.php" class="py-1.5 px-3 border border-white/20 hover:bg-white/10 text-white rounded-lg text-xs font-bold transition">
                &larr; Back to Dashboard
            </a>
            <div class="w-8 h-8 rounded bg-white/10 flex items-center justify-center border border-white/20 p-1 flex-shrink-0">
                <?php echo getAppLogoHtml('w-full h-full object-contain', 'dashboard'); ?>
            </div>
            <span class="text-white font-extrabold text-sm font-display hidden sm:inline">PBAT SMART NATION INITIATIVE</span>
        </div>
        <div class="flex items-center gap-3 text-xs font-bold text-gold uppercase tracking-wider">
            RBAC Access Control Gate
        </div>
    </header>

    <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 flex-grow w-full space-y-10">
        
        <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div class="space-y-1">
                <h1 class="text-2xl sm:text-3xl font-black text-bushgreen font-display">Role & Permission Matrix</h1>
                <p class="text-slate-500 text-xs font-light">Control role-based access limits. Authorize or revoke operational permissions across modules in real-time.</p>
            </div>

            <?php if (!empty($success)): ?>
                <div class="px-4 py-2 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs font-semibold">
                    <?php echo htmlspecialchars($success); ?>
                </div>
            <?php endif; ?>

            <?php if (!empty($error)): ?>
                <div class="px-4 py-2 bg-red-50 border border-red-200 text-red-800 rounded-xl text-xs font-semibold">
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            
            <!-- MATRIX EDITOR (Col 8) -->
            <form method="POST" action="" class="lg:col-span-8 bg-white rounded-2xl border border-slate-100 p-6 shadow-sm space-y-6">
                <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                <input type="hidden" name="action" value="update_matrix">

                <div class="pb-3 border-b border-slate-100 flex justify-between items-center">
                    <div>
                        <h3 class="text-slate-800 font-bold text-sm">Access Permission Matrix</h3>
                        <p class="text-[10px] text-slate-400 font-light">Check the boxes to map specific capabilities to leadership levels.</p>
                    </div>
                </div>

                <div class="overflow-x-auto">
                    <table class="w-full text-xs text-left text-slate-600">
                        <thead class="text-[10px] text-slate-400 font-bold uppercase tracking-wider border-b border-slate-100">
                            <tr>
                                <th class="pb-3 pr-4">Permission Capability</th>
                                <?php foreach ($roles as $r): ?>
                                    <th class="pb-3 text-center"><?php echo htmlspecialchars($r['display_name']); ?></th>
                                <?php endforeach; ?>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-50">
                            <?php foreach ($permissions as $p): ?>
                                <tr class="hover:bg-slate-50/50">
                                    <td class="py-4 pr-4">
                                        <span class="font-bold text-slate-800 block"><?php echo htmlspecialchars($p['display_name']); ?></span>
                                        <span class="text-[10px] text-slate-400 font-light"><?php echo htmlspecialchars($p['description']); ?></span>
                                    </td>
                                    <?php foreach ($roles as $r): ?>
                                        <td class="py-4 text-center">
                                            <input type="checkbox" name="matrix[<?php echo $r['id']; ?>][<?php echo $p['id']; ?>]" value="1"
                                                   <?php echo isset($mappings[$r['id']][$p['id']]) ? 'checked' : ''; ?>
                                                   class="w-4 h-4 text-bushgreen border-slate-300 rounded focus:ring-bushgreen/30">
                                        </td>
                                    <?php endforeach; ?>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <div class="pt-4 border-t border-slate-100 flex justify-end">
                    <button type="submit" class="py-2.5 px-6 bg-bushgreen hover:bg-bushgreen-light text-white text-xs font-bold rounded-lg transition shadow-md shadow-bushgreen/10">
                        Commit Matrix Changes
                    </button>
                </div>
            </form>

            <!-- ROLE CREATOR (Col 4) -->
            <div class="lg:col-span-4 bg-white rounded-2xl border border-slate-100 p-6 shadow-sm space-y-6">
                <div class="pb-3 border-b border-slate-100">
                    <h3 class="text-slate-800 font-bold text-sm">Provision Custom Role</h3>
                    <p class="text-[10px] text-slate-400 font-light">Create custom leadership classes inside the national campaign directory hierarchy.</p>
                </div>

                <form method="POST" action="" class="space-y-4">
                    <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                    <input type="hidden" name="action" value="create_role">

                    <div>
                        <label class="block text-slate-600 text-xs font-semibold mb-1.5" for="role_name">Role Reference Name *</label>
                        <input type="text" name="role_name" id="role_name" required placeholder="e.g. regional_director"
                               class="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-mono">
                        <p class="text-[9px] text-slate-400 mt-1">Lowercase letters and underscores only.</p>
                    </div>

                    <div>
                        <label class="block text-slate-600 text-xs font-semibold mb-1.5" for="display_name">Display Label *</label>
                        <input type="text" name="display_name" id="display_name" required placeholder="e.g. Regional Director"
                               class="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                    </div>

                    <div>
                        <label class="block text-slate-600 text-xs font-semibold mb-1.5" for="description">Role Description</label>
                        <textarea name="description" id="description" rows="3" placeholder="Define role capabilities..."
                                  class="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-light"></textarea>
                    </div>

                    <button type="submit" class="w-full py-2.5 bg-bushgreen hover:bg-bushgreen-light text-white text-xs font-bold rounded-lg transition shadow-md shadow-bushgreen/10">
                        Create Custom Role Node
                    </button>
                </form>
            </div>

        </div>

    </main>
</body>
</html>
