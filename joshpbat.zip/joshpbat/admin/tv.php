<?php
/**
 * PBAT Smart Nation Initiative - Smart Nation TV CMS
 * Allows scheduling livestreams, featured broadcast pins, and YouTube/Twitch integration.
 */
require_once dirname(__DIR__) . '/helpers/auth.php';
require_once dirname(__DIR__) . '/helpers/common.php';
require_once dirname(__DIR__) . '/config/database.php';

Auth::requireRole(['super_admin', 'founder_circle', 'national_steering'], '../login.php');

$user = Auth::user();
$error = '';
$success = '';
$edit_stream = null;
$edit_yt = null;

try {
    $db = Database::connect();

    // 1. Handle Form Submission (Create / Edit)
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (!Auth::validateCsrf($_POST['csrf_token'] ?? '')) {
            $error = "CSRF Token validation failed.";
        } else {
            $action = $_POST['action'] ?? 'livestream';

            if ($action === 'save_floating_tv') {
                $enabled = isset($_POST['floating_tv_enabled']) ? 1 : 0;
                $title = trim($_POST['floating_tv_title'] ?? 'Smart Nation LIVE tv');
                $description = trim($_POST['floating_tv_description'] ?? 'Watch the featured Smart Nation LIVE tv playlist, including self-hosted and YouTube videos managed from the Super Admin TV dashboard.');

                $stmt = $db->prepare("INSERT INTO `system_settings` (`setting_key`, `setting_value`) VALUES (?, ?) ON DUPLICATE KEY UPDATE `setting_value` = VALUES(`setting_value`)" );
                $stmt->execute(['floating_tv_enabled', (string)$enabled]);
                $stmt->execute(['floating_tv_title', $title]);
                $stmt->execute(['floating_tv_description', $description]);
                Auth::logAction($user['id'], 'TV_FLOATING_SAVE', 'Updated floating TV settings');
                $success = 'Floating TV settings saved successfully.';
                header('Location: tv.php?tab=youtube_videos&success=' . urlencode($success));
                exit;
            } elseif ($action === 'create_yt' || $action === 'edit_yt') {
                $title = trim($_POST['title']);
                $description = trim($_POST['description']);
                $video_source = trim($_POST['video_source'] ?? 'youtube');
                $duration = trim($_POST['duration']);
                $is_featured = isset($_POST['is_featured']) ? 1 : 0;
                $youtube_id = null;
                $video_url = null;

                if ($video_source === 'youtube') {
                    $youtube_id = trim($_POST['youtube_id'] ?? '');
                    if (empty($title) || empty($youtube_id)) {
                        $error = "Title and YouTube Video ID are required.";
                    }
                } elseif ($video_source === 'google_drive') {
                    $video_url = trim($_POST['video_url'] ?? '');
                    if (empty($title) || empty($video_url)) {
                        $error = "Title and Google Drive Embed URL are required.";
                    }
                } elseif ($video_source === 's3') {
                    $video_url = trim($_POST['video_url'] ?? '');
                    if (empty($title) || empty($video_url)) {
                        $error = "Title and Amazon S3 URL are required.";
                    }
                } elseif ($video_source === 'self_hosted') {
                    if ($action === 'edit_yt' && empty($_FILES['video_file']['name'])) {
                        $video_url = trim($_POST['existing_video_url'] ?? '');
                    } else {
                        if (isset($_FILES['video_file']) && $_FILES['video_file']['error'] === UPLOAD_ERR_OK) {
                            $file = $_FILES['video_file'];
                            $file_size = $file['size'];
                            $file_tmp = $file['tmp_name'];
                            $file_name = basename($file['name']);
                            $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

                            if ($file_ext !== 'mp4') {
                                $error = "Only MP4 video files are accepted for self-hosted videos.";
                            } else {
                                $s3_url = uploadFileToS3IfActive($file_tmp, $file_name, 'video/mp4');
                                if ($s3_url) {
                                    $video_url = $s3_url;
                                } else {
                                    $upload_dir = dirname(__DIR__) . '/uploads/';
                                    if (!is_dir($upload_dir)) {
                                        mkdir($upload_dir, 0755, true);
                                    }
                                    $new_file_name = 'video_' . time() . '.' . $file_ext;
                                    $target_file = $upload_dir . $new_file_name;
                                    if (move_uploaded_file($file_tmp, $target_file)) {
                                        $video_url = 'uploads/' . $new_file_name;
                                    } else {
                                        $error = "Failed to write uploaded video file to local storage.";
                                    }
                                }
                            }
                        } else {
                            $error = "A video file upload is required for self-hosted video source.";
                        }
                    }
                }

                if (empty($error)) {
                    if ($is_featured == 1) {
                        $db->query("UPDATE `youtube_videos` SET `is_featured` = 0");
                    }
                    if ($action === 'create_yt') {
                        $stmt = $db->prepare("
                            INSERT INTO `youtube_videos` (`title`, `description`, `youtube_id`, `video_source`, `video_url`, `duration`, `is_featured`, `created_by`)
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                        ");
                        $stmt->execute([$title, $description, $youtube_id, $video_source, $video_url, $duration, $is_featured, $user['id']]);
                        Auth::logAction($user['id'], 'TV_YT_CREATE', "Created video: '{$title}' (Source: {$video_source})");
                        $success = "Video added successfully!";
                    } else {
                        $yt_id = (int)$_POST['yt_id'];
                        $stmt = $db->prepare("
                            UPDATE `youtube_videos` 
                            SET `title` = ?, `description` = ?, `youtube_id` = ?, `video_source` = ?, `video_url` = ?, `duration` = ?, `is_featured` = ?
                            WHERE `id` = ?
                        ");
                        $stmt->execute([$title, $description, $youtube_id, $video_source, $video_url, $duration, $is_featured, $yt_id]);
                        Auth::logAction($user['id'], 'TV_YT_UPDATE', "Updated video: '{$title}' (Source: {$video_source})");
                        $success = "Video updated successfully!";
                    }
                    header("Location: tv.php?tab=youtube_videos&success=" . urlencode($success));
                    exit;
                }
            } else {
                $title = trim($_POST['title']);
                $description = trim($_POST['description']);
                $stream_url = trim($_POST['stream_url']);
                $scheduled_at = trim($_POST['scheduled_at']);
                $duration = (int)$_POST['duration'];
                $status = trim($_POST['status']);
                $stream_id = isset($_POST['stream_id']) ? (int)$_POST['stream_id'] : 0;

                if (empty($title) || empty($stream_url) || empty($scheduled_at)) {
                    $error = "Title, Stream URL, and Scheduled Date are required.";
                } else {
                    if ($stream_id > 0) {
                        $stmt = $db->prepare("
                            UPDATE `livestreams` 
                            SET `title` = ?, `description` = ?, `stream_url` = ?, `scheduled_at` = ?, `duration` = ?, `status` = ?
                            WHERE `id` = ?
                        ");
                        $stmt->execute([$title, $description, $stream_url, $scheduled_at, $duration, $status, $stream_id]);
                        Auth::logAction($user['id'], 'TV_STREAM_UPDATE', "Updated stream: '{$title}'");
                        $success = "Livestream program updated successfully!";
                    } else {
                        $stmt = $db->prepare("
                            INSERT INTO `livestreams` (`title`, `description`, `stream_url`, `scheduled_at`, `duration`, `status`, `created_by`)
                            VALUES (?, ?, ?, ?, ?, ?, ?)
                        ");
                        $stmt->execute([$title, $description, $stream_url, $scheduled_at, $duration, $status, $user['id']]);
                        Auth::logAction($user['id'], 'TV_STREAM_CREATE', "Created stream: '{$title}'");
                        $success = "Livestream program scheduled successfully!";
                    }
                    header("Location: tv.php?success=" . urlencode($success));
                    exit;
                }
            }
        }
    }

    // 2. Fetch edit request details for Livestreams
    if (isset($_GET['edit'])) {
        $edit_id = (int)$_GET['edit'];
        $stmt = $db->prepare("SELECT * FROM `livestreams` WHERE `id` = ? LIMIT 1");
        $stmt->execute([$edit_id]);
        $edit_stream = $stmt->fetch();
    }

    // 3. Handle Deletion for Livestreams
    if (isset($_GET['delete'])) {
        $delete_id = (int)$_GET['delete'];
        $stmt = $db->prepare("DELETE FROM `livestreams` WHERE `id` = ?");
        $stmt->execute([$delete_id]);
        Auth::logAction($user['id'], 'TV_STREAM_DELETE', "Deleted stream ID {$delete_id}");
        $success = "Livestream program deleted successfully!";
        header("Location: tv.php?success=" . urlencode($success));
        exit;
    }

    // 4. Handle Deletion for YouTube Videos
    if (isset($_GET['delete_yt'])) {
        $delete_yt_id = (int)$_GET['delete_yt'];
        $stmt = $db->prepare("DELETE FROM `youtube_videos` WHERE `id` = ?");
        $stmt->execute([$delete_yt_id]);
        Auth::logAction($user['id'], 'TV_YT_DELETE', "Deleted YouTube video ID {$delete_yt_id}");
        $success = "YouTube video deleted successfully!";
        header("Location: tv.php?tab=youtube_videos&success=" . urlencode($success));
        exit;
    }

    // 5. Fetch edit request details for YouTube Videos
    if (isset($_GET['edit_yt'])) {
        $edit_yt_id = (int)$_GET['edit_yt'];
        $stmt = $db->prepare("SELECT * FROM `youtube_videos` WHERE `id` = ? LIMIT 1");
        $stmt->execute([$edit_yt_id]);
        $edit_yt = $stmt->fetch();
    }

    // 5. Handle Restore: flip completed/cancelled back to scheduled
    if (isset($_GET['restore'])) {
        $restore_id = (int)$_GET['restore'];
        $stmt = $db->prepare("UPDATE `livestreams` SET `status` = 'scheduled', `scheduled_at` = DATE_ADD(NOW(), INTERVAL 1 DAY) WHERE `id` = ? AND `status` IN ('completed','cancelled')");
        $stmt->execute([$restore_id]);
        Auth::logAction($user['id'], 'TV_STREAM_RESTORE', "Restored stream ID {$restore_id} back to scheduled");
        $success = "Broadcast restored to scheduled. Please update the date/time via Edit.";
        header("Location: tv.php?success=" . urlencode($success));
        exit;
    }

    // Fetch livestreams — upcoming/live only
    $stmt = $db->query("SELECT l.*, u.name as creator_name FROM `livestreams` l JOIN `users` u ON l.created_by = u.id WHERE l.status IN ('scheduled','live') ORDER BY l.scheduled_at ASC");
    $streams = $stmt->fetchAll();

    // Fetch past broadcasts — completed/cancelled
    $stmt_past = $db->query("SELECT l.*, u.name as creator_name FROM `livestreams` l JOIN `users` u ON l.created_by = u.id WHERE l.status IN ('completed','cancelled') ORDER BY l.scheduled_at DESC");
    $past_streams = $stmt_past->fetchAll();

    // Fetch YouTube videos
    $stmt_yt = $db->query("SELECT y.*, u.name as creator_name FROM `youtube_videos` y JOIN `users` u ON y.created_by = u.id ORDER BY y.created_at DESC");
    $youtube_videos = $stmt_yt->fetchAll();

    $floating_tv_enabled = (int)($db->query("SELECT `setting_value` FROM `system_settings` WHERE `setting_key` = 'floating_tv_enabled' LIMIT 1")->fetchColumn() ?: 1);
    $floating_tv_title = $db->query("SELECT `setting_value` FROM `system_settings` WHERE `setting_key` = 'floating_tv_title' LIMIT 1")->fetchColumn();
    $floating_tv_description = $db->query("SELECT `setting_value` FROM `system_settings` WHERE `setting_key` = 'floating_tv_description' LIMIT 1")->fetchColumn();
    if (!$floating_tv_title) { $floating_tv_title = 'Smart Nation LIVE tv'; }
    if (!$floating_tv_description) { $floating_tv_description = 'Watch the featured Smart Nation LIVE tv playlist, including self-hosted and YouTube videos managed from the Super Admin TV dashboard.'; }

} catch (Exception $e) {
    $error = "TV DB Error: " . $e->getMessage();
}

if (isset($_GET['success'])) {
    $success = $_GET['success'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Scheduled TV Broadcasts & Episodes - PBAT Smart Nation</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        bushgreen: {
                            DEFAULT: '#063C1E',
                            light: '#0A4D27',
                            dark: '#03200F',
                        },
                        gold: '#D4AF37'
                    }
                }
            }
        }
    </script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
    <style>
        body { font-family: 'Inter', sans-serif; }
        h1, h2, h3, h4, .font-display { font-family: 'Outfit', sans-serif; }
    </style>
</head>
<?php 
$active_tab = (isset($_GET['tab']) && $_GET['tab'] === 'youtube_videos') || isset($_GET['edit_yt']) ? 'youtube_videos' : 'livestreams';
?>
<body class="bg-slate-50 text-slate-800 transition-colors duration-200 min-h-screen flex flex-col antialiased"
      x-data="{ 
          darkMode: localStorage.getItem('darkMode') === 'true',
          activeTab: '<?php echo $active_tab; ?>'
      }"
      x-init="$watch('darkMode', val => localStorage.setItem('darkMode', val))"
      :class="{ 'dark bg-slate-900 text-slate-100': darkMode }">

    <!-- Header Navbar -->
    <header class="bg-bushgreen text-white border-b-2 border-gold h-20 flex items-center justify-between px-6 shadow-md relative z-30">
        <div class="flex items-center gap-3">
            <a href="dashboard.php" class="py-1.5 px-3 border border-white/20 hover:bg-white/10 text-white rounded-lg text-xs font-bold transition">
                &larr; Back to Dashboard
            </a>
            <div class="w-8 h-8 rounded bg-white/10 flex items-center justify-center border border-white/20 p-1 flex-shrink-0">
                <?php echo getAppLogoHtml('w-full h-full object-contain', 'dashboard'); ?>
            </div>
            <span class="text-white font-extrabold text-sm font-display hidden sm:inline">PBAT SMART NATION INITIATIVE</span>
        </div>
        <div class="flex items-center gap-4 text-xs font-bold text-gold uppercase tracking-wider">
            <!-- Dark Mode Toggle -->
            <button @click="darkMode = !darkMode" class="p-2 rounded-lg border border-gold/45 text-gold hover:bg-gold/10 transition flex items-center justify-center">
                <svg x-show="darkMode" class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364-6.364l-.707.707M6.364 17.636l-.707.707M18.364 17.636l-.707-.707M6.364 6.364l-.707-.707M15 12a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                <svg x-show="!darkMode" class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z"/></svg>
            </button>
            <span>Scheduled TV Broadcasts & Episodes</span>
        </div>
    </header>

    <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 flex-grow w-full space-y-10">
        
        <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div class="space-y-1">
                <h1 class="text-2xl sm:text-3xl font-black text-bushgreen dark:text-gold font-display">Scheduled TV Broadcasts & Episodes</h1>
                <p class="text-slate-500 dark:text-slate-400 text-xs font-light">Create and manage scheduled broadcasts, footer TV videos, and on-demand episodes from one Super Admin dashboard.</p>
            </div>

            <?php if (!empty($success)): ?>
                <div class="px-4 py-2 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs font-semibold">
                    <?php echo htmlspecialchars($success); ?>
                </div>
            <?php endif; ?>

            <?php if (!empty($error)): ?>
                <div class="px-4 py-2 bg-red-50 border border-red-200 text-red-800 rounded-xl text-xs font-semibold">
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>
        </div>

        <!-- Tab Navigation -->
        <div class="flex border-b border-slate-200 dark:border-slate-700">
            <button @click="activeTab = 'livestreams'"
                    :class="activeTab === 'livestreams' ? 'border-gold text-bushgreen dark:text-gold border-b-2 font-bold' : 'border-transparent text-slate-400 hover:text-slate-600 dark:hover:text-slate-200'"
                    class="py-3 px-6 text-xs sm:text-sm uppercase tracking-wider font-semibold transition focus:outline-none">
                Livestream Scheduler
            </button>
            <button @click="activeTab = 'youtube_videos'"
                    :class="activeTab === 'youtube_videos' ? 'border-gold text-bushgreen dark:text-gold border-b-2 font-bold' : 'border-transparent text-slate-400 hover:text-slate-600 dark:hover:text-slate-200'"
                    class="py-3 px-6 text-xs sm:text-sm uppercase tracking-wider font-semibold transition focus:outline-none">
                On-Demand YouTube CMS
            </button>
            <button @click="activeTab = 'past_broadcasts'"
                    :class="activeTab === 'past_broadcasts' ? 'border-gold text-bushgreen dark:text-gold border-b-2 font-bold' : 'border-transparent text-slate-400 hover:text-slate-600 dark:hover:text-slate-200'"
                    class="py-3 px-6 text-xs sm:text-sm uppercase tracking-wider font-semibold transition focus:outline-none">
                Past Broadcasts
                <?php if (!empty($past_streams)): ?>
                <span class="ml-1.5 px-1.5 py-0.5 bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300 text-[9px] font-bold rounded-full"><?php echo count($past_streams); ?></span>
                <?php endif; ?>
            </button>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            
            <!-- Tab 1: Scheduled TV Broadcasts List (Col 7) -->
            <div x-show="activeTab === 'livestreams'" class="lg:col-span-7 bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
                <h3 class="text-slate-800 dark:text-slate-200 font-bold text-sm">Scheduled TV Broadcasts & Episodes</h3>
                
                <div class="space-y-4">
                    <?php if (empty($streams)): ?>
                        <div class="text-slate-400 italic text-xs py-10 text-center">No broadcasts scheduled yet.</div>
                    <?php endif; ?>
                    <?php foreach ($streams as $st): 
                        $time_ms = strtotime($st['scheduled_at']) * 1000;
                    ?>
                        <div class="p-4 rounded-xl border border-slate-100 dark:border-slate-700 hover:border-gold/30 transition flex flex-col gap-3"
                             x-data="{ 
                                 targetTime: <?php echo $time_ms; ?>,
                                 days: 0, hours: 0, minutes: 0, seconds: 0,
                                 timerFinished: false,
                                 updateTimer() {
                                     const now = new Date().getTime();
                                     const diff = this.targetTime - now;
                                     if (diff <= 0) {
                                         this.timerFinished = true;
                                         return;
                                     }
                                     this.days = Math.floor(diff / (1000 * 60 * 60 * 24));
                                     this.hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                                     this.minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
                                     this.seconds = Math.floor((diff % (1000 * 60)) / 1000);
                                 }
                             }"
                             x-init="updateTimer(); setInterval(() => updateTimer(), 1000)">
                            
                            <div class="flex justify-between items-start">
                                <div>
                                    <h4 class="font-bold text-slate-800 dark:text-slate-200 text-sm"><?php echo htmlspecialchars($st['title']); ?></h4>
                                    <span class="text-[10px] text-slate-400">Scheduled: <?php echo date('Y-m-d H:i', strtotime($st['scheduled_at'])); ?> &bull; Duration: <?php echo $st['duration']; ?> mins</span>
                                </div>
                                <span class="px-2.5 py-0.5 rounded text-[8px] font-bold uppercase tracking-wide
                                    <?php echo $st['status'] === 'live' ? 'bg-red-500 text-white animate-pulse' : ($st['status'] === 'completed' ? 'bg-blue-50 text-blue-700 border border-blue-100' : 'bg-slate-100 text-slate-600 border border-slate-200'); ?>">
                                    <?php echo htmlspecialchars($st['status']); ?>
                                </span>
                            </div>

                            <p class="text-slate-500 dark:text-slate-400 text-xs font-light leading-relaxed"><?php echo htmlspecialchars($st['description']); ?></p>

                            <!-- COUNTDOWN CLOCK WIDGET -->
                            <div x-show="!timerFinished" class="bg-slate-50 dark:bg-slate-900/50 p-2.5 rounded-xl border border-slate-100 dark:border-slate-800 flex justify-around text-center max-w-xs">
                                <div>
                                    <div class="text-sm font-bold text-bushgreen dark:text-gold" x-text="days">0</div>
                                    <div class="text-[8px] uppercase font-semibold text-slate-400">Days</div>
                                </div>
                                <div>
                                    <div class="text-sm font-bold text-bushgreen dark:text-gold" x-text="hours">0</div>
                                    <div class="text-[8px] uppercase font-semibold text-slate-400">Hrs</div>
                                </div>
                                <div>
                                    <div class="text-sm font-bold text-bushgreen dark:text-gold" x-text="minutes">0</div>
                                    <div class="text-[8px] uppercase font-semibold text-slate-400">Mins</div>
                                </div>
                                <div>
                                    <div class="text-sm font-bold text-bushgreen dark:text-gold" x-text="seconds">0</div>
                                    <div class="text-[8px] uppercase font-semibold text-slate-400">Secs</div>
                                </div>
                            </div>
                            <div x-show="timerFinished" class="text-red-500 font-bold text-xs uppercase tracking-wider animate-pulse flex items-center gap-1.5">
                                <span class="w-2.5 h-2.5 bg-red-500 rounded-full"></span>
                                Broadcast is LIVE / Ready to view
                            </div>

                            <!-- Embedded video block preview if URL exists -->
                            <?php if (!empty($st['stream_url'])): ?>
                                <div class="text-[10px] text-slate-400">
                                    Link: <code class="bg-slate-100 dark:bg-slate-900 p-1 rounded text-bushgreen dark:text-gold font-mono select-all"><?php echo htmlspecialchars($st['stream_url']); ?></code>
                                </div>
                            <?php endif; ?>

                            <div class="flex justify-end gap-2 pt-2 border-t border-slate-50 dark:border-slate-700">
                                <a href="tv.php?edit=<?php echo $st['id']; ?>" class="py-1 px-3 border border-slate-200 dark:border-slate-700 hover:border-gold hover:text-gold text-[10px] font-bold rounded transition">
                                    Edit
                                </a>
                                <a href="tv.php?delete=<?php echo $st['id']; ?>" onclick="return confirm('Are you sure you want to remove this livestream broadcast?');"
                                   class="py-1 px-3 bg-red-50 hover:bg-red-100 text-red-600 text-[10px] font-bold rounded transition">
                                    Delete
                                </a>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Tab 1 Form: Schedule Livestream (Col 5) -->
            <div x-show="activeTab === 'livestreams'" class="lg:col-span-5 bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
                <div class="pb-3 border-b border-slate-100 dark:border-slate-700">
                    <h3 class="text-slate-800 dark:text-slate-200 font-bold text-sm"><?php echo $edit_stream ? 'Edit Broadcast Settings' : 'Schedule Livestream'; ?></h3>
                    <p class="text-[10px] text-slate-400">Fill in broadcast parameters to update the live countdown clock.</p>
                </div>

                <form method="POST" action="" class="space-y-4">
                    <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                    <input type="hidden" name="action" value="<?php echo $edit_stream ? 'edit_stream' : 'create_stream'; ?>">
                    <?php if ($edit_stream): ?>
                        <input type="hidden" name="stream_id" value="<?php echo $edit_stream['id']; ?>">
                    <?php endif; ?>

                    <div>
                        <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1.5" for="title">Broadcast Title *</label>
                        <input type="text" name="title" id="title" required value="<?php echo $edit_stream ? htmlspecialchars($edit_stream['title']) : ''; ?>" placeholder="e.g. Smart Nation Weekly Review"
                               class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                    </div>

                    <div>
                        <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1.5" for="stream_url">Stream URL / YouTube Embed URL *</label>
                        <input type="url" name="stream_url" id="stream_url" required value="<?php echo $edit_stream ? htmlspecialchars($edit_stream['stream_url']) : ''; ?>" placeholder="e.g. https://www.youtube.com/embed/..."
                               class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-mono">
                    </div>

                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1.5" for="scheduled_at">Scheduled Date *</label>
                            <input type="datetime-local" name="scheduled_at" id="scheduled_at" required value="<?php echo $edit_stream ? date('Y-m-d\TH:i', strtotime($edit_stream['scheduled_at'])) : ''; ?>"
                                   class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                        </div>
                        <div>
                            <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1.5" for="duration">Duration (Minutes)</label>
                            <input type="number" name="duration" id="duration" value="<?php echo $edit_stream ? (int)$edit_stream['duration'] : 60; ?>"
                                   class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-mono">
                        </div>
                    </div>

                    <div>
                        <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1.5" for="status">Status</label>
                        <select name="status" id="status"
                                class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                            <option value="scheduled" <?php echo ($edit_stream && $edit_stream['status'] === 'scheduled') ? 'selected' : ''; ?>>Scheduled</option>
                            <option value="live" <?php echo ($edit_stream && $edit_stream['status'] === 'live') ? 'selected' : ''; ?>>Live (Ongoing)</option>
                            <option value="completed" <?php echo ($edit_stream && $edit_stream['status'] === 'completed') ? 'selected' : ''; ?>>Completed</option>
                            <option value="cancelled" <?php echo ($edit_stream && $edit_stream['status'] === 'cancelled') ? 'selected' : ''; ?>>Cancelled</option>
                        </select>
                    </div>

                    <div>
                        <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1.5" for="description">Stream Description</label>
                        <textarea name="description" id="description" rows="4" placeholder="Brief outline of agenda, guest lists, and national keypoints..."
                                  class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-light"><?php echo $edit_stream ? htmlspecialchars($edit_stream['description']) : ''; ?></textarea>
                    </div>

                    <div class="pt-2 flex gap-3">
                        <button type="submit" class="flex-grow py-2.5 bg-bushgreen hover:bg-bushgreen-light text-white text-xs font-bold rounded-lg transition shadow-md shadow-bushgreen/10">
                            <?php echo $edit_stream ? 'Update Broadcast' : 'Publish Livestream'; ?>
                        </button>
                        <?php if ($edit_stream): ?>
                            <a href="tv.php" class="py-2.5 px-4 border border-slate-200 hover:bg-slate-50 text-slate-600 text-xs font-bold rounded-lg transition">Cancel</a>
                        <?php endif; ?>
                    </div>
                </form>
            </div>

            <!-- Tab 2: On-Demand YouTube Videos Catalog (Col 7) -->
            <div x-show="activeTab === 'youtube_videos'" class="lg:col-span-7 bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
                <h3 class="text-slate-800 dark:text-slate-200 font-bold text-sm">On-Demand YouTube Videos Catalog</h3>
                
                <div class="space-y-4">
                    <?php if (empty($youtube_videos)): ?>
                        <div class="text-slate-400 italic text-xs py-10 text-center">No YouTube videos added yet.</div>
                    <?php endif; ?>
                    <?php foreach ($youtube_videos as $yt): ?>
                        <div class="p-4 rounded-xl border border-slate-100 dark:border-slate-700 hover:border-gold/30 transition flex flex-col gap-3">
                            <div class="flex justify-between items-start">
                                <div>
                                    <div class="flex items-center gap-2">
                                        <h4 class="font-bold text-slate-800 dark:text-slate-200 text-sm"><?php echo htmlspecialchars($yt['title']); ?></h4>
                                        <?php if ($yt['is_featured'] == 1): ?>
                                            <span class="px-2 py-0.5 bg-gold text-bushgreen text-[8px] font-bold uppercase rounded-md tracking-wider">Featured</span>
                                        <?php endif; ?>
                                    </div>
                                    <span class="text-[10px] text-slate-400">Duration: <?php echo htmlspecialchars($yt['duration'] ?? 'N/A'); ?> &bull; Added by: <?php echo htmlspecialchars($yt['creator_name'] ?? 'Admin'); ?></span>
                                </div>
                                <span class="font-mono text-[9px] bg-slate-100 dark:bg-slate-900 px-2 py-1 rounded text-slate-500">ID: <?php echo htmlspecialchars($yt['youtube_id']); ?></span>
                            </div>

                            <?php if (!empty($yt['description'])): ?>
                                <p class="text-slate-500 dark:text-slate-400 text-xs font-light leading-relaxed"><?php echo htmlspecialchars($yt['description']); ?></p>
                            <?php endif; ?>

                            <!-- Small embedded preview -->
                            <div class="aspect-video w-full max-w-sm rounded-xl overflow-hidden border border-slate-100 dark:border-slate-800 bg-slate-950 relative">
                                <?php if (($yt['video_source'] ?? 'youtube') === 'youtube'): ?>
                                    <iframe class="w-full h-full" src="https://www.youtube.com/embed/<?php echo htmlspecialchars($yt['youtube_id'] ?? ''); ?>" frameborder="0" allowfullscreen></iframe>
                                <?php elseif (($yt['video_source'] ?? 'youtube') === 'google_drive'): ?>
                                    <iframe class="w-full h-full" src="<?php echo htmlspecialchars($yt['video_url'] ?? ''); ?>" frameborder="0" allow="autoplay" allowfullscreen></iframe>
                                <?php else: ?>
                                    <?php 
                                    $url = $yt['video_url'] ?? '';
                                    if (!preg_match('/^https?:\/\//i', $url)) {
                                        $url = '../' . $url;
                                    }
                                    ?>
                                    <video class="w-full h-full" controls preload="metadata">
                                        <source src="<?php echo htmlspecialchars($url); ?>" type="video/mp4">
                                        Your browser does not support the video tag.
                                    </video>
                                <?php endif; ?>
                            </div>

                            <div class="flex justify-end gap-2 pt-2 border-t border-slate-50 dark:border-slate-700">
                                <a href="tv.php?edit_yt=<?php echo $yt['id']; ?>" class="py-1 px-3 border border-slate-200 dark:border-slate-700 hover:border-gold hover:text-gold text-[10px] font-bold rounded transition">
                                    Edit
                                </a>
                                <a href="tv.php?delete_yt=<?php echo $yt['id']; ?>" onclick="return confirm('Are you sure you want to remove this video?');"
                                   class="py-1 px-3 bg-red-50 hover:bg-red-100 text-red-600 text-[10px] font-bold rounded transition">
                                    Delete
                                </a>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Tab 2 Form: Add/Edit YouTube Video (Col 5) -->
            <div x-show="activeTab === 'youtube_videos'" class="lg:col-span-5 bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
                <div class="pb-3 border-b border-slate-100 dark:border-slate-700">
                    <h3 class="text-slate-800 dark:text-slate-200 font-bold text-sm">Floating TV Controls</h3>
                    <p class="text-[10px] text-slate-400">Toggle and customize the footer floating TV widget from this Super Admin page.</p>
                </div>
                <form method="POST" action="" class="space-y-4">
                    <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                    <input type="hidden" name="action" value="save_floating_tv">
                    <div class="flex items-center gap-2 py-2">
                        <input type="checkbox" name="floating_tv_enabled" id="floating_tv_enabled" value="1" <?php echo $floating_tv_enabled ? 'checked' : ''; ?> class="w-4 h-4 text-bushgreen focus:ring-bushgreen border-slate-300 rounded">
                        <label for="floating_tv_enabled" class="text-slate-700 dark:text-slate-400 text-xs font-semibold">Show the floating Smart Nation LIVE tv panel</label>
                    </div>
                    <div>
                        <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1.5" for="floating_tv_title">Panel Title</label>
                        <input type="text" name="floating_tv_title" id="floating_tv_title" value="<?php echo htmlspecialchars($floating_tv_title); ?>" class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                    </div>
                    <div>
                        <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1.5" for="floating_tv_description">Panel Description</label>
                        <textarea name="floating_tv_description" id="floating_tv_description" rows="3" class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-light"><?php echo htmlspecialchars($floating_tv_description); ?></textarea>
                    </div>
                    <button type="submit" class="w-full py-2.5 bg-bushgreen hover:bg-bushgreen-light text-white text-xs font-bold rounded-lg transition shadow-md shadow-bushgreen/10">Save Floating TV Settings</button>
                </form>
                <div class="pt-3 border-t border-slate-100 dark:border-slate-700 text-[10px] text-slate-400">This panel uses the featured video from the TV catalog, so update the video list above to change what plays inside it.</div>
            </div>

            <div x-show="activeTab === 'youtube_videos'" class="lg:col-span-5 bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6"
                 x-data="{ videoSource: '<?php echo $edit_yt ? htmlspecialchars($edit_yt['video_source'] ?? 'youtube') : 'youtube'; ?>' }">
                <div class="pb-3 border-b border-slate-100 dark:border-slate-700">
                    <h3 class="text-slate-800 dark:text-slate-200 font-bold text-sm"><?php echo $edit_yt ? 'Edit Video' : 'Add Video'; ?></h3>
                    <p class="text-[10px] text-slate-400">Select video source and parameters to update the Media Center playback playlists.</p>
                </div>

                <form method="POST" action="" enctype="multipart/form-data" class="space-y-4">
                    <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                    <input type="hidden" name="action" value="<?php echo $edit_yt ? 'edit_yt' : 'create_yt'; ?>">
                    <?php if ($edit_yt): ?>
                        <input type="hidden" name="yt_id" value="<?php echo $edit_yt['id']; ?>">
                        <input type="hidden" name="existing_video_url" value="<?php echo htmlspecialchars($edit_yt['video_url'] ?? ''); ?>">
                    <?php endif; ?>

                    <div>
                        <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1.5" for="yt_title">Video Title *</label>
                        <input type="text" name="title" id="yt_title" required value="<?php echo $edit_yt ? htmlspecialchars($edit_yt['title']) : ''; ?>" placeholder="e.g. AI & Agriculture Masterclass"
                               class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                    </div>

                    <div>
                        <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1.5" for="video_source">Video Source *</label>
                        <select name="video_source" id="video_source" required x-model="videoSource"
                                class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                            <option value="youtube">YouTube Video</option>
                            <option value="google_drive">Google Drive Video</option>
                            <option value="self_hosted">Self-hosted Video File (Local/S3)</option>
                            <option value="s3">Direct Amazon S3 Link</option>
                        </select>
                    </div>

                    <!-- YouTube Source Fields -->
                    <div x-show="videoSource === 'youtube'">
                        <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1.5" for="youtube_id">YouTube Video ID *</label>
                        <input type="text" name="youtube_id" id="youtube_id" :required="videoSource === 'youtube'" value="<?php echo $edit_yt ? htmlspecialchars($edit_yt['youtube_id'] ?? '') : ''; ?>" placeholder="e.g. dQw4w9WgXcQ"
                               class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-mono">
                    </div>

                    <!-- Google Drive Source Fields -->
                    <div x-show="videoSource === 'google_drive'">
                        <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1.5" for="google_drive_url">Google Drive Preview / Embed URL *</label>
                        <input type="url" name="video_url" id="google_drive_url" :required="videoSource === 'google_drive'" value="<?php echo ($edit_yt && $edit_yt['video_source'] === 'google_drive') ? htmlspecialchars($edit_yt['video_url']) : ''; ?>" placeholder="e.g. https://drive.google.com/file/d/XXX/preview"
                               class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-mono">
                    </div>

                    <!-- S3 Source Fields -->
                    <div x-show="videoSource === 's3'">
                        <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1.5" for="s3_url">Direct S3 Video URL *</label>
                        <input type="url" name="video_url" id="s3_url" :required="videoSource === 's3'" value="<?php echo ($edit_yt && $edit_yt['video_source'] === 's3') ? htmlspecialchars($edit_yt['video_url']) : ''; ?>" placeholder="e.g. https://mybucket.s3.amazonaws.com/video.mp4"
                               class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-mono">
                    </div>

                    <!-- Self-hosted Source Fields -->
                    <div x-show="videoSource === 'self_hosted'">
                        <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1.5" for="video_file">Upload Video File (.mp4) *</label>
                        <input type="file" name="video_file" id="video_file" accept="video/mp4" :required="videoSource === 'self_hosted' && '<?php echo $edit_yt ? 'yes' : 'no'; ?>' === 'no'"
                               class="w-full text-xs text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-semibold file:bg-bushgreen/10 file:text-bushgreen hover:file:bg-bushgreen/20">
                        <?php if ($edit_yt && $edit_yt['video_source'] === 'self_hosted'): ?>
                            <span class="text-[10px] text-slate-450 mt-1 block">Current file: <code class="break-all"><?php echo htmlspecialchars($edit_yt['video_url']); ?></code></span>
                        <?php endif; ?>
                    </div>

                    <div>
                        <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1.5" for="yt_duration">Duration (e.g., 15:30 or 45 mins)</label>
                        <input type="text" name="duration" id="yt_duration" value="<?php echo $edit_yt ? htmlspecialchars($edit_yt['duration']) : ''; ?>" placeholder="e.g. 45 mins"
                               class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-mono">
                    </div>

                    <div class="flex items-center gap-2 py-2">
                        <input type="checkbox" name="is_featured" id="is_featured" value="1" <?php echo ($edit_yt && $edit_yt['is_featured'] == 1) ? 'checked' : ''; ?>
                               class="w-4 h-4 text-bushgreen focus:ring-bushgreen border-slate-300 rounded">
                        <label for="is_featured" class="text-slate-700 dark:text-slate-400 text-xs font-semibold">Mark as featured (set as main player video)</label>
                    </div>

                    <div>
                        <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1.5" for="yt_description">Video Description</label>
                        <textarea name="description" id="yt_description" rows="4" placeholder="Outlines training topics covered, skills taught, and resources mentioned..."
                                  class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-light"><?php echo $edit_yt ? htmlspecialchars($edit_yt['description']) : ''; ?></textarea>
                    </div>

                    <div class="pt-2 flex gap-3">
                        <button type="submit" class="flex-grow py-2.5 bg-bushgreen hover:bg-bushgreen-light text-white text-xs font-bold rounded-lg transition shadow-md shadow-bushgreen/10">
                            <?php echo $edit_yt ? 'Update Video' : 'Add Video'; ?>
                        </button>
                        <?php if ($edit_yt): ?>
                            <a href="tv.php?tab=youtube_videos" class="py-2.5 px-4 border border-slate-200 hover:bg-slate-50 text-slate-600 text-xs font-bold rounded-lg transition">Cancel</a>
                        <?php endif; ?>
                    </div>
                </form>
            </div>

        <!-- Tab 3: Past Broadcasts Archive (full width) -->
        <div x-show="activeTab === 'past_broadcasts'" class="lg:col-span-12 bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
            <div class="flex justify-between items-center">
                <div>
                    <h3 class="text-slate-800 dark:text-slate-200 font-bold text-sm">Past Broadcasts Archive</h3>
                    <p class="text-[10px] text-slate-400 mt-0.5">All completed and cancelled livestream programs. Restore any entry to re-schedule it.</p>
                </div>
                <span class="text-[10px] font-bold text-slate-400 uppercase tracking-widest"><?php echo count($past_streams); ?> record<?php echo count($past_streams) !== 1 ? 's' : ''; ?></span>
            </div>

            <?php if (empty($past_streams)): ?>
                <div class="text-center py-12 text-slate-400 italic text-xs">No past broadcasts found. Completed or cancelled streams will appear here.</div>
            <?php else: ?>
            <div class="overflow-x-auto">
                <table class="w-full text-xs text-left text-slate-600 dark:text-slate-300">
                    <thead class="text-[10px] text-slate-400 uppercase tracking-wider border-b border-slate-100 dark:border-slate-700">
                        <tr>
                            <th class="pb-3 pr-4">Broadcast Title</th>
                            <th class="pb-3 pr-4">Scheduled Date</th>
                            <th class="pb-3 pr-4">Duration</th>
                            <th class="pb-3 pr-4">Status</th>
                            <th class="pb-3 pr-4">Host</th>
                            <th class="pb-3 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-50 dark:divide-slate-700">
                        <?php foreach ($past_streams as $ps): ?>
                        <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-700/30 transition">
                            <td class="py-3 pr-4">
                                <div class="font-semibold text-slate-800 dark:text-slate-200 leading-snug"><?php echo htmlspecialchars($ps['title']); ?></div>
                                <?php if (!empty($ps['description'])): ?>
                                <div class="text-[10px] text-slate-400 mt-0.5 line-clamp-1"><?php echo htmlspecialchars($ps['description']); ?></div>
                                <?php endif; ?>
                            </td>
                            <td class="py-3 pr-4 font-mono text-[10px] whitespace-nowrap"><?php echo date('d M Y @ H:i', strtotime($ps['scheduled_at'])); ?></td>
                            <td class="py-3 pr-4 font-mono text-[10px]"><?php echo (int)$ps['duration']; ?> min</td>
                            <td class="py-3 pr-4">
                                <span class="px-2 py-0.5 rounded text-[8px] font-bold uppercase tracking-wide <?php echo $ps['status'] === 'completed' ? 'bg-blue-50 text-blue-700 border border-blue-100' : 'bg-slate-100 text-slate-500 border border-slate-200'; ?>">
                                    <?php echo htmlspecialchars($ps['status']); ?>
                                </span>
                            </td>
                            <td class="py-3 pr-4 text-[10px] text-slate-500"><?php echo htmlspecialchars($ps['creator_name']); ?></td>
                            <td class="py-3 text-right">
                                <div class="flex items-center justify-end gap-2">
                                    <a href="tv.php?restore=<?php echo $ps['id']; ?>" onclick="return confirm('Restore this broadcast to Scheduled status?');"
                                       class="py-1 px-3 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 text-[10px] font-bold rounded transition">
                                        Restore
                                    </a>
                                    <a href="tv.php?edit=<?php echo $ps['id']; ?>" class="py-1 px-3 border border-slate-200 dark:border-slate-600 hover:border-gold hover:text-gold text-[10px] font-bold rounded transition">
                                        Edit
                                    </a>
                                    <a href="tv.php?delete=<?php echo $ps['id']; ?>" onclick="return confirm('Permanently delete this broadcast record?');"
                                       class="py-1 px-3 bg-red-50 hover:bg-red-100 text-red-600 text-[10px] font-bold rounded transition">
                                        Delete
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php endif; ?>
        </div>

    </div>

    </main>
</body>
</html>
