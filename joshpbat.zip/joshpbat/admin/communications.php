<?php
/**
 * PBAT Smart Nation Initiative - Communications & Discussion Board
 * Provides discussion boards filtered by Geopolitical Zone or State, plus message logs.
 */
require_once dirname(__DIR__) . '/helpers/auth.php';
require_once dirname(__DIR__) . '/helpers/common.php';
require_once dirname(__DIR__) . '/config/database.php';

Auth::requireRole(['super_admin', 'founder_circle', 'national_steering', 'zonal_chairman', 'state_chairman', 'coordinator'], '../login.php');

$user = Auth::user();
$error = '';
$success = '';
$active_channel = trim($_GET['channel'] ?? 'general');

try {
    $db = Database::connect();

    // Handle posting message
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'post_message') {
        if (!Auth::validateCsrf($_POST['csrf_token'] ?? '')) {
            $error = "CSRF protection verification failed.";
        } else {
            $body = trim($_POST['body']);
            $channel = trim($_POST['channel']);

            if (empty($body)) {
                $error = "Message content cannot be blank.";
            } else {
                $stmt = $db->prepare("INSERT INTO `messages` (`sender_id`, `recipient_id`, `channel`, `body`) VALUES (?, NULL, ?, ?)");
                $stmt->execute([$user['id'], $channel, $body]);
                
                Auth::logAction($user['id'], 'MESSAGE_POST', "Posted to discussion board: #{$channel}");
                $success = "Message posted successfully!";
                header("Location: communications.php?channel=" . urlencode($channel) . "&success=" . urlencode($success));
                exit;
            }
        }
    }

    // Fetch messages in the active channel
    $stmt = $db->prepare("
        SELECT m.*, u.name as author_name, u.avatar as author_avatar, r.display_name as role_name 
        FROM `messages` m 
        JOIN `users` u ON m.sender_id = u.id
        JOIN `roles` r ON u.role_id = r.id
        WHERE m.channel = ? 
        ORDER BY m.created_at DESC 
        LIMIT 30
    ");
    $stmt->execute([$active_channel]);
    $messages = $stmt->fetchAll();

} catch (Exception $e) {
    $error = "Communications DB Error: " . $e->getMessage();
}

if (isset($_GET['success'])) {
    $success = $_GET['success'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Communications Hub - PBAT Smart Nation</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        bushgreen: {
                            DEFAULT: '#063C1E',
                            light: '#0A4D27',
                            dark: '#03200F',
                        },
                        gold: '#D4AF37'
                    }
                }
            }
        }
    </script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        [x-cloak] { display: none !important; }
        body { font-family: 'Inter', sans-serif; }
        h1, h2, h3, h4, .font-display { font-family: 'Outfit', sans-serif; }
    </style>
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
</head>
<body class="bg-slate-50 text-slate-800 transition-colors duration-200 min-h-screen flex flex-col antialiased"
      x-data="{ darkMode: localStorage.getItem('darkMode') === 'true' }"
      x-init="$watch('darkMode', val => localStorage.setItem('darkMode', val))"
      :class="{ 'dark bg-slate-900 text-slate-100': darkMode }">

    <!-- Header Navbar -->
    <header class="bg-bushgreen text-white border-b-2 border-gold h-20 flex items-center justify-between px-6 shadow-md relative z-30">
        <div class="flex items-center gap-3">
            <a href="dashboard.php" class="py-1.5 px-3 border border-white/20 hover:bg-white/10 text-white rounded-lg text-xs font-bold transition">
                &larr; Back to Dashboard
            </a>
            <div class="w-8 h-8 rounded bg-white/10 flex items-center justify-center border border-white/20 p-1 flex-shrink-0">
                <?php echo getAppLogoHtml('w-full h-full object-contain', 'dashboard'); ?>
            </div>
            <span class="text-white font-extrabold text-sm font-display hidden sm:inline">PBAT SMART NATION INITIATIVE</span>
        </div>
        <div class="flex items-center gap-4 text-xs font-bold text-gold uppercase tracking-wider">
            <!-- Dark Mode Toggle -->
            <button @click="darkMode = !darkMode" class="p-2 rounded-lg border border-gold/45 text-gold hover:bg-gold/10 transition flex items-center justify-center">
                <svg x-show="darkMode" class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364-6.364l-.707.707M6.364 17.636l-.707.707M18.364 17.636l-.707-.707M6.364 6.364l-.707-.707M15 12a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                <svg x-show="!darkMode" class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z"/></svg>
            </button>
            <span>Communications Hub</span>
        </div>
    </header>

    <main class="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-10 flex-grow w-full space-y-10">
        
        <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div class="space-y-1">
                <h1 class="text-2xl sm:text-3xl font-black text-bushgreen dark:text-gold font-display">Discussion Channels</h1>
                <p class="text-slate-500 dark:text-slate-400 text-xs font-light">Internal messaging, leadership broadcasts, and localized state and zonal channels.</p>
            </div>

            <?php if (!empty($success)): ?>
                <div class="px-4 py-2 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs font-semibold">
                    <?php echo htmlspecialchars($success); ?>
                </div>
            <?php endif; ?>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            
            <!-- CHANNELS LIST COLUMN (Col 4) -->
            <div class="lg:col-span-4 bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-4">
                <h3 class="text-slate-800 dark:text-slate-200 font-bold text-sm">Select Active Channel</h3>
                
                <div class="flex flex-col gap-2">
                    <a href="communications.php?channel=general" class="p-3 rounded-xl border flex items-center justify-between text-xs font-bold transition
                       <?php echo $active_channel === 'general' ? 'border-gold bg-bushgreen text-white dark:text-gold' : 'border-slate-100 hover:bg-slate-50 text-slate-700 dark:text-slate-300'; ?>">
                        <span># General Discussion</span>
                    </a>
                    <a href="communications.php?channel=southwest" class="p-3 rounded-xl border flex items-center justify-between text-xs font-bold transition
                       <?php echo $active_channel === 'southwest' ? 'border-gold bg-bushgreen text-white dark:text-gold' : 'border-slate-100 hover:bg-slate-50 text-slate-700 dark:text-slate-300'; ?>">
                        <span># Southwest Zone Council</span>
                    </a>
                    <a href="communications.php?channel=lagos" class="p-3 rounded-xl border flex items-center justify-between text-xs font-bold transition
                       <?php echo $active_channel === 'lagos' ? 'border-gold bg-bushgreen text-white dark:text-gold' : 'border-slate-100 hover:bg-slate-50 text-slate-700 dark:text-slate-300'; ?>">
                        <span># Lagos State Chapter</span>
                    </a>
                    <a href="communications.php?channel=lga_coordinators" class="p-3 rounded-xl border flex items-center justify-between text-xs font-bold transition
                       <?php echo $active_channel === 'lga_coordinators' ? 'border-gold bg-bushgreen text-white dark:text-gold' : 'border-slate-100 hover:bg-slate-50 text-slate-700 dark:text-slate-300'; ?>">
                        <span># LGA Coordinators Hub</span>
                    </a>
                </div>
            </div>

            <!-- CHAT BOARD COLUMN (Col 8) -->
            <div class="lg:col-span-8 bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
                
                <!-- Post Message Box -->
                <form method="POST" action="" class="space-y-3">
                    <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                    <input type="hidden" name="action" value="post_message">
                    <input type="hidden" name="channel" value="<?php echo htmlspecialchars($active_channel); ?>">

                    <div class="flex gap-3">
                        <img src="<?php echo htmlspecialchars(getUserAvatarUrl($user['avatar'] ?? '')); ?>" class="w-8 h-8 rounded-full object-cover">
                        <textarea name="body" required rows="2" placeholder="Post a circular message in #<?php echo htmlspecialchars($active_channel); ?>..."
                                  class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs focus:outline-none focus:border-bushgreen font-light"></textarea>
                    </div>
                    <div class="flex justify-end">
                        <button type="submit" class="py-2 px-5 bg-bushgreen hover:bg-bushgreen-light text-white text-xs font-bold rounded-lg transition shadow-md">
                            Post Announcement
                        </button>
                    </div>
                </form>

                <div class="h-0.5 bg-slate-100 dark:bg-slate-700 w-full"></div>

                <!-- Messages Feed -->
                <div class="space-y-4 max-h-[400px] overflow-y-auto pr-2">
                    <?php if (empty($messages)): ?>
                        <div class="text-slate-400 dark:text-slate-500 italic text-xs py-10 text-center">No announcements posted in #<?php echo htmlspecialchars($active_channel); ?>.</div>
                    <?php endif; ?>
                    <?php foreach ($messages as $msg): ?>
                        <div class="p-3 rounded-2xl border border-slate-50 dark:border-slate-750 flex gap-3 text-xs">
                            <img src="<?php echo htmlspecialchars(getUserAvatarUrl($msg['author_avatar'] ?? '')); ?>" class="w-8 h-8 rounded-full object-cover mt-0.5">
                            <div class="space-y-1.5 flex-1">
                                <div class="flex justify-between items-center">
                                    <div>
                                        <strong class="text-slate-800 dark:text-slate-200 font-bold"><?php echo htmlspecialchars($msg['author_name']); ?></strong>
                                        <span class="text-[9px] font-bold text-gold uppercase tracking-wider ml-1"><?php echo htmlspecialchars($msg['role_name']); ?></span>
                                    </div>
                                    <span class="text-[9px] text-slate-400"><?php echo date('M d, H:i', strtotime($msg['created_at'])); ?></span>
                                </div>
                                <p class="text-slate-600 dark:text-slate-400 font-light leading-relaxed whitespace-pre-wrap"><?php echo htmlspecialchars($msg['body']); ?></p>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>

            </div>

        </div>

    </main>
</body>
</html>
