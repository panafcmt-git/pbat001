<?php
/**
 * PBAT Smart Nation Initiative - ID Cards Directory
 * Directory listing all active members and providing buttons to preview/print their credentials.
 */
require_once dirname(__DIR__) . '/helpers/auth.php';
require_once dirname(__DIR__) . '/helpers/common.php';
require_once dirname(__DIR__) . '/config/database.php';

Auth::requireRole(['super_admin', 'founder_circle', 'national_steering'], '../login.php');

$user = Auth::user();
$error = '';
$success = '';
$members = [];

try {
    $db = Database::connect();

    // Search and Filter Handling
    $search = trim($_GET['search'] ?? '');
    $role_filter = trim($_GET['role_id'] ?? '');

    $query = "
        SELECT u.id, u.name, u.email, u.status, r.display_name as role_name, r.id as role_id,
               COALESCE(a.uuid, 'N/A') as uuid, s.name as state_name
        FROM users u
        JOIN roles r ON u.role_id = r.id
        LEFT JOIN ambassadors a ON u.id = a.user_id
        LEFT JOIN states s ON a.state_id = s.id
        WHERE 1=1
    ";
    $params = [];

    if (!empty($search)) {
        $query .= " AND (u.name LIKE ? OR u.email LIKE ? OR a.uuid LIKE ?)";
        $search_val = "%{$search}%";
        $params[] = $search_val;
        $params[] = $search_val;
        $params[] = $search_val;
    }

    if (!empty($role_filter)) {
        $query .= " AND u.role_id = ?";
        $params[] = (int)$role_filter;
    }

    $query .= " ORDER BY u.name ASC";
    $stmt = $db->prepare($query);
    $stmt->execute($params);
    $members = $stmt->fetchAll();

    // Fetch Roles for filters
    $roles = $db->query("SELECT id, display_name FROM roles ORDER BY id ASC")->fetchAll();

} catch (Exception $e) {
    $error = "ID Directory DB Error: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ID Cards Directory - PBAT Smart Nation</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        bushgreen: {
                            DEFAULT: '#063C1E',
                            light: '#0A4D27',
                            dark: '#03200F',
                        },
                        gold: '#D4AF37'
                    }
                }
            }
        }
    </script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        [x-cloak] { display: none !important; }
        body { font-family: 'Inter', sans-serif; }
        h1, h2, h3, h4, .font-display { font-family: 'Outfit', sans-serif; }
    </style>
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
</head>
<body class="bg-slate-50 text-slate-800 transition-colors duration-200 min-h-screen flex flex-col antialiased"
      x-data="{ darkMode: localStorage.getItem('darkMode') === 'true' }"
      x-init="$watch('darkMode', val => localStorage.setItem('darkMode', val))"
      :class="{ 'dark bg-slate-900 text-slate-100': darkMode }">

    <!-- Header Navbar -->
    <header class="bg-bushgreen text-white border-b-2 border-gold h-20 flex items-center justify-between px-6 shadow-md relative z-30">
        <div class="flex items-center gap-3">
            <a href="dashboard.php" class="py-1.5 px-3 border border-white/20 hover:bg-white/10 text-white rounded-lg text-xs font-bold transition">
                &larr; Back to Dashboard
            </a>
            <div class="w-8 h-8 rounded bg-white/10 flex items-center justify-center border border-white/20 p-1 flex-shrink-0">
                <?php echo getAppLogoHtml('w-full h-full object-contain', 'dashboard'); ?>
            </div>
            <span class="text-white font-extrabold text-sm font-display hidden sm:inline">PBAT SMART NATION INITIATIVE</span>
        </div>
        <div class="flex items-center gap-4 text-xs font-bold text-gold uppercase tracking-wider">
            <!-- Dark Mode Toggle -->
            <button @click="darkMode = !darkMode" class="p-2 rounded-lg border border-gold/45 text-gold hover:bg-gold/10 transition flex items-center justify-center">
                <svg x-show="darkMode" class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364-6.364l-.707.707M6.364 17.636l-.707.707M18.364 17.636l-.707-.707M6.364 6.364l-.707-.707M15 12a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                <svg x-show="!darkMode" class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z"/></svg>
            </button>
            <span>ID Cards Directory</span>
        </div>
    </header>

    <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 flex-grow w-full space-y-10">
        
        <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div class="space-y-1">
                <h1 class="text-2xl sm:text-3xl font-black text-bushgreen dark:text-gold font-display">Digital ID Card Generator System</h1>
                <p class="text-slate-500 dark:text-slate-400 text-xs font-light">Generate, validate, print, or download credential cards for ambassadors and steering leaders.</p>
            </div>
        </div>

        <!-- Filters Box -->
        <div class="bg-white dark:bg-slate-800 p-6 rounded-2xl border border-slate-100 dark:border-slate-700 shadow-sm">
            <form method="GET" action="" class="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                    <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1.5" for="search">Search Member</label>
                    <input type="text" name="search" id="search" value="<?php echo htmlspecialchars($search); ?>" placeholder="Type name, email, or UUID..."
                           class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                </div>

                <div>
                    <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1.5" for="role_id">Filter by Role</label>
                    <select name="role_id" id="role_id"
                            class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                        <option value="">-- All Roles --</option>
                        <?php foreach ($roles as $r): ?>
                            <option value="<?php echo $r['id']; ?>" <?php echo $role_filter == $r['id'] ? 'selected' : ''; ?>><?php echo htmlspecialchars($r['display_name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="flex items-end">
                    <button type="submit" class="w-full py-2 bg-bushgreen hover:bg-bushgreen-light text-white text-xs font-bold rounded-lg transition shadow-md">
                        Apply Search Parameters
                    </button>
                </div>
            </form>
        </div>

        <!-- Roster Table -->
        <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm">
            <div class="overflow-x-auto">
                <table class="w-full text-xs text-left text-slate-500 dark:text-slate-400">
                    <thead class="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase border-b border-slate-100 dark:border-slate-700">
                        <tr>
                            <th class="pb-3">Name</th>
                            <th class="pb-3">Email</th>
                            <th class="pb-3">UUID</th>
                            <th class="pb-3">Role</th>
                            <th class="pb-3">State</th>
                            <th class="pb-3 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-50 dark:divide-slate-700">
                        <?php if (empty($members)): ?>
                            <tr>
                                <td colspan="6" class="py-6 text-center text-slate-400 italic">No members found matching filters.</td>
                            </tr>
                        <?php endif; ?>
                        <?php foreach ($members as $m): ?>
                            <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-700/50">
                                <td class="py-3 font-semibold text-slate-800 dark:text-slate-200"><?php echo htmlspecialchars($m['name']); ?></td>
                                <td class="py-3 font-mono"><?php echo htmlspecialchars($m['email']); ?></td>
                                <td class="py-3 font-mono text-gold font-bold"><?php echo htmlspecialchars($m['uuid']); ?></td>
                                <td class="py-3">
                                    <span class="px-2 py-0.5 rounded text-[9px] font-bold uppercase tracking-wider bg-bushgreen/10 text-bushgreen dark:bg-gold/10 dark:text-gold">
                                        <?php echo htmlspecialchars($m['role_name']); ?>
                                    </span>
                                </td>
                                <td class="py-3"><?php echo htmlspecialchars($m['state_name'] ?? 'National'); ?></td>
                                <td class="py-3 text-right">
                                    <a href="id-card.php?user_id=<?php echo $m['id']; ?>" target="_blank"
                                       class="py-1 px-3 bg-bushgreen hover:bg-bushgreen-light text-white text-[10px] font-bold rounded-lg transition inline-flex items-center gap-1">
                                        <svg class="w-3.5 h-3.5 text-gold" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/></svg>
                                        Preview & Print Card
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </main>
</body>
</html>
