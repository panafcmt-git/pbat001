<?php
/**
 * PBAT Smart Nation Initiative - Sponsors, Feedback & Newsletters Console
 * Allows Super Admin to view and follow up on sponsorships, feedbacks, and newsletter subscriptions.
 */
require_once dirname(__DIR__) . '/helpers/auth.php';
require_once dirname(__DIR__) . '/helpers/common.php';
require_once dirname(__DIR__) . '/config/database.php';

Auth::requireRole(['super_admin', 'founder_circle'], '../login.php');

$user = Auth::user();
$error = '';
$success = '';

// Handle CSV Download Action first before rendering HTML headers
if (isset($_GET['action']) && $_GET['action'] === 'download_newsletters') {
    try {
        $db = Database::connect();
        $stmt = $db->query("SELECT email, created_at FROM `newsletters` ORDER BY created_at DESC");
        $subscribers = $stmt->fetchAll(PDO::FETCH_ASSOC);

        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=newsletter_subscribers_' . date('Y-m-d') . '.csv');
        $output = fopen('php://output', 'w');
        
        // Add header row
        fputcsv($output, ['Email Address', 'Date Subscribed']);
        
        foreach ($subscribers as $row) {
            fputcsv($output, [$row['email'], $row['created_at']]);
        }
        fclose($output);
        exit;
    } catch (Exception $e) {
        $error = "Failed to export CSV: " . $e->getMessage();
    }
}

try {
    $db = Database::connect();

    // Handle Status Updates (POST)
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
        if (!Auth::validateCsrf($_POST['csrf_token'] ?? '')) {
            $error = "CSRF Token validation failed.";
        } else {
            $action = $_POST['action'];
            
            if ($action === 'update_sponsor_status') {
                $sponsor_id = (int)$_POST['sponsor_id'];
                $status = trim($_POST['status'] ?? 'pending');
                
                $stmt = $db->prepare("UPDATE `project_sponsors` SET `status` = ? WHERE `id` = ?");
                $stmt->execute([$status, $sponsor_id]);
                
                Auth::logAction($user['id'], 'SPONSOR_STATUS_UPDATE', "Updated Sponsor ID {$sponsor_id} status to {$status}");
                $success = "Sponsor status updated successfully!";
            }
            
            elseif ($action === 'update_contact_status') {
                $contact_id = (int)$_POST['contact_id'];
                $status = trim($_POST['status'] ?? 'pending');
                
                $stmt = $db->prepare("UPDATE `contact_submissions` SET `status` = ? WHERE `id` = ?");
                $stmt->execute([$status, $contact_id]);
                
                Auth::logAction($user['id'], 'CONTACT_STATUS_UPDATE', "Updated Feedback ID {$contact_id} status to {$status}");
                $success = "Feedback status updated successfully!";
            }
        }
    }

    // Fetch Project Sponsors
    $sponsors = $db->query("SELECT * FROM `project_sponsors` ORDER BY created_at DESC")->fetchAll(PDO::FETCH_ASSOC);

    // Fetch Contact Feedbacks
    $feedbacks = $db->query("SELECT * FROM `contact_submissions` ORDER BY created_at DESC")->fetchAll(PDO::FETCH_ASSOC);

    // Fetch Newsletter Subscribers
    $subscribers = $db->query("SELECT * FROM `newsletters` ORDER BY created_at DESC LIMIT 500")->fetchAll(PDO::FETCH_ASSOC);

} catch (Exception $e) {
    $error = "Database Error: " . $e->getMessage();
    $sponsors = [];
    $feedbacks = [];
    $subscribers = [];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sponsors, Feedback & Newsletters Console - PBAT Smart Nation</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        bushgreen: {
                            DEFAULT: '#063C1E',
                            light: '#0A4D27',
                            dark: '#03200F',
                        },
                        gold: '#D4AF37'
                    }
                }
            }
        }
    </script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
    <style>
        [x-cloak] { display: none !important; }
        body { font-family: 'Inter', sans-serif; }
        h1, h2, h3, h4, .font-display { font-family: 'Outfit', sans-serif; }
    </style>
</head>
<body class="bg-slate-50 text-slate-800 transition-colors duration-200 min-h-screen flex flex-col antialiased"
      x-data="{ 
          darkMode: localStorage.getItem('darkMode') === 'true',
          activeTab: 'sponsors',
          selectedSponsor: null,
          selectedFeedback: null,
          showSponsorModal: false,
          showFeedbackModal: false
      }"
      x-init="$watch('darkMode', val => localStorage.setItem('darkMode', val))"
      :class="{ 'dark bg-slate-900 text-slate-100': darkMode }">

    <!-- Header Navbar -->
    <header class="bg-bushgreen text-white border-b-2 border-gold h-20 flex items-center justify-between px-6 shadow-md relative z-30">
        <div class="flex items-center gap-3">
            <a href="dashboard.php" class="py-1.5 px-3 border border-white/20 hover:bg-white/10 text-white rounded-lg text-xs font-bold transition">
                &larr; Back to Dashboard
            </a>
            <div class="w-8 h-8 rounded bg-white/10 flex items-center justify-center border border-white/20 p-1 flex-shrink-0">
                <?php echo getAppLogoHtml('w-full h-full object-contain', 'dashboard'); ?>
            </div>
            <span class="text-white font-extrabold text-sm font-display hidden sm:inline">PBAT SMART NATION INITIATIVE</span>
        </div>
        <div class="flex items-center gap-4 text-xs font-bold text-gold uppercase tracking-wider font-display">
            <!-- Dark Mode Toggle -->
            <button @click="darkMode = !darkMode" class="p-2 rounded-lg border border-gold/45 text-gold hover:bg-gold/10 transition flex items-center justify-center">
                <svg x-show="darkMode" class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364-6.364l-.707.707M6.364 17.636l-.707.707M18.364 17.636l-.707-.707M6.364 6.364l-.707-.707M15 12a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                <svg x-show="!darkMode" class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z"/></svg>
            </button>
            <span>Sponsors & Feedback Hub</span>
        </div>
    </header>

    <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 flex-grow w-full space-y-10">
        
        <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div class="space-y-1">
                <h1 class="text-2xl sm:text-3xl font-black text-bushgreen dark:text-gold font-display uppercase tracking-tight">Sponsors & Feedback Console</h1>
                <p class="text-slate-500 dark:text-slate-400 text-xs font-light">Supervise corporate sponsors offers, public feedback messages, and newsletter subscribers.</p>
            </div>

            <?php if (!empty($success)): ?>
                <div class="px-4 py-2 bg-emerald-50 border border-emerald-250 text-emerald-800 rounded-xl text-xs font-semibold">
                    <?php echo htmlspecialchars($success); ?>
                </div>
            <?php endif; ?>

            <?php if (!empty($error)): ?>
                <div class="px-4 py-2 bg-red-50 border border-red-205 text-red-800 rounded-xl text-xs font-semibold">
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>
        </div>

        <!-- Tab switches -->
        <div class="flex flex-wrap gap-2 border-b border-slate-200 dark:border-slate-800 pb-2 justify-between items-center">
            <div class="flex gap-2">
                <button @click="activeTab = 'sponsors'" :class="activeTab === 'sponsors' ? 'bg-bushgreen text-white dark:bg-gold dark:text-bushgreen' : 'bg-white dark:bg-slate-800 text-slate-655'" class="px-4 py-1.5 rounded-lg text-xs font-bold transition">Sponsors Offers (<?php echo count($sponsors); ?>)</button>
                <button @click="activeTab = 'feedback'" :class="activeTab === 'feedback' ? 'bg-bushgreen text-white dark:bg-gold dark:text-bushgreen' : 'bg-white dark:bg-slate-800 text-slate-655'" class="px-4 py-1.5 rounded-lg text-xs font-bold transition">Public Feedback (<?php echo count($feedbacks); ?>)</button>
                <button @click="activeTab = 'newsletter'" :class="activeTab === 'newsletter' ? 'bg-bushgreen text-white dark:bg-gold dark:text-bushgreen' : 'bg-white dark:bg-slate-800 text-slate-655'" class="px-4 py-1.5 rounded-lg text-xs font-bold transition">Newsletter Subs (<?php echo count($subscribers); ?>)</button>
            </div>
            
            <div x-show="activeTab === 'newsletter'">
                <a href="sponsors-feedback.php?action=download_newsletters" class="py-1.5 px-4 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold transition shadow flex items-center gap-1.5">
                    <svg class="w-4 h-4 text-gold" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/></svg>
                    Export Newsletter CSV
                </a>
            </div>
        </div>

        <!-- 1. SPONSORS TAB -->
        <div x-show="activeTab === 'sponsors'" class="bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 shadow-sm overflow-hidden animate-fade-in">
            <div class="overflow-x-auto">
                <table class="w-full text-xs text-left text-slate-500 dark:text-slate-400">
                    <thead class="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider border-b border-slate-100 dark:border-slate-700">
                        <tr>
                            <th class="p-4">Organization / Company</th>
                            <th class="p-4">Contact Person</th>
                            <th class="p-4">Category</th>
                            <th class="p-4 text-right">Offer (₦)</th>
                            <th class="p-4">Status</th>
                            <th class="p-4">Date Submitted</th>
                            <th class="p-4 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-50 dark:divide-slate-700">
                        <?php if (empty($sponsors)): ?>
                            <tr>
                                <td colspan="7" class="p-8 text-center text-slate-400 italic">No sponsors registrations received yet.</td>
                            </tr>
                        <?php endif; ?>
                        
                        <?php foreach ($sponsors as $s): ?>
                            <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-700/50">
                                <td class="p-4 font-bold text-slate-800 dark:text-white"><?php echo htmlspecialchars($s['company_name']); ?></td>
                                <td class="p-4">
                                    <div class="font-semibold text-slate-750 dark:text-slate-300"><?php echo htmlspecialchars($s['contact_name']); ?></div>
                                    <div class="text-[9px] font-mono text-slate-400"><?php echo htmlspecialchars($s['contact_email']); ?> &bull; <?php echo htmlspecialchars($s['contact_phone'] ?: 'No Phone'); ?></div>
                                </td>
                                <td class="p-4 font-semibold text-slate-655 dark:text-slate-350"><?php echo htmlspecialchars($s['sponsorship_category']); ?></td>
                                <td class="p-4 text-right font-bold text-bushgreen dark:text-gold"><?php echo number_format($s['sponsor_amount'], 2); ?></td>
                                <td class="p-4">
                                    <span class="px-2.5 py-0.5 rounded-full text-[9px] font-extrabold uppercase tracking-wide
                                        <?php 
                                        if ($s['status'] === 'partnered') echo 'bg-emerald-50 text-emerald-800 border border-emerald-250';
                                        elseif ($s['status'] === 'contacted') echo 'bg-blue-50 text-blue-800 border border-blue-200';
                                        elseif ($s['status'] === 'declined') echo 'bg-red-50 text-red-800 border border-red-200';
                                        else echo 'bg-amber-50 text-amber-800 border border-amber-200';
                                        ?>">
                                        <?php echo htmlspecialchars($s['status']); ?>
                                    </span>
                                </td>
                                <td class="p-4 text-slate-400"><?php echo date('Y-m-d H:i', strtotime($s['created_at'])); ?></td>
                                <td class="p-4 text-right space-x-1.5 whitespace-nowrap">
                                    <button @click="selectedSponsor = <?php echo htmlspecialchars(json_encode($s)); ?>; showSponsorModal = true;"
                                            class="py-1 px-2.5 bg-bushgreen text-white hover:bg-bushgreen-light rounded text-[9px] font-bold transition">
                                        Process Offer
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- 2. FEEDBACK TAB -->
        <div x-show="activeTab === 'feedback'" class="bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 shadow-sm overflow-hidden animate-fade-in">
            <div class="overflow-x-auto">
                <table class="w-full text-xs text-left text-slate-500 dark:text-slate-400">
                    <thead class="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider border-b border-slate-100 dark:border-slate-700">
                        <tr>
                            <th class="p-4">Name / Sender</th>
                            <th class="p-4">Subject</th>
                            <th class="p-4">Message Snippet</th>
                            <th class="p-4">Status</th>
                            <th class="p-4">Submitted Date</th>
                            <th class="p-4 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-50 dark:divide-slate-700">
                        <?php if (empty($feedbacks)): ?>
                            <tr>
                                <td colspan="6" class="p-8 text-center text-slate-400 italic">No contact submissions received yet.</td>
                            </tr>
                        <?php endif; ?>
                        
                        <?php foreach ($feedbacks as $f): ?>
                            <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-700/50">
                                <td class="p-4">
                                    <div class="font-bold text-slate-800 dark:text-white"><?php echo htmlspecialchars($f['name']); ?></div>
                                    <div class="text-[9px] font-mono text-slate-400"><?php echo htmlspecialchars($f['email']); ?></div>
                                </td>
                                <td class="p-4 font-semibold text-slate-750 dark:text-slate-350"><?php echo htmlspecialchars($f['subject']); ?></td>
                                <td class="p-4 text-slate-500 dark:text-slate-400 line-clamp-1 max-w-xs mt-3 block border-0"><?php echo htmlspecialchars(substr($f['message'], 0, 80)) . (strlen($f['message']) > 80 ? '...' : ''); ?></td>
                                <td class="p-4">
                                    <span class="px-2.5 py-0.5 rounded-full text-[9px] font-extrabold uppercase tracking-wide
                                        <?php 
                                        if ($f['status'] === 'resolved') echo 'bg-emerald-50 text-emerald-800 border border-emerald-250';
                                        elseif ($f['status'] === 'in_progress') echo 'bg-blue-50 text-blue-800 border border-blue-200';
                                        else echo 'bg-amber-50 text-amber-800 border border-amber-200';
                                        ?>">
                                        <?php echo htmlspecialchars($f['status']); ?>
                                    </span>
                                </td>
                                <td class="p-4 text-slate-400"><?php echo date('Y-m-d H:i', strtotime($f['created_at'])); ?></td>
                                <td class="p-4 text-right space-x-1.5 whitespace-nowrap">
                                    <button @click="selectedFeedback = <?php echo htmlspecialchars(json_encode($f)); ?>; showFeedbackModal = true;"
                                            class="py-1 px-2.5 bg-bushgreen text-white hover:bg-bushgreen-light rounded text-[9px] font-bold transition">
                                        Open Message
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- 3. NEWSLETTER TAB -->
        <div x-show="activeTab === 'newsletter'" class="bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 shadow-sm overflow-hidden animate-fade-in">
            <div class="p-6 border-b border-slate-50 dark:border-slate-700 flex justify-between items-center bg-slate-50 dark:bg-slate-900/40">
                <span class="text-xs font-bold text-slate-655">Showing subscribers registry (Limit: 500 records)</span>
            </div>
            <div class="overflow-x-auto">
                <table class="w-full text-xs text-left text-slate-500 dark:text-slate-400">
                    <thead class="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider border-b border-slate-100 dark:border-slate-700">
                        <tr>
                            <th class="p-4">Subscriber Email</th>
                            <th class="p-4">Date Joined</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-50 dark:divide-slate-700">
                        <?php if (empty($subscribers)): ?>
                            <tr>
                                <td colspan="2" class="p-8 text-center text-slate-400 italic">No newsletter subscribers yet.</td>
                            </tr>
                        <?php endif; ?>
                        
                        <?php foreach ($subscribers as $sub): ?>
                            <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-700/50">
                                <td class="p-4 font-bold text-slate-800 dark:text-white font-mono"><?php echo htmlspecialchars($sub['email']); ?></td>
                                <td class="p-4 text-slate-400"><?php echo date('Y-m-d H:i:s', strtotime($sub['created_at'])); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </main>

    <!-- SPONSOR ACTION MODAL -->
    <div x-show="showSponsorModal" x-cloak class="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
        <div class="bg-white dark:bg-slate-800 rounded-3xl max-w-lg w-full border border-slate-100 dark:border-slate-700 shadow-2xl overflow-hidden animate-fade-in" @click.away="showSponsorModal = false">
            <div class="bg-bushgreen text-white p-5 border-b-2 border-gold flex justify-between items-center">
                <h3 class="text-sm font-black font-display uppercase tracking-wider">Process Sponsorship Offer</h3>
                <button @click="showSponsorModal = false" class="text-white hover:text-gold text-lg font-bold">&times;</button>
            </div>
            
            <div class="p-6 space-y-4" x-if="selectedSponsor">
                <div class="space-y-2.5 bg-slate-50 dark:bg-slate-900 p-4 rounded-2xl text-xs border border-slate-100 dark:border-slate-800">
                    <div class="flex justify-between border-b border-slate-200/50 pb-2">
                        <span class="text-slate-400">Organization:</span>
                        <strong class="text-slate-800 dark:text-white" x-text="selectedSponsor ? selectedSponsor.company_name : ''"></strong>
                    </div>
                    <div class="flex justify-between border-b border-slate-200/50 pb-2">
                        <span class="text-slate-400">Contact:</span>
                        <strong class="text-slate-800 dark:text-white" x-text="selectedSponsor ? selectedSponsor.contact_name : ''"></strong>
                    </div>
                    <div class="flex justify-between border-b border-slate-200/50 pb-2">
                        <span class="text-slate-400">Email:</span>
                        <strong class="text-slate-800 dark:text-white font-mono" x-text="selectedSponsor ? selectedSponsor.contact_email : ''"></strong>
                    </div>
                    <div class="flex justify-between border-b border-slate-200/50 pb-2">
                        <span class="text-slate-400">Phone:</span>
                        <strong class="text-slate-800 dark:text-white" x-text="selectedSponsor ? selectedSponsor.contact_phone : ''"></strong>
                    </div>
                    <div class="flex justify-between border-b border-slate-200/50 pb-2">
                        <span class="text-slate-400">Category:</span>
                        <strong class="text-bushgreen dark:text-gold" x-text="selectedSponsor ? selectedSponsor.sponsorship_category : ''"></strong>
                    </div>
                    <div class="flex justify-between pb-1">
                        <span class="text-slate-400">Amount Offer:</span>
                        <strong class="text-bushgreen dark:text-gold font-bold" x-text="selectedSponsor ? '₦' + parseFloat(selectedSponsor.sponsor_amount).toLocaleString('en-US', {minimumFractionDigits: 2}) : ''"></strong>
                    </div>
                </div>

                <div class="text-xs space-y-1 p-3 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl">
                    <span class="text-slate-400">Sponsor Details / Message:</span>
                    <p class="text-slate-600 dark:text-slate-350 leading-relaxed italic" x-text="selectedSponsor ? selectedSponsor.message : 'No message provided.'"></p>
                </div>

                <form method="POST" action="" class="space-y-4 pt-2">
                    <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                    <input type="hidden" name="action" value="update_sponsor_status">
                    <input type="hidden" name="sponsor_id" :value="selectedSponsor ? selectedSponsor.id : 0">
                    
                    <div>
                        <label class="block text-slate-655 dark:text-slate-400 text-xs font-semibold mb-1.5">Action Status Review State:</label>
                        <select name="status" required class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen dark:text-white">
                            <option value="pending">Pending Review</option>
                            <option value="contacted">Contacted & Discussing</option>
                            <option value="partnered">Partnered / Active Sponsor</option>
                            <option value="declined">Declined</option>
                        </select>
                    </div>

                    <div class="flex justify-end gap-2 pt-2">
                        <button type="button" @click="showSponsorModal = false" class="py-2 px-4 border border-slate-200 dark:border-slate-700 rounded-xl hover:bg-slate-100 text-xs font-bold transition">
                            Cancel
                        </button>
                        <button type="submit" class="py-2 px-5 bg-bushgreen text-white hover:bg-bushgreen-light rounded-xl text-xs font-bold transition">
                            Update Status
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- FEEDBACK ACTION MODAL -->
    <div x-show="showFeedbackModal" x-cloak class="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
        <div class="bg-white dark:bg-slate-800 rounded-3xl max-w-lg w-full border border-slate-100 dark:border-slate-700 shadow-2xl overflow-hidden animate-fade-in" @click.away="showFeedbackModal = false">
            <div class="bg-bushgreen text-white p-5 border-b-2 border-gold flex justify-between items-center">
                <h3 class="text-sm font-black font-display uppercase tracking-wider">Contact feedback Message</h3>
                <button @click="showFeedbackModal = false" class="text-white hover:text-gold text-lg font-bold">&times;</button>
            </div>
            
            <div class="p-6 space-y-4" x-if="selectedFeedback">
                <div class="space-y-2 bg-slate-50 dark:bg-slate-900 p-4 rounded-2xl text-xs border border-slate-100 dark:border-slate-800">
                    <div>
                        <span class="text-slate-400">Sender Name:</span>
                        <strong class="text-slate-800 dark:text-white block mt-0.5" x-text="selectedFeedback ? selectedFeedback.name : ''"></strong>
                    </div>
                    <div>
                        <span class="text-slate-400">Email Address:</span>
                        <strong class="text-slate-800 dark:text-white block mt-0.5 font-mono" x-text="selectedFeedback ? selectedFeedback.email : ''"></strong>
                    </div>
                    <div>
                        <span class="text-slate-400">Subject:</span>
                        <strong class="text-bushgreen dark:text-gold block mt-0.5" x-text="selectedFeedback ? selectedFeedback.subject : ''"></strong>
                    </div>
                </div>

                <div class="text-xs space-y-1.5 p-4 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl">
                    <span class="text-slate-400 font-semibold block border-b border-slate-200/50 pb-1.5">Feedback / Contact Message:</span>
                    <p class="text-slate-700 dark:text-slate-300 leading-relaxed whitespace-pre-line" x-text="selectedFeedback ? selectedFeedback.message : ''"></p>
                </div>

                <form method="POST" action="" class="space-y-4 pt-2">
                    <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                    <input type="hidden" name="action" value="update_contact_status">
                    <input type="hidden" name="contact_id" :value="selectedFeedback ? selectedFeedback.id : 0">
                    
                    <div>
                        <label class="block text-slate-655 dark:text-slate-400 text-xs font-semibold mb-1.5">Mark Request State:</label>
                        <select name="status" required class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen dark:text-white">
                            <option value="pending">Pending / New</option>
                            <option value="in_progress">In Progress / Following Up</option>
                            <option value="resolved">Resolved & Closed</option>
                        </select>
                    </div>

                    <div class="flex justify-end gap-2 pt-2">
                        <button type="button" @click="showFeedbackModal = false" class="py-2 px-4 border border-slate-200 dark:border-slate-700 rounded-xl hover:bg-slate-100 text-xs font-bold transition">
                            Cancel
                        </button>
                        <button type="submit" class="py-2 px-5 bg-bushgreen text-white hover:bg-bushgreen-light rounded-xl text-xs font-bold transition">
                            Update Status
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

</body>
</html>
