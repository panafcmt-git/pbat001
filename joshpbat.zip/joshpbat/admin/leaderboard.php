<?php
/**
 * PBAT Smart Nation Initiative - Leaderboard & Impact Scoring Engine
 * Ranks states, ambassadors, and campaigns. Manage dynamic point scoring rules.
 */
require_once dirname(__DIR__) . '/helpers/auth.php';
require_once dirname(__DIR__) . '/helpers/common.php';
require_once dirname(__DIR__) . '/config/database.php';

Auth::requireRole(['super_admin', 'founder_circle', 'national_steering', 'zonal_chairman', 'state_chairman'], '../login.php');

$user = Auth::user();
$error = '';
$success = '';

try {
    $db = Database::connect();

    // 1. Handle Point Weights Updates
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_rules') {
        if (!Auth::validateCsrf($_POST['csrf_token'] ?? '')) {
            $error = "CSRF Token validation failed.";
        } else {
            $rules = [
                'points_report_file' => (int)$_POST['points_report_file'],
                'points_event_checkin' => (int)$_POST['points_event_checkin'],
                'points_campaign_complete' => (int)$_POST['points_campaign_complete']
            ];

            $stmt = $db->prepare("INSERT INTO `system_settings` (`setting_key`, `setting_value`) VALUES (?, ?) ON DUPLICATE KEY UPDATE `setting_value` = ?");
            foreach ($rules as $key => $val) {
                $stmt->execute([$key, $val, $val]);
            }

            Auth::logAction($user['id'], 'SCORING_RULES_UPDATE', "Reconfigured impact scoring engine point parameters.");
            $success = "Point scoring parameters updated successfully!";
        }
    }

    // 2. Load point weights
    $weights_rows = $db->query("SELECT * FROM `system_settings` WHERE `setting_key` LIKE 'points_%'")->fetchAll();
    $weights = [];
    foreach ($weights_rows as $row) {
        $weights[$row['setting_key']] = (int)$row['setting_value'];
    }

    $pts_report = $weights['points_report_file'] ?? 50;
    $pts_event = $weights['points_event_checkin'] ?? 20;
    $pts_campaign = $weights['points_campaign_complete'] ?? 100;

    // 3. Fetch States Leaderboard
    $states_rank = $db->query("
        SELECT s.name, a.impact_score, a.ambassador_count, a.reports_filed
        FROM analytics_summary a
        JOIN states s ON a.state_id = s.id
        ORDER BY a.impact_score DESC
        LIMIT 10
    ")->fetchAll();

    // 4. Fetch Ambassadors Leaderboard
    $ambassadors_rank = $db->query("
        SELECT u.name, s.name as state_name, a.impact_score, a.uuid
        FROM ambassadors a
        JOIN users u ON a.user_id = u.id
        JOIN states s ON a.state_id = s.id
        WHERE u.status = 'active'
        ORDER BY a.impact_score DESC
        LIMIT 10
    ")->fetchAll();

} catch (Exception $e) {
    $error = "Leaderboard DB Error: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Leaderboard & Impact Scoring - PBAT Smart Nation</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        bushgreen: {
                            DEFAULT: '#063C1E',
                            light: '#0A4D27',
                            dark: '#03200F',
                        },
                        gold: '#D4AF37'
                    }
                }
            }
        }
    </script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        [x-cloak] { display: none !important; }
        body { font-family: 'Inter', sans-serif; }
        h1, h2, h3, h4, .font-display { font-family: 'Outfit', sans-serif; }
    </style>
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
</head>
<body class="bg-slate-50 text-slate-800 transition-colors duration-200 min-h-screen flex flex-col antialiased"
      x-data="{ darkMode: localStorage.getItem('darkMode') === 'true' }"
      x-init="$watch('darkMode', val => localStorage.setItem('darkMode', val))"
      :class="{ 'dark bg-slate-900 text-slate-100': darkMode }">

    <!-- Header Navbar -->
    <header class="bg-bushgreen text-white border-b-2 border-gold h-20 flex items-center justify-between px-6 shadow-md relative z-30">
        <div class="flex items-center gap-3">
            <a href="dashboard.php" class="py-1.5 px-3 border border-white/20 hover:bg-white/10 text-white rounded-lg text-xs font-bold transition">
                &larr; Back to Dashboard
            </a>
            <div class="w-8 h-8 rounded bg-white/10 flex items-center justify-center border border-white/20 p-1 flex-shrink-0">
                <?php echo getAppLogoHtml('w-full h-full object-contain', 'dashboard'); ?>
            </div>
            <span class="text-white font-extrabold text-sm font-display hidden sm:inline">PBAT SMART NATION INITIATIVE</span>
        </div>
        <div class="flex items-center gap-4 text-xs font-bold text-gold uppercase tracking-wider">
            <!-- Dark Mode Toggle -->
            <button @click="darkMode = !darkMode" class="p-2 rounded-lg border border-gold/45 text-gold hover:bg-gold/10 transition flex items-center justify-center">
                <svg x-show="darkMode" class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364-6.364l-.707.707M6.364 17.636l-.707.707M18.364 17.636l-.707-.707M6.364 6.364l-.707-.707M15 12a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                <svg x-show="!darkMode" class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z"/></svg>
            </button>
            <span>Impact Scoring Console</span>
        </div>
    </header>

    <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 flex-grow w-full space-y-10">
        
        <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div class="space-y-1">
                <h1 class="text-2xl sm:text-3xl font-black text-bushgreen dark:text-gold font-display">Leaderboards & Impact Engine</h1>
                <p class="text-slate-500 dark:text-slate-400 text-xs font-light">Inspect active state rankings, browse top-performing ambassadors, and update point awarding rules.</p>
            </div>

            <?php if (!empty($success)): ?>
                <div class="px-4 py-2 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs font-semibold">
                    <?php echo htmlspecialchars($success); ?>
                </div>
            <?php endif; ?>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            
            <!-- LEADERBOARDS COLUMN (Col 8) -->
            <div class="lg:col-span-8 space-y-8">
                <!-- Ranks states -->
                <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-4">
                    <h3 class="text-slate-800 dark:text-slate-200 font-bold text-sm">Top Performing States Chapter</h3>
                    <div class="overflow-x-auto">
                        <table class="w-full text-xs text-left text-slate-500 dark:text-slate-400">
                            <thead class="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase border-b border-slate-100 dark:border-slate-700">
                                <tr>
                                    <th class="pb-3">Rank</th>
                                    <th class="pb-3">State</th>
                                    <th class="pb-3 text-center">Ambassadors</th>
                                    <th class="pb-3 text-center">Reports Filed</th>
                                    <th class="pb-3 text-right">Impact Units</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-slate-50 dark:divide-slate-700">
                                <?php 
                                $rank = 1;
                                foreach ($states_rank as $sr): ?>
                                    <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-700/50">
                                        <td class="py-3 font-bold text-slate-700 dark:text-slate-300">#<?php echo $rank++; ?></td>
                                        <td class="py-3 font-semibold text-slate-800 dark:text-slate-200"><?php echo htmlspecialchars($sr['name']); ?></td>
                                        <td class="py-3 text-center"><?php echo $sr['ambassador_count']; ?></td>
                                        <td class="py-3 text-center"><?php echo $sr['reports_filed']; ?></td>
                                        <td class="py-3 text-right font-extrabold text-gold font-mono"><?php echo number_format($sr['impact_score']); ?> pts</td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- Ranks ambassadors -->
                <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-4">
                    <h3 class="text-slate-800 dark:text-slate-200 font-bold text-sm">Top Performance Grassroots Ambassadors</h3>
                    <div class="overflow-x-auto">
                        <table class="w-full text-xs text-left text-slate-500 dark:text-slate-400">
                            <thead class="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase border-b border-slate-100 dark:border-slate-700">
                                <tr>
                                    <th class="pb-3">Rank</th>
                                    <th class="pb-3">Ambassador Name</th>
                                    <th class="pb-3">Credential UUID</th>
                                    <th class="pb-3">State Chapter</th>
                                    <th class="pb-3 text-right">Impact score</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-slate-50 dark:divide-slate-700">
                                <?php 
                                $rank = 1;
                                foreach ($ambassadors_rank as $ar): ?>
                                    <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-700/50">
                                        <td class="py-3 font-bold text-slate-700 dark:text-slate-300">#<?php echo $rank++; ?></td>
                                        <td class="py-3 font-semibold text-slate-800 dark:text-slate-200"><?php echo htmlspecialchars($ar['name']); ?></td>
                                        <td class="py-3 font-mono text-gold font-bold"><?php echo htmlspecialchars($ar['uuid']); ?></td>
                                        <td class="py-3"><?php echo htmlspecialchars($ar['state_name']); ?></td>
                                        <td class="py-3 text-right font-extrabold text-gold font-mono"><?php echo $ar['impact_score']; ?> pts</td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- SCORING ENGINE RULES (Col 4) -->
            <div class="lg:col-span-4 bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-4">
                <div class="pb-2 border-b border-slate-100 dark:border-slate-700">
                    <h3 class="text-slate-800 dark:text-slate-200 font-bold text-sm">Scoring Rules Weighting</h3>
                    <p class="text-[10px] text-slate-400">Re-adjust merit points awarded dynamically on successful events or reports approval.</p>
                </div>

                <form method="POST" action="" class="space-y-4">
                    <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                    <input type="hidden" name="action" value="update_rules">

                    <div>
                        <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1.5" for="points_report_file">Filing Verified Report (Points) *</label>
                        <input type="number" name="points_report_file" id="points_report_file" required value="<?php echo $pts_report; ?>"
                               class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-mono">
                    </div>

                    <div>
                        <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1.5" for="points_event_checkin">Attending Townhall Event (Points) *</label>
                        <input type="number" name="points_event_checkin" id="points_event_checkin" required value="<?php echo $pts_event; ?>"
                               class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-mono">
                    </div>

                    <div>
                        <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1.5" for="points_campaign_complete">Completing Local Campaign (Points) *</label>
                        <input type="number" name="points_campaign_complete" id="points_campaign_complete" required value="<?php echo $pts_campaign; ?>"
                               class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-mono">
                    </div>

                    <button type="submit" class="w-full py-2.5 bg-bushgreen hover:bg-bushgreen-light text-white text-xs font-bold rounded-lg transition shadow-md">
                        Update Scoring Parameters
                    </button>
                </form>
            </div>

        </div>

    </main>
</body>
</html>
