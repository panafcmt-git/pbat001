<?php
/**
 * PBAT Smart Nation Initiative - User Details & KYC Verification Hub
 * Displays comprehensive member credentials, KYC details, regional coordinates, and direct messaging channel.
 */
require_once dirname(__DIR__) . '/helpers/auth.php';
require_once dirname(__DIR__) . '/helpers/common.php';
require_once dirname(__DIR__) . '/config/database.php';

Auth::requireRole(['super_admin', 'founder_circle'], '../login.php');

$user = Auth::user();
$error = '';
$success = '';
$target_user = null;
$geo_details = null;
$user_audit_logs = [];
$target_id = (int)($_GET['id'] ?? 0);

try {
    $db = Database::connect();
    
    // Handle Direct Message POST action
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'send_direct_message') {
        if (!Auth::validateCsrf($_POST['csrf_token'] ?? '')) {
            $error = "CSRF Token validation failed.";
        } else {
            $message_body = trim($_POST['message_body'] ?? '');
            if (empty($message_body)) {
                $error = "Message content cannot be blank.";
            } else {
                // Insert message
                $stmt_msg = $db->prepare("INSERT INTO `messages` (`sender_id`, `recipient_id`, `channel`, `subject`, `body`) VALUES (?, ?, 'direct', 'Direct Message', ?)");
                $stmt_msg->execute([$user['id'], $target_id, $message_body]);
                
                // Insert notification
                $stmt_notif = $db->prepare("INSERT INTO `notifications` (`user_id`, `message`, `type`) VALUES (?, ?, 'message')");
                $stmt_notif->execute([$target_id, "New direct message from Admin: " . substr($message_body, 0, 30) . "..."]);
                
                Auth::logAction($user['id'], 'DIRECT_MESSAGE_SEND', "Sent direct message to user ID {$target_id}.");
                $success = "Your message has been successfully sent to the user's dashboard outbox.";
            }
        }
    }
    
    // Fetch user details
    $stmt = $db->prepare("
        SELECT u.*, r.display_name as role_name 
        FROM `users` u 
        JOIN `roles` r ON u.role_id = r.id 
        WHERE u.id = ? 
        LIMIT 1
    ");
    $stmt->execute([$target_id]);
    $target_user = $stmt->fetch();
    
    if (!$target_user) {
        $error = "The requested user account does not exist in our systems.";
    } else {
        // Fetch geographic coordinates
        if ((int)$target_user['role_id'] === 7) {
            // Ambassador
            $stmt_geo = $db->prepare("
                SELECT s.name as state_name, l.name as lga_name, w.name as ward_name, a.impact_score, a.uuid
                FROM `ambassadors` a
                LEFT JOIN `states` s ON a.state_id = s.id 
                LEFT JOIN `lgas` l ON a.lga_id = l.id 
                LEFT JOIN `wards` w ON a.ward_id = w.id
                WHERE a.user_id = ? 
                LIMIT 1
            ");
            $stmt_geo->execute([$target_id]);
            $geo_details = $stmt_geo->fetch();
        } else {
            // Leadership
            $stmt_geo = $db->prepare("
                SELECT s.name as state_name, l.name as lga_name, w.name as ward_name
                FROM `user_leadership` ul
                LEFT JOIN `states` s ON ul.state_id = s.id 
                LEFT JOIN `lgas` l ON ul.lga_id = l.id 
                LEFT JOIN `wards` w ON ul.ward_id = w.id
                WHERE ul.user_id = ? 
                LIMIT 1
            ");
            $stmt_geo->execute([$target_id]);
            $geo_details = $stmt_geo->fetch();
        }

        // Fetch target's audit logs
        $stmt_audit = $db->prepare("
            SELECT * FROM `audit_logs` 
            WHERE `user_id` = ? 
            ORDER BY `created_at` DESC 
            LIMIT 10
        ");
        $stmt_audit->execute([$target_id]);
        $user_audit_logs = $stmt_audit->fetchAll();
    }
} catch (Exception $e) {
    $error = "System Query Failure: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Member Dossier - PBAT Smart Nation</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        bushgreen: {
                            DEFAULT: '#063C1E',
                            light: '#0A4D27',
                            dark: '#03200F',
                        },
                        gold: '#D4AF37'
                    }
                }
            }
        }
    </script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        [x-cloak] { display: none !important; }
        body { font-family: 'Inter', sans-serif; }
        h1, h2, h3, h4, .font-display { font-family: 'Outfit', sans-serif; }
    </style>
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
</head>
<body class="bg-slate-50 text-slate-800 transition-colors duration-200 min-h-screen flex flex-col antialiased"
      x-data="{ darkMode: localStorage.getItem('darkMode') === 'true' }"
      x-init="$watch('darkMode', val => localStorage.setItem('darkMode', val))"
      :class="{ 'dark bg-slate-900 text-slate-100': darkMode }">

    <!-- Header Navbar -->
    <header class="bg-bushgreen text-white border-b-2 border-gold h-20 flex items-center justify-between px-6 shadow-md relative z-30">
        <div class="flex items-center gap-3">
            <a href="users.php" class="py-1.5 px-3 border border-white/20 hover:bg-white/10 text-white rounded-lg text-xs font-bold transition">
                &larr; Back to Users
            </a>
            <div class="w-8 h-8 rounded bg-white/10 flex items-center justify-center border border-white/20 p-1 flex-shrink-0">
                <?php echo getAppLogoHtml('w-full h-full object-contain', 'dashboard'); ?>
            </div>
            <span class="text-white font-extrabold text-sm font-display hidden sm:inline">PBAT SMART NATION INITIATIVE</span>
        </div>
        <div class="flex items-center gap-4 text-xs font-bold text-gold uppercase tracking-wider">
            <!-- Dark Mode Toggle -->
            <button @click="darkMode = !darkMode" class="p-2 rounded-lg border border-gold/45 text-gold hover:bg-gold/10 transition flex items-center justify-center">
                <svg x-show="darkMode" class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364-6.364l-.707.707M6.364 17.636l-.707.707M18.364 17.636l-.707-.707M6.364 6.364l-.707-.707M15 12a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                <svg x-show="!darkMode" class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z"/></svg>
            </button>
            <span>Member Dossier</span>
        </div>
    </header>

    <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 flex-grow w-full space-y-8">
        
        <!-- Alerts -->
        <?php if (!empty($success)): ?>
            <div class="p-4 bg-emerald-50 dark:bg-emerald-500/10 border border-emerald-250 dark:border-emerald-500/20 text-emerald-800 dark:text-emerald-450 rounded-2xl text-xs font-semibold">
                <?php echo $success; ?>
            </div>
        <?php endif; ?>
        <?php if (!empty($error)): ?>
            <div class="p-4 bg-red-50 dark:bg-red-500/10 border border-red-250 dark:border-red-500/20 text-red-800 dark:text-red-450 rounded-2xl text-xs font-semibold">
                <?php echo $error; ?>
            </div>
        <?php endif; ?>

        <?php if ($target_user): ?>
            <!-- User Summary Hero Card -->
            <div class="bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 shadow-sm p-6 flex flex-col md:flex-row items-center gap-6">
                <img src="<?php echo htmlspecialchars(!empty($target_user['avatar']) ? '../' . $target_user['avatar'] : '../assets/img/default-avatar.png'); ?>" 
                     alt="Profile Avatar" 
                     class="w-28 h-28 rounded-full border-4 border-gold/45 object-cover shadow">
                
                <div class="text-center md:text-left space-y-2 flex-grow">
                    <div class="flex flex-col md:flex-row md:items-center gap-2">
                        <h2 class="text-2xl font-black text-slate-850 dark:text-white font-display"><?php echo htmlspecialchars($target_user['name']); ?></h2>
                        <span class="inline-block self-center md:self-auto px-2.5 py-0.5 bg-bushgreen/10 text-bushgreen dark:bg-gold/10 dark:text-gold rounded text-[10px] font-bold uppercase tracking-wider">
                            <?php echo htmlspecialchars($target_user['role_name']); ?>
                        </span>
                    </div>
                    
                    <div class="text-xs text-slate-500 dark:text-slate-400 space-y-1">
                        <p class="font-mono">Email: <span class="text-slate-800 dark:text-slate-200"><?php echo htmlspecialchars($target_user['email']); ?></span></p>
                        <p class="font-mono">Phone: <span class="text-slate-800 dark:text-slate-200"><?php echo htmlspecialchars($target_user['phone'] ?: 'None'); ?></span></p>
                        <p class="font-mono">Membership Code: <span class="text-gold font-bold"><?php echo htmlspecialchars($target_user['membership_code'] ?: 'N/A'); ?></span></p>
                    </div>
                </div>

                <div class="flex flex-col sm:flex-row gap-3 w-full md:w-auto self-stretch items-center justify-center md:items-end">
                    <?php if ($user['role'] === 'super_admin'): ?>
                        <a href="user-edit.php?id=<?php echo $target_user['id']; ?>"
                           class="py-2.5 px-6 bg-gold hover:bg-gold/90 text-bushgreen text-xs font-bold rounded-xl transition text-center shadow-md w-full sm:w-auto">
                            ✏️ Edit Coordinates
                        </a>
                    <?php endif; ?>
                    <?php if ((int)$target_user['email_verified'] === 1): ?>
                        <a href="id-card.php?user_id=<?php echo $target_user['id']; ?>" target="_blank"
                           class="py-2.5 px-6 bg-bushgreen hover:bg-bushgreen-light text-white text-xs font-bold rounded-xl transition text-center shadow-md w-full sm:w-auto">
                            📇 View Print Badge
                        </a>
                    <?php else: ?>
                        <span class="py-2 px-4 bg-slate-100 dark:bg-slate-700 text-slate-400 dark:text-slate-500 rounded-xl text-[10px] font-semibold text-center w-full sm:w-auto">
                            Email Not Verified
                        </span>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Detailed Grid Details -->
            <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                
                <!-- Left Details: KYC + Geography (Col 7) -->
                <div class="lg:col-span-7 space-y-6">
                    
                    <!-- Profile KYC Box -->
                    <div class="bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-4">
                        <h3 class="text-slate-800 dark:text-white font-bold text-sm font-display border-b border-slate-50 dark:border-slate-700 pb-2 flex items-center gap-2">
                            <span>📋 Profile KYC Compliance</span>
                            <?php if ((int)$target_user['profile_completed'] === 1): ?>
                                <span class="text-[9px] px-2 py-0.5 bg-emerald-50 dark:bg-emerald-500/10 text-emerald-800 dark:text-emerald-400 rounded-full font-bold uppercase">COMPLETED</span>
                            <?php else: ?>
                                <span class="text-[9px] px-2 py-0.5 bg-amber-50 dark:bg-amber-500/10 text-amber-800 dark:text-amber-400 rounded-full font-bold uppercase">INCOMPLETE</span>
                            <?php endif; ?>
                        </h3>

                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                            <div>
                                <span class="text-slate-400 block mb-0.5">Residential Address</span>
                                <span class="font-semibold text-slate-800 dark:text-slate-200"><?php echo htmlspecialchars($target_user['address'] ?: 'Not Provided'); ?></span>
                            </div>
                            <div>
                                <span class="text-slate-400 block mb-0.5">Occupation / Profession</span>
                                <span class="font-semibold text-slate-800 dark:text-slate-200"><?php echo htmlspecialchars($target_user['occupation'] ?: 'Not Provided'); ?></span>
                            </div>
                            <div>
                                <span class="text-slate-400 block mb-0.5">Age</span>
                                <span class="font-semibold text-slate-800 dark:text-slate-200"><?php echo $target_user['age'] ? htmlspecialchars($target_user['age']) . ' Years' : 'Not Provided'; ?></span>
                            </div>
                            <div>
                                <span class="text-slate-400 block mb-0.5">Gender</span>
                                <span class="font-semibold text-slate-800 dark:text-slate-200"><?php echo htmlspecialchars($target_user['gender'] ?: 'Not Provided'); ?></span>
                            </div>
                        </div>
                    </div>

                    <!-- Geopolitical Coordinates -->
                    <div class="bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-4">
                        <h3 class="text-slate-800 dark:text-white font-bold text-sm font-display border-b border-slate-50 dark:border-slate-700 pb-2">
                            🗺️ Geopolitical Scope & Coordinates
                        </h3>

                        <div class="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
                            <div>
                                <span class="text-slate-400 block mb-0.5">State Assignment</span>
                                <span class="font-bold text-bushgreen dark:text-gold"><?php echo htmlspecialchars($geo_details['state_name'] ?? 'National'); ?></span>
                            </div>
                            <div>
                                <span class="text-slate-400 block mb-0.5">Local Government Area</span>
                                <span class="font-bold text-slate-800 dark:text-slate-200"><?php echo htmlspecialchars($geo_details['lga_name'] ?? 'Not Applicable'); ?></span>
                            </div>
                            <div>
                                <span class="text-slate-400 block mb-0.5">Ward Assignment</span>
                                <span class="font-bold text-slate-800 dark:text-slate-200"><?php echo htmlspecialchars($geo_details['ward_name'] ?? 'Not Applicable'); ?></span>
                            </div>
                            <?php if (isset($geo_details['impact_score'])): ?>
                                <div>
                                    <span class="text-slate-400 block mb-0.5">Advocacy Impact Rating</span>
                                    <span class="font-extrabold text-emerald-600"><?php echo (int)$geo_details['impact_score']; ?> points</span>
                                </div>
                                <div>
                                    <span class="text-slate-400 block mb-0.5">System Assigned UUID</span>
                                    <span class="font-mono text-slate-600 dark:text-slate-400"><?php echo htmlspecialchars($geo_details['uuid']); ?></span>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Activity / Audit Trail -->
                    <div class="bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-4">
                        <h3 class="text-slate-800 dark:text-white font-bold text-sm font-display border-b border-slate-50 dark:border-slate-700 pb-2">
                            ⏱️ Security Audit: Recent Activities
                        </h3>

                        <?php if (empty($user_audit_logs)): ?>
                            <p class="text-slate-400 text-xs italic">No activity logs recorded for this account.</p>
                        <?php else: ?>
                            <div class="flow-root">
                                <ul class="-mb-8">
                                    <?php foreach ($user_audit_logs as $index => $log): ?>
                                        <li>
                                            <div class="relative pb-8">
                                                <?php if ($index !== count($user_audit_logs) - 1): ?>
                                                    <span class="absolute top-4 left-4 -ml-px h-full w-0.5 bg-slate-200 dark:bg-slate-700" aria-hidden="true"></span>
                                                <?php endif; ?>
                                                <div class="relative flex space-x-3">
                                                    <div>
                                                        <span class="h-8 w-8 rounded-full bg-bushgreen/10 text-bushgreen dark:bg-gold/10 dark:text-gold flex items-center justify-center text-[10px] font-extrabold">
                                                            L
                                                        </span>
                                                    </div>
                                                    <div class="flex-grow pt-1.5 flex justify-between space-x-4">
                                                        <div>
                                                            <p class="text-xs text-slate-800 dark:text-slate-200 font-bold"><?php echo htmlspecialchars($log['action']); ?></p>
                                                            <p class="text-[10px] text-slate-400 leading-relaxed"><?php echo htmlspecialchars($log['details']); ?></p>
                                                        </div>
                                                        <div class="text-right text-[9px] whitespace-nowrap text-slate-400 font-mono">
                                                            <?php echo date('M d, H:i', strtotime($log['created_at'])); ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Right Details: Direct messaging (Col 5) -->
                <div class="lg:col-span-5 space-y-6">
                    
                    <!-- DM panel -->
                    <div class="bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-4">
                        <h3 class="text-slate-800 dark:text-white font-bold text-sm font-display border-b border-slate-50 dark:border-slate-700 pb-2">
                            ✉️ Dispatch Direct Message
                        </h3>
                        <p class="text-[11px] text-slate-500 leading-relaxed font-light">
                            Send an internal message directly to this member. The message will appear instantly in their dashboard notification center and outbox.
                        </p>

                        <form method="POST" action="" class="space-y-4">
                            <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                            <input type="hidden" name="action" value="send_direct_message">
                            
                            <div>
                                <label class="block text-slate-600 dark:text-slate-400 text-[10px] font-semibold mb-1.5">Recipient</label>
                                <input type="text" readonly disabled value="<?php echo htmlspecialchars($target_user['name']); ?> (<?php echo htmlspecialchars($target_user['email']); ?>)"
                                       class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-500 dark:text-slate-400 font-light">
                            </div>
                            
                            <div>
                                <label class="block text-slate-600 dark:text-slate-400 text-[10px] font-semibold mb-1.5" for="message_body">Message Body *</label>
                                <textarea name="message_body" id="message_body" required rows="6"
                                          placeholder="Type your message details here..."
                                          class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs focus:outline-none focus:border-bushgreen text-slate-800 dark:text-white font-light"></textarea>
                            </div>
                            
                            <button type="submit" class="w-full py-2.5 bg-bushgreen hover:bg-bushgreen-light text-white text-xs font-bold rounded-xl transition shadow-md">
                                Send Direct Message
                            </button>
                        </form>
                    </div>

                </div>

            </div>
        <?php else: ?>
            <div class="text-center py-20 bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 space-y-4">
                <p class="text-slate-400 text-sm font-light">No member profile coordinates loaded. Please return to the management screen.</p>
                <a href="users.php" class="inline-block py-2 px-6 bg-bushgreen text-white rounded-xl text-xs font-bold">
                    Return to User Management
                </a>
            </div>
        <?php endif; ?>

    </main>
</body>
</html>
