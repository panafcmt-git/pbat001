<?php
/**
 * PBAT Smart Nation Initiative - Live Command Center
 * Premium feature providing real-time operations overview, tickers of logins, and active campaigns.
 */
require_once dirname(__DIR__) . '/helpers/auth.php';
require_once dirname(__DIR__) . '/helpers/common.php';
require_once dirname(__DIR__) . '/config/database.php';

Auth::requireRole(['super_admin', 'founder_circle'], '../login.php');

$user = Auth::user();
$error = '';
$success = '';

try {
    $db = Database::connect();

    // 1. Fetch real-time registrations ticker
    $registrations = $db->query("
        SELECT name, email, created_at 
        FROM users 
        ORDER BY created_at DESC 
        LIMIT 10
    ")->fetchAll();

    // 2. Fetch live streams
    $streams = $db->query("
        SELECT title, status, scheduled_at 
        FROM livestreams 
        ORDER BY scheduled_at ASC 
        LIMIT 5
    ")->fetchAll();

    // 3. Fetch active campaigns
    $campaigns = $db->query("
        SELECT title, status 
        FROM campaigns 
        ORDER BY scheduled_at DESC 
        LIMIT 5
    ")->fetchAll();

    // 4. Fetch recent logs
    $recent_logs = $db->query("
        SELECT a.*, u.name as user_name 
        FROM audit_logs a 
        LEFT JOIN users u ON a.user_id = u.id 
        ORDER BY a.created_at DESC 
        LIMIT 8
    ")->fetchAll();

} catch (Exception $e) {
    $error = "Command Center Error: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Live Command Center - PBAT Smart Nation</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        bushgreen: {
                            DEFAULT: '#063C1E',
                            light: '#0A4D27',
                            dark: '#03200F',
                        },
                        gold: '#D4AF37'
                    }
                }
            }
        }
    </script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        [x-cloak] { display: none !important; }
        body { font-family: 'Inter', sans-serif; }
        h1, h2, h3, h4, .font-display { font-family: 'Outfit', sans-serif; }
    </style>
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
</head>
<body class="bg-slate-50 text-slate-800 transition-colors duration-200 min-h-screen flex flex-col antialiased"
      x-data="{ darkMode: localStorage.getItem('darkMode') === 'true' }"
      x-init="$watch('darkMode', val => localStorage.setItem('darkMode', val))"
      :class="{ 'dark bg-slate-900 text-slate-100': darkMode }">

    <!-- Header Navbar -->
    <header class="bg-bushgreen text-white border-b-2 border-gold h-20 flex items-center justify-between px-6 shadow-md relative z-30">
        <div class="flex items-center gap-3">
            <a href="dashboard.php" class="py-1.5 px-3 border border-white/20 hover:bg-white/10 text-white rounded-lg text-xs font-bold transition">
                &larr; Back to Dashboard
            </a>
            <div class="w-8 h-8 rounded bg-white/10 flex items-center justify-center border border-white/20 p-1 flex-shrink-0">
                <?php echo getAppLogoHtml('w-full h-full object-contain', 'dashboard'); ?>
            </div>
            <span class="text-white font-extrabold text-sm font-display hidden sm:inline">PBAT SMART NATION INITIATIVE</span>
        </div>
        <div class="flex items-center gap-4 text-xs font-bold text-gold uppercase tracking-wider">
            <!-- Dark Mode Toggle -->
            <button @click="darkMode = !darkMode" class="p-2 rounded-lg border border-gold/45 text-gold hover:bg-gold/10 transition flex items-center justify-center">
                <svg x-show="darkMode" class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364-6.364l-.707.707M6.364 17.636l-.707.707M18.364 17.636l-.707-.707M6.364 6.364l-.707-.707M15 12a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                <svg x-show="!darkMode" class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z"/></svg>
            </button>
            <span class="flex items-center gap-1.5">
                <span class="w-2.5 h-2.5 bg-red-500 rounded-full animate-ping"></span>
                Live Command Console
            </span>
        </div>
    </header>

    <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 flex-grow w-full space-y-10">
        
        <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div class="space-y-1">
                <h1 class="text-2xl sm:text-3xl font-black text-bushgreen dark:text-gold font-display">Live Command Center</h1>
                <p class="text-slate-500 dark:text-slate-400 text-xs font-light">Real-time monitoring console listing live streams, registrations ticker, active campaigns, and user operations.</p>
            </div>
        </div>

        <!-- Scrolling Ticker -->
        <div class="bg-bushgreen-dark text-gold p-3.5 rounded-2xl border border-gold/30 shadow-md overflow-hidden relative">
            <div class="flex gap-4 items-center">
                <span class="bg-red-500 text-white text-[9px] font-bold px-2 py-0.5 rounded animate-pulse uppercase">Ticker</span>
                <marquee class="text-xs font-mono tracking-wide leading-none select-none">
                    <?php foreach ($registrations as $reg): ?>
                        &bull; [Registration] <?php echo htmlspecialchars($reg['name']); ?> registered successfully! (<?php echo date('H:i', strtotime($reg['created_at'])); ?>) &nbsp;&nbsp;&nbsp;&nbsp;
                    <?php endforeach; ?>
                </marquee>
            </div>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            
            <!-- REAL-TIME OPERATIONS FEED (Col 8) -->
            <div class="lg:col-span-8 bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-4">
                <h3 class="text-slate-800 dark:text-slate-200 font-bold text-sm">Real-Time Administrative Log Stream</h3>
                <div class="space-y-3">
                    <?php foreach ($recent_logs as $log): ?>
                        <div class="p-3 bg-slate-50 dark:bg-slate-900/50 rounded-xl border border-slate-100 dark:border-slate-800 text-xs flex justify-between items-center">
                            <div>
                                <span class="font-bold text-slate-800 dark:text-slate-200 block"><?php echo htmlspecialchars($log['details']); ?></span>
                                <span class="text-[9px] text-slate-400">Triggered by: <?php echo htmlspecialchars($log['user_name'] ?? 'Guest'); ?> &bull; IP: <?php echo htmlspecialchars($log['ip_address']); ?></span>
                            </div>
                            <span class="text-[10px] text-slate-400 dark:text-slate-500 font-mono"><?php echo date('H:i:s', strtotime($log['created_at'])); ?></span>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- REGISTRIES SUMMARY (Col 4) -->
            <div class="lg:col-span-4 space-y-6">
                <!-- Campaigns checks -->
                <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-4">
                    <h3 class="text-slate-800 dark:text-slate-200 font-bold text-sm">Campaign Active Progress</h3>
                    <div class="space-y-2.5 text-xs leading-normal">
                        <?php foreach ($campaigns as $camp): ?>
                            <div class="flex justify-between items-center pb-2 border-b border-slate-100 dark:border-slate-700">
                                <span class="font-semibold text-slate-700 dark:text-slate-300"><?php echo htmlspecialchars($camp['title']); ?></span>
                                <span class="px-2 py-0.5 rounded text-[8px] font-bold uppercase
                                    <?php echo $camp['status'] === 'active' ? 'bg-emerald-50 text-emerald-800' : 'bg-slate-100 text-slate-600'; ?>">
                                    <?php echo htmlspecialchars($camp['status']); ?>
                                </span>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- Streams checks -->
                <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-4">
                    <h3 class="text-slate-800 dark:text-slate-200 font-bold text-sm">TV Stream Schedules</h3>
                    <div class="space-y-2.5 text-xs leading-normal">
                        <?php foreach ($streams as $str): ?>
                            <div class="flex justify-between items-center pb-2 border-b border-slate-100 dark:border-slate-700">
                                <span class="font-semibold text-slate-700 dark:text-slate-300"><?php echo htmlspecialchars($str['title']); ?></span>
                                <span class="px-2 py-0.5 rounded text-[8px] font-bold uppercase
                                    <?php echo $str['status'] === 'live' ? 'bg-red-500 text-white animate-pulse' : 'bg-slate-100 text-slate-600'; ?>">
                                    <?php echo htmlspecialchars($str['status']); ?>
                                </span>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>

        </div>

    </main>
</body>
</html>
