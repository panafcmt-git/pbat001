<?php
/**
 * PBAT Smart Nation Initiative - User Management System
 * Full CRUD, bulk import/export, filters, password resets, and login history audits.
 */
require_once dirname(__DIR__) . '/helpers/auth.php';
require_once dirname(__DIR__) . '/helpers/common.php';
require_once dirname(__DIR__) . '/helpers/notifications.php';
require_once dirname(__DIR__) . '/config/database.php';

Auth::requireRole(['super_admin', 'founder_circle'], '../login.php');

$user = Auth::user();
$error = '';
$success = '';

try {
    $db = Database::connect();

    // 1. Handle Bulk CSV Export
    if (isset($_GET['action']) && $_GET['action'] === 'export_csv') {
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=users_export_' . date('Ymd') . '.csv');
        $output = fopen('php://output', 'w');
        fputcsv($output, ['ID', 'Name', 'Email', 'Phone', 'Role ID', 'Status', 'Verified']);
        
        $stmt_export = $db->query("SELECT id, name, email, phone, role_id, status, email_verified FROM users ORDER BY id ASC");
        while ($row = $stmt_export->fetch(PDO::FETCH_ASSOC)) {
            fputcsv($output, $row);
        }
        fclose($output);
        exit;
    }

    // 2. Handle CRUD Actions
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
        if (!Auth::validateCsrf($_POST['csrf_token'] ?? '')) {
            $error = "CSRF Token validation failed.";
        } else {
            $action = $_POST['action'];

            // 2.1 CREATE USER
            if ($action === 'create_user') {
                $name = trim($_POST['name']);
                $email = trim($_POST['email']);
                $phone = trim($_POST['phone']);
                $role_id = (int)$_POST['role_id'];

                if (empty($name) || empty($email) || empty($role_id)) {
                    $error = "Name, Email, and Role Level are required parameters.";
                } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                    $error = "Invalid email formatting.";
                } else {
                    try {
                        // Check if user already exists
                        $stmt_chk = $db->prepare("SELECT COUNT(1) FROM users WHERE email = ?");
                        $stmt_chk->execute([$email]);
                        if ($stmt_chk->fetchColumn() > 0) {
                            $error = "An account with this email address already exists.";
                        } else {
                            $db->beginTransaction();
                            
                            // Generate cryptographically secure random password
                            $temp_password = bin2hex(random_bytes(16));
                            $hash = password_hash($temp_password, PASSWORD_BCRYPT);
                            
                            // Generate reset token active for 24 hours
                            $reset_token = bin2hex(random_bytes(32));
                            $reset_expires = date('Y-m-d H:i:s', strtotime('+24 hours'));
                            
                            $stmt = $db->prepare("INSERT INTO `users` (`name`, `email`, `password`, `role_id`, `phone`, `status`, `email_verified`, `reset_token`, `reset_expires`) VALUES (?, ?, ?, ?, ?, 'active', 1, ?, ?)");
                            $stmt->execute([$name, $email, $hash, $role_id, $phone, $reset_token, $reset_expires]);
                            $new_user_id = $db->lastInsertId();
                            
                            // Get role name to send in welcome email
                            $stmt_role = $db->prepare("SELECT display_name FROM roles WHERE id = ?");
                            $stmt_role->execute([$role_id]);
                            $role_display = $stmt_role->fetchColumn() ?: 'Grassroots Member';

                            // Relational table entries depending on role
                            if ($role_id == 7) {
                                // Ambassador
                                $state_id = (int)($_POST['state_id'] ?? 0);
                                $lga_id = (int)($_POST['lga_id'] ?? 0);
                                $ward_id = (int)($_POST['ward_id'] ?? 0);
                                
                                if (empty($state_id) || empty($lga_id) || empty($ward_id)) {
                                    throw new Exception("State, LGA, and Ward are required for Ambassadors.");
                                }
                                
                                $uuid = generateUuid('AMB-');
                                $hash_qr = hash('sha256', $uuid . time());
                                $stmt_amb = $db->prepare("INSERT INTO `ambassadors` (`user_id`, `uuid`, `state_id`, `lga_id`, `ward_id`, `qr_code_hash`, `is_verified`) VALUES (?, ?, ?, ?, ?, ?, 1)");
                                $stmt_amb->execute([$new_user_id, $uuid, $state_id, $lga_id, $ward_id, $hash_qr]);
                            } elseif (in_array($role_id, [3, 4, 5, 6])) {
                                // Leadership
                                $tier_id = 1;
                                $zone = null;
                                $state_id = null;
                                $lga_id = null;
                                
                                if ($role_id == 3) {
                                    $tier_id = 1; // National
                                } elseif ($role_id == 4) {
                                    $tier_id = 2; // Zonal
                                    $zone = trim($_POST['zone'] ?? '');
                                    if (empty($zone)) {
                                        throw new Exception("Zone is required for Zonal Chairmen.");
                                    }
                                } elseif ($role_id == 5) {
                                    $tier_id = 3; // State
                                    $state_id = (int)($_POST['state_id'] ?? 0);
                                    if (empty($state_id)) {
                                        throw new Exception("State is required for State Chairmen.");
                                    }
                                    // Fetch zone from state
                                    $stmt_z = $db->prepare("SELECT zone FROM states WHERE id = ?");
                                    $stmt_z->execute([$state_id]);
                                    $zone = $stmt_z->fetchColumn();
                                } elseif ($role_id == 6) {
                                    $tier_id = 4; // LGA Coordinator
                                    $state_id = (int)($_POST['state_id'] ?? 0);
                                    $lga_id = (int)($_POST['lga_id'] ?? 0);
                                    if (empty($state_id) || empty($lga_id)) {
                                        throw new Exception("State and LGA are required for LGA Coordinators.");
                                    }
                                    // Fetch zone from state
                                    $stmt_z = $db->prepare("SELECT zone FROM states WHERE id = ?");
                                    $stmt_z->execute([$state_id]);
                                    $zone = $stmt_z->fetchColumn();
                                }
                                
                                $stmt_lead = $db->prepare("INSERT INTO `user_leadership` (`user_id`, `tier_id`, `zone`, `state_id`, `lga_id`, `appointed_by`) VALUES (?, ?, ?, ?, ?, ?)");
                                $stmt_lead->execute([$new_user_id, $tier_id, $zone, $state_id, $lga_id, $user['id']]);
                            }

                            // Commit transaction
                            $db->commit();
                            
                            // Send new user invitation email
                            $http_host = $_SERVER['HTTP_HOST'] ?? 'localhost';
                            $base_dir = rtrim(dirname(dirname($_SERVER['PHP_SELF'])), '/\\');
                            $reset_link = "http://{$http_host}" . $base_dir . "/reset-password.php?token=" . $reset_token;
                            
                            NotificationEmail::sendNewUserInvitation($email, $name, $reset_link, $role_display);
                            
                            Auth::logAction($user['id'], 'USER_CREATE', "Created and invited user account: {$email} (Role: {$role_display})");
                            $success = "User account successfully provisioned and welcome invitation sent!";
                        }
                    } catch (Exception $ex) {
                        if (isset($db) && $db->inTransaction()) {
                            $db->rollBack();
                        }
                        $error = "Provisioning Failed: " . $ex->getMessage();
                    }
                }
            }

            // 2.2 EDIT USER
            if ($action === 'edit_user') {
                $edit_id = (int)$_POST['edit_id'];
                $name = trim($_POST['name']);
                $email = trim($_POST['email']);
                $phone = trim($_POST['phone']);
                $role_id = (int)$_POST['role_id'];

                if ($edit_id === $user['id']) {
                    $error = "You cannot modify your own administrative coordinates.";
                } else {
                    $stmt = $db->prepare("UPDATE `users` SET `name` = ?, `email` = ?, `phone` = ?, `role_id` = ? WHERE `id` = ?");
                    $stmt->execute([$name, $email, $phone, $role_id, $edit_id]);
                    
                    Auth::logAction($user['id'], 'USER_EDIT', "Modified credentials for user ID {$edit_id}");
                    $success = "User credentials updated successfully!";
                }
            }

            // 2.3 RESET PASSWORD
            if ($action === 'reset_pass') {
                $target_id = (int)$_POST['target_id'];
                $new_pass = trim($_POST['new_password']);

                if (empty($new_pass)) {
                    $error = "Password cannot be blank.";
                } else {
                    $hash = password_hash($new_pass, PASSWORD_BCRYPT);
                    $stmt = $db->prepare("UPDATE `users` SET `password` = ? WHERE `id` = ?");
                    $stmt->execute([$hash, $target_id]);

                    Auth::logAction($user['id'], 'USER_PASSWORD_RESET', "Reset passcode keys for user ID {$target_id}");
                    $success = "Password reset completed successfully!";
                }
            }

            // 2.4 DELETE USER
            if ($action === 'delete_user') {
                $delete_id = (int)$_POST['delete_id'];
                if ($delete_id === $user['id']) {
                    $error = "You cannot delete your own session credentials.";
                } else {
                    $stmt = $db->prepare("DELETE FROM `users` WHERE `id` = ?");
                    $stmt->execute([$delete_id]);

                    Auth::logAction($user['id'], 'USER_DELETE', "Deleted user account ID {$delete_id}");
                    $success = "User account removed successfully!";
                }
            }

            // 2.5 STATUS TOGGLE (Suspend/Activate)
            if ($action === 'toggle_status') {
                $target_user_id = (int)$_POST['target_user_id'];
                $new_status = trim($_POST['new_status']);

                if ($target_user_id === $user['id']) {
                    $error = "You cannot suspend your own credentials.";
                } elseif (in_array($new_status, ['active', 'suspended'])) {
                    $stmt = $db->prepare("UPDATE `users` SET `status` = ? WHERE `id` = ?");
                    $stmt->execute([$new_status, $target_user_id]);

                    // Send email notification
                    $stmt_target = $db->prepare("SELECT `name`, `email` FROM `users` WHERE `id` = ?");
                    $stmt_target->execute([$target_user_id]);
                    $target_user = $stmt_target->fetch();

                    if ($target_user) {
                        if ($new_status === 'suspended') {
                            NotificationEmail::sendProfileSuspended($target_user['email'], $target_user['name'], "Administrative policy check.");
                            Auth::logAction($user['id'], 'USER_SUSPEND', "Suspended account: {$target_user['email']}");
                        } else {
                            NotificationEmail::sendProfileReactivated($target_user['email'], $target_user['name']);
                            Auth::logAction($user['id'], 'USER_REACTIVATE', "Reactivated account: {$target_user['email']}");
                        }
                    }
                    $success = "User status switched to '{$new_status}' successfully.";
                }
            }

            // 2.5.5 MANUALLY VERIFY & ACTIVATE USER (Super Admin Only)
            if ($action === 'admin_verify_user') {
                if ($user['role'] !== 'super_admin') {
                    $error = "Access Denied. Only Super Admin can verify users.";
                } else {
                    $target_user_id = (int)$_POST['target_user_id'];
                    
                    $stmt_usr = $db->prepare("SELECT name, email FROM users WHERE id = ?");
                    $stmt_usr->execute([$target_user_id]);
                    $target_user_info = $stmt_usr->fetch();
                    
                    if ($target_user_info) {
                        $stmt_up = $db->prepare("UPDATE `users` SET `email_verified` = 1, `email_token` = NULL, `status` = 'active' WHERE `id` = ?");
                        $stmt_up->execute([$target_user_id]);
                        
                        Auth::logAction($user['id'], 'USER_MANUAL_VERIFY', "Manually verified and activated user: {$target_user_info['email']} (ID {$target_user_id})");
                        
                        // Send welcome activation email
                        NotificationEmail::sendWelcomeActivation($target_user_info['email'], $target_user_info['name']);
                        
                        $success = "User account manually verified and activated successfully!";
                    } else {
                        $error = "User not found.";
                    }
                }
            }
            // 2.5.6 RESEND PASSWORD RESET EMAIL
            if ($action === 'resend_reset_email') {
                $target_user_id = (int)$_POST['target_user_id'];
                
                $stmt_target = $db->prepare("SELECT `name`, `email` FROM `users` WHERE `id` = ?");
                $stmt_target->execute([$target_user_id]);
                $target_user = $stmt_target->fetch();
                
                if ($target_user) {
                    $reset_token = bin2hex(random_bytes(32));
                    $reset_expires = date('Y-m-d H:i:s', strtotime('+24 hours'));
                    $stmt = $db->prepare("UPDATE `users` SET `reset_token` = ?, `reset_expires` = ? WHERE `id` = ?");
                    $stmt->execute([$reset_token, $reset_expires, $target_user_id]);
                    
                    $http_host = $_SERVER['HTTP_HOST'] ?? 'localhost';
                    $base_dir = rtrim(dirname(dirname($_SERVER['PHP_SELF'])), '/\\');
                    $reset_link = "http://{$http_host}" . $base_dir . "/reset-password.php?token=" . $reset_token;
                    
                    NotificationEmail::sendPasswordRecovery($target_user['email'], $target_user['name'], $reset_link);
                    
                    Auth::logAction($user['id'], 'USER_RESEND_RESET_EMAIL', "Resent password reset invitation email to: {$target_user['email']}");
                    $success = "Password reset invitation email successfully resent to " . htmlspecialchars($target_user['name']) . "!";
                } else {
                    $error = "User not found.";
                }
            }

            // 2.5.7 SEND KYC & PROFILE PHOTO REMINDER
            if ($action === 'send_kyc_reminder') {
                $target_user_id = (int)$_POST['target_user_id'];
                
                $stmt_target = $db->prepare("SELECT `name`, `email` FROM `users` WHERE `id` = ?");
                $stmt_target->execute([$target_user_id]);
                $target_user = $stmt_target->fetch();
                
                if ($target_user) {
                    NotificationEmail::sendKycReminder($target_user['email'], $target_user['name']);
                    
                    Auth::logAction($user['id'], 'USER_KYC_REMINDER', "Sent profile KYC & photo reminder email to: {$target_user['email']}");
                    $success = "Profile KYC & photo completion reminder email successfully sent to " . htmlspecialchars($target_user['name']) . "!";
                } else {
                    $error = "User not found.";
                }
            }

            // 2.5.8 APPROVE KYC (Super Admin Only)
            if ($action === 'approve_kyc') {
                if ($user['role'] !== 'super_admin') {
                    $error = "Access Denied. Only Super Admin can approve KYC profiles.";
                } else {
                    $target_user_id = (int)$_POST['target_user_id'];

                    // Fetch target user details + current kyc status
                    $stmt_kyc_usr = $db->prepare(
                        "SELECT u.name, u.email, u.membership_code, kyc.kyc_status
                         FROM users u
                         LEFT JOIN user_kyc_extended kyc ON u.id = kyc.user_id
                         WHERE u.id = ?
                         LIMIT 1"
                    );
                    $stmt_kyc_usr->execute([$target_user_id]);
                    $kyc_target = $stmt_kyc_usr->fetch(PDO::FETCH_ASSOC);

                    if (!$kyc_target) {
                        $error = "User not found.";
                    } elseif ($kyc_target['kyc_status'] !== 'pending_review') {
                        $error = "KYC cannot be approved. Status must be 'Pending Review'. Only submitted KYC profiles awaiting review can be approved.";
                    } else {
                        // Update kyc_status to approved in user_kyc_extended
                        $stmt_upd_kyc = $db->prepare(
                            "UPDATE user_kyc_extended SET kyc_status = 'approved' WHERE user_id = ?"
                        );
                        $stmt_upd_kyc->execute([$target_user_id]);

                        Auth::logAction($user['id'], 'KYC_APPROVED', "Approved KYC profile for: {$kyc_target['email']} (ID {$target_user_id})");

                        // Send KYC approval notification email with membership code
                        $membership_code = $kyc_target['membership_code'] ?? 'N/A';
                        NotificationEmail::sendKycApproved(
                            $kyc_target['email'],
                            $kyc_target['name'],
                            $membership_code,
                            $user['name']
                        );

                        $success = "KYC for <strong>" . htmlspecialchars($kyc_target['name']) . "</strong> has been approved successfully! Approval notification email dispatched.";
                    }
                }
            }

            // 2.6 BULK CSV IMPORT
            if ($action === 'import_csv') {
                if (isset($_FILES['csv_file']) && $_FILES['csv_file']['error'] === UPLOAD_ERR_OK) {
                    $file_tmp = $_FILES['csv_file']['tmp_name'];
                    
                    // Fetch roles, first state, and first LGA to avoid foreign key failures
                    $roles_stmt = $db->query("SELECT id, name, display_name FROM roles");
                    $roles_db = $roles_stmt->fetchAll(PDO::FETCH_ASSOC);

                    $state_stmt = $db->query("SELECT id FROM states LIMIT 1");
                    $first_state_id = $state_stmt->fetchColumn() ?: 1;

                    $lga_stmt = $db->prepare("SELECT id FROM lgas WHERE state_id = ? LIMIT 1");
                    $lga_stmt->execute([$first_state_id]);
                    $first_lga_id = $lga_stmt->fetchColumn() ?: 1;

                    if (($handle = fopen($file_tmp, "r")) !== FALSE) {
                        // Skip header row
                        fgetcsv($handle, 1000, ",");
                        $import_count = 0;
                        while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
                            if (count($data) >= 3) {
                                $name = trim($data[0]);
                                $email = trim($data[1]);
                                $phone = trim($data[2]);
                                
                                // Robust role validation
                                $role_input = isset($data[3]) ? trim($data[3]) : '';
                                $role_id = 7; // Default to Grassroots Ambassador

                                if (!empty($role_input)) {
                                    if (is_numeric($role_input)) {
                                        $check_id = (int)$role_input;
                                        foreach ($roles_db as $r) {
                                            if ((int)$r['id'] === $check_id) {
                                                $role_id = $check_id;
                                                break;
                                            }
                                        }
                                    } else {
                                        $role_input_lower = strtolower($role_input);
                                        foreach ($roles_db as $r) {
                                            if (strtolower($r['name']) === $role_input_lower || 
                                                strtolower($r['display_name']) === $role_input_lower) {
                                                $role_id = (int)$r['id'];
                                                break;
                                            }
                                        }
                                    }
                                }

                                $pass_hash = password_hash('password123', PASSWORD_BCRYPT); // default pass

                                // Check if user already exists
                                $stmt_chk = $db->prepare("SELECT COUNT(1) FROM users WHERE email = ?");
                                $stmt_chk->execute([$email]);
                                if ($stmt_chk->fetchColumn() == 0) {
                                    $stmt_ins = $db->prepare("INSERT INTO `users` (`name`, `email`, `password`, `role_id`, `phone`, `status`, `email_verified`) VALUES (?, ?, ?, ?, ?, 'active', 1)");
                                    $stmt_ins->execute([$name, $email, $pass_hash, $role_id, $phone]);
                                    
                                    $new_id = $db->lastInsertId();
                                    if ($role_id == 7) {
                                        $uuid = 'AMB-' . strtoupper(bin2hex(random_bytes(3))) . '-' . rand(1000, 9999);
                                        $hash_qr = md5($uuid);
                                        $stmt_amb = $db->prepare("INSERT INTO `ambassadors` (`user_id`, `uuid`, `state_id`, `lga_id`, `qr_code_hash`, `is_verified`) VALUES (?, ?, ?, ?, ?, 1)");
                                        $stmt_amb->execute([$new_id, $uuid, $first_state_id, $first_lga_id, $hash_qr]);
                                    }
                                    $import_count++;
                                }
                            }
                        }
                        fclose($handle);
                        Auth::logAction($user['id'], 'USER_CSV_IMPORT', "Bulk imported {$import_count} members from CSV file.");
                        $success = "Successfully imported {$import_count} new accounts from CSV file!";
                    }
                } else {
                    $error = "CSV upload error. No file selected.";
                }
            }

            // 2.7 SEND BULK MESSAGE
            if ($action === 'send_bulk_message') {
                $user_ids_str = trim($_POST['user_ids'] ?? '');
                $message_content = trim($_POST['message_content'] ?? '');
                
                if (empty($user_ids_str) || empty($message_content)) {
                    $error = "Recipient list and message content cannot be empty.";
                } else {
                    $user_ids = array_filter(array_map('intval', explode(',', $user_ids_str)));
                    if (empty($user_ids)) {
                        $error = "Invalid recipient list.";
                    } else {
                        $stmt_msg = $db->prepare("INSERT INTO `messages` (`sender_id`, `recipient_id`, `channel`, `subject`, `body`) VALUES (?, ?, 'direct', 'Direct Message', ?)");
                        $stmt_notif = $db->prepare("INSERT INTO `notifications` (`user_id`, `message`, `type`) VALUES (?, ?, 'message')");
                        
                        $count = 0;
                        foreach ($user_ids as $uid) {
                            $stmt_msg->execute([$user['id'], $uid, $message_content]);
                            $stmt_notif->execute([$uid, "New direct message from Admin: " . substr($message_content, 0, 30) . "..."]);
                            $count++;
                        }
                        
                        Auth::logAction($user['id'], 'BULK_MESSAGE_SEND', "Sent direct message to {$count} users.");
                        $success = "Successfully dispatched direct message to {$count} selected users.";
                    }
                }
            }

            // 2.8 ASSIGN LEADERSHIP TIER
            if ($action === 'assign_leadership') {
                if ($user['role'] !== 'super_admin') {
                    $error = "Access Denied. Only Super Admin can perform leadership promotions.";
                } else {
                    $target_user_id = (int)$_POST['target_user_id'];
                    $tier_id_raw = $_POST['tier_id'];
                    $is_super_admin_promo = ($tier_id_raw === 'super_admin_role');
                    $tier_id = $is_super_admin_promo ? null : (int)$tier_id_raw;
                    
                    $stmt_usr = $db->prepare("SELECT id, name, email FROM users WHERE id = ?");
                    $stmt_usr->execute([$target_user_id]);
                    $target_user = $stmt_usr->fetch();
                    
                    if (!$target_user) {
                        $error = "The specified user does not exist.";
                    } else {
                        $zone = !empty($_POST['zone']) ? trim($_POST['zone']) : null;
                        $state_id = !empty($_POST['state_id']) ? (int)$_POST['state_id'] : null;
                        $lga_id = !empty($_POST['lga_id']) ? (int)$_POST['lga_id'] : null;
                        $ward_id = !empty($_POST['ward_id']) ? (int)$_POST['ward_id'] : null;
                        
                        try {
                            $db->beginTransaction();
                            
                            // Map tier_id to role_id
                            if ($is_super_admin_promo) {
                                $role_id = 1;
                            } else {
                                $role_id = 7; // Default ambassador (Tier 5)
                                if ($tier_id === 1) $role_id = 3; // National Steering Council
                                elseif ($tier_id === 2) $role_id = 4; // Zonal Chairman
                                elseif ($tier_id === 3) $role_id = 5; // State Chairman
                                elseif ($tier_id === 4) $role_id = 6; // LGA Coordinator
                            }
                            
                            // Clear existing leadership mappings to avoid conflicts
                            $stmt_del_lead = $db->prepare("DELETE FROM `user_leadership` WHERE `user_id` = ?");
                            $stmt_del_lead->execute([$target_user_id]);
                            
                            // Clear existing ambassador mappings
                            $stmt_del_amb = $db->prepare("DELETE FROM `ambassadors` WHERE `user_id` = ?");
                            $stmt_del_amb->execute([$target_user_id]);
                            
                            // Auto-resolve zone from state if state is provided and zone is not explicitly set
                            if (!empty($state_id) && empty($zone)) {
                                $stmt_z = $db->prepare("SELECT zone FROM states WHERE id = ?");
                                $stmt_z->execute([$state_id]);
                                $zone = $stmt_z->fetchColumn() ?: null;
                            }
                            
                            if (!$is_super_admin_promo) {
                                if ($tier_id >= 1 && $tier_id <= 4) {
                                    $stmt_ins = $db->prepare("
                                        INSERT INTO `user_leadership` (`user_id`, `tier_id`, `zone`, `state_id`, `lga_id`, `ward_id`, `appointed_by`)
                                        VALUES (?, ?, ?, ?, ?, ?, ?)
                                    ");
                                    $stmt_ins->execute([$target_user_id, $tier_id, $zone, $state_id, $lga_id, $ward_id, $user['id']]);
                                } elseif ($tier_id === 5) {
                                    $uuid = generateUuid('AMB-');
                                    $hash_qr = hash('sha256', $uuid . time());
                                    $stmt_amb = $db->prepare("
                                        INSERT INTO `ambassadors` (`user_id`, `uuid`, `state_id`, `lga_id`, `ward_id`, `qr_code_hash`, `is_verified`)
                                        VALUES (?, ?, ?, ?, ?, ?, 1)
                                    ");
                                    $stmt_amb->execute([$target_user_id, $uuid, $state_id, $lga_id, $ward_id, $hash_qr]);
                                }
                            }
                            
                            // Update user role
                            $stmt_upd_role = $db->prepare("UPDATE `users` SET `role_id` = ? WHERE `id` = ?");
                            $stmt_upd_role->execute([$role_id, $target_user_id]);
                            
                            Auth::logAction($user['id'], 'USER_PROMOTION', "Promoted user {$target_user['email']} (ID {$target_user_id}) to Tier " . ($is_super_admin_promo ? 'Super Admin' : $tier_id));
                            $db->commit();
                            
                            // Get role display name
                            $stmt_role = $db->prepare("SELECT display_name FROM roles WHERE id = ?");
                            $stmt_role->execute([$role_id]);
                            $role_display = $stmt_role->fetchColumn() ?: 'Grassroots Member';
                            
                            // Send appointment notification email
                            NotificationEmail::sendAppointment($target_user['email'], $target_user['name'], $role_display, $user['name']);
                            
                            $success = "User " . htmlspecialchars($target_user['name']) . " successfully assigned to leadership " . $role_display . "!";
                        } catch (Exception $ex) {
                            if ($db->inTransaction()) {
                                $db->rollBack();
                            }
                            $error = "Leadership Assignment Failed: " . $ex->getMessage();
                        }
                    }
                }
            }
        }
    }

    // 3. Search, Filters, and Pagination
    $search = trim($_GET['search'] ?? '');
    $role_filter = trim($_GET['role_id'] ?? '');
    $completion_filter = trim($_GET['completion'] ?? '');

    // Determine page size (options: 50, 100, 200, 500)
    $per_page = 50;
    if (isset($_GET['per_page']) && in_array((int)$_GET['per_page'], [50, 100, 200, 500])) {
        $per_page = (int)$_GET['per_page'];
    }

    // Determine current page
    $page = 1;
    if (isset($_GET['page']) && (int)$_GET['page'] > 0) {
        $page = (int)$_GET['page'];
    }

    // Build the query conditions
    $where = " WHERE 1=1";
    $params = [];

    if (!empty($search)) {
        $where .= " AND (u.name LIKE ? OR u.email LIKE ?)";
        $search_val = "%{$search}%";
        $params[] = $search_val;
        $params[] = $search_val;
    }

    if (!empty($role_filter)) {
        $where .= " AND u.role_id = ?";
        $params[] = (int)$role_filter;
    }

    if ($completion_filter === 'fully_completed') {
        $where .= " AND kyc.kyc_status = 'approved' AND u.reset_token IS NULL";
    } elseif ($completion_filter === 'kyc_incomplete') {
        $where .= " AND (kyc.kyc_status IS NULL OR kyc.kyc_status != 'approved' OR u.avatar IS NULL OR u.avatar = 'assets/img/default-avatar.png')";
    } elseif ($completion_filter === 'invite_pending') {
        $where .= " AND u.reset_token IS NOT NULL";
    }

    // First fetch total matching users
    $stmt_count = $db->prepare("SELECT COUNT(1) FROM `users` u LEFT JOIN `user_kyc_extended` kyc ON u.id = kyc.user_id" . $where);
    $stmt_count->execute($params);
    $total_users = (int)$stmt_count->fetchColumn();

    // Calculate total pages
    $total_pages = max(1, ceil($total_users / $per_page));
    if ($page > $total_pages) {
        $page = $total_pages;
    }
    $offset = ($page - 1) * $per_page;

    // Fetch paginated user list
    $query = "
        SELECT u.*, r.display_name as role_display, kyc.kyc_status 
        FROM `users` u 
        JOIN `roles` r ON u.role_id = r.id 
        LEFT JOIN `user_kyc_extended` kyc ON u.id = kyc.user_id 
    " . $where . " ORDER BY u.created_at DESC LIMIT " . (int)$per_page . " OFFSET " . (int)$offset;

    $stmt = $db->prepare($query);
    $stmt->execute($params);
    $users_list = $stmt->fetchAll();

    // 4. Fetch Roles & Tiers
    $roles_list = $db->query("SELECT * FROM `roles` ORDER BY `id` ASC")->fetchAll();
    $tiers_list = $db->query("SELECT * FROM `leadership_tiers` ORDER BY `level` ASC")->fetchAll();
    
    // Fetch States & LGAs lists for provisioning jurisdictions
    $states_list = $db->query("SELECT `id`, `name`, `code`, `zone` FROM `states` ORDER BY `name` ASC")->fetchAll(PDO::FETCH_ASSOC);
    $lgas_list = $db->query("SELECT `id`, `name`, `state_id` FROM `lgas` ORDER BY `name` ASC")->fetchAll(PDO::FETCH_ASSOC);
    
    $state_zones = [];
    foreach ($states_list as $s) {
        $state_zones[$s['id']] = $s['zone'];
    }

    $lgas_by_state = [];
    foreach ($lgas_list as $lga) {
        $lgas_by_state[$lga['state_id']][] = [
            'id' => (int)$lga['id'],
            'name' => $lga['name']
        ];
    }

    // 5. Fetch Login History
    $login_history = $db->query("
        SELECT lh.*, u.name as user_name 
        FROM login_history lh
        JOIN users u ON lh.user_id = u.id
        ORDER BY lh.created_at DESC
        LIMIT 10
    ")->fetchAll();

} catch (Exception $e) {
    $error = "User Management System Error: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Management - PBAT Smart Nation</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        bushgreen: {
                            DEFAULT: '#063C1E',
                            light: '#0A4D27',
                            dark: '#03200F',
                        },
                        gold: '#D4AF37'
                    }
                }
            }
        }
    </script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; }
        h1, h2, h3, h4, .font-display { font-family: 'Outfit', sans-serif; }
        [x-cloak] { display: none !important; }
    </style>
    <!-- AlpineJS for Interactive Micro-Animations & State -->
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
</head>
<body class="bg-slate-50 text-slate-800 transition-colors duration-200 min-h-screen flex flex-col antialiased"
      x-data="{ 
          darkMode: localStorage.getItem('darkMode') === 'true', 
          selectedUsers: [], 
          showBulkModal: false, 
          bulkMessage: '',
          selectedRole: '',
          selectedState: '',
          selectedLga: '',
          selectedWard: '',
          selectedZone: '',
          lgas: <?php echo htmlspecialchars(json_encode($lgas_by_state), ENT_QUOTES, 'UTF-8'); ?>,
          stateZones: <?php echo htmlspecialchars(json_encode($state_zones), ENT_QUOTES, 'UTF-8'); ?>,
          wards: [],
          loadingWards: false,
          fetchWards() {
              if (!this.selectedLga) {
                  this.wards = [];
                  this.selectedWard = '';
                  return;
              }
              this.loadingWards = true;
              this.selectedWard = '';
              fetch('../api/wards.php?lga_id=' + this.selectedLga)
                  .then(res => res.json())
                  .then(data => {
                      this.wards = data;
                      this.loadingWards = false;
                  })
                  .catch(err => {
                      console.error('Error fetching wards:', err);
                      this.loadingWards = false;
                  });
          },
          showPromoteModal: false,
          promoteUserId: null,
          promoteUserName: '',
          promoteTierId: '',
          promoteZone: '',
          promoteStateId: '',
          promoteLgaId: '',
          promoteWardId: '',
          promoteWards: [],
          loadingPromoteWards: false,
          fetchPromoteWards() {
              if (!this.promoteLgaId) {
                  this.promoteWards = [];
                  this.promoteWardId = '';
                  return;
              }
              this.loadingPromoteWards = true;
              this.promoteWardId = '';
              fetch('../api/wards.php?lga_id=' + this.promoteLgaId)
                  .then(res => res.json())
                  .then(data => {
                      this.promoteWards = data;
                      this.loadingPromoteWards = false;
                  })
                  .catch(err => {
                      console.error('Error fetching promote wards:', err);
                      this.loadingPromoteWards = false;
                  });
          }
      }"
      x-init="$watch('darkMode', val => localStorage.setItem('darkMode', val))"
      :class="{ 'dark bg-slate-900 text-slate-100': darkMode }">

    <!-- Header Navbar -->
    <header class="bg-bushgreen text-white border-b-2 border-gold h-20 flex items-center justify-between px-6 shadow-md relative z-30">
        <div class="flex items-center gap-3">
            <a href="dashboard.php" class="py-1.5 px-3 border border-white/20 hover:bg-white/10 text-white rounded-lg text-xs font-bold transition">
                &larr; Back to Dashboard
            </a>
            <div class="w-8 h-8 rounded bg-white/10 flex items-center justify-center border border-white/20 p-1 flex-shrink-0">
                <?php echo getAppLogoHtml('w-full h-full object-contain', 'dashboard'); ?>
            </div>
            <span class="text-white font-extrabold text-sm font-display hidden sm:inline">PBAT SMART NATION INITIATIVE</span>
        </div>
        <div class="flex items-center gap-4 text-xs font-bold text-gold uppercase tracking-wider">
            <!-- Dark Mode Toggle -->
            <button @click="darkMode = !darkMode" class="p-2 rounded-lg border border-gold/45 text-gold hover:bg-gold/10 transition flex items-center justify-center">
                <svg x-show="darkMode" class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364-6.364l-.707.707M6.364 17.636l-.707.707M18.364 17.636l-.707-.707M6.364 6.364l-.707-.707M15 12a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                <svg x-show="!darkMode" class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z"/></svg>
            </button>
            <span>User Provisioning Hub</span>
        </div>
    </header>

    <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 flex-grow w-full space-y-10">
        
        <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div class="space-y-1">
                <h1 class="text-2xl sm:text-3xl font-black text-bushgreen dark:text-gold font-display">User Management Center</h1>
                <p class="text-slate-500 dark:text-slate-400 text-xs font-light">Create, edit, suspend, or delete users, execute bulk CSV actions, and inspect login device trails.</p>
            </div>

            <?php if (!empty($success)): ?>
                <div class="px-4 py-2 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs font-semibold">
                    <?php echo $success; ?>
                </div>
            <?php endif; ?>

            <?php if (!empty($error)): ?>
                <div class="px-4 py-2 bg-red-50 border border-red-200 text-red-800 rounded-xl text-xs font-semibold">
                    <?php echo $error; ?>
                </div>
            <?php endif; ?>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            
            <!-- ACTIONS PANEL (Col 4) -->
            <div class="lg:col-span-4 space-y-6">
                <!-- Create User -->
                <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-4">
                    <h3 class="text-slate-800 dark:text-slate-200 font-bold text-sm">Provision New Member</h3>
                    <form method="POST" action="" class="space-y-3">
                        <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                        <input type="hidden" name="action" value="create_user">

                        <div>
                            <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="name">Full Name *</label>
                            <input type="text" name="name" required class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                        </div>
                        <div>
                            <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="email">Email *</label>
                            <input type="email" name="email" required class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-mono">
                        </div>
                        <div>
                            <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="phone">Phone</label>
                            <input type="text" name="phone" class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-mono">
                        </div>
                        <div>
                            <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="role_id">Role Level *</label>
                            <select name="role_id" required x-model="selectedRole" @change="selectedState = ''; selectedLga = ''; selectedWard = ''; selectedZone = ''; wards = [];" class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                                <option value="">-- Choose Role --</option>
                                <?php foreach ($roles_list as $ro): ?>
                                    <option value="<?php echo $ro['id']; ?>"><?php echo htmlspecialchars($ro['display_name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <!-- ZONAL CHAIRMAN (Role ID = 4) -->
                        <div x-show="selectedRole == 4" class="space-y-1" x-transition x-cloak>
                            <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="zone">Geopolitical Zone *</label>
                            <select name="zone" :required="selectedRole == 4" class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                                <option value="">-- Choose Zone --</option>
                                <option value="South-West">South-West</option>
                                <option value="North-Central">North-Central</option>
                                <option value="South-South">South-South</option>
                                <option value="North-West">North-West</option>
                                <option value="South-East">South-East</option>
                                <option value="North-East">North-East</option>
                            </select>
                        </div>

                        <!-- STATE CHAIRMAN (Role ID = 5), LGA COORDINATOR (Role ID = 6), AMBASSADOR (Role ID = 7) -->
                        <div x-show="[5, 6, 7].includes(parseInt(selectedRole))" class="space-y-3" x-transition x-cloak>
                            <div>
                                <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="state_id">State *</label>
                                <select name="state_id" :required="[5, 6, 7].includes(parseInt(selectedRole))" x-model="selectedState" @change="selectedLga = ''; selectedWard = ''; wards = [];" class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                                    <option value="">-- Choose State --</option>
                                    <?php foreach ($states_list as $state): ?>
                                        <option value="<?php echo $state['id']; ?>"><?php echo htmlspecialchars($state['name']); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>

                        <!-- LGA COORDINATOR (Role ID = 6), AMBASSADOR (Role ID = 7) -->
                        <div x-show="[6, 7].includes(parseInt(selectedRole))" class="space-y-3" x-transition x-cloak>
                            <div>
                                <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="lga_id">LGA *</label>
                                <select name="lga_id" :required="[6, 7].includes(parseInt(selectedRole))" x-model="selectedLga" @change="fetchWards()" class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                                    <option value="">-- Choose LGA --</option>
                                    <template x-if="selectedState && lgas[selectedState]">
                                        <template x-for="lga in lgas[selectedState]" :key="lga.id">
                                            <option :value="lga.id" x-text="lga.name"></option>
                                        </template>
                                    </template>
                                </select>
                            </div>
                        </div>

                        <!-- AMBASSADOR (Role ID = 7) -->
                        <div x-show="selectedRole == 7" class="space-y-3" x-transition x-cloak>
                            <div>
                                <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="ward_id">Ward *</label>
                                <div class="relative">
                                    <select name="ward_id" :required="selectedRole == 7" x-model="selectedWard" :disabled="loadingWards || !selectedLga" class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen disabled:opacity-60">
                                        <option value="">-- Choose Ward --</option>
                                        <template x-for="ward in wards" :key="ward.id">
                                            <option :value="ward.id" x-text="ward.name"></option>
                                        </template>
                                    </select>
                                    <div x-show="loadingWards" class="absolute right-3 top-2 flex items-center gap-1 text-[9px] text-slate-400 font-medium bg-white px-2 py-0.5 rounded border border-slate-100 shadow-sm">
                                        <span class="w-1.5 h-1.5 rounded-full bg-gold animate-ping"></span>
                                        <span>fetching...</span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <button type="submit" class="w-full py-2 bg-bushgreen hover:bg-bushgreen-light text-white text-xs font-bold rounded-lg transition shadow-md">
                            Provision Member
                        </button>
                    </form>
                </div>

                <!-- CSV Bulk operations -->
                <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-4">
                    <h3 class="text-slate-800 dark:text-slate-200 font-bold text-sm">Bulk CSV Management</h3>
                    <form method="POST" action="" enctype="multipart/form-data" class="space-y-3">
                        <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                        <input type="hidden" name="action" value="import_csv">

                        <div>
                            <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1" for="csv_file">Upload CSV File</label>
                            <input type="file" name="csv_file" required accept=".csv" class="w-full text-xs text-slate-500 file:mr-4 file:py-1.5 file:px-3 file:rounded-xl file:border-0 file:bg-bushgreen/10 file:text-bushgreen">
                        </div>
                        <button type="submit" class="w-full py-2 bg-bushgreen hover:bg-bushgreen-light text-white text-xs font-bold rounded-lg transition shadow-md">
                            Import CSV List
                        </button>
                    </form>
                    
                    <a href="users.php?action=export_csv" class="block w-full py-2 text-center border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-xs font-bold rounded-lg hover:border-gold hover:text-gold transition">
                        Export Users to CSV
                    </a>
                </div>
            </div>

            <!-- USERS LIST & SEARCH (Col 8) -->
            <div class="lg:col-span-8 space-y-8">
                <!-- Bulk action bar -->
                <div x-show="selectedUsers.length > 0" x-transition class="flex items-center justify-between bg-gold/10 border border-gold/40 p-4 rounded-2xl mb-4">
                    <span class="text-xs font-bold text-slate-700 dark:text-gold">
                        Selected <span x-text="selectedUsers.length" class="font-extrabold text-bushgreen dark:text-gold"></span> users
                    </span>
                    <button @click="showBulkModal = true" class="py-1.5 px-4 bg-bushgreen hover:bg-bushgreen-light text-white text-xs font-bold rounded-xl transition shadow">
                        ✉️ Send Bulk Message
                    </button>
                </div>

                <!-- Search panel -->
                <div class="bg-white dark:bg-slate-800 p-4 rounded-2xl border border-slate-100 dark:border-slate-700 shadow-sm">
                    <form method="GET" class="flex flex-col sm:flex-row gap-4 items-center w-full">
                        <!-- Keep page size reset to 1 when search parameters change -->
                        <input type="hidden" name="page" value="1">
                        
                        <div class="relative flex-grow w-full">
                            <input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>" placeholder="Search by name or email..." class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                        </div>
                        <div class="flex flex-wrap gap-2 w-full sm:w-auto items-center">
                            <select name="role_id" onchange="this.form.submit()" class="px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                                <option value="">All Roles</option>
                                <?php foreach ($roles_list as $ro): ?>
                                    <option value="<?php echo $ro['id']; ?>" <?php echo $role_filter == $ro['id'] ? 'selected' : ''; ?>><?php echo htmlspecialchars($ro['display_name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                            
                            <select name="completion" onchange="this.form.submit()" class="px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                                <option value="">All Completion Status</option>
                                <option value="fully_completed" <?php echo $completion_filter === 'fully_completed' ? 'selected' : ''; ?>>Fully Completed (KYC + Invite)</option>
                                <option value="kyc_incomplete" <?php echo $completion_filter === 'kyc_incomplete' ? 'selected' : ''; ?>>KYC Incomplete</option>
                                <option value="invite_pending" <?php echo $completion_filter === 'invite_pending' ? 'selected' : ''; ?>>Invitation Pending</option>
                            </select>

                            <select name="per_page" onchange="this.form.submit()" class="px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen font-medium">
                                <option value="50" <?php echo $per_page == 50 ? 'selected' : ''; ?>>50 per page</option>
                                <option value="100" <?php echo $per_page == 100 ? 'selected' : ''; ?>>100 per page</option>
                                <option value="200" <?php echo $per_page == 200 ? 'selected' : ''; ?>>200 per page</option>
                                <option value="500" <?php echo $per_page == 500 ? 'selected' : ''; ?>>500 per page</option>
                            </select>
                            
                            <button type="submit" class="py-2 px-5 bg-bushgreen hover:bg-bushgreen-light text-white text-xs font-bold rounded-lg transition shadow-sm w-full sm:w-auto">
                                Filter
                            </button>
                        </div>
                    </form>
                </div>

                <!-- Users table -->
                <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm">
                    <div class="overflow-x-auto">
                        <table class="w-full text-xs text-left text-slate-500 dark:text-slate-400">
                            <thead class="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase border-b border-slate-100 dark:border-slate-700">
                                <tr>
                                    <th class="pb-3 w-8">
                                        <input type="checkbox" class="rounded border-slate-300 dark:border-slate-600 text-bushgreen focus:ring-bushgreen bg-slate-50 dark:bg-slate-900" 
                                               @change="selectedUsers = $el.checked ? [<?php echo implode(',', array_map(function($u) { return (int)$u['id']; }, $users_list)); ?>] : []"
                                               :checked="selectedUsers.length === <?php echo count($users_list); ?> && <?php echo count($users_list); ?> > 0">
                                    </th>
                                    <th class="pb-3">Name / Role</th>
                                    <th class="pb-3">Contact</th>
                                    <th class="pb-3">Status</th>
                                    <th class="pb-3 text-right">Actions</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-slate-50 dark:divide-slate-700">
                                <?php foreach ($users_list as $row): ?>
                                    <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-700/50" x-data="{ openReset: false }">
                                        <td class="py-3.5 pr-2 w-8">
                                            <input type="checkbox" :value="<?php echo (int)$row['id']; ?>" x-model.number="selectedUsers"
                                                   class="rounded border-slate-300 dark:border-slate-600 text-bushgreen focus:ring-bushgreen bg-slate-50 dark:bg-slate-900">
                                        </td>
                                        <td class="py-3.5 pr-2">
                                            <a href="user-details.php?id=<?php echo $row['id']; ?>" class="font-bold text-slate-800 dark:text-slate-200 block hover:text-gold transition">
                                                <?php echo htmlspecialchars($row['name']); ?>
                                            </a>
                                            <div class="flex items-center gap-1.5 mt-1 flex-wrap">
                                                <?php if (!empty($row['membership_code'])): ?>
                                                    <span class="text-[9px] px-2 py-0.5 rounded bg-gold/20 text-gold font-mono uppercase font-bold tracking-wider" title="Membership ID"><?php echo htmlspecialchars($row['membership_code']); ?></span>
                                                <?php endif; ?>
                                                <span class="text-[9px] px-2 py-0.5 rounded bg-bushgreen/10 text-bushgreen dark:bg-gold/10 dark:text-gold uppercase font-bold tracking-wider"><?php echo htmlspecialchars($row['role_display']); ?></span>
                                                
                                                <?php if ($row['kyc_status'] === 'approved' && empty($row['reset_token'])): ?>
                                                    <span class="text-[9px] px-1.5 py-0.5 rounded bg-emerald-600 text-white font-extrabold uppercase tracking-wide shadow-sm" title="KYC approved and Invitation responded">✓ Complete</span>
                                                <?php else: ?>
                                                    <?php if ($row['kyc_status'] === 'approved'): ?>
                                                        <span class="text-[9px] px-1.5 py-0.5 rounded bg-emerald-50 text-emerald-700 dark:bg-emerald-950/20 dark:text-emerald-400 font-bold" title="KYC completed and approved">✓ KYC</span>
                                                    <?php elseif ($row['kyc_status'] === 'pending_review'): ?>
                                                        <span class="text-[9px] px-1.5 py-0.5 rounded bg-amber-100 text-amber-700 dark:bg-amber-950/30 dark:text-amber-400 font-bold border border-amber-300" title="KYC submitted — awaiting Super Admin approval">🕐 KYC Review</span>
                                                    <?php else: ?>
                                                        <span class="text-[9px] px-1.5 py-0.5 rounded bg-slate-100 text-slate-400 dark:bg-slate-800 dark:text-slate-500 font-medium" title="KYC verification pending or uninitiated">⏳ KYC</span>
                                                    <?php endif; ?>

                                                    <?php if (empty($row['reset_token'])): ?>
                                                        <span class="text-[9px] px-1.5 py-0.5 rounded bg-emerald-50 text-emerald-700 dark:bg-emerald-950/20 dark:text-emerald-400 font-bold" title="Invitation responded and password set up">✓ Invite</span>
                                                    <?php else: ?>
                                                        <span class="text-[9px] px-1.5 py-0.5 rounded bg-amber-50 text-amber-600 dark:bg-amber-950/20 dark:text-amber-400 font-medium" title="Invitation sent, password setup pending">⏳ Invite</span>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                        <td class="py-3.5">
                                            <span class="font-mono block"><?php echo htmlspecialchars($row['email']); ?></span>
                                            <span class="text-slate-400 text-[10px]"><?php echo htmlspecialchars($row['phone']); ?></span>
                                        </td>
                                        <td class="py-3.5">
                                            <span class="px-2 py-0.5 rounded-full text-[9px] font-bold uppercase tracking-wider
                                                <?php echo $row['status'] === 'active' ? 'bg-emerald-50 text-emerald-800 dark:bg-emerald-500/10 dark:text-emerald-400' : 'bg-red-50 text-red-800 dark:bg-red-500/10 dark:text-red-400'; ?>">
                                                <?php echo htmlspecialchars($row['status']); ?>
                                            </span>
                                        </td>
                                        <td class="py-3.5 text-right">
                                            <?php if ($row['id'] !== $user['id']): ?>
                                                <div class="flex items-center justify-end gap-2 flex-wrap">
                                                    <!-- Verify & Activate (if not verified) -->
                                                    <?php if ((int)$row['email_verified'] === 0): ?>
                                                        <form method="POST" action="" class="inline">
                                                            <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                                                            <input type="hidden" name="action" value="admin_verify_user">
                                                            <input type="hidden" name="target_user_id" value="<?php echo $row['id']; ?>">
                                                            <button type="submit" class="py-1 px-2.5 rounded bg-emerald-600 hover:bg-emerald-700 text-white text-[9px] font-bold uppercase tracking-wide transition" title="Manually Verify and Activate User">
                                                                Verify & Activate
                                                            </button>
                                                        </form>
                                                    <?php endif; ?>

                                                    <!-- Edit user -->
                                                    <a href="user-edit.php?id=<?php echo $row['id']; ?>" class="py-1 px-2.5 bg-sky-600 hover:bg-sky-700 text-white text-[9px] font-bold rounded uppercase transition">
                                                        Edit
                                                    </a>

                                                    <!-- Suspend toggle -->
                                                    <form method="POST" action="" class="inline">
                                                        <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                                                        <input type="hidden" name="action" value="toggle_status">
                                                        <input type="hidden" name="target_user_id" value="<?php echo $row['id']; ?>">
                                                        <input type="hidden" name="new_status" value="<?php echo $row['status'] === 'active' ? 'suspended' : 'active'; ?>">
                                                        <button type="submit" class="py-1 px-2.5 rounded text-[9px] font-bold uppercase tracking-wide transition
                                                            <?php echo $row['status'] === 'active' ? 'bg-red-50 hover:bg-red-100 text-red-600' : 'bg-emerald-50 hover:bg-emerald-100 text-emerald-600'; ?>">
                                                            <?php echo $row['status'] === 'active' ? 'Suspend' : 'Activate'; ?>
                                                        </button>
                                                    </form>

                                                    <!-- Resend Password Reset Invite -->
                                                    <form method="POST" action="" class="inline">
                                                        <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                                                        <input type="hidden" name="action" value="resend_reset_email">
                                                        <input type="hidden" name="target_user_id" value="<?php echo $row['id']; ?>">
                                                        <button type="submit" class="py-1 px-2 bg-amber-500 hover:bg-amber-600 text-white text-[9px] font-bold rounded uppercase transition" title="Resend Password Reset Invitation Email">
                                                            Resend Invite
                                                        </button>
                                                    </form>

                                                    <!-- Approve KYC (Super Admin only, active when pending_review) -->
                                                    <?php if ($user['role'] === 'super_admin' && $row['kyc_status'] === 'pending_review'): ?>
                                                        <form method="POST" action="" class="inline" onsubmit="return confirm('Approve KYC for <?php echo addslashes($row['name']); ?>? This will set their status to Approved and notify them by email.')">
                                                            <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                                                            <input type="hidden" name="action" value="approve_kyc">
                                                            <input type="hidden" name="target_user_id" value="<?php echo $row['id']; ?>">
                                                            <button type="submit" class="py-1 px-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-[9px] font-bold rounded uppercase tracking-wide transition shadow-sm flex items-center gap-1" title="Approve KYC — User has completed 100% KYC submission">
                                                                ✓ Approve KYC
                                                            </button>
                                                        </form>
                                                    <?php endif; ?>

                                                    <!-- Remind KYC if incomplete -->
                                                    <?php 
                                                    $is_kyc_incomplete = (empty($row['kyc_status']) || $row['kyc_status'] !== 'approved' || empty($row['avatar']) || $row['avatar'] === 'assets/img/default-avatar.png');
                                                    if ($is_kyc_incomplete): 
                                                    ?>
                                                        <form method="POST" action="" class="inline">
                                                            <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                                                            <input type="hidden" name="action" value="send_kyc_reminder">
                                                            <input type="hidden" name="target_user_id" value="<?php echo $row['id']; ?>">
                                                            <button type="submit" class="py-1 px-2 bg-indigo-600 hover:bg-indigo-700 text-white text-[9px] font-bold rounded uppercase transition" title="Send KYC & Profile Photo Completion Reminder">
                                                                Remind KYC
                                                            </button>
                                                        </form>
                                                    <?php endif; ?>

                                                    <!-- Reset Pass toggle -->
                                                    <button @click="openReset = !openReset" class="py-1 px-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-[9px] font-bold rounded uppercase">Pass</button>

                                                    <!-- Super Admin Promotion Button -->
                                                    <?php if ($user['role'] === 'super_admin'): ?>
                                                        <button @click="
                                                            promoteUserId = <?php echo (int)$row['id']; ?>;
                                                            promoteUserName = '<?php echo addslashes($row['name']); ?>';
                                                            promoteTierId = '';
                                                            promoteZone = '';
                                                            promoteStateId = '';
                                                            promoteLgaId = '';
                                                            promoteWardId = '';
                                                            promoteWards = [];
                                                            showPromoteModal = true;
                                                        " class="py-1 px-2.5 bg-gold hover:bg-gold/90 text-bushgreen text-[9px] font-bold rounded uppercase transition">
                                                            Promote
                                                        </button>
                                                    <?php endif; ?>

                                                    <!-- Delete -->
                                                    <form method="POST" action="" class="inline" onsubmit="return confirm('Are you sure you want to delete this user?');">
                                                        <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                                                        <input type="hidden" name="action" value="delete_user">
                                                        <input type="hidden" name="delete_id" value="<?php echo $row['id']; ?>">
                                                        <button type="submit" class="py-1 px-2 bg-red-500 hover:bg-red-600 text-white text-[9px] font-bold rounded uppercase">Del</button>
                                                    </form>
                                                </div>

                                                <!-- Reset password dropdown form -->
                                                <div x-show="openReset" class="mt-2 text-left bg-slate-50 dark:bg-slate-900 p-2.5 rounded-lg border border-slate-200 dark:border-slate-750">
                                                    <form method="POST" action="">
                                                        <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                                                        <input type="hidden" name="action" value="reset_pass">
                                                        <input type="hidden" name="target_id" value="<?php echo $row['id']; ?>">
                                                        <label class="block text-[10px] text-slate-500 font-bold mb-1">New Password</label>
                                                        <div class="flex gap-2">
                                                            <input type="text" name="new_password" required placeholder="New passcode" class="flex-grow px-2 py-1 bg-white dark:bg-slate-800 border border-slate-200 rounded text-xs">
                                                            <button type="submit" class="py-1 px-3 bg-bushgreen text-white text-[10px] font-bold rounded">Reset</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <!-- Pagination Panel -->
                    <?php if ($total_pages > 1 || $total_users > 0): ?>
                    <div class="flex flex-col sm:flex-row justify-between items-center gap-4 mt-6 pt-4 border-t border-slate-100 dark:border-slate-700">
                        <div class="text-xs text-slate-500 dark:text-slate-400">
                            Showing <span class="font-semibold text-slate-800 dark:text-slate-200"><?php echo min($total_users, $offset + 1); ?></span> to 
                            <span class="font-semibold text-slate-800 dark:text-slate-200"><?php echo min($total_users, $offset + count($users_list)); ?></span> of 
                            <span class="font-semibold text-slate-800 dark:text-slate-200"><?php echo $total_users; ?></span> members
                        </div>
                        
                        <div class="flex items-center gap-1">
                            <?php if ($page > 1): ?>
                                <a href="?<?php echo http_build_query(array_merge($_GET, ['page' => $page - 1])); ?>" class="px-2.5 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 hover:border-gold hover:text-gold text-[11px] font-bold transition">
                                    &larr; Prev
                                </a>
                            <?php endif; ?>
                            
                            <?php
                            $start_p = max(1, $page - 2);
                            $end_p = min($total_pages, $page + 2);
                            if ($start_p > 1) {
                                echo '<a href="?' . http_build_query(array_merge($_GET, ['page' => 1])) . '" class="px-2.5 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 hover:border-gold hover:text-gold text-[11px] font-bold transition">1</a>';
                                if ($start_p > 2) {
                                    echo '<span class="text-slate-400 dark:text-slate-600 px-1 text-[11px]">...</span>';
                                }
                            }
                            for ($p = $start_p; $p <= $end_p; $p++) {
                                $active_class = $p === $page 
                                    ? 'bg-bushgreen text-white border-bushgreen dark:bg-gold dark:text-bushgreen dark:border-gold shadow-sm' 
                                    : 'border-slate-200 dark:border-slate-700 hover:border-gold hover:text-gold text-slate-600 dark:text-slate-300';
                                echo '<a href="?' . http_build_query(array_merge($_GET, ['page' => $p])) . '" class="px-2.5 py-1.5 rounded-xl border text-[11px] font-bold transition ' . $active_class . '">' . $p . '</a>';
                            }
                            if ($end_p < $total_pages) {
                                if ($end_p < $total_pages - 1) {
                                    echo '<span class="text-slate-400 dark:text-slate-600 px-1 text-[11px]">...</span>';
                                }
                                echo '<a href="?' . http_build_query(array_merge($_GET, ['page' => $total_pages])) . '" class="px-2.5 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 hover:border-gold hover:text-gold text-[11px] font-bold transition">' . $total_pages . '</a>';
                            }
                            ?>
                            
                            <?php if ($page < $total_pages): ?>
                                <a href="?<?php echo http_build_query(array_merge($_GET, ['page' => $page + 1])); ?>" class="px-2.5 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 hover:border-gold hover:text-gold text-[11px] font-bold transition">
                                    Next &rarr;
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>

                <!-- Login history / Security log panel -->
                <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-4">
                    <h3 class="text-slate-800 dark:text-slate-200 font-bold text-sm">Security Audit: Login Session History</h3>
                    <div class="overflow-x-auto">
                        <table class="w-full text-xs text-left text-slate-500 dark:text-slate-400">
                            <thead class="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase border-b border-slate-100 dark:border-slate-700">
                                <tr>
                                    <th class="pb-3">User</th>
                                    <th class="pb-3">IP Address</th>
                                    <th class="pb-3">Device / Browser Info</th>
                                    <th class="pb-3 text-right">Login Time</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-slate-50 dark:divide-slate-700">
                                <?php foreach ($login_history as $lh): ?>
                                    <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-700/50">
                                        <td class="py-3 font-semibold text-slate-800 dark:text-slate-200"><?php echo htmlspecialchars($lh['user_name']); ?></td>
                                        <td class="py-3 font-mono"><?php echo htmlspecialchars($lh['ip_address']); ?></td>
                                        <td class="py-3 truncate max-w-xs" title="<?php echo htmlspecialchars($lh['device_info']); ?>"><?php echo htmlspecialchars($lh['device_info']); ?></td>
                                        <td class="py-3 text-right text-slate-400 font-mono"><?php echo date('Y-m-d H:i', strtotime($lh['created_at'])); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

            </div>

        </div>

    </main>

    <!-- Bulk Message Modal -->
    <div x-show="showBulkModal" class="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4" x-cloak>
        <div class="bg-white dark:bg-slate-800 rounded-3xl max-w-md w-full border border-gold/40 shadow-2xl p-6 space-y-4" @click.away="showBulkModal = false">
            <div class="flex justify-between items-center border-b border-slate-100 dark:border-slate-700 pb-3">
                <h3 class="text-slate-850 dark:text-white font-bold text-sm">Send Internal Message</h3>
                <button @click="showBulkModal = false" class="text-slate-400 hover:text-slate-600 font-bold text-lg">&times;</button>
            </div>
            <form method="POST" action="" class="space-y-4">
                <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                <input type="hidden" name="action" value="send_bulk_message">
                <input type="hidden" name="user_ids" :value="selectedUsers.join(',')">
                
                <div>
                    <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1.5">Message Content</label>
                    <textarea name="message_content" required rows="4" 
                              placeholder="Type your message to the selected users..." 
                              class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs focus:outline-none focus:border-bushgreen"></textarea>
                </div>
                
                <div class="flex justify-end gap-2 border-t border-slate-100 dark:border-slate-700 pt-3">
                    <button type="button" @click="showBulkModal = false" class="py-2 px-4 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-bold text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-900">
                        Cancel
                    </button>
                    <button type="submit" class="py-2 px-5 bg-bushgreen hover:bg-bushgreen-light text-white text-xs font-bold rounded-xl transition shadow-md">
                        Send Message
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Leadership Promotion Modal -->
    <?php if ($user['role'] === 'super_admin'): ?>
    <div x-show="showPromoteModal" class="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4" x-cloak>
        <div class="bg-white dark:bg-slate-800 rounded-3xl max-w-md w-full border border-gold/40 shadow-2xl p-6 space-y-4" @click.away="showPromoteModal = false">
            <div class="flex justify-between items-center border-b border-slate-100 dark:border-slate-700 pb-3">
                <div>
                    <h3 class="text-slate-850 dark:text-white font-bold text-sm">Leadership Tier Promotion</h3>
                    <p class="text-[10px] text-slate-400 font-light mt-0.5">Assign <span class="font-bold text-bushgreen dark:text-gold" x-text="promoteUserName"></span> to a leadership role instantly.</p>
                </div>
                <button @click="showPromoteModal = false" class="text-slate-400 hover:text-slate-600 font-bold text-lg">&times;</button>
            </div>
            
            <form method="POST" action="" class="space-y-4">
                <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                <input type="hidden" name="action" value="assign_leadership">
                <input type="hidden" name="target_user_id" :value="promoteUserId">
                
                <div>
                    <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1.5" for="promote_tier_id">Select Leadership Tier *</label>
                    <select name="tier_id" id="promote_tier_id" required x-model="promoteTierId" 
                            @change="promoteZone = ''; promoteStateId = ''; promoteLgaId = ''; promoteWardId = ''; promoteWards = [];"
                            class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs focus:outline-none focus:border-bushgreen">
                        <option value="">-- Choose Tier --</option>
                        <option value="super_admin_role">Super Admin (System Owner)</option>
                        <?php foreach ($tiers_list as $t): ?>
                            <option value="<?php echo $t['id']; ?>"><?php echo htmlspecialchars($t['name']); ?> (Level <?php echo $t['level']; ?>)</option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <!-- Geopolitical Zone (If Zonal, Tier ID = 2) -->
                <div x-show="promoteTierId == 2" x-transition x-cloak>
                    <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1.5" for="promote_zone">Geopolitical Zone *</label>
                    <select name="zone" id="promote_zone" :required="promoteTierId == 2" x-model="promoteZone"
                            class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs focus:outline-none focus:border-bushgreen font-medium">
                        <option value="">-- Choose Zone --</option>
                        <option value="South-West">South-West</option>
                        <option value="North-Central">North-Central</option>
                        <option value="South-South">South-South</option>
                        <option value="North-West">North-West</option>
                        <option value="South-East">South-East</option>
                        <option value="North-East">North-East</option>
                    </select>
                </div>

                <!-- State Chapter (If State (3), LGA (4), or Grassroots (5)) -->
                <div x-show="[3, 4, 5].includes(parseInt(promoteTierId))" x-transition x-cloak class="space-y-4">
                    <div>
                        <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1.5" for="promote_state_id">State *</label>
                        <select name="state_id" id="promote_state_id" :required="[3, 4, 5].includes(parseInt(promoteTierId))" x-model="promoteStateId" @change="promoteLgaId = ''; promoteWardId = ''; promoteWards = [];"
                                class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs focus:outline-none focus:border-bushgreen">
                            <option value="">-- Choose State --</option>
                            <?php foreach ($states_list as $state): ?>
                                <option value="<?php echo $state['id']; ?>"><?php echo htmlspecialchars($state['name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <!-- LGA (If LGA (4) or Grassroots (5)) -->
                <div x-show="[4, 5].includes(parseInt(promoteTierId))" x-transition x-cloak class="space-y-4">
                    <div>
                        <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1.5" for="promote_lga_id">Local Government Area (LGA) *</label>
                        <select name="lga_id" id="promote_lga_id" :required="[4, 5].includes(parseInt(promoteTierId))" x-model="promoteLgaId" @change="fetchPromoteWards()"
                                class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs focus:outline-none focus:border-bushgreen">
                            <option value="">-- Choose LGA --</option>
                            <template x-if="promoteStateId && lgas[promoteStateId]">
                                <template x-for="lga in lgas[promoteStateId]" :key="lga.id">
                                    <option :value="lga.id" x-text="lga.name"></option>
                                </template>
                            </template>
                        </select>
                    </div>
                </div>

                <!-- Ward (If Grassroots (5)) -->
                <div x-show="promoteTierId == 5" x-transition x-cloak>
                    <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1.5" for="promote_ward_id">Ward *</label>
                    <div class="relative">
                        <select name="ward_id" id="promote_ward_id" :required="promoteTierId == 5" x-model="promoteWardId" :disabled="loadingPromoteWards || !promoteLgaId"
                                class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs focus:outline-none focus:border-bushgreen disabled:opacity-60">
                            <option value="">-- Choose Ward --</option>
                            <template x-for="ward in promoteWards" :key="ward.id">
                                <option :value="ward.id" x-text="ward.name"></option>
                            </template>
                        </select>
                        <div x-show="loadingPromoteWards" class="absolute right-3 top-2 flex items-center gap-1 text-[9px] text-slate-400 font-medium bg-white px-2 py-0.5 rounded border border-slate-100 shadow-sm">
                            <span class="w-1.5 h-1.5 rounded-full bg-gold animate-ping"></span>
                            <span>fetching...</span>
                        </div>
                    </div>
                </div>

                <div class="flex justify-end gap-2 border-t border-slate-100 dark:border-slate-700 pt-3">
                    <button type="button" @click="showPromoteModal = false" class="py-2 px-4 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-bold text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-900">
                        Cancel
                    </button>
                    <button type="submit" class="py-2 px-5 bg-bushgreen hover:bg-bushgreen-light text-white text-xs font-bold rounded-xl transition shadow-md">
                        Assign Role
                    </button>
                </div>
            </form>
        </div>
    </div>
    <?php endif; ?>
</body>
</html>
