<?php
/**
 * PBAT Smart Nation Initiative - Event & Town Hall Scheduler
 * Dynamic webinar, conference and livestream dispatcher. Adds registrants list and check-in options.
 */
require_once dirname(__DIR__) . '/helpers/auth.php';
require_once dirname(__DIR__) . '/helpers/common.php';
require_once dirname(__DIR__) . '/config/database.php';

Auth::requireRole(['super_admin', 'founder_circle', 'national_steering', 'state_chairman', 'coordinator'], '../login.php');

$user = Auth::user();
$user_id = $user['id'];
$error = '';
$success = '';
$events = [];
$registrants = [];

try {
    $db = Database::connect();

    // 1. Handle Event Actions (Create, Edit, Delete)
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
        if (!isset($_POST['csrf_token']) || !Auth::validateCsrf($_POST['csrf_token'])) {
            $error = "CSRF Token validation failed.";
        } else {
            $action = $_POST['action'];
            
            if ($action === 'create_event' || $action === 'edit_event') {
                $title = trim($_POST['title']);
                $description = trim($_POST['description']);
                $event_date = $_POST['event_date'];
                $location = trim($_POST['location']);
                $event_type = trim($_POST['event_type']);
                $is_virtual = isset($_POST['is_virtual']) ? 1 : 0;
                $stream_url = trim($_POST['stream_url'] ?? '');
                $meeting_platform = trim($_POST['meeting_platform'] ?? 'none');
                $meeting_link = trim($_POST['meeting_link'] ?? '');
                $meeting_id = trim($_POST['meeting_id'] ?? '');
                $meeting_passcode = trim($_POST['meeting_passcode'] ?? '');
                $max_capacity = intval($_POST['max_capacity'] ?? 0);

                if (empty($title) || empty($description) || empty($event_date) || empty($location)) {
                    $error = "Please complete all required event scheduling parameters.";
                } else {
                    if ($action === 'create_event') {
                        $stmt = $db->prepare("INSERT INTO `events` (`title`, `description`, `event_date`, `location`, `event_type`, `is_virtual`, `stream_url`, `meeting_platform`, `meeting_link`, `meeting_id`, `meeting_passcode`, `max_capacity`, `created_by`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                        $stmt->execute([$title, $description, $event_date, $location, $event_type, $is_virtual, $stream_url, $meeting_platform, $meeting_link, $meeting_id, $meeting_passcode, $max_capacity, $user_id]);

                        // Add notification trigger
                        $stmt_notify = $db->prepare("INSERT INTO `notifications` (`user_id`, `message`, `type`) SELECT `id`, ?, 'event' FROM `users` WHERE `status` = 'active'");
                        $stmt_notify->execute(["New Town Hall scheduled: '{$title}' on {$event_date}"]);

                        Auth::logAction($user_id, 'EVENT_CREATE', "Created event circular: '{$title}'");
                        $success = "Event scheduled and notifications dispatched successfully!";
                    } else {
                        $event_id = intval($_POST['event_id']);
                        $stmt = $db->prepare("UPDATE `events` SET `title` = ?, `description` = ?, `event_date` = ?, `location` = ?, `event_type` = ?, `is_virtual` = ?, `stream_url` = ?, `meeting_platform` = ?, `meeting_link` = ?, `meeting_id` = ?, `meeting_passcode` = ?, `max_capacity` = ? WHERE `id` = ?");
                        $stmt->execute([$title, $description, $event_date, $location, $event_type, $is_virtual, $stream_url, $meeting_platform, $meeting_link, $meeting_id, $meeting_passcode, $max_capacity, $event_id]);

                        Auth::logAction($user_id, 'EVENT_EDIT', "Edited event ID: {$event_id}");
                        $success = "Event updated successfully!";
                    }
                }
            } elseif ($action === 'delete_event') {
                $event_id = intval($_POST['event_id']);
                
                // Delete event registrants first to preserve foreign key constraints
                $stmt_reg_del = $db->prepare("DELETE FROM `event_registrants` WHERE `event_id` = ?");
                $stmt_reg_del->execute([$event_id]);
                
                $stmt = $db->prepare("DELETE FROM `events` WHERE `id` = ?");
                $stmt->execute([$event_id]);

                Auth::logAction($user_id, 'EVENT_DELETE', "Deleted event ID: {$event_id}");
                $success = "Event deleted successfully!";
            }
        }
    }

    // 2. Fetch events lists with rsvp counts
    $stmt = $db->query("
        SELECT e.*, u.name as author_name, COUNT(r.id) as rsvp_count 
        FROM `events` e 
        JOIN `users` u ON e.created_by = u.id 
        LEFT JOIN `event_registrants` r ON e.id = r.event_id
        GROUP BY e.id
        ORDER BY e.event_date ASC
    ");
    $events = $stmt->fetchAll();

    // 3. Fetch actual event registrants
    $stmt_reg = $db->query("
        SELECT r.id as rsvp_id, u.name, u.email, u.status, e.title as event_title 
        FROM event_registrants r 
        JOIN users u ON r.user_id = u.id 
        JOIN events e ON r.event_id = e.id 
        ORDER BY r.created_at DESC
    ");
    $registrants = $stmt_reg->fetchAll();

} catch (Exception $e) {
    $error = "Events DB Error: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upcoming Town Halls & Conferences - PBAT Smart Nation</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        bushgreen: {
                            DEFAULT: '#063C1E',
                            light: '#0A4D27',
                            dark: '#03200F',
                        },
                        gold: '#D4AF37'
                    }
                }
            }
        }
    </script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        [x-cloak] { display: none !important; }
        body { font-family: 'Inter', sans-serif; }
        h1, h2, h3, h4, .font-display { font-family: 'Outfit', sans-serif; }
    </style>
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
</head>
<body class="bg-slate-50 text-slate-800 transition-colors duration-200 min-h-screen flex flex-col antialiased"
      x-data="{ 
          darkMode: localStorage.getItem('darkMode') === 'true',
          editingEvent: null,
          isVirtual: false,
          form: {
              title: '',
              event_type: 'Digital Town Hall',
              event_date: '',
              location: '',
              max_capacity: 0,
              meeting_platform: 'none',
              meeting_link: '',
              meeting_id: '',
              meeting_passcode: '',
              description: '',
              stream_url: ''
          },
          setEvent(ev) {
              this.editingEvent = ev;
              if (ev) {
                  this.form.title = ev.title;
                  this.form.event_type = ev.event_type;
                  this.form.event_date = ev.event_date.replace(' ', 'T').substring(0, 16);
                  this.form.location = ev.location;
                  this.form.max_capacity = ev.max_capacity;
                  this.form.meeting_platform = ev.meeting_platform;
                  this.form.meeting_link = ev.meeting_link || '';
                  this.form.meeting_id = ev.meeting_id || '';
                  this.form.meeting_passcode = ev.meeting_passcode || '';
                  this.form.description = ev.description;
                  this.form.stream_url = ev.stream_url || '';
                  this.isVirtual = (ev.is_virtual == 1);
              } else {
                  this.form.title = '';
                  this.form.event_type = 'Digital Town Hall';
                  this.form.event_date = '';
                  this.form.location = '';
                  this.form.max_capacity = 0;
                  this.form.meeting_platform = 'none';
                  this.form.meeting_link = '';
                  this.form.meeting_id = '';
                  this.form.meeting_passcode = '';
                  this.form.description = '';
                  this.form.stream_url = '';
                  this.isVirtual = false;
              }
          }
      }"
      x-init="$watch('darkMode', val => localStorage.setItem('darkMode', val))"
      :class="{ 'dark bg-slate-900 text-slate-100': darkMode }">

    <!-- Header Navbar -->
    <header class="bg-bushgreen text-white border-b-2 border-gold h-20 flex items-center justify-between px-6 shadow-md relative z-30">
        <div class="flex items-center gap-3">
            <a href="dashboard.php" class="py-1.5 px-3 border border-white/20 hover:bg-white/10 text-white rounded-lg text-xs font-bold transition">
                &larr; Back to Dashboard
            </a>
            <div class="w-8 h-8 rounded bg-white/10 flex items-center justify-center border border-white/20 p-1 flex-shrink-0">
                <?php echo getAppLogoHtml('w-full h-full object-contain', 'dashboard'); ?>
            </div>
            <span class="text-white font-extrabold text-sm font-display hidden sm:inline">PBAT SMART NATION INITIATIVE</span>
        </div>
        <div class="flex items-center gap-4 text-xs font-bold text-gold uppercase tracking-wider">
            <!-- Dark Mode Toggle -->
            <button @click="darkMode = !darkMode" class="p-2 rounded-lg border border-gold/45 text-gold hover:bg-gold/10 transition flex items-center justify-center">
                <svg x-show="darkMode" class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364-6.364l-.707.707M6.364 17.636l-.707.707M18.364 17.636l-.707-.707M6.364 6.364l-.707-.707M15 12a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                <svg x-show="!darkMode" class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z"/></svg>
            </button>
            <span>Upcoming Town Halls & Conferences</span>
        </div>
    </header>

    <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 flex-grow w-full space-y-10">
        
        <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div class="space-y-1">
                <h1 class="text-2xl sm:text-3xl font-black text-bushgreen dark:text-gold font-display">Upcoming Town Halls & Conferences</h1>
                <p class="text-slate-500 dark:text-slate-400 text-xs font-light">Schedule upcoming conferences, town halls, webinars, and coordinate physical and virtual program attendance check-ins.</p>
            </div>
            
            <?php if (!empty($success)): ?>
                <div class="px-4 py-2 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs font-semibold">
                    <?php echo htmlspecialchars($success); ?>
                </div>
            <?php endif; ?>
            <?php if (!empty($error)): ?>
                <div class="px-4 py-2 bg-red-50 border border-red-200 text-red-800 rounded-xl text-xs font-semibold">
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            
            <!-- LIST COLUMN (Col 7) -->
            <div class="lg:col-span-7 space-y-6">
                
                <!-- Events index list -->
                <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
                    <h3 class="text-slate-800 dark:text-slate-200 font-bold text-sm">Upcoming Town Halls & Conferences Index</h3>
                    
                    <div class="space-y-4">
                        <?php if (empty($events)): ?>
                            <div class="p-8 text-center text-slate-400 italic text-xs">No programs scheduled yet.</div>
                        <?php endif; ?>
                        <?php foreach ($events as $ev): ?>
                            <div class="p-4 rounded-xl border border-slate-100 dark:border-slate-700 hover:border-gold/30 transition space-y-3">
                                <div class="flex justify-between items-center">
                                    <span class="px-2 py-0.5 rounded bg-bushgreen/10 text-bushgreen dark:bg-gold/10 dark:text-gold text-[9px] font-bold uppercase tracking-wider">
                                        <?php echo htmlspecialchars($ev['event_type'] ?? 'Conference'); ?>
                                    </span>
                                    <span class="text-xs text-slate-400 font-semibold">
                                        <?php echo date('M d, Y @ H:i', strtotime($ev['event_date'])); ?>
                                    </span>
                                </div>
                                <h4 class="font-bold text-slate-800 dark:text-slate-200 text-xs"><?php echo htmlspecialchars($ev['title']); ?></h4>
                                <p class="text-slate-500 dark:text-slate-400 text-xs leading-relaxed font-light"><?php echo htmlspecialchars($ev['description']); ?></p>
                                
                                <?php if ($ev['is_virtual'] && !empty($ev['meeting_platform']) && $ev['meeting_platform'] !== 'none'): ?>
                                    <div class="p-3 bg-slate-50 dark:bg-slate-900 rounded-lg text-xs space-y-1 border border-slate-200/50 dark:border-slate-700/50">
                                        <div class="flex items-center gap-1.5 font-semibold text-bushgreen dark:text-gold text-[10px] uppercase">
                                            <svg class="w-3.5 h-3.5 text-gold" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z"/></svg>
                                            <span><?php echo htmlspecialchars(ucfirst(str_replace('_', ' ', $ev['meeting_platform']))); ?> Connection Info</span>
                                        </div>
                                        <?php if (!empty($ev['meeting_link'])): ?>
                                            <div><strong>Link:</strong> <a href="<?php echo htmlspecialchars($ev['meeting_link']); ?>" target="_blank" class="text-blue-600 dark:text-blue-400 hover:underline break-all"><?php echo htmlspecialchars($ev['meeting_link']); ?></a></div>
                                        <?php endif; ?>
                                        <?php if (!empty($ev['meeting_id'])): ?>
                                            <div><strong>Meeting ID:</strong> <?php echo htmlspecialchars($ev['meeting_id']); ?></div>
                                        <?php endif; ?>
                                        <?php if (!empty($ev['meeting_passcode'])): ?>
                                            <div><strong>Passcode / PIN:</strong> <?php echo htmlspecialchars($ev['meeting_passcode']); ?></div>
                                        <?php endif; ?>
                                    </div>
                                <?php endif; ?>

                                <div class="pt-3 border-t border-slate-50 dark:border-slate-750 flex flex-wrap justify-between items-center text-[10px] text-slate-400 font-semibold gap-2">
                                    <span>Venue: <?php echo htmlspecialchars($ev['location']); ?></span>
                                    <span>RSVP: <?php echo intval($ev['rsvp_count']); ?><?php echo $ev['max_capacity'] > 0 ? ' / ' . intval($ev['max_capacity']) . ' max' : ' registered'; ?></span>
                                    <span>Announcer: <?php echo htmlspecialchars($ev['author_name'] ?? 'System'); ?></span>
                                </div>

                                <div class="flex items-center justify-end gap-2 pt-2 border-t border-slate-50 dark:border-slate-700/50">
                                    <button @click="setEvent(<?php echo htmlspecialchars(json_encode($ev)); ?>)"
                                            class="px-3 py-1 bg-amber-500 hover:bg-amber-600 text-white rounded text-[10px] font-bold uppercase transition">
                                        Edit
                                    </button>
                                    <form method="POST" action="" onsubmit="return confirm('Are you sure you want to delete this event?');" class="inline">
                                        <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                                        <input type="hidden" name="action" value="delete_event">
                                        <input type="hidden" name="event_id" value="<?php echo $ev['id']; ?>">
                                        <button type="submit" class="px-3 py-1 bg-red-600 hover:bg-red-700 text-white rounded text-[10px] font-bold uppercase transition">
                                            Delete
                                        </button>
                                    </form>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- Event registrants list -->
                <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-4">
                    <h3 class="text-slate-800 dark:text-slate-200 font-bold text-sm">Event Registrations & Checked-in Attendance</h3>
                    <div class="overflow-x-auto">
                        <table class="w-full text-xs text-left text-slate-500 dark:text-slate-400">
                            <thead class="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase border-b border-slate-100 dark:border-slate-700">
                                <tr>
                                    <th class="pb-3">Name</th>
                                    <th class="pb-3">Email</th>
                                    <th class="pb-3">Program / Event</th>
                                    <th class="pb-3">Status</th>
                                    <th class="pb-3 text-right">Actions</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-slate-50 dark:divide-slate-700">
                                <?php if (empty($registrants)): ?>
                                    <tr>
                                        <td colspan="5" class="py-8 text-center text-slate-400 italic">No registrations logged yet.</td>
                                    </tr>
                                <?php endif; ?>
                                <?php foreach ($registrants as $reg): ?>
                                    <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-700/50" x-data="{ checkedIn: false }">
                                        <td class="py-3 font-semibold text-slate-800 dark:text-slate-200"><?php echo htmlspecialchars($reg['name']); ?></td>
                                        <td class="py-3 font-mono"><?php echo htmlspecialchars($reg['email']); ?></td>
                                        <td class="py-3 text-slate-500 dark:text-slate-400"><?php echo htmlspecialchars($reg['event_title']); ?></td>
                                        <td class="py-3">
                                            <span class="px-2 py-0.5 rounded text-[8px] font-bold uppercase"
                                                  :class="checkedIn ? 'bg-emerald-50 text-emerald-800' : 'bg-amber-50 text-amber-800'">
                                                <span x-text="checkedIn ? 'Checked-In' : 'Registered'"></span>
                                            </span>
                                        </td>
                                        <td class="py-3 text-right">
                                            <button @click="checkedIn = !checkedIn" class="py-1 px-2.5 bg-bushgreen hover:bg-bushgreen-light text-white text-[9px] font-bold rounded uppercase">
                                                Toggle Check-in
                                            </button>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

            </div>

            <!-- SCHEDULER COLUMN (Col 5) -->
            <div class="lg:col-span-5 bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 p-6 shadow-sm space-y-6">
                <div class="pb-3 border-b border-slate-100 dark:border-slate-700">
                    <h3 class="text-slate-800 dark:text-slate-200 font-bold text-sm" x-text="editingEvent ? 'Edit Program Settings' : 'Broadcast Settings'">Broadcast Settings</h3>
                    <p class="text-[10px] text-slate-400" x-text="editingEvent ? 'Modify existing scheduled program details.' : 'Coordinators and Steering members can dispatch public circular schedules instantly.'">Coordinators and Steering members can dispatch public circular schedules instantly.</p>
                </div>

                <form method="POST" action="" class="space-y-4">
                    <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                    <input type="hidden" name="action" :value="editingEvent ? 'edit_event' : 'create_event'">
                    <input type="hidden" name="event_id" :value="editingEvent ? editingEvent.id : ''">
                    
                    <div>
                        <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1.5" for="title">Program Title *</label>
                        <input type="text" name="title" id="title" required placeholder="e.g. Southwest Technology Summit" x-model="form.title"
                               class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                    </div>

                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1.5" for="event_type">Format *</label>
                            <select name="event_type" id="event_type" required x-model="form.event_type"
                                    class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                                <option value="Digital Town Hall">Digital Town Hall</option>
                                <option value="Conference">Conference</option>
                                <option value="Webinar">Webinar</option>
                                <option value="Workshop">Workshop</option>
                            </select>
                        </div>
                        <div>
                            <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1.5" for="event_date">Time *</label>
                            <input type="datetime-local" name="event_date" id="event_date" required x-model="form.event_date"
                                   class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                        </div>
                    </div>

                    <div>
                        <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1.5" for="location">Venue / Location Address *</label>
                        <input type="text" name="location" id="location" required placeholder="e.g. YouTube Live or physical building" x-model="form.location"
                               class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                    </div>

                    <div class="grid grid-cols-2 gap-4">
                        <div class="flex items-center gap-2 py-2">
                            <input type="checkbox" name="is_virtual" id="is_virtual" value="1" x-model="isVirtual"
                                   class="w-4 h-4 text-bushgreen focus:ring-bushgreen border-slate-300 rounded">
                            <label for="is_virtual" class="text-slate-700 dark:text-slate-400 text-xs font-semibold">Virtual stream</label>
                        </div>
                        <div>
                            <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1.5" for="max_capacity">Max Capacity</label>
                            <input type="number" name="max_capacity" id="max_capacity" min="0" placeholder="0 for unlimited" x-model.number="form.max_capacity"
                                   class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                        </div>
                    </div>

                    <div x-show="isVirtual" class="space-y-4 border-l-2 border-gold/45 pl-3 pt-1">
                        <div>
                            <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1.5" for="meeting_platform">Meeting Platform *</label>
                            <select name="meeting_platform" id="meeting_platform" x-model="form.meeting_platform"
                                    class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                                <option value="none">Select Platform</option>
                                <option value="zoom">Zoom</option>
                                <option value="google_meet">Google Meet</option>
                                <option value="youtube_live">YouTube Live</option>
                                <option value="other">Other Platform</option>
                            </select>
                        </div>
                        <div>
                            <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1.5" for="meeting_link">Meeting / Join Link</label>
                            <input type="url" name="meeting_link" id="meeting_link" placeholder="e.g. https://zoom.us/j/..." x-model="form.meeting_link"
                                   class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                        </div>
                        <div class="grid grid-cols-2 gap-4">
                            <div>
                                <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1.5" for="meeting_id">Meeting ID</label>
                                <input type="text" name="meeting_id" id="meeting_id" placeholder="e.g. 123 456 7890" x-model="form.meeting_id"
                                       class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                            </div>
                            <div>
                                <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1.5" for="meeting_passcode">Passcode / PIN</label>
                                <input type="text" name="meeting_passcode" id="meeting_passcode" placeholder="e.g. 123456" x-model="form.meeting_passcode"
                                       class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                            </div>
                        </div>
                    </div>

                    <div>
                        <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1.5" for="description">Description *</label>
                        <textarea name="description" id="description" required rows="3" placeholder="Describe the focus and goals of this event..." x-model="form.description"
                                  class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen"></textarea>
                    </div>

                    <div>
                        <label class="block text-slate-600 dark:text-slate-400 text-xs font-semibold mb-1.5" for="stream_url">YouTube Stream / Video URL (Optional)</label>
                        <input type="url" name="stream_url" id="stream_url" placeholder="e.g. https://www.youtube.com/embed/..." x-model="form.stream_url"
                               class="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs focus:outline-none focus:border-bushgreen">
                    </div>

                    <div class="flex gap-2">
                        <button type="submit" class="flex-grow py-2.5 bg-bushgreen hover:bg-bushgreen-light text-white text-xs font-bold rounded-lg transition shadow-md shadow-bushgreen/10"
                                x-text="editingEvent ? 'Update Scheduled Program' : 'Commit Schedule & Disseminate'">
                            Commit Schedule & Disseminate
                        </button>
                        <button type="button" x-show="editingEvent" @click="setEvent(null)"
                                class="py-2.5 px-4 bg-slate-250 dark:bg-slate-700 text-slate-750 dark:text-slate-200 text-xs font-bold rounded-lg transition">
                            Cancel
                        </button>
                    </div>
                </form>
            </div>

        </div>

    </main>
</body>
</html>
