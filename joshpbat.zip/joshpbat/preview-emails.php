<?php
/**
 * PBAT Smart Nation Initiative - Mock Emails Outbox Preview Ledger
 * Visually attractive administrative sandbox tool to review colorful HTML notifications.
 */
require_once __DIR__ . '/helpers/auth.php';
require_once __DIR__ . '/helpers/common.php';
require_once __DIR__ . '/config/database.php';

$emails = [];
$selected_email = null;

try {
    $db = Database::connect();
    
    // Fetch all outbox emails
    $stmt = $db->query("SELECT * FROM `sent_emails` ORDER BY `created_at` DESC LIMIT 20");
    $emails = $stmt->fetchAll();
    
    // Select specific email preview
    $id = (int)($_GET['id'] ?? 0);
    if ($id > 0) {
        $stmt = $db->prepare("SELECT * FROM `sent_emails` WHERE `id` = ? LIMIT 1");
        $stmt->execute([$id]);
        $selected_email = $stmt->fetch();
    } elseif (!empty($emails)) {
        $selected_email = $emails[0];
    }
} catch (Exception $e) {
    // Elegant warning
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mock Mail Ledger - PBAT Smart Nation</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        bushgreen: {
                            DEFAULT: '#063C1E',
                            light: '#0A4D27',
                            dark: '#03200F',
                        },
                        gold: '#D4AF37'
                    }
                }
            }
        }
    </script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; }
        h1, h2, h3, h4, .font-display { font-family: 'Outfit', sans-serif; }
    </style>
</head>
<body class="bg-slate-50 min-h-screen flex flex-col antialiased">

    <!-- Header bar -->
    <header class="bg-bushgreen text-white border-b-2 border-gold h-20 flex items-center justify-between px-6 shadow-md relative z-30">
        <div class="flex items-center gap-3">
            <span class="text-white font-extrabold text-lg tracking-tight font-display">PBAT SMART NATION</span>
            <span class="text-gold font-bold text-[9px] tracking-widest leading-none uppercase bg-white/10 px-2 py-0.5 rounded border border-white/20">Mail Sandbox</span>
        </div>
        <a href="index.php" class="py-1.5 px-3 border border-gold/40 hover:bg-gold hover:text-bushgreen text-gold rounded-lg text-[10px] font-bold tracking-wide transition-all uppercase">
            Back to Site
        </a>
    </header>

    <div class="flex flex-1 overflow-hidden h-[calc(100vh-80px)]">
        
        <!-- Sidebar: Emails List -->
        <aside class="w-80 bg-white border-r border-slate-200 flex flex-col flex-shrink-0">
            <div class="p-4 border-b border-slate-100 bg-slate-50/50">
                <h3 class="text-slate-800 font-bold text-xs uppercase tracking-wider font-display">Mock Dispatched Outbox</h3>
                <p class="text-[10px] text-slate-400 mt-1 font-light leading-normal">Review rich HTML templates captured inside local sandbox storage.</p>
            </div>
            
            <div class="flex-grow overflow-y-auto divide-y divide-slate-100">
                <?php if (empty($emails)): ?>
                    <div class="p-6 text-center text-xs text-slate-400 font-light">
                        No emails sent yet. Trigger registration or password recovery to test.
                    </div>
                <?php else: ?>
                    <?php foreach ($emails as $email): ?>
                        <a href="?id=<?php echo $email['id']; ?>" 
                           class="block p-4 hover:bg-slate-50 transition text-left space-y-1.5 <?php echo ($selected_email && $selected_email['id'] == $email['id']) ? 'bg-emerald-50/45 border-l-4 border-gold' : ''; ?>">
                            <div class="flex justify-between items-start gap-2">
                                <span class="font-extrabold text-slate-800 text-[11px] truncate max-w-[150px]"><?php echo htmlspecialchars($email['to_email']); ?></span>
                                <span class="text-[8px] font-mono text-slate-400 bg-slate-100 px-1.5 py-0.5 rounded"><?php echo date('H:i:s', strtotime($email['created_at'])); ?></span>
                            </div>
                            <h4 class="text-slate-700 font-bold text-[11px] leading-tight truncate"><?php echo htmlspecialchars($email['subject']); ?></h4>
                            <span class="inline-block px-1.5 py-0.5 bg-emerald-50 text-emerald-800 rounded text-[8px] font-bold uppercase tracking-wider">
                                status: <?php echo htmlspecialchars($email['status']); ?>
                            </span>
                        </a>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </aside>

        <!-- Main Preview Workspace -->
        <main class="flex-grow flex flex-col bg-slate-100 p-6 overflow-hidden">
            <?php if (!$selected_email): ?>
                <div class="flex-grow flex flex-col items-center justify-center text-center space-y-3">
                    <svg class="w-12 h-12 text-slate-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 19v-8.93a2 2 0 01.89-1.664l8-5.333a2 2 0 012.22 0l8 5.333A2 2 0 0121 10.07V19M3 19a2 2 0 002 2h14a2 2 0 002-2M3 19l6.75-4.5M21 19l-6.75-4.5M3 10l6.75 4.5M21 10l-6.75 4.5m0 0l-2.25-1.5a2 2 0 00-2.22 0l-2.25 1.5"/></svg>
                    <span class="text-xs text-slate-400">Select an email from the left sidebar to preview its rich layout.</span>
                </div>
            <?php else: ?>
                <div class="bg-white rounded-2xl border border-slate-200 shadow-sm flex flex-col flex-1 overflow-hidden">
                    <!-- Preview Header Bar -->
                    <div class="p-4 border-b border-slate-200 bg-white flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-xs">
                        <div class="space-y-1 text-left">
                            <div><strong class="text-slate-800">To:</strong> <span class="font-mono text-bushgreen font-bold"><?php echo htmlspecialchars($selected_email['to_email']); ?></span></div>
                            <div><strong class="text-slate-800">Subject:</strong> <span class="font-bold text-slate-700"><?php echo htmlspecialchars($selected_email['subject']); ?></span></div>
                        </div>
                        <div class="text-right text-[10px] text-slate-400 font-light flex-shrink-0">
                            <strong>Dispatched:</strong> <?php echo date('Y-m-d H:i:s', strtotime($selected_email['created_at'])); ?>
                        </div>
                    </div>
                    
                    <!-- Preview Body Frame -->
                    <div class="flex-1 bg-slate-100 p-4 overflow-y-auto flex justify-center">
                        <div class="w-full max-w-[620px] bg-white rounded-2xl shadow-md border border-slate-200/50 p-2 overflow-hidden h-fit">
                            <iframe srcdoc="<?php echo htmlspecialchars($selected_email['body'], ENT_QUOTES, 'UTF-8'); ?>" 
                                    class="w-full min-h-[520px] border-0 rounded-xl"
                                    sandbox="allow-same-origin">
                            </iframe>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </main>
    </div>
</body>
</html>
