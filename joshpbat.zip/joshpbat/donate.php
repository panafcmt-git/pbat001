<?php
/**
 * PBAT Smart Nation Initiative - Donate / Support
 * Elegant page describing sponsorship & donation opportunities, with a database-backed pledge form.
 */
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/helpers/auth.php';
require_once __DIR__ . '/helpers/common.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$donation_success = '';
$donation_error = '';

// Handle Support/Donation Form Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'submit_donation') {
    if (!Auth::validateCsrf($_POST['csrf_token'] ?? '')) {
        $donation_error = "CSRF Token validation failed.";
    } else {
        $donor_name = trim($_POST['donor_name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $phone = trim($_POST['phone'] ?? '');
        $amount = (float)($_POST['amount'] ?? 0);
        $project_area = trim($_POST['project_area'] ?? '');
        $comments = trim($_POST['comments'] ?? '');
        
        if (empty($donor_name) || empty($email) || $amount <= 0 || empty($project_area)) {
            $donation_error = "Please fill in all required fields and enter a valid donation amount.";
        } else {
            try {
                $db = Database::connect();
                // Map donation pledge to the project_sponsors table for admin visibility
                $company_name = "Individual Donor / Supporter";
                $sponsorship_category = "Donation: " . $project_area;
                
                $stmt = $db->prepare("INSERT INTO `project_sponsors` (company_name, contact_name, contact_email, contact_phone, sponsorship_category, sponsor_amount, message, status) VALUES (?, ?, ?, ?, ?, ?, ?, 'pending')");
                $stmt->execute([$company_name, $donor_name, $email, $phone, $sponsorship_category, $amount, $comments]);
                
                $donation_success = "Thank you for your generous pledge! Our steering unit will contact you with secure remittance details.";
            } catch (Exception $e) {
                $donation_error = "Error recording donation pledge: " . $e->getMessage();
            }
        }
    }
}

require_once __DIR__ . '/helpers/seo.php';
SEO::init([
    'title' => 'Donate, Support & Project Sponsorships | PBAT Smart Nation',
    'description' => 'Support the grassroots digital transition in Nigeria. Pledge sponsorships or make donations to fund laptops, solar grids, and broadband connectivity.',
    'keywords' => 'Donate technology Nigeria, Community Solar grids sponsor, Broadband donation, PBAT Smart Nation Funding',
    'breadcrumbs' => [
        ['name' => 'Donate & Support', 'url' => '/donate']
    ]
]);

require_once __DIR__ . '/includes/header.php';
?>

<!-- Hero Header Section -->
<section class="relative bg-bushgreen text-white py-16 overflow-hidden border-b-8 border-gold">
    <div class="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-bushgreen-light/80 via-bushgreen to-bushgreen opacity-95"></div>
    <div class="absolute inset-0 bg-[linear-gradient(to_right,#ffffff05_1px,transparent_1px),linear-gradient(to_bottom,#ffffff05_1px,transparent_1px)] bg-[size:4rem_4rem]"></div>
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
        <span class="text-gold font-bold text-xs uppercase tracking-widest font-display">Empowering Communities</span>
        <h1 class="text-3xl sm:text-4xl md:text-5xl font-black font-display uppercase tracking-tight mt-2">
            Donate & Support
        </h1>
        <p class="text-slate-350 text-xs sm:text-sm max-w-xl mx-auto font-light mt-3 leading-relaxed">
            Support the grassroots digital transition. Your contributions directly fund computers, internet bandwidth, and solar arrays for community coding centers.
        </p>
    </div>
</section>

<!-- Content Section -->
<section class="py-16 bg-slate-50 dark:bg-slate-900/50">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            
            <!-- Column 1: Financial Transparency & Projects -->
            <div class="lg:col-span-5 space-y-6">
                <div class="bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-800 p-6 sm:p-8 shadow-sm space-y-6">
                    <h2 class="text-lg font-bold text-bushgreen dark:text-gold font-display uppercase tracking-wider">How Funds Are Used</h2>
                    <p class="text-xs text-slate-650 dark:text-slate-350 leading-relaxed font-light">
                        Every single Naira donated to the PBAT Smart Nation Initiative is directly integrated into community tech deployment budgets. We maintain complete financial transparency, publishing detailed expenditure lists in the admin panel to show where devices, solar hardware, and router packages are deployed.
                    </p>
                    <div class="space-y-4 text-xs font-light text-slate-600 dark:text-slate-350 leading-relaxed">
                        <div class="p-3 bg-slate-50 dark:bg-slate-900 rounded-xl border border-slate-100 dark:border-slate-800">
                            <strong class="text-slate-800 dark:text-white font-bold block mb-1">💻 Community Tech Labs</strong>
                            Funding is used to source robust, low-maintenance laptops and tablets for training hubs setup in rural communities.
                        </div>

                        <div class="p-3 bg-slate-50 dark:bg-slate-900 rounded-xl border border-slate-100 dark:border-slate-800">
                            <strong class="text-slate-800 dark:text-white font-bold block mb-1">☀️ Solar Micro-Grids</strong>
                            To bypass grid shortages, we install solar panel micro-systems to ensure 24/7 power at local computer centers.
                        </div>

                        <div class="p-3 bg-slate-50 dark:bg-slate-900 rounded-xl border border-slate-100 dark:border-slate-800">
                            <strong class="text-slate-800 dark:text-white font-bold block mb-1">📡 High-Speed Broadband</strong>
                            Each center is equipped with reliable high-speed regional Wi-Fi subscriptions, keeping students connected to digital learning.
                        </div>
                    </div>
                </div>
            </div>

            <!-- Column 2: Form -->
            <div class="lg:col-span-7 bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-800 p-6 sm:p-8 shadow-sm space-y-6">
                <div>
                    <h2 class="text-lg font-bold text-bushgreen dark:text-gold font-display uppercase tracking-wider">Support Pledge Form</h2>
                    <p class="text-slate-550 dark:text-slate-400 text-xs font-light mt-1">
                        Register your support pledge. Once submitted, our coordination desk will reach out with secure transaction options.
                    </p>
                </div>

                <?php if (!empty($donation_success)): ?>
                    <div class="p-3 bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-250 text-emerald-800 dark:text-emerald-400 rounded-xl text-xs font-semibold">
                        ✓ <?php echo htmlspecialchars($donation_success); ?>
                    </div>
                <?php endif; ?>

                <?php if (!empty($donation_error)): ?>
                    <div class="p-3 bg-red-50 dark:bg-red-950/30 border border-red-205 text-red-800 dark:text-red-400 rounded-xl text-xs font-semibold">
                        ⚠ <?php echo htmlspecialchars($donation_error); ?>
                    </div>
                <?php endif; ?>

                <form method="POST" action="" class="space-y-4">
                    <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                    <input type="hidden" name="action" value="submit_donation">

                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-slate-700 dark:text-slate-350 text-[10px] font-bold uppercase tracking-wider mb-1" for="donor_name">Your Full Name *</label>
                            <input type="text" name="donor_name" id="donor_name" required placeholder="e.g. John Doe"
                                   class="w-full px-3.5 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-bushgreen/20 focus:border-bushgreen dark:text-white transition">
                        </div>
                        <div>
                            <label class="block text-slate-700 dark:text-slate-350 text-[10px] font-bold uppercase tracking-wider mb-1" for="email">Email Address *</label>
                            <input type="email" name="email" id="email" required placeholder="john@example.com"
                                   class="w-full px-3.5 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-bushgreen/20 focus:border-bushgreen dark:text-white font-mono transition">
                        </div>
                    </div>

                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-slate-700 dark:text-slate-350 text-[10px] font-bold uppercase tracking-wider mb-1" for="phone">Phone Number</label>
                            <input type="text" name="phone" id="phone" placeholder="+234..."
                                   class="w-full px-3.5 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-bushgreen/20 focus:border-bushgreen dark:text-white font-mono transition">
                        </div>
                        <div>
                            <label class="block text-slate-700 dark:text-slate-350 text-[10px] font-bold uppercase tracking-wider mb-1" for="amount">Pledge Amount (₦) *</label>
                            <input type="number" name="amount" id="amount" required min="500" step="500" placeholder="Minimum ₦500"
                                   class="w-full px-3.5 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-bushgreen/20 focus:border-bushgreen dark:text-white font-mono transition">
                        </div>
                    </div>

                    <div>
                        <label class="block text-slate-700 dark:text-slate-350 text-[10px] font-bold uppercase tracking-wider mb-1" for="project_area">Project to Support *</label>
                        <select name="project_area" id="project_area" required
                                class="w-full px-3.5 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-bushgreen/20 focus:border-bushgreen dark:text-white transition">
                            <option value="Community Tech Labs">Community Computer Kiosks & Labs</option>
                            <option value="Solar Micro-Grid Power">Solar Micro-Grid Installations</option>
                            <option value="Internet Connectivity Support">Broadband & Router Bandwidth Support</option>
                            <option value="Ambassador Training kits">Outreach Training Kits for Ambassadors</option>
                            <option value="General Initiative Funding">General Support & Operations Fund</option>
                        </select>
                    </div>

                    <div>
                        <label class="block text-slate-700 dark:text-slate-350 text-[10px] font-bold uppercase tracking-wider mb-1" for="comments">Comments & Support Details</label>
                        <textarea name="comments" id="comments" rows="4" placeholder="Any specific requests, dedication details, or notes regarding your pledge..."
                                  class="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-bushgreen/20 focus:border-bushgreen dark:text-white leading-relaxed font-light transition"></textarea>
                    </div>

                    <button type="submit" class="w-full py-3 bg-bushgreen hover:bg-bushgreen-light text-white text-xs font-bold rounded-xl transition shadow-md border border-gold/20 flex items-center justify-center gap-1.5 uppercase tracking-wide">
                        Submit Support Pledge
                    </button>
                </form>
            </div>

        </div>
    </div>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
