<?php
/**
 * PBAT Smart Nation Initiative - Contact Us / Feedback
 * Dedicated contact and inquiry submission page.
 */
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/helpers/auth.php';
require_once __DIR__ . '/helpers/common.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$contact_success = '';
$contact_error = '';

// Handle Contact Feedback Form Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'submit_contact') {
    if (!Auth::validateCsrf($_POST['csrf_token'] ?? '')) {
        $contact_error = "CSRF Token validation failed.";
    } else {
        $name = trim($_POST['name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $subject = trim($_POST['subject'] ?? '');
        $message = trim($_POST['message'] ?? '');
        
        if (empty($name) || empty($email) || empty($subject) || empty($message)) {
            $contact_error = "All contact form fields are required.";
        } else {
            try {
                $db = Database::connect();
                $stmt = $db->prepare("INSERT INTO `contact_submissions` (name, email, subject, message, status) VALUES (?, ?, ?, ?, 'pending')");
                $stmt->execute([$name, $email, $subject, $message]);
                
                $contact_success = "Your feedback has been successfully submitted. Thank you!";
            } catch (Exception $e) {
                $contact_error = "Error submitting feedback: " . $e->getMessage();
            }
        }
    }
}

require_once __DIR__ . '/helpers/seo.php';
SEO::init([
    'title' => 'Contact Us & Public Feedback Channels | PBAT Smart Nation',
    'description' => 'Get in touch with the PBAT Smart Nation Initiative Directorate. Submit inquiries, partnership requests, or grassroots feedback.',
    'keywords' => 'Contact PBAT Smart Nation, Tech Advocacy Feedback Nigeria, Abuja Technology Secretariat, Regional Coordinators Directory',
    'breadcrumbs' => [
        ['name' => 'Contact Us', 'url' => '/contact']
    ]
]);

require_once __DIR__ . '/includes/header.php';
?>

<!-- Hero Header Section -->
<section class="relative bg-bushgreen text-white py-16 overflow-hidden border-b-8 border-gold">
    <div class="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-bushgreen-light/80 via-bushgreen to-bushgreen opacity-95"></div>
    <div class="absolute inset-0 bg-[linear-gradient(to_right,#ffffff05_1px,transparent_1px),linear-gradient(to_bottom,#ffffff05_1px,transparent_1px)] bg-[size:4rem_4rem]"></div>
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
        <span class="text-gold font-bold text-xs uppercase tracking-widest font-display">Get In Touch</span>
        <h1 class="text-3xl sm:text-4xl md:text-5xl font-black font-display uppercase tracking-tight mt-2">
            Contact Us & Feedback
        </h1>
        <p class="text-slate-355 text-xs sm:text-sm max-w-xl mx-auto font-light mt-3 leading-relaxed">
            Have questions, feedback, or suggestions? Reach out directly to the PBAT Smart Nation Steering Directorate.
        </p>
    </div>
</section>

<!-- Content Form Section -->
<section class="py-16 bg-slate-50 dark:bg-slate-900/50">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            
            <!-- Column 1: Contact details -->
            <div class="lg:col-span-5 space-y-6">
                <div class="bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-800 p-6 sm:p-8 shadow-sm space-y-6">
                    <h2 class="text-lg font-bold text-bushgreen dark:text-gold font-display uppercase tracking-wider">Contact Channels</h2>
                    <p class="text-xs text-slate-600 dark:text-slate-350 leading-relaxed font-light">
                        We value community input, tech inquiries, and feedback regarding our grassroots programs. Our steering committee actively monitors all messages to ensure that technical assistance is provided to local coordinators and citizens.
                    </p>
                    <div class="space-y-4">
                        <div class="p-4 bg-slate-50 dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800">
                            <strong class="text-slate-800 dark:text-white font-bold block mb-1">⏱️ Response Timeline</strong>
                            <p class="text-[11px] text-slate-505 dark:text-slate-400 font-light">
                                Our administrative team processes public feedback within 48 business hours. For urgent regional technical issues, local coordinators should use the dedicated messaging console in the Ambassador Portal.
                            </p>
                        </div>
                        <div class="p-4 bg-slate-50 dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800">
                            <strong class="text-slate-800 dark:text-white font-bold block mb-1">📍 Headquarters & Mailing</strong>
                            <p class="text-[11px] text-slate-505 dark:text-slate-400 font-light">
                                PBAT Smart Nation Initiative Directorate,<br>
                                Main Secretariat Area, Abuja, Nigeria.<br>
                                Email: <span class="font-semibold font-mono text-[10px]">info@pbat-smartnation.ng</span>
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Column 2: Form -->
            <div class="lg:col-span-7 bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-800 p-6 sm:p-10 shadow-md space-y-8">
                
                <div class="border-b border-slate-100 dark:border-slate-700 pb-4">
                    <h2 class="text-lg sm:text-xl font-bold text-bushgreen dark:text-gold font-display">Inquiry & Feedback Form</h2>
                    <p class="text-slate-500 dark:text-slate-400 text-xs font-light mt-1">
                        Please provide your name, email, subject, and message. We will review your message and reply as soon as possible.
                    </p>
                </div>

                <?php if (!empty($contact_success)): ?>
                    <div class="p-4 bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-250 text-emerald-800 dark:text-emerald-400 rounded-2xl text-xs font-semibold flex items-center gap-2">
                        <svg class="w-4.5 h-4.5 text-emerald-500 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/></svg>
                        <?php echo htmlspecialchars($contact_success); ?>
                    </div>
                <?php endif; ?>

                <?php if (!empty($contact_error)): ?>
                    <div class="p-4 bg-red-50 dark:bg-red-950/30 border border-red-205 text-red-800 dark:text-red-400 rounded-2xl text-xs font-semibold flex items-center gap-2">
                        <svg class="w-4.5 h-4.5 text-red-500 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clip-rule="evenodd"/></svg>
                        <?php echo htmlspecialchars($contact_error); ?>
                    </div>
                <?php endif; ?>

                <form method="POST" action="" class="space-y-6">
                    <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                    <input type="hidden" name="action" value="submit_contact">

                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-6">
                        <div>
                            <label class="block text-slate-700 dark:text-slate-350 text-[11px] font-bold uppercase tracking-wider mb-2" for="contact_full_name">Your Full Name *</label>
                            <input type="text" name="name" id="contact_full_name" required placeholder="e.g. Jane Doe"
                                   class="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-bushgreen/20 focus:border-bushgreen dark:text-white transition">
                        </div>
                        <div>
                            <label class="block text-slate-700 dark:text-slate-350 text-[11px] font-bold uppercase tracking-wider mb-2" for="contact_sender_email">Email Address *</label>
                            <input type="email" name="email" id="contact_sender_email" required placeholder="jane@example.com"
                                   class="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-bushgreen/20 focus:border-bushgreen dark:text-white font-mono transition">
                        </div>
                    </div>

                    <div>
                        <label class="block text-slate-700 dark:text-slate-350 text-[11px] font-bold uppercase tracking-wider mb-2" for="contact_subject">Subject *</label>
                        <input type="text" name="subject" id="contact_subject" required placeholder="Subject of your message"
                               class="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-bushgreen/20 focus:border-bushgreen dark:text-white transition">
                    </div>

                    <div>
                        <label class="block text-slate-700 dark:text-slate-350 text-[11px] font-bold uppercase tracking-wider mb-2" for="contact_message">Your Message *</label>
                        <textarea name="message" id="contact_message" required rows="6" placeholder="Provide details of your feedback or inquiry here..."
                                  class="w-full px-4 py-3 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-bushgreen/20 focus:border-bushgreen dark:text-white leading-relaxed font-light transition"></textarea>
                    </div>

                    <button type="submit" class="w-full py-3.5 bg-bushgreen hover:bg-bushgreen-light text-white text-xs font-bold rounded-xl transition shadow-md border border-gold/20 flex items-center justify-center gap-1.5 uppercase tracking-wider">
                        Send Message
                    </button>
                </form>
            </div>

        </div>
    </div>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
