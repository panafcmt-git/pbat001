<?php
/**
 * PBAT Smart Nation Initiative - Focus & Pillars
 * Premium detailed review of the five focus areas driving technology sensitization.
 */
require_once __DIR__ . '/helpers/seo.php';
SEO::init([
    'title' => 'Development Focus & Technology Pillars | PBAT Smart Nation',
    'description' => 'Explore the five development vectors of the PBAT Smart Nation Initiative: Smart Governance, Economy, People, Infrastructure, and Smart Living in Nigeria.',
    'keywords' => 'Technology Pillars Nigeria, Smart Cities Development, Digital Economy Nigeria, Broadband Expansion, Civic Tech Awareness',
    'breadcrumbs' => [
        ['name' => 'Development Pillars', 'url' => '/pillars']
    ]
]);

require_once __DIR__ . '/includes/header.php';
?>

<!-- Sub-Page Hero Banner -->
<section class="relative bg-bushgreen text-white py-20 overflow-hidden border-b-4 border-gold">
    <div class="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-bushgreen-light/70 via-bushgreen to-bushgreen-dark opacity-95"></div>
    <div class="absolute inset-0 bg-[linear-gradient(to_right,#ffffff02_1px,transparent_1px),linear-gradient(to_bottom,#ffffff02_1px,transparent_1px)] bg-[size:3rem_3rem]"></div>
    
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center space-y-4">
        <span class="text-gold font-bold text-xs uppercase tracking-widest font-display block"><?php echo htmlspecialchars(getSystemSetting('page_pillars_banner_badge', 'Development Vectors')); ?></span>
        <h1 class="text-3xl sm:text-5xl font-black font-display tracking-tight uppercase"><?php echo htmlspecialchars(getSystemSetting('page_pillars_banner_title', 'Our Key Pillars')); ?></h1>
        <p class="text-slate-300 text-xs sm:text-sm max-w-xl mx-auto font-light leading-relaxed">
            <?php echo htmlspecialchars(getSystemSetting('page_pillars_banner_desc', 'Exploring the structural parameters driving open administration, cashless trading, and broadband accessibility.')); ?>
        </p>
    </div>
</section>

<!-- Pillars Granular Details -->
<section class="py-20 bg-white dark:bg-slate-900">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <!-- Introductory Copy Section -->
        <div class="max-w-4xl mx-auto text-center space-y-6 mb-16">
            <p class="text-slate-600 dark:text-slate-300 text-xs sm:text-sm md:text-base leading-relaxed font-light">
                <?php echo htmlspecialchars(getSystemSetting('page_pillars_intro_desc1', "Our Key Pillars represent the core values and strategic focus areas that drive our vision for growth, innovation, and sustainable impact. They serve as the foundation for every initiative, program, and partnership we undertake, ensuring that our efforts remain aligned with our mission to empower people, strengthen communities, and create lasting transformation.")); ?>
            </p>
            <p class="text-slate-600 dark:text-slate-300 text-xs sm:text-sm md:text-base leading-relaxed font-light">
                <?php echo htmlspecialchars(getSystemSetting('page_pillars_intro_desc2', "Through these pillars, we are committed to advancing opportunities in education, technology, entrepreneurship, leadership, and social development. Each pillar is carefully designed to address critical challenges, encourage innovation, and promote inclusive progress across different sectors and communities.")); ?>
            </p>
            <p class="text-slate-600 dark:text-slate-300 text-xs sm:text-sm md:text-base leading-relaxed font-light">
                <?php echo htmlspecialchars(getSystemSetting('page_pillars_intro_desc3', "We believe that meaningful development is achieved through collaboration, creativity, and consistent investment in people and ideas. By focusing on these essential areas, we create pathways for individuals and organizations to grow, thrive, and contribute positively to society.")); ?>
            </p>
            <p class="text-slate-600 dark:text-slate-300 text-xs sm:text-sm md:text-base leading-relaxed font-light">
                <?php echo htmlspecialchars(getSystemSetting('page_pillars_intro_desc4', "Our Key Pillars are more than just areas of focus — they are a reflection of our commitment to building a future driven by knowledge, empowerment, sustainability, and measurable impact. Together, they guide our journey toward creating innovative solutions and transformative opportunities for generations to come.")); ?>
            </p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            
            <!-- Pillar 1 -->
            <a href="pillar-detail.php?type=governance" class="bg-slate-50 p-6 rounded-2xl border border-slate-100 hover:border-gold hover:ring-1 hover:ring-gold/40 hover:shadow-lg hover:-translate-y-1 transition-all flex flex-col justify-between group">
                <div class="space-y-4">
                    <div class="w-12 h-12 rounded-xl bg-bushgreen/10 text-bushgreen flex items-center justify-center border border-bushgreen/5 group-hover:bg-bushgreen group-hover:text-white transition">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/></svg>
                    </div>
                    <h3 class="text-slate-800 font-bold text-base font-display">1. Smart Governance</h3>
                    <p class="text-slate-600 text-xs leading-relaxed font-light">
                        Sensitizing local government units on implementing open source data archives, cloud integration platforms, and paperless workflow management to ensure administrative efficiency.
                    </p>
                </div>
            </a>

            <!-- Pillar 2 -->
            <a href="pillar-detail.php?type=economy" class="bg-slate-50 p-6 rounded-2xl border border-slate-100 hover:border-gold hover:ring-1 hover:ring-gold/40 hover:shadow-lg hover:-translate-y-1 transition-all flex flex-col justify-between group">
                <div class="space-y-4">
                    <div class="w-12 h-12 rounded-xl bg-bushgreen/10 text-bushgreen flex items-center justify-center border border-bushgreen/5 group-hover:bg-bushgreen group-hover:text-white transition">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                    </div>
                    <h3 class="text-slate-800 font-bold text-base font-display">2. Smart Economy</h3>
                    <p class="text-slate-600 text-xs leading-relaxed font-light">
                        Empowering micro and small business owners with simple software applications to capture cashless sales, formulate inventory metrics, and gain access to wider digital markets.
                    </p>
                </div>
            </a>

            <!-- Pillar 3 -->
            <a href="pillar-detail.php?type=people" class="bg-slate-50 p-6 rounded-2xl border border-slate-100 hover:border-gold hover:ring-1 hover:ring-gold/40 hover:shadow-lg hover:-translate-y-1 transition-all flex flex-col justify-between group">
                <div class="space-y-4">
                    <div class="w-12 h-12 rounded-xl bg-bushgreen/10 text-bushgreen flex items-center justify-center border border-bushgreen/5 group-hover:bg-bushgreen group-hover:text-white transition">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"/></svg>
                    </div>
                    <h3 class="text-slate-800 font-bold text-base font-display">3. Smart People</h3>
                    <p class="text-slate-600 text-xs leading-relaxed font-light">
                        Deploying regional tech skill centers focusing on frontend coding, cyber-safety audits, and basic database cataloging courses targeting primary youth populations.
                    </p>
                </div>
            </a>

            <!-- Pillar 4 -->
            <a href="pillar-detail.php?type=infrastructure" class="bg-slate-50 p-6 rounded-2xl border border-slate-100 hover:border-gold hover:ring-1 hover:ring-gold/40 hover:shadow-lg hover:-translate-y-1 transition-all flex flex-col justify-between group">
                <div class="space-y-4">
                    <div class="w-12 h-12 rounded-xl bg-bushgreen/10 text-bushgreen flex items-center justify-center border border-bushgreen/5 group-hover:bg-bushgreen group-hover:text-white transition">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"/></svg>
                    </div>
                    <h3 class="text-slate-800 font-bold text-base font-display">4. Smart Infrastructure</h3>
                    <p class="text-slate-600 text-xs leading-relaxed font-light">
                        Promoting policies and private investments targeting community micro-grid solar systems, municipal public Wi-Fi hotspots, and shared community computer laboratories.
                    </p>
                </div>
            </a>

            <!-- Pillar 5 -->
            <a href="pillar-detail.php?type=living" class="bg-slate-50 p-6 rounded-2xl border border-slate-100 hover:border-gold hover:ring-1 hover:ring-gold/40 hover:shadow-lg hover:-translate-y-1 transition-all flex flex-col justify-between group">
                <div class="space-y-4">
                    <div class="w-12 h-12 rounded-xl bg-bushgreen/10 text-bushgreen flex items-center justify-center border border-bushgreen/5 group-hover:bg-bushgreen group-hover:text-white transition">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"/></svg>
                    </div>
                    <h3 class="text-slate-800 font-bold text-base font-display">5. Smart Living</h3>
                    <p class="text-slate-600 text-xs leading-relaxed font-light">
                        Sensitizing local families on dynamic digital identity protection, basic medical sensitization tools, and active virtual civic town hall participations.
                    </p>
                </div>
            </a>

        </div>

    </div>
</section>

<?php
require_once __DIR__ . '/includes/footer.php';
?>
