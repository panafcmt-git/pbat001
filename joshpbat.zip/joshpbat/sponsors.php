<?php
/**
 * PBAT Smart Nation Initiative - Project Sponsors Program
 * Dedicated page for corporate and strategic funding proposals.
 */
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/helpers/auth.php';
require_once __DIR__ . '/helpers/common.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$sponsor_success = '';
$sponsor_error = '';

// Handle Project Sponsor Form Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'submit_sponsor') {
    if (!Auth::validateCsrf($_POST['csrf_token'] ?? '')) {
        $sponsor_error = "CSRF Token validation failed.";
    } else {
        $company_name = trim($_POST['company_name'] ?? '');
        $contact_name = trim($_POST['contact_name'] ?? '');
        $contact_email = trim($_POST['contact_email'] ?? '');
        $contact_phone = trim($_POST['contact_phone'] ?? '');
        $sponsorship_category = trim($_POST['sponsorship_category'] ?? '');
        $sponsor_amount = (float)($_POST['sponsor_amount'] ?? 0);
        $message = trim($_POST['message'] ?? '');
        
        if (empty($company_name) || empty($contact_name) || empty($contact_email)) {
            $sponsor_error = "Please fill in all required fields (Company Name, Contact Name, and Email).";
        } else {
            try {
                $db = Database::connect();
                $stmt = $db->prepare("INSERT INTO `project_sponsors` (company_name, contact_name, contact_email, contact_phone, sponsorship_category, sponsor_amount, message, status) VALUES (?, ?, ?, ?, ?, ?, ?, 'pending')");
                $stmt->execute([$company_name, $contact_name, $contact_email, $contact_phone, $sponsorship_category, $sponsor_amount, $message]);
                
                $sponsor_success = "Thank you for your interest! Our strategic steering directorate will follow up with you shortly.";
            } catch (Exception $e) {
                $sponsor_error = "Error submitting sponsorship request: " . $e->getMessage();
            }
        }
    }
}

require_once __DIR__ . '/helpers/seo.php';
SEO::init([
    'title' => 'Project Sponsors Program & Corporate Backers | PBAT Smart Nation',
    'description' => 'Become a strategic project sponsor. Fund digital skills centers, youth innovation bootcamps, and local AI literacy programs across Nigeria.',
    'keywords' => 'Project Sponsors Nigeria, Corporate Tech CSR, Civic Tech Backers, cPanel Tech secretariat, PBAT Smart Nation Program',
    'breadcrumbs' => [
        ['name' => 'Sponsors Program', 'url' => '/sponsors']
    ]
]);

require_once __DIR__ . '/includes/header.php';
?>

<!-- Hero Header Section -->
<section class="relative bg-bushgreen text-white py-16 overflow-hidden border-b-8 border-gold">
    <div class="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-bushgreen-light/80 via-bushgreen to-bushgreen opacity-95"></div>
    <div class="absolute inset-0 bg-[linear-gradient(to_right,#ffffff05_1px,transparent_1px),linear-gradient(to_bottom,#ffffff05_1px,transparent_1px)] bg-[size:4rem_4rem]"></div>
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
        <span class="text-gold font-bold text-xs uppercase tracking-widest font-display">Strategic Support</span>
        <h1 class="text-3xl sm:text-4xl md:text-5xl font-black font-display uppercase tracking-tight mt-2">
            Project Sponsors Program
        </h1>
        <p class="text-slate-350 text-xs sm:text-sm max-w-xl mx-auto font-light mt-3 leading-relaxed">
            Partner with the PBAT Smart Nation Initiative to scale youth digital skills, AI literacy, and grassroots technical empowerment hubs across Nigeria.
        </p>
    </div>
</section>

<!-- Content Form Section -->
<section class="py-16 bg-slate-50 dark:bg-slate-900/50">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            
            <!-- Column 1: Sponsorship Details -->
            <div class="lg:col-span-5 space-y-6">
                <div class="bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-800 p-6 sm:p-8 shadow-sm space-y-6">
                    <h2 class="text-lg font-bold text-bushgreen dark:text-gold font-display uppercase tracking-wider">Advocacy & Sponsorship</h2>
                    <p class="text-xs text-slate-600 dark:text-slate-350 leading-relaxed font-light">
                        The PBAT Smart Nation Initiative operates a fully transparent, highly audited sponsorship program designed to support sustainable technological growth across Nigeria. By partnering with our program, corporate sponsors gain direct access to a network of young, trained ambassadors who spearhead local digitization.
                    </p>
                    <div class="space-y-4">
                        <div class="p-4 bg-slate-50 dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800">
                            <strong class="text-slate-800 dark:text-white font-bold block mb-1">🔍 Accountability & Audits</strong>
                            <p class="text-[11px] text-slate-500 dark:text-slate-400 font-light">
                                Every sponsorship contribution is linked directly to a physical community project. We publish quarterly resource-allocation logs and audit summaries in our Super Admin dashboard for complete transparency.
                            </p>
                        </div>
                        <div class="p-4 bg-slate-50 dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800">
                            <strong class="text-slate-800 dark:text-white font-bold block mb-1">📢 Corporate Branding & Recognition</strong>
                            <p class="text-[11px] text-slate-500 dark:text-slate-400 font-light">
                                Sponsors are prominently recognized during our national webinars, local town halls, and featured on the official PBAT Smart Nation platform homepage and press briefs.
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Column 2: Form -->
            <div class="lg:col-span-7 bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-800 p-6 sm:p-10 shadow-md space-y-8">
                
                <div class="border-b border-slate-100 dark:border-slate-700 pb-4">
                    <h2 class="text-lg sm:text-xl font-bold text-bushgreen dark:text-gold font-display">Sponsorship Proposal Form</h2>
                    <p class="text-slate-500 dark:text-slate-400 text-xs font-light mt-1">
                        Fill in your organization details, choose a sponsorship tier/category, and submit your proposal. Our partnership unit will review the request.
                    </p>
                </div>

                <?php if (!empty($sponsor_success)): ?>
                    <div class="p-4 bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-250 text-emerald-800 dark:text-emerald-400 rounded-2xl text-xs font-semibold flex items-center gap-2">
                        <svg class="w-4.5 h-4.5 text-emerald-500 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/></svg>
                        <?php echo htmlspecialchars($sponsor_success); ?>
                    </div>
                <?php endif; ?>

                <?php if (!empty($sponsor_error)): ?>
                    <div class="p-4 bg-red-50 dark:bg-red-950/30 border border-red-205 text-red-800 dark:text-red-400 rounded-2xl text-xs font-semibold flex items-center gap-2">
                        <svg class="w-4.5 h-4.5 text-red-500 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clip-rule="evenodd"/></svg>
                        <?php echo htmlspecialchars($sponsor_error); ?>
                    </div>
                <?php endif; ?>

                <form method="POST" action="" class="space-y-6">
                    <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                    <input type="hidden" name="action" value="submit_sponsor">

                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-6">
                        <div>
                            <label class="block text-slate-700 dark:text-slate-350 text-[11px] font-bold uppercase tracking-wider mb-2" for="company_name">Company / Organization Name *</label>
                            <input type="text" name="company_name" id="company_name" required placeholder="Acme Tech Group"
                                   class="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-bushgreen/20 focus:border-bushgreen dark:text-white transition">
                        </div>
                        <div>
                            <label class="block text-slate-700 dark:text-slate-350 text-[11px] font-bold uppercase tracking-wider mb-2" for="contact_name">Contact Person Name *</label>
                            <input type="text" name="contact_name" id="contact_name" required placeholder="e.g. John Doe"
                                   class="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-bushgreen/20 focus:border-bushgreen dark:text-white transition">
                        </div>
                    </div>

                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-6">
                        <div>
                            <label class="block text-slate-700 dark:text-slate-350 text-[11px] font-bold uppercase tracking-wider mb-2" for="contact_email">Email Address *</label>
                            <input type="email" name="contact_email" id="contact_email" required placeholder="johndoe@acme.com"
                                   class="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-bushgreen/20 focus:border-bushgreen dark:text-white font-mono transition">
                        </div>
                        <div>
                            <label class="block text-slate-700 dark:text-slate-350 text-[11px] font-bold uppercase tracking-wider mb-2" for="contact_phone">Phone Number</label>
                            <input type="text" name="contact_phone" id="contact_phone" placeholder="+234..."
                                   class="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-bushgreen/20 focus:border-bushgreen dark:text-white font-mono transition">
                        </div>
                    </div>

                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-6">
                        <div>
                            <label class="block text-slate-700 dark:text-slate-350 text-[11px] font-bold uppercase tracking-wider mb-2" for="sponsorship_category">Sponsorship Category *</label>
                            <select name="sponsorship_category" id="sponsorship_category" required
                                    class="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-bushgreen/20 focus:border-bushgreen dark:text-white transition">
                                <option value="Corporate Partnership">Corporate Partnership</option>
                                <option value="Strategic Funding">Strategic Funding</option>
                                <option value="Training Infrastructure">Training Infrastructure</option>
                                <option value="Publicity Sponsor">Publicity Sponsor</option>
                            </select>
                        </div>
                        <div>
                            <label class="block text-slate-700 dark:text-slate-350 text-[11px] font-bold uppercase tracking-wider mb-2" for="sponsor_amount">Sponsorship Amount Offer (₦) *</label>
                            <input type="number" name="sponsor_amount" id="sponsor_amount" required min="0" step="1000" placeholder="e.g. 500000"
                                   class="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-bushgreen/20 focus:border-bushgreen dark:text-white font-mono transition">
                        </div>
                    </div>

                    <div>
                        <label class="block text-slate-700 dark:text-slate-350 text-[11px] font-bold uppercase tracking-wider mb-2" for="sponsor_message">Sponsorship Proposal Details</label>
                        <textarea name="message" id="sponsor_message" rows="5" placeholder="Describe how your resources will help scale the initiative..."
                                  class="w-full px-4 py-3 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-bushgreen/20 focus:border-bushgreen dark:text-white leading-relaxed font-light transition"></textarea>
                    </div>

                    <button type="submit" class="w-full py-3.5 bg-bushgreen hover:bg-bushgreen-light text-white text-xs font-bold rounded-xl transition shadow-md border border-gold/20 flex items-center justify-center gap-1.5 uppercase tracking-wider">
                        Submit Sponsorship Proposal
                    </button>
                </form>
            </div>

        </div>
    </div>
</section>


<?php require_once __DIR__ . '/includes/footer.php'; ?>
