<?php
/**
 * PBAT Smart Nation Initiative - Media Center & Smart Nation TV
 * Gorgeous media hub compiling active video streams, policy drafts, and tech bulletins.
 */
require_once __DIR__ . '/helpers/seo.php';
SEO::init([
    'title' => 'Advocacy News, Media Center & Smart Nation TV | PBAT Smart Nation',
    'description' => 'Read our strategic news circulars, view upcoming technology webinars, and watch live Smart Nation TV streams.',
    'keywords' => 'Digital Advocacy Nigeria News, Smart Nation TV, Tech Policy Broadcasts, Nigeria Innovation Webinars, Youth Technology Updates',
    'breadcrumbs' => [
        ['name' => 'Media Center', 'url' => '/media']
    ]
]);

require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/helpers/common.php';

$blog_posts = [];

try {
    $db = Database::connect();
    // Fetch publications
    $stmt = $db->query("SELECT b.*, u.name as author_name FROM `blog_posts` b JOIN `users` u ON b.author_id = u.id WHERE b.status = 'published' AND b.is_approved = 1 ORDER BY b.created_at DESC");
    $blog_posts = $stmt->fetchAll();

    // Fetch on-demand YouTube videos
    $stmt_yt = $db->query("SELECT * FROM `youtube_videos` ORDER BY `is_featured` DESC, `created_at` DESC");
    $youtube_videos = $stmt_yt->fetchAll();

    // Determine featured video
    $featured_video = null;
    foreach ($youtube_videos as $yt) {
        if ($yt['is_featured'] == 1) {
            $featured_video = $yt;
            break;
        }
    }
    // Fallback to first video if no featured video exists
    if (!$featured_video && !empty($youtube_videos)) {
        $featured_video = $youtube_videos[0];
    }
} catch (Exception $e) {
    // Fallbacks if DB offline
    $blog_posts = [
        [
            'title' => 'PBAT Smart Nation System Performance',
            'summary' => 'An overview of our advocacy reach across the six geo-political zones of Nigeria.',
            'cover_image' => 'assets/img/blog1.jpg',
            'author_name' => 'Hon. Yusuf Bello',
            'created_at' => '2026-06-01'
        ],
        [
            'title' => 'AI Revolution and National Development',
            'summary' => 'Exploring how Artificial Intelligence can catalyze growth in small and medium enterprises.',
            'cover_image' => 'assets/img/blog2.jpg',
            'author_name' => 'Alhaji Ibrahim Dan-Ina',
            'created_at' => '2026-05-28'
        ],
        [
            'title' => 'Infrastructure Strategy for Smart Cities',
            'summary' => 'Developing modern templates for internet connectivity, secure cloud nodes, and community digital workspaces.',
            'cover_image' => 'assets/img/blog3.jpg',
            'author_name' => 'Dr. Chioma Nnaji',
            'created_at' => '2026-05-25'
        ]
    ];
}

// Fallback if DB offline or empty for YouTube videos
if (empty($youtube_videos)) {
    $youtube_videos = [
        [
            'id' => 1,
            'title' => 'Grassroots Tech Inclusion Guidelines',
            'description' => 'Instructions for LGA coordinators establishing community digital centers.',
            'youtube_id' => 'dQw4w9WgXcQ',
            'video_source' => 'youtube',
            'video_url' => '',
            'duration' => '45 mins',
            'is_featured' => 1
        ],
        [
            'id' => 2,
            'title' => 'AI Literacy Policy Dialog',
            'description' => 'Strategic conversation explaining neural net integration frameworks in Nigeria.',
            'youtube_id' => 'dQw4w9WgXcQ',
            'video_source' => 'youtube',
            'video_url' => '',
            'duration' => '32 mins',
            'is_featured' => 0
        ]
    ];
    $featured_video = $youtube_videos[0];
}
?>

<!-- Sub-Page Hero Banner -->
<section class="relative bg-bushgreen text-white py-20 overflow-hidden border-b-4 border-gold">
    <div class="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-bushgreen-light/70 via-bushgreen to-bushgreen-dark opacity-95"></div>
    <div class="absolute inset-0 bg-[linear-gradient(to_right,#ffffff02_1px,transparent_1px),linear-gradient(to_bottom,#ffffff02_1px,transparent_1px)] bg-[size:3rem_3rem]"></div>
    
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center space-y-4">
        <span class="text-gold font-bold text-xs uppercase tracking-widest font-display block">Information Center</span>
        <h1 class="text-3xl sm:text-5xl font-black font-display tracking-tight uppercase">Media Center & TV</h1>
        <p class="text-slate-300 text-xs sm:text-sm max-w-xl mx-auto font-light leading-relaxed">
            Access recent educational broadcasts, policy briefs, and national coordinator activity summaries.
        </p>
    </div>
</section>

<!-- Smart Nation LIVE tv Section -->
<section id="smart-nation-live-tv" class="py-20 bg-white">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        <div class="space-y-2">
            <span class="text-gold font-bold text-xs uppercase tracking-widest font-display block">Active Streams</span>
            <h2 class="text-2xl font-extrabold text-bushgreen font-display">Smart Nation LIVE tv</h2>
            <p class="text-slate-500 text-xs font-light">Watch educational webinars, civic leadership guides, and tech policy dialogs live from the Smart Nation LIVE tv hub.</p>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-12 gap-8"
             x-data="{ 
                 currentId: '<?php echo $featured_video['id'] ?? 1; ?>',
                 currentSource: '<?php echo $featured_video['video_source'] ?? 'youtube'; ?>',
                 currentYoutubeId: '<?php echo $featured_video['youtube_id'] ?? ''; ?>',
                 currentVideoUrl: '<?php echo $featured_video['video_url'] ?? ''; ?>',
                 currentTitle: <?php echo htmlspecialchars(json_encode($featured_video['title'])); ?>,
                 currentDescription: <?php echo htmlspecialchars(json_encode($featured_video['description'])); ?>
             }">
            <!-- Simulated Video Player -->
            <div class="lg:col-span-8 space-y-4">
                <div class="bg-slate-900 rounded-2xl overflow-hidden border border-slate-800 shadow-2xl relative aspect-video">
                    <!-- YouTube Source -->
                    <template x-if="currentSource === 'youtube'">
                        <iframe class="w-full h-full" 
                                :src="'https://www.youtube.com/embed/' + currentYoutubeId" 
                                title="PBAT Smart Nation Featured Broadcast" 
                                frameborder="0" 
                                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" 
                                allowfullscreen>
                        </iframe>
                    </template>
                    
                    <!-- Google Drive Source -->
                    <template x-if="currentSource === 'google_drive'">
                        <iframe class="w-full h-full" 
                                :src="currentVideoUrl" 
                                title="PBAT Smart Nation Featured Broadcast" 
                                frameborder="0" 
                                allow="autoplay; encrypted-media" 
                                allowfullscreen>
                        </iframe>
                    </template>
                    
                    <!-- Self-hosted or S3 Video Source -->
                    <template x-if="currentSource === 'self_hosted' || currentSource === 's3'">
                        <video class="w-full h-full animate-fade-in" controls preload="metadata" :src="currentVideoUrl" :key="currentVideoUrl">
                            Your browser does not support the video tag.
                        </video>
                    </template>
                </div>
                <div class="p-5 bg-slate-50 rounded-2xl border border-slate-100 shadow-sm space-y-2">
                    <h3 class="text-sm sm:text-base font-bold text-bushgreen font-display" x-text="currentTitle"></h3>
                    <p class="text-slate-500 text-xs font-light leading-relaxed" x-text="currentDescription"></p>
                </div>
            </div>

            <!-- Up Next List -->
            <div class="lg:col-span-4 space-y-4">
                <h3 class="text-slate-800 font-bold text-xs tracking-wider uppercase border-b border-slate-100 pb-2">Up Next</h3>
                
                <div class="space-y-3 max-h-[500px] overflow-y-auto pr-1">
                    <?php foreach ($youtube_videos as $yt): ?>
                        <div class="bg-slate-50 rounded-xl p-3 border border-slate-100 flex gap-3 hover:border-gold/30 cursor-pointer transition"
                             :class="currentId == '<?php echo $yt['id']; ?>' ? 'border-gold ring-1 ring-gold/40 bg-gold/5' : ''"
                             @click="currentId = '<?php echo $yt['id']; ?>'; currentSource = '<?php echo $yt['video_source'] ?? 'youtube'; ?>'; currentYoutubeId = '<?php echo $yt['youtube_id'] ?? ''; ?>'; currentVideoUrl = '<?php echo $yt['video_url'] ?? ''; ?>'; currentTitle = <?php echo htmlspecialchars(json_encode($yt['title'])); ?>; currentDescription = <?php echo htmlspecialchars(json_encode($yt['description'])); ?>;">
                            <div class="w-20 aspect-video bg-bushgreen rounded-lg flex-shrink-0 flex items-center justify-center border border-gold/25 relative text-white overflow-hidden">
                                <?php if (($yt['video_source'] ?? 'youtube') === 'youtube' && !empty($yt['youtube_id'])): ?>
                                    <img src="https://img.youtube.com/vi/<?php echo htmlspecialchars($yt['youtube_id']); ?>/hqdefault.jpg" class="w-full h-full object-cover opacity-85" />
                                <?php else: ?>
                                    <div class="absolute inset-0 bg-gradient-to-br from-bushgreen-light to-bushgreen-dark flex flex-col items-center justify-center p-1">
                                        <span class="text-[8px] font-bold text-gold uppercase tracking-widest mb-0.5">
                                            <?php 
                                            $src = $yt['video_source'] ?? 'video';
                                            if ($src === 'self_hosted') echo 'LOCAL';
                                            elseif ($src === 'google_drive') echo 'DRIVE';
                                            elseif ($src === 's3') echo 'S3';
                                            else echo strtoupper($src);
                                            ?>
                                        </span>
                                        <svg class="w-4 h-4 text-white/40" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z"/>
                                        </svg>
                                    </div>
                                <?php endif; ?>
                                <span class="absolute right-1 bottom-1 text-[8px] px-1 py-0.2 rounded bg-black/60 font-mono"><?php echo htmlspecialchars($yt['duration'] ?? 'N/A'); ?></span>
                                <div class="absolute inset-0 flex items-center justify-center bg-black/20">
                                    <svg class="w-5 h-5 text-gold drop-shadow" fill="currentColor" viewBox="0 0 20 20"><path d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z"/></svg>
                                </div>
                            </div>
                            <div class="space-y-1 min-w-0 flex-grow">
                                <h4 class="text-xs font-bold text-slate-800 line-clamp-1 font-display" :class="currentId == '<?php echo $yt['id']; ?>' ? 'text-bushgreen font-black' : ''"><?php echo htmlspecialchars($yt['title']); ?></h4>
                                <p class="text-[10px] text-slate-500 line-clamp-2 leading-relaxed font-light"><?php echo htmlspecialchars($yt['description']); ?></p>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Publications Grid -->
<section class="py-20 bg-slate-50 border-t border-slate-100">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        <div class="space-y-2">
            <span class="text-gold font-bold text-xs uppercase tracking-widest font-display block">Advocacy Feed</span>
            <h2 class="text-2xl font-extrabold text-bushgreen font-display">Strategic News & Policy Updates</h2>
            <p class="text-slate-500 text-xs font-light">Read circular briefings and national technology outlines.</p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
            <?php foreach ($blog_posts as $post): 
                $cover = $post['cover_image'] ?? '';
                if (empty($cover) || strpos($cover, 'assets/') === 0) {
                    if (strpos($cover, 'blog1') !== false) {
                        $cover = 'https://images.unsplash.com/photo-1557804506-669a67965ba0?auto=format&fit=crop&w=800&q=80';
                    } elseif (strpos($cover, 'blog2') !== false) {
                        $cover = 'https://images.unsplash.com/photo-1531482615713-2afd69097998?auto=format&fit=crop&w=800&q=80';
                    } elseif (strpos($cover, 'blog3') !== false) {
                        $cover = 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=800&q=80';
                    } else {
                        $cover = 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=800&q=80';
                    }
                }
            ?>
                <div class="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden hover:shadow-md hover:border-gold/30 transition flex flex-col justify-between">
                    <div>
                        <div class="h-48 w-full bg-slate-100 relative">
                            <div class="absolute inset-0 bg-cover bg-center" style="background-image: url('<?php echo htmlspecialchars($cover); ?>');"></div>
                            <span class="absolute left-4 bottom-4 bg-bushgreen text-white font-bold text-[9px] px-2 py-1 rounded uppercase tracking-widest"><?php echo htmlspecialchars($post['category'] ?? 'News'); ?></span>
                        </div>
                        <div class="p-6 space-y-3">
                            <h3 class="text-slate-800 font-bold text-sm line-clamp-2 font-display"><?php echo htmlspecialchars($post['title']); ?></h3>
                            <p class="text-slate-500 text-xs leading-relaxed font-light line-clamp-3">
                                <?php echo htmlspecialchars($post['summary'] ?? ''); ?>
                            </p>
                        </div>
                    </div>
                    <div class="p-6 pt-0 flex justify-between items-center border-t border-slate-50 mt-4 text-[10px] text-slate-400 font-semibold">
                        <span>By: <?php echo htmlspecialchars($post['author_name'] ?? 'National Director'); ?></span>
                        <a href="article.php?id=<?php echo $post['id']; ?>" class="text-bushgreen hover:text-gold font-bold">Read Full &rarr;</a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<?php
require_once __DIR__ . '/includes/footer.php';
?>
