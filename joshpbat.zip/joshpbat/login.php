<?php
/**
 * PBAT Smart Nation Initiative - Portal Login
 * Secure, stunning glassmorphic login gate with CSRF protection and sanitization.
 */
require_once __DIR__ . '/helpers/auth.php';
require_once __DIR__ . '/helpers/common.php';
require_once __DIR__ . '/config/database.php';

if (Auth::isLoggedIn()) {
    header("Location: admin/dashboard.php");
    exit;
}

$error = '';
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 1. CSRF Verification
    if (!Auth::validateCsrf($_POST['csrf_token'] ?? '')) {
        $error = "Security validation expired. Please refresh and try again.";
    } else {
        $email = trim($_POST['email']);
        $password = $_POST['password'];

        if (empty($email) || empty($password)) {
            $error = "Please fill in all credentials.";
        } else {
            try {
                $db = Database::connect();
                
                // Fetch user record
                $stmt = $db->prepare("SELECT * FROM `users` WHERE `email` = ? LIMIT 1");
                $stmt->execute([$email]);
                $user = $stmt->fetch();

                if ($user && password_verify($password, $user['password'])) {
                    if ($user['status'] === 'suspended') {
                        $error = "Your account has been temporarily suspended. Contact steering council.";
                    } elseif (!$user['email_verified']) {
                        $error = 'Your email address is not verified yet. <a href="onboard.php?email=' . urlencode($user['email']) . '" class="text-bushgreen hover:underline font-bold">Click here to resend the verification link</a>.';
                    } else {
                        // Success - Establish session details
                        Auth::login($user);
                        
                        // Clear alerts and redirect
                        $_SESSION['success_msg'] = "Welcome back, " . $user['name'] . "!";
                        header("Location: admin/dashboard.php");
                        exit;
                    }
                } else {
                    $error = "Invalid email address or password combination.";
                }
            } catch (Exception $e) {
                $error = "System Connection Issue: " . $e->getMessage();
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ambassador Portal Login - PBAT Smart Nation</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        bushgreen: {
                            DEFAULT: '#063C1E',
                            light: '#0A4D27',
                            dark: '#03200F',
                        },
                        gold: '#D4AF37'
                    }
                }
            }
        }
    </script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Outfit', sans-serif; }
    </style>
</head>
<body class="bg-slate-50 min-h-screen flex items-center justify-center p-4 relative overflow-hidden">
    <!-- Visual glows background -->
    <div class="absolute w-[500px] h-[500px] bg-bushgreen/10 rounded-full blur-[100px] -top-40 -left-40 pointer-events-none"></div>
    <div class="absolute w-[500px] h-[500px] bg-gold/5 rounded-full blur-[100px] -bottom-40 -right-40 pointer-events-none"></div>

    <div class="max-w-md w-full bg-white rounded-3xl shadow-2xl overflow-hidden border border-slate-100 relative z-10 transition-all duration-300">
        
        <!-- Header banner background curved -->
        <div class="bg-bushgreen p-8 text-center relative overflow-hidden">
            <div class="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-emerald-800/50 via-bushgreen to-bushgreen opacity-95"></div>
            <div class="relative z-10 space-y-2">
                <a href="index.php" class="inline-block">
                    <div class="w-12 h-12 bg-white/10 rounded-xl flex items-center justify-center mx-auto border border-white/20 hover:scale-105 transition p-2">
                        <?php echo getAppLogoHtml('w-full h-full object-contain', 'login'); ?>
                    </div>
                </a>
                <h1 class="text-white text-xl font-bold tracking-tight">Ambassador Portal Login</h1>
                <p class="text-emerald-200/80 text-xs font-light">PBAT Smart Nation Initiative &bull; Advocacy Team</p>
            </div>
        </div>

        <div class="p-8">
            <!-- Alert Display -->
            <?php if (!empty($error)): ?>
                <div class="mb-5 p-3.5 bg-red-50 border-l-4 border-red-500 rounded-r-lg text-xs text-red-700 font-semibold flex items-center gap-2">
                    <svg class="w-4 h-4 text-red-500 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clip-rule="evenodd"/></svg>
                    <?php echo $error; ?>
                </div>
            <?php endif; ?>

            <?php if (isset($_SESSION['auth_error'])): ?>
                <div class="mb-5 p-3.5 bg-amber-50 border-l-4 border-amber-500 rounded-r-lg text-xs text-amber-800 font-semibold flex items-center gap-2">
                    <svg class="w-4 h-4 text-amber-500 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clip-rule="evenodd"/></svg>
                    <?php echo htmlspecialchars($_SESSION['auth_error']); unset($_SESSION['auth_error']); ?>
                </div>
            <?php endif; ?>

            <form method="POST" action="" class="space-y-5">
                <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">

                <div>
                    <label class="block text-slate-700 text-xs font-semibold mb-1.5" for="email">Portal Email Address</label>
                    <input type="email" name="email" id="email" value="<?php echo htmlspecialchars($email); ?>" required placeholder="e.g. ambassador@pbat-smartnation.ng"
                           class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 focus:outline-none focus:ring-2 focus:ring-bushgreen/20 focus:border-bushgreen transition text-xs">
                </div>

                <div>
                    <div class="flex justify-between items-center mb-1.5">
                        <label class="text-slate-700 text-xs font-semibold" for="password">Account Password</label>
                        <a href="forgot-password.php" class="text-bushgreen hover:text-gold text-[10px] font-bold">Forgot Password?</a>
                    </div>
                    <input type="password" name="password" id="password" required placeholder="Enter password key"
                           class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 focus:outline-none focus:ring-2 focus:ring-bushgreen/20 focus:border-bushgreen transition text-xs">
                </div>

                <button type="submit" class="w-full py-3 bg-bushgreen hover:bg-bushgreen-light text-white font-bold rounded-xl text-xs shadow-md shadow-bushgreen/10 transition-all flex items-center justify-center gap-1.5 hover:scale-105">
                    AUTHENTICATE PORTAL ACCESS
                </button>
            </form>

            <div class="mt-8 border-t border-slate-100 pt-6 text-center text-xs">
                <span class="text-slate-500">Not yet an appointed ambassador?</span>
                <a href="register.php" class="text-bushgreen hover:text-gold font-bold ml-1.5">Register / Join Movement</a>
            </div>
            
            <div class="mt-4 text-center text-[10px] text-slate-400">
                Independent Advocacy &bull; <a href="index.php" class="hover:underline text-bushgreen">Back to Site Front</a>
            </div>
        </div>
    </div>
</body>
</html>
