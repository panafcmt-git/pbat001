<?php
/**
 * PBAT Smart Nation Initiative - Auto-Setup & Installer Wizard
 * Beautiful, secure installation panel for cPanel/Apache environments
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

$config_file = __DIR__ . '/config.php';
$schema_file = dirname(__DIR__) . '/database/schema.sql';

$error = '';
$success = '';

// Check if already installed
$is_installed = false;
if (file_exists($config_file)) {
    require_once $config_file;
    if (defined('DB_HOST') && defined('DB_NAME') && defined('DB_USER') && defined('DB_PASS')) {
        // Verify database is connected and tables actually exist
        try {
            $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
            $pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_TIMEOUT => 2
            ]);
            // If users table exists, the system is fully installed
            $pdo->query("SELECT 1 FROM `users` LIMIT 1");
            $is_installed = true;
        } catch (Exception $e) {
            // Partial installation or connection issue - let them configure again
            $is_installed = false;
        }
    }
}

if (isset($_POST['install'])) {
    $db_host = trim($_POST['db_host']);
    $db_name = trim($_POST['db_name']);
    $db_user = trim($_POST['db_user']);
    $db_pass = $_POST['db_pass'];

    try {
        // 1. Try to connect to MySQL server
        $dsn = "mysql:host={$db_host};charset=utf8mb4";
        $pdo = new PDO($dsn, $db_user, $db_pass, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_TIMEOUT => 5 // 5 seconds timeout
        ]);

        // 2. Drop database and recreate for a 100% clean slate, avoiding any orphaned foreign key constraints
        $pdo->exec("DROP DATABASE IF EXISTS `{$db_name}`");
        $pdo->exec("CREATE DATABASE `{$db_name}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
        $pdo->exec("USE `{$db_name}`");

        // 3. Import Schema from schema.sql
        if (!file_exists($schema_file)) {
            throw new Exception("Schema file not found at " . $schema_file);
        }

        $sql = file_get_contents($schema_file);
        
        // Execute queries as a single multi-statement transaction, which is highly robust in PDO
        // We explicitly turn off foreign key checks on the session first
        $pdo->exec("SET FOREIGN_KEY_CHECKS = 0");
        
        // Execute the entire SQL script directly as a single robust batch
        $pdo->exec($sql);
        
        $pdo->exec("SET FOREIGN_KEY_CHECKS = 1");

        $json_file = dirname(__DIR__) . '/database/lgas-with-wards.json';
        if (file_exists($json_file)) {
            set_time_limit(600); // Give it up to 10 minutes to run without timing out
            
            $geo_data = json_decode(file_get_contents($json_file), true);
            if (is_array($geo_data)) {
                // Zone and code maps
                $zone_mapping = [
                    'Abia' => 'South-East', 'Adamawa' => 'North-East', 'Akwa Ibom' => 'South-South',
                    'Anambra' => 'South-East', 'Bauchi' => 'North-East', 'Bayelsa' => 'South-South',
                    'Benue' => 'North-Central', 'Borno' => 'North-East', 'Cross River' => 'South-South',
                    'Delta' => 'South-South', 'Ebonyi' => 'South-East', 'Edo' => 'South-South',
                    'Ekiti' => 'South-West', 'Enugu' => 'South-East', 'Federal Capital Territory' => 'North-Central',
                    'Gombe' => 'North-East', 'Imo' => 'South-East', 'Jigawa' => 'North-West',
                    'Kaduna' => 'North-West', 'Kano' => 'North-West', 'Katsina' => 'North-West',
                    'Kebbi' => 'North-West', 'Kogi' => 'North-Central', 'Kwara' => 'North-Central',
                    'Lagos' => 'South-West', 'Nasarawa' => 'North-Central', 'Niger' => 'North-Central',
                    'Ogun' => 'South-West', 'Ondo' => 'South-West', 'Osun' => 'South-West',
                    'Oyo' => 'South-West', 'Plateau' => 'North-Central', 'Rivers' => 'South-South',
                    'Sokoto' => 'North-West', 'Taraba' => 'North-East', 'Yobe' => 'North-East',
                    'Zamfara' => 'North-West'
                ];
                $state_codes = [
                    'Abia' => 'AB', 'Adamawa' => 'AD', 'Akwa Ibom' => 'AK', 'Anambra' => 'AN', 'Bauchi' => 'BA',
                    'Bayelsa' => 'BY', 'Benue' => 'BE', 'Borno' => 'BO', 'Cross River' => 'CR', 'Delta' => 'DE',
                    'Ebonyi' => 'EB', 'Edo' => 'ED', 'Ekiti' => 'EK', 'Enugu' => 'EN', 'Federal Capital Territory' => 'FCT',
                    'Gombe' => 'GO', 'Imo' => 'IM', 'Jigawa' => 'JI', 'Kaduna' => 'KD', 'Kano' => 'KN',
                    'Katsina' => 'KT', 'Kebbi' => 'KE', 'Kogi' => 'KO', 'Kwara' => 'KW', 'Lagos' => 'LA',
                    'Nasarawa' => 'NA', 'Niger' => 'NI', 'Ogun' => 'OG', 'Ondo' => 'ON', 'Osun' => 'OS',
                    'Oyo' => 'OY', 'Plateau' => 'PL', 'Rivers' => 'RV', 'Sokoto' => 'SO', 'Taraba' => 'TA',
                    'Yobe' => 'YO', 'Zamfara' => 'ZA'
                ];

                // First, query currently seeded states to avoid duplication and keep their primary key IDs
                $stmt = $pdo->query("SELECT `id`, `name` FROM `states`");
                $existing_states = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
                $existing_states_flipped = array_flip($existing_states);

                // Insert other states
                $state_insert_stmt = $pdo->prepare("INSERT INTO `states` (`name`, `code`, `zone`) VALUES (?, ?, ?)");
                foreach ($geo_data as $state_name => $lgas) {
                    if (!isset($existing_states_flipped[$state_name])) {
                        $code = $state_codes[$state_name] ?? strtoupper(substr($state_name, 0, 3));
                        $zone = $zone_mapping[$state_name] ?? 'Unmapped';
                        $state_insert_stmt->execute([$state_name, $code, $zone]);
                        $existing_states_flipped[$state_name] = $pdo->lastInsertId();
                    }
                }

                // Query currently seeded LGAs
                $stmt = $pdo->query("SELECT `id`, `name`, `state_id` FROM `lgas`");
                $existing_lgas = $stmt->fetchAll(PDO::FETCH_ASSOC);
                $existing_lgas_map = [];
                foreach ($existing_lgas as $el) {
                    $existing_lgas_map[$el['state_id']][strtolower(trim($el['name']))] = $el['id'];
                }

                // Prepare insert statements
                $lga_insert_stmt = $pdo->prepare("INSERT INTO `lgas` (`state_id`, `name`) VALUES (?, ?)");
                $ward_insert_stmt = $pdo->prepare("INSERT INTO `wards` (`lga_id`, `name`) VALUES (?, ?)");

                $lga_id_map = $existing_lgas_map;

                $pdo->beginTransaction();
                foreach ($geo_data as $state_name => $lgas) {
                    $state_id = $existing_states_flipped[$state_name] ?? null;
                    if (!$state_id) continue;

                    foreach ($lgas as $lga_name => $wards) {
                        $lga_key = strtolower(trim($lga_name));
                        
                        // Insert LGA if it doesn't exist
                        if (!isset($lga_id_map[$state_id][$lga_key])) {
                            $lga_insert_stmt->execute([$state_id, $lga_name]);
                            $lga_id_map[$state_id][$lga_key] = $pdo->lastInsertId();
                        }
                        $lga_id = $lga_id_map[$state_id][$lga_key];

                        // Insert Wards
                        if (is_array($wards)) {
                            foreach ($wards as $ward) {
                                $ward_name = is_array($ward) ? ($ward['name'] ?? '') : $ward;
                                $ward_name = trim($ward_name);
                                if ($ward_name !== '') {
                                    $ward_insert_stmt->execute([$lga_id, $ward_name]);
                                }
                            }
                        }
                    }
                }
                $pdo->commit();

                // Link default seeded ambassadors to one of their newly created wards
                // Amara Eke: Ikeja (LGA ID 1) -> get first ward of Ikeja
                $stmt = $pdo->query("SELECT `id` FROM `wards` WHERE `lga_id` = 1 LIMIT 1");
                $ikeja_ward_id = $stmt->fetchColumn();
                if ($ikeja_ward_id) {
                    $pdo->exec("UPDATE `ambassadors` SET `ward_id` = {$ikeja_ward_id} WHERE `id` = 2");
                }

                // Tunde Coker: Alimosho (LGA ID 2) -> get first ward of Alimosho
                $stmt = $pdo->query("SELECT `id` FROM `wards` WHERE `lga_id` = 2 LIMIT 1");
                $alimosho_ward_id = $stmt->fetchColumn();
                if ($alimosho_ward_id) {
                    $pdo->exec("UPDATE `ambassadors` SET `ward_id` = {$alimosho_ward_id} WHERE `id` = 1");
                }
            }
        }

        // 4. Write config.php credentials
        $config_content = "<?php\n";
        $config_content .= "// PBAT Smart Nation Initiative - Autogenerated DB Config\n";
        $config_content .= "define('DB_HOST', '" . addslashes($db_host) . "');\n";
        $config_content .= "define('DB_NAME', '" . addslashes($db_name) . "');\n";
        $config_content .= "define('DB_USER', '" . addslashes($db_user) . "');\n";
        $config_content .= "define('DB_PASS', '" . addslashes($db_pass) . "');\n";
        
        if (file_put_contents($config_file, $config_content) === false) {
            throw new Exception("Failed to write database config.php file. Check directory permissions.");
        }

        $success = "Database installation, seeding, and configuration file creation were successful!";
        $is_installed = true;

    } catch (Exception $e) {
        if (isset($pdo) && $pdo->inTransaction()) {
            $pdo->rollBack();
        }
        $error = "Installation Error: " . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Database Setup Wizard - PBAT Smart Nation</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        bushgreen: '#063C1E',
                        gold: '#D4AF37'
                    }
                }
            }
        }
    </script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700&display=swap" rel="stylesheet">
    <style>
        html, body {
            margin: 0;
            padding: 0;
            width: 100%;
            height: 100%;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: #f8fafc;
        }
        body { 
            font-family: 'Outfit', sans-serif; 
        }
    </style>
</head>
<body class="bg-slate-50 min-h-screen flex items-center justify-center p-4">
    <div class="max-w-xl w-full bg-white rounded-2xl shadow-xl overflow-hidden border border-slate-100 my-8">
        
        <!-- Header -->
        <div class="bg-bushgreen p-8 text-center relative overflow-hidden">
            <div class="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-emerald-800/50 via-bushgreen to-bushgreen opacity-90"></div>
            <div class="relative z-10">
                <div class="w-16 h-16 bg-white/10 rounded-full flex items-center justify-center mx-auto mb-4 border border-white/20">
                    <svg class="w-8 h-8 text-gold" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" />
                    </svg>
                </div>
                <h1 class="text-white text-2xl font-bold tracking-tight">PBAT Smart Nation Initiative</h1>
                <p class="text-gold/90 text-sm mt-1 uppercase tracking-widest font-semibold">Database Auto-Installer Panel</p>
            </div>
        </div>

        <div class="p-8">
            <?php if (!empty($error)): ?>
                <div class="mb-6 p-4 bg-red-50 border-l-4 border-red-500 rounded-r-lg text-sm text-red-700">
                    <strong class="font-bold">Error:</strong> <?php echo $error; ?>
                </div>
            <?php endif; ?>

            <?php if (!empty($success)): ?>
                <div class="mb-6 p-4 bg-emerald-50 border-l-4 border-emerald-500 rounded-r-lg text-sm text-emerald-800">
                    <strong class="font-bold">Success!</strong> <?php echo $success; ?>
                </div>
            <?php endif; ?>

            <?php if ($is_installed && empty($success)): ?>
                <div class="bg-amber-50 border border-amber-200 rounded-xl p-6 text-center">
                    <svg class="w-12 h-12 text-amber-500 mx-auto mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                    </svg>
                    <h3 class="text-slate-800 font-bold text-lg">Platform Already Configured</h3>
                    <p class="text-slate-600 text-sm mt-1 leading-relaxed">
                        A config file already exists with database credentials. If you wish to re-install, delete `config/config.php` from your directory first.
                    </p>
                    <div class="mt-6 flex justify-center gap-4">
                        <a href="../index.php" class="py-2.5 px-6 bg-slate-800 text-white rounded-lg text-sm font-semibold hover:bg-slate-700 transition shadow">
                            Go to Homepage
                        </a>
                        <a href="../login.php" class="py-2.5 px-6 bg-bushgreen text-white rounded-lg text-sm font-semibold hover:bg-emerald-800 transition shadow">
                            Go to Dashboard Login
                        </a>
                    </div>
                </div>
            <?php else: ?>
                <p class="text-slate-600 text-sm mb-6 leading-relaxed">
                    Welcome to the Smart Nation database setup wizard. Enter your local MySQL settings below. The script will dynamically generate all required tables, relationships, permissions, and seed datasets.
                </p>

                <form method="POST" action="" class="space-y-5">
                    <div>
                        <label class="block text-slate-700 text-sm font-semibold mb-1.5" for="db_host">Database Host</label>
                        <input type="text" name="db_host" id="db_host" value="127.0.0.1" required
                               class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 focus:outline-none focus:ring-2 focus:ring-bushgreen/20 focus:border-bushgreen transition text-sm">
                        <p class="text-xs text-slate-400 mt-1">Usually '127.0.0.1' or 'localhost' on cPanel.</p>
                    </div>

                    <div>
                        <label class="block text-slate-700 text-sm font-semibold mb-1.5" for="db_name">Database Name</label>
                        <input type="text" name="db_name" id="db_name" value="pbat_smartnation" required
                               class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 focus:outline-none focus:ring-2 focus:ring-bushgreen/20 focus:border-bushgreen transition text-sm">
                        <p class="text-xs text-slate-400 mt-1">The database must exist or the user must have CREATE permissions.</p>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-slate-700 text-sm font-semibold mb-1.5" for="db_user">Database Username</label>
                            <input type="text" name="db_user" id="db_user" value="root" required
                                   class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 focus:outline-none focus:ring-2 focus:ring-bushgreen/20 focus:border-bushgreen transition text-sm">
                        </div>
                        <div>
                            <label class="block text-slate-700 text-sm font-semibold mb-1.5" for="db_pass">Database Password</label>
                            <input type="password" name="db_pass" id="db_pass" value=""
                                   class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 focus:outline-none focus:ring-2 focus:ring-bushgreen/20 focus:border-bushgreen transition text-sm">
                        </div>
                    </div>

                    <div class="pt-4 border-t border-slate-100">
                        <button type="submit" name="install" class="w-full py-3 bg-bushgreen text-white hover:bg-emerald-800 transition font-bold rounded-lg text-sm shadow-md shadow-bushgreen/10 flex items-center justify-center gap-2">
                            <svg class="w-4 h-4 text-gold" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                            </svg>
                            Execute DB Schema & Seed Data
                        </button>
                    </div>
                </form>
            <?php endif; ?>

            <?php if (!empty($success)): ?>
                <div class="mt-8 border-t border-slate-100 pt-6">
                    <h4 class="text-slate-800 font-bold text-sm mb-3">Seed Administrator Login Details:</h4>
                    <div class="bg-slate-50 p-4 rounded-xl space-y-2 border border-slate-100 text-sm font-mono text-slate-700">
                        <div><span class="font-bold text-slate-900">Email:</span> admin@pbat-smartnation.ng</div>
                        <div><span class="font-bold text-slate-900">Password:</span> password123</div>
                        <div><span class="font-bold text-slate-900">Role:</span> Super Admin</div>
                    </div>
                    <div class="mt-6 flex justify-center gap-4">
                        <a href="../index.php" class="py-2 px-4 border border-slate-200 text-slate-700 rounded-lg text-xs font-semibold hover:bg-slate-50 transition">
                            Visit Site Front
                        </a>
                        <a href="../login.php" class="py-2 px-5 bg-bushgreen text-white rounded-lg text-xs font-semibold hover:bg-emerald-800 transition shadow">
                            Access Administrator Panel
                        </a>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
