<?php
// SMTP Configurations - PBAT Smart Nation
define('SMTP_ENABLED', true);
define('SMTP_HOST', 'premium48.web-hosting.com');
define('SMTP_PORT', 465);
define('SMTP_USER', 'no-reply@pbatsmartnation.org.ng');
define('SMTP_PASS', '123!@Petroleu');
define('SMTP_ENCRYPTION', 'ssl');
define('SMTP_FROM_EMAIL', 'no-reply@pbatsmartnation.org.ng');
define('SMTP_FROM_NAME', 'PBAT SmartNation');
