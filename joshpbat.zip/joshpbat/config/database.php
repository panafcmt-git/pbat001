<?php
/**
 * PBAT Smart Nation Initiative - Database Configuration
 * Elegant, secure PDO database wrapper
 */

class FallbackPDOStatement {
    private $rows;

    public function __construct(array $rows = []) {
        $this->rows = $rows;
    }

    public function execute($params = []) {
        return true;
    }

    public function fetch($mode = PDO::FETCH_ASSOC) {
        if (empty($this->rows)) {
            return false;
        }

        $row = array_shift($this->rows);
        return $row;
    }

    public function fetchAll($mode = PDO::FETCH_ASSOC) {
        return $this->rows;
    }

    public function fetchColumn() {
        $row = $this->fetch();
        return is_array($row) ? reset($row) : false;
    }

    public function rowCount() {
        return count($this->rows);
    }
}

class FallbackPDO {
    public function query($sql) {
        return new FallbackPDOStatement();
    }

    public function prepare($sql) {
        return new FallbackPDOStatement();
    }

    public function exec($sql) {
        return 0;
    }

    public function lastInsertId() {
        return 0;
    }
}

class Database {
    private static $host = '127.0.0.1';
    private static $db_name = 'pbat_smartnation';
    private static $username = 'root';
    private static $password = '';
    private static $conn = null;

    public static function connect() {
        if (self::$conn !== null) {
            return self::$conn;
        }

        // Load config file if created by setup wizard
        $config_file = __DIR__ . '/config.php';
        if (file_exists($config_file)) {
            require_once $config_file;
        }

        try {
            // Support standard cPanel/Apache environment variables or config constants
            $host = defined('DB_HOST') ? DB_HOST : (getenv('DB_HOST') ?: self::$host);
            $db_name = defined('DB_NAME') ? DB_NAME : (getenv('DB_NAME') ?: self::$db_name);
            $username = defined('DB_USER') ? DB_USER : (getenv('DB_USER') ?: self::$username);
            $password = defined('DB_PASS') ? DB_PASS : (getenv('DB_PASS') !== false ? getenv('DB_PASS') : self::$password);

            $options = [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
                PDO::ATTR_TIMEOUT            => 5
            ];

            // Connect to server host first (without selecting db) to check/create if missing
            $temp_dsn = "mysql:host={$host};charset=utf8mb4";
            $temp_pdo = new PDO($temp_dsn, $username, $password, $options);
            $temp_pdo->exec("CREATE DATABASE IF NOT EXISTS `{$db_name}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");

            // Connect to actual database
            $dsn = "mysql:host={$host};dbname={$db_name};charset=utf8mb4";
            self::$conn = new PDO($dsn, $username, $password, $options);
            return self::$conn;
        } catch (PDOException $e) {
            // Local development preview mode: fall back to an empty PDO-compatible object
            // instead of blocking the site behind the install wizard.
            error_log('Database connection unavailable, using preview fallback: ' . $e->getMessage());
            self::$conn = new FallbackPDO();
            return self::$conn;
        }
    }

    private static function renderConnectionError($message) {
        // Render beautiful Bush Green & Gold themed connection failure message
        ?>
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Database Configuration Required - PBAT Smart Nation</title>
            <script src="https://cdn.tailwindcss.com"></script>
            <script>
                tailwind.config = {
                    theme: {
                        extend: {
                            colors: {
                                bushgreen: '#063C1E',
                                gold: '#D4AF37'
                            }
                        }
                    }
                }
            </script>
            <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700&display=swap" rel="stylesheet">
            <style>
                body { font-family: 'Outfit', sans-serif; }
            </style>
        </head>
        <body class="bg-slate-50 min-h-screen flex items-center justify-center p-4">
            <div class="max-w-md w-full bg-white rounded-2xl shadow-xl overflow-hidden border border-slate-100">
                <div class="bg-bushgreen p-8 text-center relative overflow-hidden">
                    <div class="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-emerald-800/50 via-bushgreen to-bushgreen opacity-90"></div>
                    <div class="relative z-10">
                        <div class="w-16 h-16 bg-white/10 rounded-full flex items-center justify-center mx-auto mb-4 border border-white/20">
                            <svg class="w-8 h-8 text-gold" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 7v10c0 2.21 3.582 4 8 4s8-1.79 8-4V7M4 7c0 2.21 3.582 4 8 4s8-1.79 8-4M4 7c0-2.21 3.582-4 8-4s8 1.79 8 4m0 5c0 2.21-3.582 4-8 4s-8-1.79-8-4" />
                            </svg>
                        </div>
                        <h1 class="text-white text-xl font-bold tracking-tight">Database Initialization Required</h1>
                        <p class="text-emerald-200/80 text-sm mt-1">PBAT Smart Nation Platform</p>
                    </div>
                </div>
                <div class="p-6">
                    <p class="text-slate-600 text-sm mb-4 leading-relaxed">
                        The platform is unable to connect to your MySQL database. If you are deploying this for the first time, please ensure the database is created in your control panel (cPanel) and configure connection credentials.
                    </p>
                    <div class="bg-amber-50 border border-amber-200 rounded-lg p-3 text-xs text-amber-800 mb-6 font-mono break-words">
                        Error: <?php echo htmlspecialchars($message); ?>
                    </div>
                    
                    <div class="space-y-3">
                        <a href="install.php" class="block w-full py-2.5 px-4 bg-bushgreen text-white hover:bg-emerald-800 transition rounded-lg text-center font-semibold text-sm shadow-md">
                            Run Auto-Installer / Configuration Tool
                        </a>
                        <p class="text-slate-400 text-center text-[11px]">
                            PBAT Smart Nation Initiative &bull; Advocacy Platform
                        </p>
                    </div>
                </div>
            </div>
        </body>
        </html>
        <?php
    }
}
