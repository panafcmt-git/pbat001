<?php
/**
 * PBAT Smart Nation Initiative - Password Reset Gateway
 * Secure key establishment validating cryptographic hashes.
 */
require_once __DIR__ . '/helpers/auth.php';
require_once __DIR__ . '/helpers/common.php';
require_once __DIR__ . '/helpers/notifications.php';
require_once __DIR__ . '/config/database.php';

$token = trim($_GET['token'] ?? '');
$error = '';
$success = '';
$user = null;

if (empty($token)) {
    $error = "Missing account recovery token. Please verify the reset link in your email.";
} else {
    try {
        $db = Database::connect();
        
        // Find user by reset token and ensure token is not expired (within 1 hour)
        $stmt = $db->prepare("SELECT `id`, `name`, `email` FROM `users` WHERE `reset_token` = ? AND `reset_expires` > NOW() LIMIT 1");
        $stmt->execute([$token]);
        $user = $stmt->fetch();
        
        if (!$user) {
            $error = "This recovery link is invalid or has expired. Please request a new passkey reset link.";
        }
    } catch (Exception $e) {
        $error = "Database Connection failure: " . $e->getMessage();
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $user) {
    if (!Auth::validateCsrf($_POST['csrf_token'] ?? '')) {
        $error = "Security validation expired. Please refresh and try again.";
    } else {
        $new_password = $_POST['password'] ?? '';
        $confirm_password = $_POST['confirm_password'] ?? '';
        
        if (empty($new_password)) {
            $error = "Please provide your new passcode key.";
        } elseif (strlen($new_password) < 6) {
            $error = "Passcode key must be at least 6 characters in length.";
        } elseif ($new_password !== $confirm_password) {
            $error = "The passcode keys do not match. Please verify them.";
        } else {
            try {
                $db = Database::connect();
                $db->beginTransaction();
                
                // 1. Hash and update password, clear recovery keys
                $hashed_pass = password_hash($new_password, PASSWORD_BCRYPT);
                $stmt = $db->prepare("UPDATE `users` SET `password` = ?, `reset_token` = NULL, `reset_expires` = NULL WHERE `id` = ?");
                $stmt->execute([$hashed_pass, $user['id']]);
                
                // 2. Audit log
                Auth::logAction($user['id'], 'PASSWORD_RESET', "Established new administrative password key.");
                
                // 3. Dispatch colorful HTML confirmation email
                NotificationEmail::sendPasswordChanged($user['email'], $user['name']);
                
                $db->commit();
                
                $_SESSION['success_msg'] = "Password passcode key established successfully! You can now log into your universal portal.";
                header("Location: login.php");
                exit;
                
            } catch (Exception $e) {
                if (isset($db) && $db->inTransaction()) {
                    $db->rollBack();
                }
                $error = "System Database Exception: " . $e->getMessage();
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password - PBAT Smart Nation</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        bushgreen: {
                            DEFAULT: '#063C1E',
                            light: '#0A4D27',
                            dark: '#03200F',
                        },
                        gold: '#D4AF37'
                    }
                }
            }
        }
    </script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Outfit', sans-serif; }
    </style>
</head>
<body class="bg-slate-50 min-h-screen flex items-center justify-center p-4 relative overflow-hidden">
    <!-- Visual background glows -->
    <div class="absolute w-[500px] h-[500px] bg-bushgreen/10 rounded-full blur-[100px] -top-40 -left-40 pointer-events-none"></div>
    <div class="absolute w-[500px] h-[500px] bg-gold/5 rounded-full blur-[100px] -bottom-40 -right-40 pointer-events-none"></div>

    <div class="max-w-md w-full bg-white rounded-3xl shadow-2xl overflow-hidden border border-slate-100 relative z-10 my-8">
        
        <!-- Curved Banner -->
        <div class="bg-bushgreen p-8 text-center relative overflow-hidden border-b-4 border-gold">
            <div class="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-emerald-800/50 via-bushgreen to-bushgreen opacity-95"></div>
            <div class="relative z-10 space-y-2">
                <a href="index.php" class="inline-block">
                    <div class="w-12 h-12 bg-white/10 rounded-xl flex items-center justify-center mx-auto border border-white/20">
                        <svg class="w-6 h-6 text-gold animate-pulse" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/>
                        </svg>
                    </div>
                </a>
                <h1 class="text-white text-xl font-bold tracking-tight">Establish New Passkey</h1>
                <p class="text-gold/90 text-xs uppercase tracking-widest font-semibold">Account Recovery Assistance</p>
            </div>
        </div>

        <div class="p-8">
            <!-- Alert Display -->
            <?php if (!empty($error)): ?>
                <div class="mb-5 p-3.5 bg-red-50 border-l-4 border-red-500 rounded-r-lg text-xs text-red-700 font-semibold flex items-center gap-2 text-left">
                    <svg class="w-4 h-4 text-red-500 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clip-rule="evenodd"/></svg>
                    <span><?php echo $error; ?></span>
                </div>
            <?php endif; ?>

            <?php if ($user): ?>
                <form method="POST" action="" class="space-y-5">
                    <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">

                    <div>
                        <label class="block text-slate-700 text-xs font-semibold mb-1.5" for="password">Create New Passcode Key *</label>
                        <input type="password" name="password" id="password" required placeholder="Minimum 6 characters"
                               class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 focus:outline-none focus:ring-2 focus:ring-bushgreen/20 focus:border-bushgreen transition text-xs">
                    </div>

                    <div>
                        <label class="block text-slate-700 text-xs font-semibold mb-1.5" for="confirm_password">Confirm New Passcode Key *</label>
                        <input type="password" name="confirm_password" id="confirm_password" required placeholder="Repeat passcode key"
                               class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 focus:outline-none focus:ring-2 focus:ring-bushgreen/20 focus:border-bushgreen transition text-xs">
                    </div>

                    <button type="submit" class="w-full py-3 bg-bushgreen hover:bg-bushgreen-light text-white font-bold rounded-xl text-xs shadow-md shadow-bushgreen/10 transition-all flex items-center justify-center gap-1.5 hover:scale-105">
                        UPDATE PORTAL PASSWORD
                    </button>
                </form>
            <?php else: ?>
                <div class="pt-4 flex flex-col gap-2">
                    <a href="forgot-password.php" class="py-2.5 bg-slate-800 text-white rounded-xl text-xs font-bold hover:bg-slate-700 text-center transition">
                        Request New Password Reset Link
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
