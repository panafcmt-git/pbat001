<?php
/**
 * PBAT Smart Nation Initiative - Partner With Us
 * Elegant, meaningful page describing partnership channels with an inquiry form.
 */
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/helpers/auth.php';
require_once __DIR__ . '/helpers/common.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$partner_success = '';
$partner_error = '';

// Handle Partner Form Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'submit_partner') {
    if (!Auth::validateCsrf($_POST['csrf_token'] ?? '')) {
        $partner_error = "CSRF Token validation failed.";
    } else {
        $org_name = trim($_POST['org_name'] ?? '');
        $contact_name = trim($_POST['contact_name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $phone = trim($_POST['phone'] ?? '');
        $partnership_type = trim($_POST['partnership_type'] ?? '');
        $proposal = trim($_POST['proposal'] ?? '');
        
        if (empty($org_name) || empty($contact_name) || empty($email) || empty($partnership_type) || empty($proposal)) {
            $partner_error = "Please fill in all required fields.";
        } else {
            try {
                $db = Database::connect();
                // We submit to contact_submissions with subject "Partnership Request"
                $subject = "Partnership: " . $partnership_type . " - " . $org_name;
                $formatted_message = "Organization Type: " . $partnership_type . "\n"
                                   . "Contact Person: " . $contact_name . "\n"
                                   . "Phone: " . $phone . "\n\n"
                                   . "Proposal Details:\n" . $proposal;

                $stmt = $db->prepare("INSERT INTO `contact_submissions` (name, email, subject, message, status) VALUES (?, ?, ?, ?, 'pending')");
                $stmt->execute([$contact_name, $email, $subject, $formatted_message]);
                
                $partner_success = "Partnership proposal submitted successfully! Our strategic collaboration desk will contact you.";
            } catch (Exception $e) {
                $partner_error = "Error submitting proposal: " . $e->getMessage();
            }
        }
    }
}

require_once __DIR__ . '/helpers/seo.php';
SEO::init([
    'title' => 'Partner With Us & Civic Collaborations | PBAT Smart Nation',
    'description' => 'Explore tech collaborations, academic integrations, and state alliances. Submit a partnership proposal to build a digitally inclusive Nigeria.',
    'keywords' => 'Technology Partnerships Nigeria, Academic Integration Advocacy, cPanel Tech secretariat, Corporate CSR tech Nigeria',
    'breadcrumbs' => [
        ['name' => 'Partner With Us', 'url' => '/partner']
    ]
]);

require_once __DIR__ . '/includes/header.php';
?>

<!-- Hero Header Section -->
<section class="relative bg-bushgreen text-white py-16 overflow-hidden border-b-8 border-gold">
    <div class="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-bushgreen-light/80 via-bushgreen to-bushgreen opacity-95"></div>
    <div class="absolute inset-0 bg-[linear-gradient(to_right,#ffffff05_1px,transparent_1px),linear-gradient(to_bottom,#ffffff05_1px,transparent_1px)] bg-[size:4rem_4rem]"></div>
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
        <span class="text-gold font-bold text-xs uppercase tracking-widest font-display">Collaborative Growth</span>
        <h1 class="text-3xl sm:text-4xl md:text-5xl font-black font-display uppercase tracking-tight mt-2">
            Partner With Us
        </h1>
        <p class="text-slate-350 text-xs sm:text-sm max-w-xl mx-auto font-light mt-3 leading-relaxed">
            Co-designing a digital future for Nigeria. We invite technology firms, educational systems, state directorates, and global non-profits to build with us.
        </p>
    </div>
</section>

<!-- Main content grid -->
<section class="py-16 bg-slate-50 dark:bg-slate-900/50">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            
            <!-- Column 1: Info Cards -->
            <div class="lg:col-span-5 space-y-6">
                <div class="bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-800 p-6 sm:p-8 shadow-sm space-y-6">
                    <h2 class="text-lg font-bold text-bushgreen dark:text-gold font-display uppercase tracking-wider">Partnership Pillars</h2>
                    <p class="text-xs text-slate-650 dark:text-slate-350 leading-relaxed font-light">
                        The PBAT Smart Nation Initiative collaborates with international development agencies, local state departments, and corporate organizations to deliver inclusive and structured technical learning systems across Nigeria. Together, we build local hubs, support local innovators, and set coding curriculum benchmarks. Our partnership system is divided into key operational areas to ensure maximal impact and resources integration.
                    </p>
                    <div class="space-y-4">
                        <div class="flex gap-4 items-start pb-4 border-b border-slate-100 dark:border-slate-700">
                            <div class="w-8 h-8 rounded-lg bg-bushgreen/10 flex items-center justify-center flex-shrink-0 text-bushgreen dark:text-gold">
                                💻
                            </div>
                            <div>
                                <h3 class="text-xs sm:text-sm font-bold text-slate-800 dark:text-white">Tech Industry Partnerships</h3>
                                <p class="text-[11px] text-slate-550 dark:text-slate-400 mt-1 leading-normal font-light">
                                    Collaborate on delivering curriculum, providing software licenses, and building employment pathways for our certified grassroots ambassadors.
                                </p>
                            </div>
                        </div>

                        <div class="flex gap-4 items-start pb-4 border-b border-slate-100 dark:border-slate-700">
                            <div class="w-8 h-8 rounded-lg bg-bushgreen/10 flex items-center justify-center flex-shrink-0 text-bushgreen dark:text-gold">
                                🏫
                            </div>
                            <div>
                                <h3 class="text-xs sm:text-sm font-bold text-slate-800 dark:text-white">Academic Collaborations</h3>
                                <p class="text-[11px] text-slate-550 dark:text-slate-400 mt-1 leading-normal font-light">
                                    Link secondary schools and tertiary hubs with our community coding labs to provide structured internet facilities and solar training kiosks.
                                </p>
                            </div>
                        </div>

                        <div class="flex gap-4 items-start">
                            <div class="w-8 h-8 rounded-lg bg-bushgreen/10 flex items-center justify-center flex-shrink-0 text-bushgreen dark:text-gold">
                                🏛️
                            </div>
                            <div>
                                <h3 class="text-xs sm:text-sm font-bold text-slate-800 dark:text-white">Government Alignments</h3>
                                <p class="text-[11px] text-slate-550 dark:text-slate-400 mt-1 leading-normal font-light">
                                    Provide local governments and state secretariats with modern administrative training tools, paperless workflow templates, and secure registry schemas.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Column 2: Form -->
            <div class="lg:col-span-7 bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-800 p-6 sm:p-8 shadow-sm space-y-6">
                <div>
                    <h2 class="text-lg font-bold text-bushgreen dark:text-gold font-display uppercase tracking-wider">Submit Collaboration Proposal</h2>
                    <p class="text-slate-550 dark:text-slate-400 text-xs font-light mt-1">
                        Tell us about your organization and how we can work together.
                    </p>
                </div>

                <?php if (!empty($partner_success)): ?>
                    <div class="p-3 bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-250 text-emerald-800 dark:text-emerald-400 rounded-xl text-xs font-semibold">
                        ✓ <?php echo htmlspecialchars($partner_success); ?>
                    </div>
                <?php endif; ?>

                <?php if (!empty($partner_error)): ?>
                    <div class="p-3 bg-red-50 dark:bg-red-950/30 border border-red-205 text-red-800 dark:text-red-400 rounded-xl text-xs font-semibold">
                        ⚠ <?php echo htmlspecialchars($partner_error); ?>
                    </div>
                <?php endif; ?>

                <form method="POST" action="" class="space-y-4">
                    <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                    <input type="hidden" name="action" value="submit_partner">

                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-slate-700 dark:text-slate-350 text-[10px] font-bold uppercase tracking-wider mb-1" for="org_name">Organization Name *</label>
                            <input type="text" name="org_name" id="org_name" required placeholder="Organization / Institution"
                                   class="w-full px-3.5 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-bushgreen/20 focus:border-bushgreen dark:text-white transition">
                        </div>
                        <div>
                            <label class="block text-slate-700 dark:text-slate-350 text-[10px] font-bold uppercase tracking-wider mb-1" for="contact_name">Primary Contact Name *</label>
                            <input type="text" name="contact_name" id="contact_name" required placeholder="Contact Representative"
                                   class="w-full px-3.5 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-bushgreen/20 focus:border-bushgreen dark:text-white transition">
                        </div>
                    </div>

                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-slate-700 dark:text-slate-350 text-[10px] font-bold uppercase tracking-wider mb-1" for="email">Email Address *</label>
                            <input type="email" name="email" id="email" required placeholder="contact@domain.com"
                                   class="w-full px-3.5 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-bushgreen/20 focus:border-bushgreen dark:text-white font-mono transition">
                        </div>
                        <div>
                            <label class="block text-slate-700 dark:text-slate-350 text-[10px] font-bold uppercase tracking-wider mb-1" for="phone">Phone Number</label>
                            <input type="text" name="phone" id="phone" placeholder="+234..."
                                   class="w-full px-3.5 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-bushgreen/20 focus:border-bushgreen dark:text-white font-mono transition">
                        </div>
                    </div>

                    <div>
                        <label class="block text-slate-700 dark:text-slate-350 text-[10px] font-bold uppercase tracking-wider mb-1" for="partnership_type">Partnership Category *</label>
                        <select name="partnership_type" id="partnership_type" required
                                class="w-full px-3.5 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-bushgreen/20 focus:border-bushgreen dark:text-white transition">
                            <option value="Tech Industry Program">Technology Industry Collaboration</option>
                            <option value="Academic Integration">Academic / Educational Alliance</option>
                            <option value="State/LGA Integration">State or LGA Digitization Support</option>
                            <option value="NGO/Grassroots Alliance">NGO / Civil Society Synergy</option>
                            <option value="Other Partnership">Other Partnership Type</option>
                        </select>
                    </div>

                    <div>
                        <label class="block text-slate-700 dark:text-slate-350 text-[10px] font-bold uppercase tracking-wider mb-1" for="proposal">Partnership Proposal Overview *</label>
                        <textarea name="proposal" id="proposal" required rows="5" placeholder="Briefly describe the focus area, objectives, and resource contributions for the proposed collaboration..."
                                  class="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-bushgreen/20 focus:border-bushgreen dark:text-white leading-relaxed font-light transition"></textarea>
                    </div>

                    <button type="submit" class="w-full py-3 bg-bushgreen hover:bg-bushgreen-light text-white text-xs font-bold rounded-xl transition shadow-md border border-gold/20 flex items-center justify-center gap-1.5 uppercase tracking-wide">
                        Submit Collaboration Request
                    </button>
                </form>
            </div>

        </div>
    </div>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
