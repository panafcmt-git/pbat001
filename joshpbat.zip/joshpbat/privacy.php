<?php
/**
 * PBAT Smart Nation Initiative - Privacy Policy
 * Dedicated privacy policy page.
 */
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/helpers/auth.php';
require_once __DIR__ . '/helpers/common.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/includes/header.php';
?>

<!-- Hero Header Section -->
<section class="relative bg-bushgreen text-white py-16 overflow-hidden border-b-8 border-gold">
    <div class="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-bushgreen-light/80 via-bushgreen to-bushgreen opacity-95"></div>
    <div class="absolute inset-0 bg-[linear-gradient(to_right,#ffffff05_1px,transparent_1px),linear-gradient(to_bottom,#ffffff05_1px,transparent_1px)] bg-[size:4rem_4rem]"></div>
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
        <span class="text-gold font-bold text-xs uppercase tracking-widest font-display">Data Protection</span>
        <h1 class="text-3xl sm:text-4xl md:text-5xl font-black font-display uppercase tracking-tight mt-2">
            Privacy Policy
        </h1>
        <p class="text-slate-355 text-xs sm:text-sm max-w-xl mx-auto font-light mt-3 leading-relaxed">
            How we protect, store, and utilize your personal information and ambassador profile data.
        </p>
    </div>
</section>

<!-- Privacy Content Section -->
<section class="py-16 bg-slate-50 dark:bg-slate-900/50">
    <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-800 p-6 sm:p-10 shadow-md space-y-8 text-xs sm:text-sm text-slate-655 dark:text-slate-300 leading-relaxed font-light">
            
            <div>
                <h2 class="text-lg font-bold text-bushgreen dark:text-gold font-display uppercase tracking-wider mb-2">1. Information Collection</h2>
                <p>
                    We collect personal information directly when you register as a grassroots ambassador, sign up for our newsletters, or submit project feedback. This information includes your name, email address, phone number, and location details (State, LGA, and Ward). This data is strictly used to organize local technical training and coordinator assignments.
                </p>
            </div>

            <div>
                <h2 class="text-lg font-bold text-bushgreen dark:text-gold font-display uppercase tracking-wider mb-2">2. Data Security & Storage</h2>
                <p>
                    The PBAT Smart Nation Initiative implements modern encryption and access control parameters to protect user registry systems. We do not sell, rent, or distribute any ambassador profiles or contact details to third-party marketing services. Access to user data is restricted to authorized steering directors and database administrators.
                </p>
            </div>

            <div>
                <h2 class="text-lg font-bold text-bushgreen dark:text-gold font-display uppercase tracking-wider mb-2">3. Compliance Standards</h2>
                <p>
                    Our data management procedures align with the Nigeria Data Protection Regulation (NDPR) guidelines. If you wish to request the deletion or correction of your coordinator account or personal credentials, please send an inquiry through the Contact Us form.
                </p>
            </div>

            <div class="border-t border-slate-100 dark:border-slate-700 pt-6 text-center text-slate-400 text-[11px]">
                Last Updated: June 2026 • PBAT Smart Nation Initiative Directorate
            </div>

        </div>
    </div>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
