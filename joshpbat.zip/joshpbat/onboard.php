<?php
/**
 * PBAT Smart Nation Initiative - Onboarding Celebration & Verification Resend Gateway
 * Premium, dynamic and stunning celebratory gate for advocacy advocates.
 */
require_once __DIR__ . '/helpers/auth.php';
require_once __DIR__ . '/helpers/common.php';
require_once __DIR__ . '/helpers/notifications.php';
require_once __DIR__ . '/config/database.php';

$email = trim($_GET['email'] ?? '');
$error = '';
$success = '';

if (empty($email)) {
    header("Location: register.php");
    exit;
}

// 1. Handle Resend Verification Trigger
if (isset($_POST['resend'])) {
    if (!Auth::validateCsrf($_POST['csrf_token'] ?? '')) {
        $error = "Security validation expired. Please try again.";
    } else {
        try {
            $db = Database::connect();
            $stmt = $db->prepare("SELECT `id`, `name`, `email`, `status`, `email_verified` FROM `users` WHERE `email` = ? LIMIT 1");
            $stmt->execute([$email]);
            $user = $stmt->fetch();

            if (!$user) {
                $error = "No registered account found with that email address.";
            } elseif ($user['email_verified']) {
                $success = "Your email has already been verified! You can proceed to log in.";
            } else {
                // Generate a fresh email token
                $email_token = bin2hex(random_bytes(32));
                $stmt = $db->prepare("UPDATE `users` SET `email_token` = ? WHERE `id` = ?");
                $stmt->execute([$email_token, $user['id']]);

                // Dispatch colorful verification email
                $http_host = $_SERVER['HTTP_HOST'] ?? 'localhost';
                $verify_link = "http://{$http_host}" . dirname($_SERVER['PHP_SELF']) . "/verify-email.php?token=" . $email_token;
                NotificationEmail::sendOnboardingVerification($email, $user['name'], $verify_link);
                $success = "A fresh, secure activation link has been dispatched to: " . htmlspecialchars($email);
            }
        } catch (Exception $e) {
            $error = "Database Exception: " . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome Onboard - PBAT Smart Nation</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        bushgreen: {
                            DEFAULT: '#063C1E',
                            light: '#0A4D27',
                            dark: '#03200F',
                        },
                        gold: '#D4AF37'
                    }
                }
            }
        }
    </script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Outfit', sans-serif; }
    </style>
</head>
<body class="bg-slate-50 min-h-screen flex items-center justify-center p-4 relative overflow-hidden">
    <!-- Celebratory glows -->
    <div class="absolute w-[600px] h-[600px] bg-bushgreen/10 rounded-full blur-[120px] -top-60 -left-60 pointer-events-none"></div>
    <div class="absolute w-[600px] h-[600px] bg-gold/5 rounded-full blur-[120px] -bottom-60 -right-60 pointer-events-none"></div>

    <div class="max-w-md w-full bg-white rounded-3xl shadow-2xl overflow-hidden border border-slate-100 relative z-10 text-center my-8">
        
        <!-- Premium Curved Header Banner -->
        <div class="bg-bushgreen p-8 text-center relative overflow-hidden border-b-4 border-gold">
            <div class="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-emerald-800/50 via-bushgreen to-bushgreen opacity-95"></div>
            
            <!-- Confetti Stars / Graphics -->
            <div class="relative z-10 space-y-3">
                <div class="w-16 h-16 bg-white/10 rounded-full flex items-center justify-center mx-auto border border-white/20 hover:scale-110 transition duration-300">
                    <svg class="w-8 h-8 text-gold animate-bounce" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
                    </svg>
                </div>
                <h1 class="text-white text-2xl font-bold tracking-tight font-display">Welcome Onboard!</h1>
                <p class="text-gold font-bold text-xs uppercase tracking-widest leading-none">Advocacy Ambassador Mobilization</p>
            </div>
        </div>

        <div class="p-8 space-y-6">
            <?php if (!empty($error)): ?>
                <div class="p-3.5 bg-red-50 border-l-4 border-red-500 rounded-r-lg text-xs text-red-700 font-semibold flex items-center gap-2 text-left">
                    <svg class="w-4 h-4 text-red-500 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clip-rule="evenodd"/></svg>
                    <?php echo $error; ?>
                </div>
            <?php endif; ?>

            <?php if (!empty($success)): ?>
                <div class="p-3.5 bg-emerald-50 border-l-4 border-emerald-500 rounded-r-lg text-xs text-emerald-800 font-semibold text-left flex items-center gap-2">
                    <svg class="w-4 h-4 text-emerald-500 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/></svg>
                    <?php echo $success; ?>
                </div>
            <?php endif; ?>

            <div class="space-y-3">
                <h3 class="text-slate-800 font-extrabold text-lg leading-snug">Verification Email Dispatched</h3>
                <p class="text-slate-500 text-xs leading-relaxed font-light px-2">
                    We have dispatched a highly stylized, colorful HTML verification credential key to: <br>
                    <strong class="text-bushgreen font-mono text-xs break-all"><?php echo htmlspecialchars($email); ?></strong>
                </p>
                <p class="text-slate-400 text-[10px] leading-relaxed font-light">
                    Your portal account remains in <span class="font-bold text-amber-600">Pending</span> state until your email has been authenticated. Check your junk/spam folders if you do not see it within a minute.
                </p>
            </div>


            <form method="POST" action="" class="pt-4 border-t border-slate-100 flex flex-col gap-3">
                <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                
                <button type="submit" name="resend" class="w-full py-3 bg-bushgreen hover:bg-bushgreen-light text-white font-bold rounded-xl text-xs shadow-md transition-all flex items-center justify-center gap-1.5 hover:scale-105">
                    <svg class="w-4 h-4 text-gold animate-spin-slow" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 1121.21 8H18.5" /></svg>
                    RESEND ACTIVATION EMAIL
                </button>
                
                <a href="login.php" class="text-xs text-slate-500 hover:text-bushgreen">Proceed to Portal login gateway</a>
            </form>
        </div>
    </div>
</body>
</html>
