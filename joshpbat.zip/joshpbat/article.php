<?php
/**
 * PBAT Smart Nation Initiative - Dynamic Article Detail Page
 * Premium, high-fidelity article reading experience.
 */
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/helpers/common.php';

$article_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$post = null;
$recent_posts = [];
$error_message = '';

try {
    $db = Database::connect();
    
    if ($article_id > 0) {
        // Fetch article details along with author name and avatar
        $stmt = $db->prepare("
            SELECT b.*, u.name as author_name, u.avatar as author_avatar, r.display_name as author_role 
            FROM `blog_posts` b 
            JOIN `users` u ON b.author_id = u.id 
            JOIN `roles` r ON u.role_id = r.id 
            WHERE b.id = ? AND b.status = 'published' AND b.is_approved = 1 
            LIMIT 1
        ");
        $stmt->execute([$article_id]);
        $post = $stmt->fetch();
        
        if (!$post) {
            $error_message = "The requested article or policy draft could not be found, or it is currently saved as a draft.";
        }
    } else {
        $error_message = "Invalid publication reference ID.";
    }

    // Fetch up to 3 recent published posts excluding the current one
    $recent_stmt = $db->prepare("
        SELECT b.*, u.name as author_name 
        FROM `blog_posts` b 
        JOIN `users` u ON b.author_id = u.id 
        WHERE b.id != ? AND b.status = 'published' AND b.is_approved = 1 
        ORDER BY b.created_at DESC 
        LIMIT 3
    ");
    $recent_stmt->execute([$article_id]);
    $recent_posts = $recent_stmt->fetchAll();
    
} catch (Exception $e) {
    $error_message = "Database System Connection Timeout: " . $e->getMessage();
}

// Calculate reading time
$reading_time = 3; // default fallback
if ($post) {
    $word_count = str_word_count(strip_tags($post['content']));
    $reading_time = max(1, (int)ceil($word_count / 200));
}

// Category styling dictionary
$category_labels = [
    'News' => [
        'bg' => 'bg-amber-50 text-amber-800 border-amber-200/50',
        'icon' => '<svg class="w-3.5 h-3.5 text-amber-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9a2 2 0 00-2-2h-2m-4-3H9M7 16h6M7 8h6v4H7V8z"/></svg>'
    ],
    'Updates' => [
        'bg' => 'bg-emerald-50 text-emerald-800 border-emerald-200/50',
        'icon' => '<svg class="w-3.5 h-3.5 text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>'
    ],
    'Policy Drafts' => [
        'bg' => 'bg-blue-50 text-blue-800 border-blue-200/50',
        'icon' => '<svg class="w-3.5 h-3.5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>'
    ]
];

$cat = $post['category'] ?? 'News';
$style = $category_labels[$cat] ?? $category_labels['News'];

if ($post) {
    // Generate Article Schema
    $articleSchema = [
        '@context' => 'https://schema.org',
        '@type' => 'NewsArticle',
        'headline' => $post['title'],
        'image' => [
            !empty($post['cover_image']) ? $post['cover_image'] : 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=1200&h=630&q=80'
        ],
        'datePublished' => date('c', strtotime($post['created_at'])),
        'author' => [
            '@type' => 'Person',
            'name' => $post['author_name']
        ],
        'publisher' => [
            '@type' => 'Organization',
            'name' => 'PBAT Smart Nation Initiative',
            'logo' => [
                '@type' => 'ImageObject',
                'url' => 'https://app.pbatsmartnation.org.ng/uploads/logo_1780429255.png'
            ]
        ],
        'description' => $post['summary']
    ];

    require_once __DIR__ . '/helpers/seo.php';
    SEO::init([
        'title' => $post['title'] . ' | PBAT Smart Nation Initiative',
        'description' => $post['summary'],
        'keywords' => 'PBAT Smart Nation Articles, Nigeria Digital Policy, ' . $post['category'] . ', ' . $post['title'],
        'image' => !empty($post['cover_image']) ? $post['cover_image'] : 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=1200&h=630&q=80',
        'type' => 'article',
        'breadcrumbs' => [
            ['name' => 'Media Center', 'url' => '/media'],
            ['name' => $post['title'], 'url' => '/article.php?id=' . $post['id']]
        ],
        'schemas' => [$articleSchema]
    ]);
} else {
    require_once __DIR__ . '/helpers/seo.php';
    SEO::init([
        'title' => 'Article Not Found | PBAT Smart Nation Initiative',
        'description' => 'The requested article or policy draft could not be found.',
        'breadcrumbs' => [
            ['name' => 'Media Center', 'url' => '/media']
        ]
    ]);
}

require_once __DIR__ . '/includes/header.php';
?>

<!-- Scroll Progress Bar -->
<div id="scroll-progress-container" class="fixed top-[80px] left-0 w-full h-1 z-50 bg-slate-100">
    <div id="scroll-progress-bar" class="h-full bg-gradient-to-r from-gold via-emerald-600 to-bushgreen w-0 transition-all duration-75"></div>
</div>

<main class="bg-slate-50 min-h-screen pb-24" x-data="{ fontSize: 'base', activeTab: 'article' }">

    <?php if ($error_message): ?>
        <!-- Error State Interface -->
        <div class="max-w-xl mx-auto px-4 py-20 text-center">
            <div class="w-16 h-16 bg-red-50 text-red-500 rounded-full flex items-center justify-center mx-auto mb-6 border border-red-100">
                <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/></svg>
            </div>
            <h2 class="text-2xl font-black text-bushgreen font-display">Publication Unreachable</h2>
            <p class="text-slate-500 text-xs mt-2 leading-relaxed"><?php echo htmlspecialchars($error_message); ?></p>
            <div class="mt-8 flex justify-center gap-4">
                <a href="index.php" class="px-5 py-2.5 bg-bushgreen hover:bg-emerald-800 text-white font-bold text-xs rounded-xl shadow-md transition">&larr; Return Home</a>
                <a href="media.php" class="px-5 py-2.5 border border-slate-200 hover:bg-slate-100 text-slate-600 font-bold text-xs rounded-xl transition">Advocacy Media</a>
            </div>
        </div>
    <?php else: 
        // Resolve cover image path
        $cover = $post['cover_image'] ?? '';
        if (empty($cover) || strpos($cover, 'assets/') === 0) {
            if (strpos($cover, 'blog1') !== false) {
                $cover = 'https://images.unsplash.com/photo-1557804506-669a67965ba0?auto=format&fit=crop&w=1200&q=80';
            } elseif (strpos($cover, 'blog2') !== false) {
                $cover = 'https://images.unsplash.com/photo-1531482615713-2afd69097998?auto=format&fit=crop&w=1200&q=80';
            } elseif (strpos($cover, 'blog3') !== false) {
                $cover = 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=1200&q=80';
            } else {
                $cover = 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=1200&q=80';
            }
        }
    ?>

        <!-- Article Banner / Header -->
        <article class="relative w-full">
            
            <!-- Breadcrumbs Header -->
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 relative z-10">
                <nav class="flex items-center gap-2 text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                    <a href="index.php" class="hover:text-bushgreen transition">Home</a>
                    <span>&bull;</span>
                    <a href="media.php" class="hover:text-bushgreen transition">Advocacy Hub</a>
                    <span>&bull;</span>
                    <span class="text-slate-500 font-extrabold line-clamp-1 max-w-[200px] sm:max-w-none"><?php echo htmlspecialchars($post['title']); ?></span>
                </nav>
            </div>

            <!-- Big Visual Header Grid -->
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                
                <!-- Main Content Panel (Col 8) -->
                <div class="lg:col-span-8 space-y-8">
                    
                    <!-- Title, Category & Read Time Info -->
                    <div class="space-y-4">
                        <div class="flex flex-wrap items-center gap-3">
                            <span class="flex items-center gap-1.5 px-3 py-1 rounded-full border text-[10px] font-extrabold uppercase tracking-wider <?php echo $style['bg']; ?>">
                                <?php echo $style['icon']; ?>
                                <?php echo htmlspecialchars($cat); ?>
                            </span>
                            <span class="text-[11px] font-bold text-slate-400 flex items-center gap-1">
                                <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6l4 2m0-6a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                                <?php echo $reading_time; ?> Min Read
                            </span>
                            <span class="text-[11px] font-bold text-slate-400 flex items-center gap-1">
                                <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
                                <?php echo date('M d, Y', strtotime($post['created_at'])); ?>
                            </span>
                        </div>

                        <h1 class="text-2xl sm:text-4xl lg:text-5xl font-black text-bushgreen tracking-tight leading-tight font-display">
                            <?php echo htmlspecialchars($post['title']); ?>
                        </h1>
                        
                        <p class="text-slate-600 text-sm sm:text-base font-light leading-relaxed border-l-4 border-gold pl-4 py-1.5">
                            <?php echo htmlspecialchars($post['summary']); ?>
                        </p>
                    </div>

                    <!-- Cover Image Container -->
                    <div class="h-64 sm:h-[450px] w-full rounded-3xl overflow-hidden border border-slate-100 shadow-lg relative bg-slate-900 group">
                        <img src="<?php echo htmlspecialchars($cover); ?>" 
                             alt="<?php echo htmlspecialchars($post['title']); ?>" 
                             class="w-full h-full object-cover group-hover:scale-[1.02] transition-transform duration-700 ease-out">
                        <div class="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent"></div>
                    </div>

                    <!-- Article Reading Area (White Box Container) -->
                    <div class="bg-white rounded-3xl border border-slate-100 shadow-sm p-6 sm:p-10 space-y-8">
                        
                        <!-- Accessibility Widget (Font Size adjustment & Reader settings) -->
                        <div class="flex justify-between items-center pb-4 border-b border-slate-50 text-xs font-semibold text-slate-400">
                            <span class="flex items-center gap-1">
                                <svg class="w-4 h-4 text-gold" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"/></svg>
                                Reader Panel
                            </span>
                            <div class="flex items-center gap-2">
                                <span class="text-[10px] uppercase font-bold tracking-widest text-slate-400">Text Size:</span>
                                <button @click="fontSize = 'sm'" :class="fontSize === 'sm' ? 'bg-bushgreen text-white border-bushgreen' : 'bg-slate-50 text-slate-600 hover:bg-slate-100 border-slate-200'" class="w-7 h-7 rounded border text-[10px] font-bold transition flex items-center justify-center">A-</button>
                                <button @click="fontSize = 'base'" :class="fontSize === 'base' ? 'bg-bushgreen text-white border-bushgreen' : 'bg-slate-50 text-slate-600 hover:bg-slate-100 border-slate-200'" class="w-7 h-7 rounded border text-xs font-bold transition flex items-center justify-center font-display">A</button>
                                <button @click="fontSize = 'lg'" :class="fontSize === 'lg' ? 'bg-bushgreen text-white border-bushgreen' : 'bg-slate-50 text-slate-600 hover:bg-slate-100 border-slate-200'" class="w-7 h-7 rounded border text-sm font-bold transition flex items-center justify-center font-display">A+</button>
                            </div>
                        </div>

                        <!-- Core HTML Article Body Content -->
                        <div class="prose max-w-none text-slate-700 leading-relaxed font-light font-sans space-y-6"
                             :class="{
                                 'text-sm leading-relaxed': fontSize === 'sm',
                                 'text-base leading-relaxed': fontSize === 'base',
                                 'text-lg leading-loose': fontSize === 'lg'
                             }">
                            <?php 
                                // Since database HTML tags are allowed, output content directly but carefully
                                echo $post['content']; 
                            ?>
                        </div>

                        <!-- Share & Social Interaction Bar -->
                        <div class="pt-8 border-t border-slate-100 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                            <div class="space-y-1">
                                <span class="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">Policy & Campaign Reference</span>
                                <span class="text-xs text-slate-500">Official statement from the <strong>PBAT Smart Nation Executive Council</strong>.</span>
                            </div>
                            
                            <!-- Share Simulation Grid -->
                            <div class="flex items-center gap-2">
                                <span class="text-[10px] text-slate-400 font-bold uppercase tracking-widest mr-1">Share:</span>
                                
                                <!-- Twitter X -->
                                <button onclick="alert('Link copied! Simulate dispatch to Twitter/X feed.')" class="w-9 h-9 rounded-xl border border-slate-200 hover:border-gold hover:text-gold flex items-center justify-center text-slate-500 hover:bg-slate-50 transition">
                                    <svg class="w-4 h-4 fill-current" viewBox="0 0 24 24"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>
                                </button>
                                
                                <!-- Facebook -->
                                <button onclick="alert('Link copied! Simulate dispatch to Facebook.')" class="w-9 h-9 rounded-xl border border-slate-200 hover:border-gold hover:text-gold flex items-center justify-center text-slate-500 hover:bg-slate-50 transition">
                                    <svg class="w-4 h-4 fill-current" viewBox="0 0 24 24"><path d="M22 12c0-5.52-4.48-10-10-10S2 6.48 2 12c0 4.84 3.44 8.87 8 9.8V15H8v-3h2V9.5C10 7.57 11.57 6 13.5 6H16v3h-2c-.55 0-1 .45-1 1v2h3v3h-3v6.95c4.56-.93 8-4.96 8-9.75z"/></svg>
                                </button>

                                <!-- LinkedIn -->
                                <button onclick="alert('Link copied! Simulate dispatch to LinkedIn network.')" class="w-9 h-9 rounded-xl border border-slate-200 hover:border-gold hover:text-gold flex items-center justify-center text-slate-500 hover:bg-slate-50 transition">
                                    <svg class="w-4 h-4 fill-current" viewBox="0 0 24 24"><path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/></svg>
                                </button>

                                <!-- WhatsApp -->
                                <button onclick="alert('Link copied! Opening WhatsApp share simulator.')" class="w-9 h-9 rounded-xl border border-slate-200 hover:border-gold hover:text-gold flex items-center justify-center text-slate-500 hover:bg-slate-50 transition">
                                    <svg class="w-4 h-4 fill-current" viewBox="0 0 24 24"><path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946C.06 5.348 5.397.01 12.008.01c3.202.001 6.212 1.246 8.477 3.514 2.266 2.268 3.507 5.28 3.505 8.484-.004 6.657-5.34 11.997-11.953 11.997-2.005-.001-3.973-.504-5.714-1.466L0 24zm6.59-3.791c1.624.965 3.222 1.48 5.345 1.483 5.516.002 10.002-4.482 10.005-10.003.002-2.673-1.037-5.184-2.932-7.081-1.897-1.897-4.409-2.935-7.083-2.937-5.52 0-10.005 4.48-10.008 10.003-.001 2.154.562 3.797 1.554 5.485L1.512 21.09l4.582-1.201c.205.109.336.18.553.32z"/></svg>
                                </button>
                            </div>
                        </div>

                    </div>

                    <!-- Premium Simulated Interactive Feedback Zone (For Policy Comments) -->
                    <div class="bg-white rounded-3xl border border-slate-100 shadow-sm p-6 sm:p-10 space-y-6">
                        <div class="space-y-1">
                            <h3 class="text-slate-800 font-bold text-lg font-display">Citizen Engagement & Feedback</h3>
                            <p class="text-slate-400 text-xs font-light">Join the national technological dialogue. Submit feedback or recommendations on this publication.</p>
                        </div>

                        <!-- Feedback Form -->
                        <form onsubmit="event.preventDefault(); alert('Thank you! Your feedback has been queued. An administrator will review and spotlight your comment shortly.'); this.reset();" class="space-y-4 pt-2">
                            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                <div>
                                    <label class="block text-slate-600 text-xs font-semibold mb-1" for="comment_name">Your Full Name</label>
                                    <input type="text" id="comment_name" required placeholder="e.g. Yusuf Haruna"
                                           class="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-none focus:border-bushgreen">
                                </div>
                                <div>
                                    <label class="block text-slate-600 text-xs font-semibold mb-1" for="comment_role">Your Designation/State</label>
                                    <input type="text" id="comment_role" required placeholder="e.g. Tech Lead, Kaduna"
                                           class="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-none focus:border-bushgreen">
                                </div>
                            </div>
                            <div>
                                <label class="block text-slate-600 text-xs font-semibold mb-1" for="comment_body">Your Feedback Commentary</label>
                                <textarea id="comment_body" required rows="4" placeholder="Express your views or recommend structural policy edits here..."
                                          class="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-none focus:border-bushgreen font-light leading-relaxed"></textarea>
                            </div>
                            <button type="submit" class="w-full sm:w-auto py-2.5 px-6 bg-bushgreen hover:bg-bushgreen-light text-white text-xs font-bold rounded-xl transition shadow-md shadow-bushgreen/10 flex items-center justify-center gap-2">
                                <svg class="w-3.5 h-3.5 text-gold" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"/></svg>
                                Submit Civic Commentary
                            </button>
                        </form>

                        <!-- Existing Feedback List -->
                        <div class="pt-6 border-t border-slate-100 space-y-4">
                            <h4 class="text-xs text-slate-500 font-bold uppercase tracking-wider">Spotlight Feedback (3)</h4>
                            
                            <div class="space-y-4">
                                <div class="p-4 rounded-2xl bg-slate-50 border border-slate-100 text-xs space-y-2">
                                    <div class="flex justify-between items-center">
                                        <span class="font-bold text-slate-800">Engr. Funsho Balogun</span>
                                        <span class="text-[10px] text-slate-400">State Chairman, Lagos</span>
                                    </div>
                                    <p class="text-slate-600 leading-relaxed font-light">Outstanding technological performance review. We need our local governments in Lagos to integrate these blueprints immediately.</p>
                                </div>

                                <div class="p-4 rounded-2xl bg-slate-50 border border-slate-100 text-xs space-y-2">
                                    <div class="flex justify-between items-center">
                                        <span class="font-bold text-slate-800">Adebayo Adeola</span>
                                        <span class="text-[10px] text-slate-400">Zonal Chairman, South-West</span>
                                    </div>
                                    <p class="text-slate-600 leading-relaxed font-light">This is highly strategic. Demystifying tech policies will empower local groups and build massive digital awareness.</p>
                                </div>

                                <div class="p-4 rounded-2xl bg-slate-50 border border-slate-100 text-xs space-y-2">
                                    <div class="flex justify-between items-center">
                                        <span class="font-bold text-slate-800">Tunde Coker</span>
                                        <span class="text-[10px] text-slate-400">Ambassador, Alimosho</span>
                                    </div>
                                    <p class="text-slate-600 leading-relaxed font-light">Fascinating insights. Alimosho youth are ready to deploy these internet hubs to boost local digital literacy.</p>
                                </div>
                            </div>
                        </div>

                    </div>

                </div>

                <!-- Sidebar (Col 4) -->
                <div class="lg:col-span-4 space-y-8">
                    
                    <!-- Author Information Widget -->
                    <div class="bg-white rounded-3xl border border-slate-100 shadow-sm p-6 space-y-4">
                        <h3 class="text-slate-800 font-bold text-xs tracking-wider uppercase border-b border-slate-50 pb-2">Author & Publisher</h3>
                        <div class="flex items-center gap-4">
                            <img src="<?php echo htmlspecialchars($post['author_avatar'] ?? 'assets/img/default-avatar.png'); ?>" 
                                 alt="<?php echo htmlspecialchars($post['author_name']); ?>" 
                                 class="w-14 h-14 rounded-2xl border-2 border-gold/45 object-cover">
                            <div class="space-y-0.5">
                                <h4 class="font-bold text-slate-800 text-sm font-display"><?php echo htmlspecialchars($post['author_name']); ?></h4>
                                <span class="text-[10px] text-gold font-bold uppercase tracking-wider block"><?php echo htmlspecialchars($post['author_role'] ?? 'Founder Circle'); ?></span>
                                <span class="text-[9px] text-slate-400 block">Smart Nation Council Representative</span>
                            </div>
                        </div>
                        <p class="text-slate-500 text-[11px] leading-relaxed font-light">
                            Tasked with reviewing digital infrastructures and organizing sensitization webinars for local coordinators in all geopolitical zones.
                        </p>
                    </div>

                    <!-- Related/Recent Articles Sidebar -->
                    <div class="bg-white rounded-3xl border border-slate-100 shadow-sm p-6 space-y-4">
                        <h3 class="text-slate-800 font-bold text-xs tracking-wider uppercase border-b border-slate-50 pb-2">Other Publications</h3>
                        
                        <div class="space-y-4">
                            <?php if (empty($recent_posts)): ?>
                                <p class="text-xs text-slate-400 italic">No other published articles are currently available.</p>
                            <?php else: ?>
                                <?php foreach ($recent_posts as $recent): 
                                    $recent_cover = $recent['cover_image'] ?? '';
                                    if (empty($recent_cover) || strpos($recent_cover, 'assets/') === 0) {
                                        if (strpos($recent_cover, 'blog1') !== false) {
                                            $recent_cover = 'https://images.unsplash.com/photo-1557804506-669a67965ba0?auto=format&fit=crop&w=300&q=80';
                                        } elseif (strpos($recent_cover, 'blog2') !== false) {
                                            $recent_cover = 'https://images.unsplash.com/photo-1531482615713-2afd69097998?auto=format&fit=crop&w=300&q=80';
                                        } elseif (strpos($recent_cover, 'blog3') !== false) {
                                            $recent_cover = 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=300&q=80';
                                        } else {
                                            $recent_cover = 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=300&q=80';
                                        }
                                    }
                                ?>
                                    <a href="article.php?id=<?php echo $recent['id']; ?>" class="flex gap-3 hover:bg-slate-50 rounded-xl p-2 transition group">
                                        <div class="w-16 h-16 rounded-xl overflow-hidden bg-slate-100 border border-slate-100 flex-shrink-0">
                                            <img src="<?php echo htmlspecialchars($recent_cover); ?>" 
                                                 alt="<?php echo htmlspecialchars($recent['title']); ?>" 
                                                 class="w-full h-full object-cover group-hover:scale-105 transition duration-500">
                                        </div>
                                        <div class="space-y-1">
                                            <h4 class="text-xs font-bold text-slate-800 line-clamp-2 leading-snug group-hover:text-bushgreen transition font-display"><?php echo htmlspecialchars($recent['title']); ?></h4>
                                            <span class="text-[9px] text-slate-400 block"><?php echo date('M d, Y', strtotime($recent['created_at'])); ?></span>
                                        </div>
                                    </a>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Call To Action Card -->
                    <div class="bg-bushgreen rounded-3xl p-6 border border-gold/25 relative overflow-hidden shadow-lg text-white">
                        <div class="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-bushgreen-light/40 via-bushgreen to-bushgreen-dark opacity-95"></div>
                        <div class="relative z-10 space-y-4">
                            <span class="text-gold font-bold text-[10px] tracking-widest uppercase block">Join the advocacy</span>
                            <h4 class="font-extrabold text-base tracking-tight font-display">Become an Ambassador for your community</h4>
                            <p class="text-slate-300 text-[11px] font-light leading-relaxed">
                                Drive technological sensitization, network with civic advocates, and build smart structures.
                            </p>
                            <a href="register.php" class="inline-block w-full text-center py-2.5 px-4 bg-gold hover:bg-gold-light text-bushgreen font-bold text-xs rounded-xl shadow transition">
                                Start Onboarding &rarr;
                            </a>
                        </div>
                    </div>

                </div>

            </div>

        </article>

        <!-- Javascript Scroll Indicator Link -->
        <script>
            document.addEventListener('DOMContentLoaded', () => {
                const updateProgressBar = () => {
                    const winScroll = document.documentElement.scrollTop || document.body.scrollTop;
                    const height = document.documentElement.scrollHeight - document.documentElement.clientHeight;
                    const scrolled = height > 0 ? (winScroll / height) * 100 : 0;
                    const progressBar = document.getElementById('scroll-progress-bar');
                    if (progressBar) {
                        progressBar.style.width = scrolled + '%';
                    }
                };
                window.addEventListener('scroll', updateProgressBar);
                updateProgressBar(); // initial trigger
            });
        </script>

    <?php endif; ?>

</main>

<?php
require_once __DIR__ . '/includes/footer.php';
?>
