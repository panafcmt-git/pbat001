<?php
/**
 * PBAT Smart Nation Initiative - Email Verification Gate
 * Validates cryptographic tokens, activates user accounts, and outputs stunning success feedback.
 */
require_once __DIR__ . '/helpers/auth.php';
require_once __DIR__ . '/helpers/common.php';
require_once __DIR__ . '/helpers/notifications.php';
require_once __DIR__ . '/config/database.php';

$token = trim($_GET['token'] ?? '');
$error = '';
$success = '';

if (empty($token)) {
    $error = "Missing credentials token. Please click the full link in your verification email.";
} else {
    try {
        $db = Database::connect();
        
        // Find user by verification token
        $stmt = $db->prepare("SELECT `id`, `name`, `email` FROM `users` WHERE `email_token` = ? LIMIT 1");
        $stmt->execute([$token]);
        $user = $stmt->fetch();
        
        if (!$user) {
            $error = "Invalid activation key. The link has either expired or already been utilized.";
        } else {
            $db->beginTransaction();
            
            // 1. Activate user
            $stmt = $db->prepare("UPDATE `users` SET `email_verified` = 1, `email_token` = NULL, `status` = 'active' WHERE `id` = ?");
            $stmt->execute([$user['id']]);
            
            // 2. Audit log
            Auth::logAction($user['id'], 'EMAIL_VERIFY', "Email address verified successfully: '{$user['email']}'.");
            
            // 3. Dispatch a celebratory welcome email!
            NotificationEmail::sendWelcomeActivation($user['email'], $user['name']);
            
            $db->commit();
            $success = "Congratulations, " . htmlspecialchars($user['name']) . "! Your email address has been successfully verified.";
        }
    } catch (Exception $e) {
        if (isset($db) && $db->inTransaction()) {
            $db->rollBack();
        }
        $error = "System Database Exception: " . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Email Verification - PBAT Smart Nation</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        bushgreen: {
                            DEFAULT: '#063C1E',
                            light: '#0A4D27',
                            dark: '#03200F',
                        },
                        gold: '#D4AF37'
                    }
                }
            }
        }
    </script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Outfit', sans-serif; }
    </style>
</head>
<body class="bg-slate-50 min-h-screen flex items-center justify-center p-4 relative overflow-hidden">
    <!-- Visual background glows -->
    <div class="absolute w-[500px] h-[500px] bg-bushgreen/10 rounded-full blur-[100px] -top-40 -left-40 pointer-events-none"></div>
    <div class="absolute w-[500px] h-[500px] bg-gold/5 rounded-full blur-[100px] -bottom-40 -right-40 pointer-events-none"></div>

    <div class="max-w-md w-full bg-white rounded-3xl shadow-2xl overflow-hidden border border-slate-100 relative z-10 text-center my-8">
        
        <!-- Curved Banner -->
        <div class="bg-bushgreen p-8 text-center relative overflow-hidden border-b-4 border-gold">
            <div class="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-emerald-800/50 via-bushgreen to-bushgreen opacity-95"></div>
            <div class="relative z-10 space-y-2">
                <div class="w-12 h-12 bg-white/10 rounded-xl flex items-center justify-center mx-auto border border-white/20">
                    <svg class="w-6 h-6 text-gold" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
                    </svg>
                </div>
                <h1 class="text-white text-xl font-bold tracking-tight">Credentials Certification Gate</h1>
                <p class="text-gold/90 text-xs uppercase tracking-widest font-semibold">Verify Portal Credentials</p>
            </div>
        </div>

        <div class="p-8 space-y-6">
            <?php if (!empty($error)): ?>
                <!-- Verification Failure -->
                <div class="space-y-4">
                    <div class="w-16 h-16 bg-red-50 rounded-full border border-red-200 flex items-center justify-center mx-auto text-red-500">
                        <svg class="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/>
                        </svg>
                    </div>
                    <div class="space-y-1">
                        <h3 class="text-slate-800 font-extrabold text-lg">Activation Failed</h3>
                        <p class="text-xs text-red-600 font-semibold leading-relaxed px-4">
                            <?php echo $error; ?>
                        </p>
                    </div>
                    <div class="pt-4 border-t border-slate-100 flex flex-col gap-2">
                        <a href="register.php" class="py-2.5 bg-bushgreen text-white rounded-xl text-xs font-bold hover:bg-emerald-800 transition">
                            Back to Registration Page
                        </a>
                    </div>
                </div>
            <?php else: ?>
                <!-- Verification Success -->
                <div class="space-y-4">
                    <div class="w-16 h-16 bg-emerald-50 rounded-full border border-emerald-200 flex items-center justify-center mx-auto text-emerald-500 animate-pulse">
                        <svg class="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
                        </svg>
                    </div>
                    <div class="space-y-1">
                        <h3 class="text-slate-800 font-extrabold text-lg">Verification Successful!</h3>
                        <p class="text-xs text-slate-500 leading-relaxed px-4 font-light">
                            <?php echo $success; ?> Your administrative account is now active, and we have dispatched a welcome notification packet.
                        </p>
                    </div>
                    <div class="pt-4 border-t border-slate-100 flex flex-col gap-2">
                        <a href="login.php" class="py-2.5 bg-bushgreen text-white rounded-xl text-xs font-bold hover:bg-emerald-800 transition shadow hover:scale-105 transition-all">
                            Proceed to Portal Sign In
                        </a>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
