<?php
/**
 * PBAT Smart Nation Initiative - Real-Time Recent Ambassadors API
 * Returns the latest registered ambassadors as JSON for live homepage sync.
 */
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../helpers/common.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

$ambassadors = [];

try {
    $db = Database::connect();

    $stmt = $db->query("
        SELECT
            u.name,
            u.avatar,
            u.created_at,
            r.display_name AS role_display,
            COALESCE(s.name, sl.name) AS state_name,
            COALESCE(l.name, ll.name) AS lga_name
        FROM users u
        JOIN roles r ON u.role_id = r.id
        LEFT JOIN ambassadors a ON a.user_id = u.id
        LEFT JOIN states s ON a.state_id = s.id
        LEFT JOIN lgas l ON a.lga_id = l.id
        LEFT JOIN user_leadership ul ON ul.user_id = u.id
        LEFT JOIN states sl ON ul.state_id = sl.id
        LEFT JOIN lgas ll ON ul.lga_id = ll.id
        WHERE u.role_id IN (3, 4, 5, 6, 7)
          AND u.status = 'active'
        ORDER BY u.created_at DESC
        LIMIT 20
    ");

    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    foreach ($rows as &$amb) {
        // Avatar / initials normalisation
        if (empty($amb['avatar']) || $amb['avatar'] === 'assets/img/default-avatar.png') {
            $amb['avatar'] = '';
            $parts    = explode(' ', trim($amb['name']));
            $amb['initials']   = strtoupper(substr($parts[0] ?? 'U', 0, 1) . (isset($parts[1]) ? substr($parts[1], 0, 1) : ''));
            $amb['avatar_hue'] = abs(crc32($amb['name'])) % 360;
        } else {
            $amb['initials']   = '';
            $amb['avatar_hue'] = 0;
        }

        // Joined label
        if (!empty($amb['created_at'])) {
            $diff = (new DateTime())->diff(new DateTime($amb['created_at']));
            $days = (int)$diff->days;
            if ($days === 0)       $amb['joined_label'] = 'Joined today';
            elseif ($days === 1)   $amb['joined_label'] = 'Joined yesterday';
            elseif ($days < 7)     $amb['joined_label'] = "Joined {$days} days ago";
            elseif ($days < 30)  { $w = (int)ceil($days / 7);  $amb['joined_label'] = "Joined {$w}w ago"; }
            elseif ($days < 365) { $m = (int)ceil($days / 30); $amb['joined_label'] = "Joined {$m}mo ago"; }
            else                 { $y = (int)floor($days / 365); $amb['joined_label'] = "Joined {$y}yr ago"; }
        } else {
            $amb['joined_label'] = 'New Advocate';
        }

        // Location string
        $loc_parts = array_filter([
            $amb['lga_name']   ?? null,
            ($amb['state_name'] ?? null) ? ($amb['state_name'] . ' State') : null,
        ]);
        $amb['location'] = implode(', ', $loc_parts) ?: 'Nigeria';

        // Sanitise
        $amb['name']         = htmlspecialchars($amb['name']);
        $amb['role_display'] = htmlspecialchars($amb['role_display'] ?? '');
        $amb['avatar']       = htmlspecialchars($amb['avatar']);
        $amb['initials']     = htmlspecialchars($amb['initials']);
        $amb['location']     = htmlspecialchars($amb['location']);

        unset($amb['created_at'], $amb['state_name'], $amb['lga_name']);
    }
    unset($amb);

    echo json_encode([
        'status'      => 'success',
        'count'       => count($rows),
        'ambassadors' => $rows,
        'timestamp'   => time(),
    ]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'status'  => 'error',
        'message' => 'Unable to fetch data.',
    ]);
}
