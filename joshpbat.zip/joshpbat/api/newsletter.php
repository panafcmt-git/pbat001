<?php
/**
 * PBAT Smart Nation Initiative - Newsletter API Handler
 * Receives and validates AJAX newsletter subscriptions.
 */
header('Content-Type: application/json');
require_once dirname(__DIR__) . '/config/database.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['status' => 'error', 'message' => 'Method not allowed.']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$email = trim($input['email'] ?? $_POST['email'] ?? '');

if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'Please enter a valid email address.']);
    exit;
}

try {
    $db = Database::connect();
    
    // Check if newsletters table exists, if not create it dynamically (extra safety)
    $db->exec("CREATE TABLE IF NOT EXISTS `newsletters` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `email` VARCHAR(150) UNIQUE NOT NULL,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    // Insert email
    $stmt = $db->prepare("INSERT IGNORE INTO `newsletters` (`email`) VALUES (?)");
    $stmt->execute([$email]);

    echo json_encode(['status' => 'success', 'message' => 'Thank you! You have been successfully subscribed.']);
    exit;
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'Database error: ' . $e->getMessage()]);
    exit;
}
