<?php
/**
 * PBAT Smart Nation Initiative - AJAX Wards API
 * Fetch wards dynamically based on selected LGA ID to keep registration pages extremely lightweight.
 */
require_once dirname(__DIR__) . '/config/database.php';

header('Content-Type: application/json');
header('Cache-Control: public, max-age=86400'); // Cache for 24 hours to boost performance

$lga_id = (int)($_GET['lga_id'] ?? 0);

if ($lga_id <= 0) {
    echo json_encode([]);
    exit;
}

try {
    $db = Database::connect();
    $stmt = $db->prepare("SELECT `id`, `name` FROM `wards` WHERE `lga_id` = ? ORDER BY `name` ASC");
    $stmt->execute([$lga_id]);
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($results);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database operation failure: ' . $e->getMessage()]);
}
