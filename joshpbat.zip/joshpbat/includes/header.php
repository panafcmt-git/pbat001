<?php
/**
 * PBAT Smart Nation Initiative - Shared Header Template
 * Modern, elegant glassmorphism navbar, responsive mobile dropdown, and brand assets.
 */
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once dirname(__DIR__) . '/helpers/auth.php';
require_once dirname(__DIR__) . '/helpers/common.php';
?>
<!DOCTYPE html>
<html lang="en" class="scroll-smooth">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!-- SEO Optimization -->
    <?php
    require_once dirname(__DIR__) . '/helpers/seo.php';
    SEO::renderMeta();
    SEO::renderSchemas();
    ?>
    
    <!-- Tailwind Play CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        bushgreen: {
                            DEFAULT: '#063C1E',
                            light: '#0A4D27',
                            dark: '#03200F',
                        },
                        gold: {
                            DEFAULT: '#D4AF37',
                            light: '#E5C158',
                            dark: '#A6841C',
                        }
                    },
                    fontFamily: {
                        sans: ['Inter', 'sans-serif'],
                        display: ['Outfit', 'sans-serif'],
                    }
                }
            }
        }
    </script>
    
    <!-- Elegant Typography Integration -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600&family=Outfit:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    
    <!-- AlpineJS for Interactive Micro-Animations & State -->
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
 
    <style>
        body {
            font-family: 'Inter', sans-serif;
            font-weight: 400;
        }
        h1, h2, h3, h4, .font-display {
            font-family: 'Outfit', sans-serif;
        }
        /* Custom scrollbar matching green-gold branding */
        ::-webkit-scrollbar {
            width: 8px;
        }
        ::-webkit-scrollbar-track {
            background: #F8F9FA;
        }
        ::-webkit-scrollbar-thumb {
            background: #063C1E;
            border-radius: 4px;
        }
        ::-webkit-scrollbar-thumb:hover {
            background: #D4AF37;
        }
    </style>
</head>
<body class="bg-white text-slate-800 flex flex-col min-h-screen antialiased">
 
    <!-- Sticky Glassmorphism Header Navbar -->
    <header x-data="{ open: false }" class="sticky top-0 z-50 w-full bg-white/90 backdrop-blur-md border-b border-slate-100 transition-all duration-300">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center h-20">
                
                <!-- Logo & Brand Title -->
                <a href="index.php" class="flex items-center gap-3 group focus:outline-none">
                    <div class="w-12 h-12 bg-bushgreen rounded-xl flex items-center justify-center border border-gold/30 shadow-md group-hover:border-gold transition-colors duration-300">
                        <!-- Custom Futuristic Logo / Fallback -->
                        <?php echo getAppLogoHtml('w-7 h-7 object-contain group-hover:scale-105 transition-transform duration-300', 'header'); ?>
                    </div>
                    <div class="flex flex-col">
                        <span class="text-bushgreen font-extrabold text-lg tracking-tight font-display leading-none">PBAT SMART NATION</span>
                        <span class="text-gold font-bold text-[10px] tracking-widest mt-0.5 leading-none">INITIATIVE</span>
                    </div>
                </a>

                <!-- Desktop Navigation Links -->
                <nav class="hidden md:flex space-x-8 items-center">
                    <a href="index.php" class="text-slate-600 hover:text-bushgreen font-medium text-[14px] transition-colors">Home</a>
                    <a href="about.php" class="text-slate-600 hover:text-bushgreen font-medium text-[14px] transition-colors">Who We Are</a>
                    <a href="pillars.php" class="text-slate-600 hover:text-bushgreen font-medium text-[14px] transition-colors">Focus & Tech</a>
                    <a href="media.php" class="text-slate-600 hover:text-bushgreen font-medium text-[14px] transition-colors">Media Center</a>
                    
                    <!-- Contact Us Dropdown -->
                    <div x-data="{ openContact: false }" @click.away="openContact = false" class="relative">
                        <button @click="openContact = !openContact" class="text-slate-600 hover:text-bushgreen font-medium text-[14px] transition-colors flex items-center gap-1 focus:outline-none">
                            Contact Us
                            <svg class="w-4 h-4 text-slate-400 transition-transform duration-200" :class="{'rotate-180': openContact}" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/></svg>
                        </button>
                        <div x-show="openContact" 
                             x-transition:enter="transition ease-out duration-100"
                             x-transition:enter-start="transform opacity-0 scale-95"
                             x-transition:enter-end="transform opacity-100 scale-100"
                             x-transition:leave="transition ease-in duration-75"
                             x-transition:leave-start="transform opacity-100 scale-100"
                             x-transition:leave-end="transform opacity-0 scale-95"
                             class="absolute right-0 mt-2 w-56 rounded-xl bg-white border border-slate-100 shadow-lg py-1.5 z-50"
                             style="display: none;">
                            <a href="sponsors.php" class="block px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 hover:text-bushgreen transition">Project Sponsors Program</a>
                            <a href="contact.php" class="block px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 hover:text-bushgreen transition">Contact Us / Feedback</a>
                            <a href="partner.php" class="block px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 hover:text-bushgreen transition">Partner With Us</a>
                            <a href="donate.php" class="block px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 hover:text-bushgreen transition">Donate / Support</a>
                        </div>
                    </div>
                    
                    <?php if (Auth::isLoggedIn()): ?>
                        <a href="admin/dashboard.php" class="text-bushgreen hover:text-emerald-800 font-semibold text-[14px] flex items-center gap-1">
                            <svg class="w-4 h-4 text-gold" fill="currentColor" viewBox="0 0 24 24"><path fill-rule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clip-rule="evenodd"/></svg>
                            Portal Dashboard
                        </a>
                        <a href="logout.php" class="text-red-600 hover:text-red-700 font-medium text-[14px]">Logout</a>
                    <?php else: ?>
                        <a href="login.php" class="text-slate-600 hover:text-bushgreen font-medium text-[14px] transition-colors">Ambassador Portal</a>
                        <a href="register.php" class="bg-bushgreen hover:bg-bushgreen-light text-white px-5 py-2.5 rounded-lg font-semibold text-[13px] tracking-wide shadow-md shadow-bushgreen/10 hover:shadow-lg transition-all duration-300 border border-gold/20 flex items-center gap-1.5 hover:scale-105">
                            Join Initiative
                            <svg class="w-4 h-4 text-gold" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7l5 5m0 0l-5 5m5-5H6"/></svg>
                        </a>
                    <?php endif; ?>
                </nav>

                <!-- Mobile Menu Button Toggle -->
                <div class="md:hidden">
                    <button @click="open = !open" class="text-bushgreen p-2 focus:outline-none" aria-label="Toggle Menu">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" x-show="!open">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" />
                        </svg>
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" x-show="open" style="display: none;">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                        </svg>
                    </button>
                </div>
            </div>
        </div>

        <!-- Mobile Navigation Menu Draw -->
        <div x-show="open" 
             x-transition:enter="transition ease-out duration-200"
             x-transition:enter-start="opacity-0 -translate-y-4"
             x-transition:enter-end="opacity-100 translate-y-0"
             x-transition:leave="transition ease-in duration-150"
             x-transition:leave-start="opacity-100 translate-y-0"
             x-transition:leave-end="opacity-0 -translate-y-4"
             class="md:hidden bg-white border-b border-slate-100 px-4 pt-2 pb-6 space-y-3 shadow-lg"
             style="display: none;">
            <a href="index.php" @click="open = false" class="block py-2 px-3 hover:bg-slate-50 rounded-lg text-slate-700 font-medium text-[15px]">Home</a>
            <a href="about.php" @click="open = false" class="block py-2 px-3 hover:bg-slate-50 rounded-lg text-slate-700 font-medium text-[15px]">Who We Are</a>
            <a href="pillars.php" @click="open = false" class="block py-2 px-3 hover:bg-slate-50 rounded-lg text-slate-700 font-medium text-[15px]">Focus & Tech</a>
            <a href="media.php" @click="open = false" class="block py-2 px-3 hover:bg-slate-50 rounded-lg text-slate-700 font-medium text-[15px]">Media Center</a>
            
            <!-- Mobile Contact Us Submenu -->
            <div x-data="{ openContactMobile: false }" class="space-y-1">
                <button @click="openContactMobile = !openContactMobile" class="w-full flex justify-between items-center py-2 px-3 hover:bg-slate-50 rounded-lg text-slate-700 font-medium text-[15px] focus:outline-none">
                    <span>Contact Us</span>
                    <svg class="w-4 h-4 text-slate-400 transition-transform duration-200" :class="{'rotate-180': openContactMobile}" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/></svg>
                </button>
                <div x-show="openContactMobile" class="pl-4 space-y-1" style="display: none;">
                    <a href="sponsors.php" @click="open = false" class="block py-2 px-3 hover:bg-slate-50 rounded-lg text-slate-600 font-medium text-[14px]">Project Sponsors Program</a>
                    <a href="contact.php" @click="open = false" class="block py-2 px-3 hover:bg-slate-50 rounded-lg text-slate-600 font-medium text-[14px]">Contact Us / Feedback</a>
                    <a href="partner.php" @click="open = false" class="block py-2 px-3 hover:bg-slate-50 rounded-lg text-slate-600 font-medium text-[14px]">Partner With Us</a>
                    <a href="donate.php" @click="open = false" class="block py-2 px-3 hover:bg-slate-50 rounded-lg text-slate-600 font-medium text-[14px]">Donate / Support</a>
                </div>
            </div>
            
            <?php if (Auth::isLoggedIn()): ?>
                <a href="admin/dashboard.php" class="block py-2 px-3 bg-bushgreen text-white rounded-lg font-semibold text-[15px]">Portal Dashboard</a>
                <a href="logout.php" class="block py-2 px-3 text-red-600 font-medium text-[15px]">Logout</a>
            <?php else: ?>
                <a href="login.php" @click="open = false" class="block py-2 px-3 hover:bg-slate-50 rounded-lg text-slate-700 font-medium text-[15px]">Ambassador Portal</a>
                <a href="register.php" @click="open = false" class="block py-2 px-3 bg-bushgreen text-white text-center rounded-lg font-semibold text-[14px]">Join Initiative</a>
            <?php endif; ?>
        </div>
    </header>

    <!-- Main Content wrapper flex -->
    <main class="flex-grow">
