<?php
/**
 * PBAT Smart Nation Initiative - Shared Footer Template
 * Gorgeous dark-green footer with newsletter interactive widget, social feeds, and navigation.
 */
require_once __DIR__ . '/../config/database.php';

$footer_tv_videos = [];
try {
    $db = Database::connect();
    $stmt = $db->query("SELECT * FROM `youtube_videos` ORDER BY `is_featured` DESC, `created_at` DESC LIMIT 4");
    $footer_tv_videos = $stmt->fetchAll();
} catch (Exception $e) {
    $footer_tv_videos = [];
}

if (empty($footer_tv_videos)) {
    $footer_tv_videos = [[
        'id' => 0,
        'title' => 'Smart Nation LIVE tv Placeholder',
        'description' => 'Featured broadcast preview for the footer TV rail. Add videos from the Super Admin TV dashboard to replace this placeholder.',
        'youtube_id' => 'dQw4w9WgXcQ',
        'video_source' => 'youtube',
        'video_url' => '',
        'duration' => '05:00',
        'is_featured' => 1,
    ]];
}
$footer_featured_video = $footer_tv_videos[0];
$floating_tv_enabled = (int)getSystemSetting('floating_tv_enabled', 1);
$floating_tv_title = getSystemSetting('floating_tv_title', 'Smart Nation LIVE tv');
$floating_tv_description = getSystemSetting('floating_tv_description', 'Watch the featured Smart Nation LIVE tv playlist, including self-hosted and YouTube videos managed from the Super Admin TV dashboard.');
?>
    </main> <!-- End of main content tag -->

    <!-- Elegant Footer -->
    <footer class="bg-bushgreen text-white pt-16 pb-8 border-t-2 border-gold/45 relative overflow-hidden">
        <!-- Background light glows -->
        <div class="absolute inset-0 bg-[radial-gradient(circle_at_bottom_right,_var(--tw-gradient-stops))] from-emerald-800/10 via-bushgreen to-bushgreen opacity-95 pointer-events-none"></div>

        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 border-b border-white/10 pb-12">
                
                <!-- Brand Column -->
                <div class="space-y-4">
                    <div class="flex items-center gap-3">
                        <div class="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center border border-gold/40">
                            <!-- Custom dynamic logo / fallback -->
                            <?php echo getAppLogoHtml('w-6 h-6 object-contain', 'footer'); ?>
                        </div>
                        <div class="flex flex-col">
                            <span class="text-white font-extrabold tracking-tight font-display text-base">PBAT SMART NATION</span>
                            <span class="text-gold font-bold text-[9px] tracking-widest leading-none">INITIATIVE</span>
                        </div>
                    </div>
                    <p class="text-slate-300 text-xs leading-relaxed max-w-sm">
                        An independent, non-governmental nationwide advocacy and sensitization project focusing on tech empowerment, national digital adaptation, and youth digital capacity scaling.
                    </p>
                    
                    <!-- Social Icons -->
                    <div class="flex items-center gap-3 pt-2">
                        <a href="https://x.com" target="_blank" rel="noopener noreferrer" class="w-8 h-8 rounded-full bg-white/5 border border-white/10 hover:border-gold hover:text-gold flex items-center justify-center transition-colors text-slate-300">
                            <span class="sr-only">Twitter</span>
                            <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 24 24"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>
                        </a>
                        <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer" class="w-8 h-8 rounded-full bg-white/5 border border-white/10 hover:border-gold hover:text-gold flex items-center justify-center transition-colors text-slate-300">
                            <span class="sr-only">LinkedIn</span>
                            <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M16.338 16.338H13.67V12.16c0-.995-.017-2.277-1.387-1.387-1.388 0-1.601 1.086-1.601 2.202v4.363H8.016V8h2.56v1.137h.036c.356-.675 1.227-1.387 2.526-1.387 2.7 0 3.2 1.777 3.2 4.086v4.502zM4.982 6.51c-.856 0-1.547-.69-1.547-1.548 0-.856.691-1.548 1.547-1.548.856 0 1.548.692 1.548 1.548 0 .857-.692 1.548-1.548 1.548zm1.333 9.828H3.65V8h2.665v8.338z" clip-rule="evenodd"/></svg>
                        </a>
                        <a href="https://youtube.com" target="_blank" rel="noopener noreferrer" class="w-8 h-8 rounded-full bg-white/5 border border-white/10 hover:border-gold hover:text-gold flex items-center justify-center transition-colors text-slate-300">
                            <span class="sr-only">YouTube</span>
                            <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 20 20"><path d="M10 2.3c2.7 0 3 .02 4.06.07 1 .04 1.53.2 1.9.35a3.22 3.22 0 011.89 1.9c.15.35.31.9.35 1.9.05 1 .07 1.35.07 4.06s-.02 3-.07 4.06c-.04 1-.2 1.53-.35 1.9a3.22 3.22 0 01-1.9 1.89c-.35.15-.9.31-1.9.35-1 .05-1.35.07-4.06.07s-3-.02-4.06-.07c-1-.04-1.53-.2-1.9-.35a3.22 3.22 0 01-1.89-1.9c-.15-.35-.31-.9-.35-1.9-.05-1-.07-1.35-.07-4.06s.02-3 .07-4.06c.04-1 .2-1.53.35-1.9A3.22 3.22 0 014.3 2.7c.36-.15.9-.31 1.9-.35 1-.05 1.35-.07 4.06-.07zM10 0C7.2 0 6.9.02 5.8.07c-1.1.05-1.87.23-2.53.48a4.93 4.93 0 00-3.1 3.1A20.3 20.3 0 000 10c0 2.7.02 3 .07 4.1.05 1.1.23 1.87.48 2.53a4.93 4.93 0 003.1 3.1c.66.25 1.43.43 2.53.48 1.1.05 1.4.07 4.1.07s3-.02 4.1-.07c1.1-.05 1.87-.23 2.53-.48a4.93 4.93 0 003.1-3.1c.25-.66.43-1.43.48-2.53.05-1.1.07-1.4.07-4.1s-.02-3-.07-4.1c-.05-1.1-.23-1.87-.48-2.53a4.93 4.93 0 00-3.1-3.1C13.1.25 12.3.07 11.2.02 10.1.02 9.8 0 10 0zm0 4.9a5.1 5.1 0 100 10.2 5.1 5.1 0 000-10.2zm0 8.4a3.3 3.3 0 110-6.6 3.3 3.3 0 010 6.6z"/></svg>
                        </a>
                    </div>
                </div>

                <!-- Navigation Quick links -->
                <div class="space-y-4">
                    <h3 class="text-gold font-bold text-sm tracking-wider uppercase">Strategic Index</h3>
                    <ul class="space-y-2.5 text-slate-300 text-xs">
                        <li><a href="about.php" class="hover:text-gold hover:underline transition">Who We Are</a></li>
                        <li><a href="pillars.php" class="hover:text-gold hover:underline transition">Focus & Pillars</a></li>
                        <li><a href="media.php" class="hover:text-gold hover:underline transition">Smart Nation TV / Media</a></li>
                        <li><a href="townhalls.php" class="hover:text-gold hover:underline transition">Upcoming Town Halls</a></li>
                    </ul>
                </div>

                <!-- Portals Column -->
                <div class="space-y-4">
                    <h3 class="text-gold font-bold text-sm tracking-wider uppercase">Ambassador Hub</h3>
                    <ul class="space-y-2.5 text-slate-300 text-xs">
                        <li><a href="login.php" class="hover:text-gold hover:underline transition">Ambassador Portal Login</a></li>
                        <li><a href="register.php" class="hover:text-gold hover:underline transition">Join the Grassroots Network</a></li>
                        <li><a href="forgot-password.php" class="hover:text-gold hover:underline transition">Account Retrieval</a></li>
                        <li>
                            <a href="#ambassador-verification" class="text-emerald-300 font-semibold hover:text-gold flex items-center gap-1">
                                <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/></svg>
                                Verify Ambassador ID
                            </a>
                        </li>
                    </ul>
                </div>

                <!-- Interactive Newsletter Form -->
                <div class="space-y-4" x-data="{ email: '', success: false, loading: false, errorMessage: '' }">
                    <h3 class="text-gold font-bold text-sm tracking-wider uppercase">Stay Updated</h3>
                    <p class="text-slate-300 text-xs leading-relaxed">
                        Subscribe to get updates on national digital skill initiatives, webinars, and tech policy drafts.
                    </p>
                    <form @submit.prevent="
                        loading = true; 
                        errorMessage = '';
                        fetch('api/newsletter.php', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json'
                            },
                            body: JSON.stringify({ email: email })
                        })
                        .then(res => res.json())
                        .then(data => {
                            loading = false;
                            if (data.status === 'success') {
                                success = true;
                                email = '';
                            } else {
                                errorMessage = data.message;
                            }
                        })
                        .catch(err => {
                            loading = false;
                            errorMessage = 'Something went wrong. Please try again.';
                        });
                    " class="space-y-2">
                        <div x-show="!success" class="flex gap-2">
                            <input x-model="email" type="email" placeholder="Enter email address" required
                                   class="bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-xs text-white placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-gold focus:border-gold flex-grow min-w-0 transition-colors">
                            <button type="submit" :disabled="loading" class="bg-gold hover:bg-gold-light text-bushgreen text-xs font-bold px-4 py-2 rounded-lg transition-all flex items-center justify-center flex-shrink-0">
                                <span x-show="!loading">Join</span>
                                <svg x-show="loading" class="animate-spin h-4 w-4 text-bushgreen" fill="none" viewBox="0 0 24 24" style="display: none;">
                                    <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                                    <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                </svg>
                            </button>
                        </div>
                        <template x-if="errorMessage">
                            <div class="text-red-400 text-[10px] font-semibold mt-1" x-text="errorMessage"></div>
                        </template>
                        <div x-show="success" style="display: none;" class="p-2 bg-white/10 border border-white/20 rounded-lg text-gold font-semibold text-[11px] flex items-center gap-1.5 animate-pulse">
                            <svg class="w-4 h-4 text-emerald-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
                            Thank you! You are now subscribed.
                        </div>
                    </form>
                </div>

                <!-- Verification Gateway -->
                <div class="space-y-4" id="ambassador-verification">
                    <span class="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-gold/10 border border-gold/30 text-gold text-[9px] font-bold uppercase tracking-widest">
                        <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/></svg>
                        Verification Gateway
                    </span>
                    <h3 class="text-gold font-bold text-sm tracking-wider uppercase">Ambassador Credential Validation</h3>
                    <p class="text-slate-300 text-xs leading-relaxed">Confirm the identity and valid credentials of any local PBAT Smart Nation representative.</p>
                    <form action="verify.php" method="GET" class="space-y-2">
                        <label class="block text-slate-300 text-[10px] font-semibold" for="footer-uuid">Verify by ID Hash or UUID:</label>
                        <div class="flex gap-2">
                            <input type="text" name="uuid" id="footer-uuid" placeholder="e.g. AMB-6A3B91-3829" required class="bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-xs text-white placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-gold focus:border-gold flex-grow min-w-0 transition-colors font-mono">
                            <button type="submit" class="bg-gold hover:bg-gold-light text-bushgreen text-xs font-bold px-3 py-2 rounded-lg transition-all flex items-center justify-center gap-1 flex-shrink-0">
                                <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/></svg>
                                Verify
                            </button>
                        </div>
                        <p class="text-slate-400 text-[9px] leading-relaxed">Enter the ambassador's unique membership code to validate their credentials.</p>
                    </form>
                </div>
            </div>

            <?php if ($floating_tv_enabled): ?>
            <aside class="floating-tv-card fixed bottom-3 right-3 z-[60] w-[16.66vw] min-w-[14rem] max-w-[17rem] rounded-3xl border border-gold/30 bg-slate-950/95 shadow-2xl shadow-black/30 backdrop-blur-xl overflow-hidden md:bottom-4 md:right-4">
                <button type="button" id="floating-tv-toggle" class="w-full flex items-center justify-between gap-3 rounded-t-3xl bg-gradient-to-r from-gold/20 via-amber-400/10 to-emerald-400/10 px-4 py-3 text-left text-white hover:bg-gold/15 transition" aria-expanded="true" aria-controls="floating-tv-panel">
                    <span class="flex items-center gap-2 text-[11px] font-black uppercase tracking-[0.35em] text-gold">
                        <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z"/></svg>
                        <?php echo htmlspecialchars($floating_tv_title); ?>
                    </span>
                    <span id="floating-tv-label" class="rounded-full bg-white/10 px-2.5 py-1 text-[10px] font-semibold text-slate-200">Hide</span>
                </button>
                <div id="floating-tv-panel" class="space-y-2 p-2.5 sm:space-y-3 sm:p-3">
                    <div class="aspect-video overflow-hidden rounded-2xl border border-white/10 bg-slate-950" style="aspect-ratio: 16 / 10;">
                        <?php if (($footer_featured_video['video_source'] ?? 'youtube') === 'youtube' && !empty($footer_featured_video['youtube_id'])): ?>
                            <iframe class="w-full h-full" src="https://www.youtube.com/embed/<?php echo htmlspecialchars($footer_featured_video['youtube_id']); ?>" title="Smart Nation LIVE tv" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
                        <?php elseif (($footer_featured_video['video_source'] ?? 'youtube') === 'self_hosted' || ($footer_featured_video['video_source'] ?? 'youtube') === 's3' || ($footer_featured_video['video_source'] ?? 'youtube') === 'google_drive'): ?>
                            <?php $footer_video_url = $footer_featured_video['video_url'] ?? ''; if (!preg_match('/^https?:\/\//i', $footer_video_url)) { $footer_video_url = '../' . ltrim($footer_video_url, '/'); } ?>
                            <?php if (($footer_featured_video['video_source'] ?? 'youtube') === 'google_drive'): ?>
                                <iframe class="w-full h-full" src="<?php echo htmlspecialchars($footer_video_url); ?>" title="Smart Nation LIVE tv" allow="autoplay; encrypted-media" allowfullscreen></iframe>
                            <?php else: ?>
                                <video class="w-full h-full" controls preload="metadata"><source src="<?php echo htmlspecialchars($footer_video_url); ?>" type="video/mp4">Your browser does not support the video tag.</video>
                            <?php endif; ?>
                        <?php else: ?>
                            <iframe class="w-full h-full" src="https://www.youtube.com/embed/dQw4w9WgXcQ" title="Smart Nation LIVE tv placeholder" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
                        <?php endif; ?>
                    </div>
                    <div class="space-y-1.5">
                        <h3 class="text-xs font-extrabold text-white font-display leading-tight sm:text-sm"><?php echo htmlspecialchars($floating_tv_title); ?></h3>
                        <p class="text-slate-300 text-[10px] leading-relaxed sm:text-[11px]"><?php echo htmlspecialchars($floating_tv_description); ?></p>
                    </div>
                </div>
            </aside>
            <?php endif; ?>

            <!-- Footer Bottom -->
            <div class="pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
                <p class="text-slate-400 text-xs text-center md:text-left">
                    &copy; 2026 PBAT Smart Nation Initiative. All rights reserved. 
                    <span class="text-[10px] text-slate-505 block md:inline md:ml-2">An independent, non-governmental public awareness & advocacy platform.</span>
                </p>
                <div class="flex gap-6 text-[11px] text-slate-400">
                    <a href="terms.php" class="hover:text-gold transition">Terms & Charter</a>
                    <a href="privacy.php" class="hover:text-gold transition">Privacy Policy</a>
                </div>
            </div>
        </div>
    </footer>

    <style>
        /* Premium Page Burst-In Effect (Scale + Blur + Fade on Load) */
        @keyframes page-burst-in {
            0% {
                opacity: 0;
                transform: scale(0.975);
                filter: blur(4px);
            }
            100% {
                opacity: 1;
                transform: scale(1);
                filter: blur(0);
            }
        }
        body {
            animation: page-burst-in 0.8s cubic-bezier(0.16, 1, 0.3, 1) forwards;
            overflow-x: hidden;
        }

        /* Footer Fly-In Effect (Slide up + Fade) */
        @keyframes footer-fly-in {
            0% {
                transform: translateY(60px);
                opacity: 0;
            }
            100% {
                transform: translateY(0);
                opacity: 1;
            }
        }
        
        /* Initial state before scroll trigger */
        footer.bg-bushgreen {
            opacity: 0;
            transform: translateY(60px);
            transition: opacity 1.2s cubic-bezier(0.16, 1, 0.3, 1), transform 1.2s cubic-bezier(0.16, 1, 0.3, 1);
        }

        footer.bg-bushgreen.footer-flyin {
            opacity: 1;
            transform: translateY(0);
        }

        .floating-tv-card {
            will-change: transform;
            transform: translateZ(0);
        }

        @media (max-width: 640px) {
            .floating-tv-card {
                width: calc(100vw - 0.75rem);
                max-width: 16rem;
                right: 0.375rem;
                bottom: 0.375rem;
            }
        }
    </style>

    <!-- Scroll triggered intersection observer for footer fly-in effect -->
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            const footer = document.querySelector("footer");
            if (footer) {
                const observer = new IntersectionObserver((entries) => {
                    entries.forEach(entry => {
                        if (entry.isIntersecting) {
                            footer.classList.add("footer-flyin");
                            observer.unobserve(footer);
                        }
                    });
                }, { threshold: 0.05 });
                observer.observe(footer);
            }

            const toggle = document.getElementById('floating-tv-toggle');
            const panel = document.getElementById('floating-tv-panel');
            const label = document.getElementById('floating-tv-label');
            if (toggle && panel && label) {
                const key = 'pbatFloatingTvCollapsed';
                const collapsed = localStorage.getItem(key) === '1';
                const applyState = (isCollapsed) => {
                    panel.style.display = isCollapsed ? 'none' : 'block';
                    toggle.setAttribute('aria-expanded', String(!isCollapsed));
                    label.textContent = isCollapsed ? 'Show' : 'Hide';
                };
                applyState(collapsed);
                toggle.addEventListener('click', () => {
                    const next = panel.style.display === 'none';
                    localStorage.setItem(key, next ? '0' : '1');
                    applyState(!next);
                });
            }
        });
    </script>
</body>
</html>
