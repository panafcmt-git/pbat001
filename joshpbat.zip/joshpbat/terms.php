<?php
/**
 * PBAT Smart Nation Initiative - Terms & Charter
 * Dedicated legal and initiative charter page.
 */
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/helpers/auth.php';
require_once __DIR__ . '/helpers/common.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/includes/header.php';
?>

<!-- Hero Header Section -->
<section class="relative bg-bushgreen text-white py-16 overflow-hidden border-b-8 border-gold">
    <div class="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-bushgreen-light/80 via-bushgreen to-bushgreen opacity-95"></div>
    <div class="absolute inset-0 bg-[linear-gradient(to_right,#ffffff05_1px,transparent_1px),linear-gradient(to_bottom,#ffffff05_1px,transparent_1px)] bg-[size:4rem_4rem]"></div>
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
        <span class="text-gold font-bold text-xs uppercase tracking-widest font-display">Governance & Principles</span>
        <h1 class="text-3xl sm:text-4xl md:text-5xl font-black font-display uppercase tracking-tight mt-2">
            Terms & Charter
        </h1>
        <p class="text-slate-355 text-xs sm:text-sm max-w-xl mx-auto font-light mt-3 leading-relaxed">
            The guiding code of conduct, ethics framework, and rules for ambassadors, partners, and community hubs.
        </p>
    </div>
</section>

<!-- Terms Content Section -->
<section class="py-16 bg-slate-50 dark:bg-slate-900/50">
    <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-800 p-6 sm:p-10 shadow-md space-y-8 text-xs sm:text-sm text-slate-655 dark:text-slate-300 leading-relaxed font-light">
            
            <div>
                <h2 class="text-lg font-bold text-bushgreen dark:text-gold font-display uppercase tracking-wider mb-2">1. The Initiative Charter</h2>
                <p>
                    The PBAT Smart Nation Initiative is an independent, non-governmental advocacy and awareness organization. Our primary purpose is to advocate for grassroots digital transition, facilitate basic computer literacy workshops, and establish community coding libraries across Nigerian Local Government Areas (LGAs). All volunteers, coordinators, and ambassadors agree to act in accordance with this core mandate.
                </p>
            </div>

            <div>
                <h2 class="text-lg font-bold text-bushgreen dark:text-gold font-display uppercase tracking-wider mb-2">2. Ambassador Code of Conduct</h2>
                <p>
                    Ambassadors are expected to maintain the highest levels of civic integrity, non-partisanship in community execution, and professional ethics. When operating local training centers or broadband grids:
                </p>
                <ul class="list-disc pl-5 mt-2 space-y-1">
                    <li>Provide free, equal access to all students, regardless of background or affiliation.</li>
                    <li>Protect shared computer hardware, power accessories, and solar arrays.</li>
                    <li>Avoid representing the initiative for unauthorized personal or political fundraising.</li>
                </ul>
            </div>

            <div>
                <h2 class="text-lg font-bold text-bushgreen dark:text-gold font-display uppercase tracking-wider mb-2">3. Limitation of Liability</h2>
                <p>
                    The resources, training modules, and public guides provided on this platform are for educational and sensitization purposes. While we strive to ensure the accuracy of all technical templates, local coordinators implement them at their discretion.
                </p>
            </div>

            <div class="border-t border-slate-100 dark:border-slate-700 pt-6 text-center text-slate-400 text-[11px]">
                Last Updated: June 2026 • PBAT Smart Nation Initiative Directorate
            </div>

        </div>
    </div>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
