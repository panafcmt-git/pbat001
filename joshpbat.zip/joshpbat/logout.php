<?php
/**
 * PBAT Smart Nation Initiative - Secure Logout Session Terminator
 * Clears authentication session values and redirects securely to the login portal.
 */
require_once __DIR__ . '/helpers/auth.php';

Auth::logout();

// Start a fresh session just to hold the feedback notification banner
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$_SESSION['auth_error'] = "You have been successfully logged out of the portal.";

header("Location: login.php");
exit;
