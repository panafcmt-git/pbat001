<?php
/**
 * PBAT Smart Nation Initiative - Database Schema Repair & Migration Utility
 * Safe, idempotent, non-destructive script to add missing tables/columns to an existing database.
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/config/config.php';

$output_logs = [];
$success = true;

try {
    $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
    $pdo = new PDO($dsn, DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_TIMEOUT => 5
    ]);
    
    $output_logs[] = "Successfully connected to database: " . DB_NAME;

    // Helper to check if table exists
    function tableExists($pdo, $table) {
        try {
            $result = $pdo->query("SELECT 1 FROM `{$table}` LIMIT 1");
            return $result !== false;
        } catch (Exception $e) {
            return false;
        }
    }

    // Helper to check if column exists
    function columnExists($pdo, $table, $column) {
        try {
            $stmt = $pdo->prepare("SHOW COLUMNS FROM `{$table}` LIKE ?");
            $stmt->execute([$column]);
            return $stmt->rowCount() > 0;
        } catch (Exception $e) {
            return false;
        }
    }

    // 1. Create Campaigns Table
    if (!tableExists($pdo, 'campaigns')) {
        $pdo->exec("
            CREATE TABLE `campaigns` (
              `id` INT AUTO_INCREMENT PRIMARY KEY,
              `title` VARCHAR(255) NOT NULL,
              `description` TEXT NOT NULL,
              `category` VARCHAR(100) DEFAULT 'General',
              `status` ENUM('draft', 'scheduled', 'active', 'completed') DEFAULT 'draft',
              `scheduled_at` DATETIME DEFAULT NULL,
              `leader_id` INT DEFAULT NULL,
              `created_by` INT NOT NULL,
              `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
              FOREIGN KEY (`leader_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
              FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        $output_logs[] = "Created table: `campaigns`";
    } else {
        $output_logs[] = "Table `campaigns` already exists.";
    }

    // 2. Create Campaign Analytics Table
    if (!tableExists($pdo, 'campaign_analytics')) {
        $pdo->exec("
            CREATE TABLE `campaign_analytics` (
              `id` INT AUTO_INCREMENT PRIMARY KEY,
              `campaign_id` INT NOT NULL,
              `reach_count` INT DEFAULT 0,
              `engagement_rate` FLOAT DEFAULT 0.0,
              `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
              FOREIGN KEY (`campaign_id`) REFERENCES `campaigns` (`id`) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        $output_logs[] = "Created table: `campaign_analytics`";
    } else {
        $output_logs[] = "Table `campaign_analytics` already exists.";
    }

    // 3. Create Permissions Table
    if (!tableExists($pdo, 'permissions')) {
        $pdo->exec("
            CREATE TABLE `permissions` (
              `id` INT AUTO_INCREMENT PRIMARY KEY,
              `name` VARCHAR(100) NOT NULL UNIQUE,
              `display_name` VARCHAR(150) NOT NULL,
              `description` TEXT
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        $output_logs[] = "Created table: `permissions`";
    } else {
        $output_logs[] = "Table `permissions` already exists.";
    }

    // 4. Create Role Permissions Mapping
    if (!tableExists($pdo, 'role_permissions')) {
        $pdo->exec("
            CREATE TABLE `role_permissions` (
              `role_id` INT NOT NULL,
              `permission_id` INT NOT NULL,
              PRIMARY KEY (`role_id`, `permission_id`),
              FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
              FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        $output_logs[] = "Created table: `role_permissions`";
    } else {
        $output_logs[] = "Table `role_permissions` already exists.";
    }

    // 5. Create Login History Table
    if (!tableExists($pdo, 'login_history')) {
        $pdo->exec("
            CREATE TABLE `login_history` (
              `id` INT AUTO_INCREMENT PRIMARY KEY,
              `user_id` INT NOT NULL,
              `ip_address` VARCHAR(45) NOT NULL,
              `device_info` VARCHAR(255) DEFAULT NULL,
              `status` ENUM('success', 'failed') DEFAULT 'success',
              `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
              FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        $output_logs[] = "Created table: `login_history`";
    } else {
        $output_logs[] = "Table `login_history` already exists.";
    }

    // 6. Create Messages Table
    if (!tableExists($pdo, 'messages')) {
        $pdo->exec("
            CREATE TABLE `messages` (
              `id` INT AUTO_INCREMENT PRIMARY KEY,
              `sender_id` INT NOT NULL,
              `recipient_id` INT DEFAULT NULL,
              `channel` VARCHAR(50) DEFAULT 'general',
              `subject` VARCHAR(255) DEFAULT NULL,
              `body` TEXT NOT NULL,
              `is_read` TINYINT(1) DEFAULT 0,
              `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
              FOREIGN KEY (`sender_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
              FOREIGN KEY (`recipient_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        $output_logs[] = "Created table: `messages`";
    } else {
        $output_logs[] = "Table `messages` already exists.";
    }

    // 7. Create System Settings Table
    if (!tableExists($pdo, 'system_settings')) {
        $pdo->exec("
            CREATE TABLE `system_settings` (
              `setting_key` VARCHAR(100) PRIMARY KEY,
              `setting_value` TEXT
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        $output_logs[] = "Created table: `system_settings`";
    } else {
        $output_logs[] = "Table `system_settings` already exists.";
    }

    // 8. Create KYC Extended Table
    if (!tableExists($pdo, 'user_kyc_extended')) {
        $pdo->exec("
            CREATE TABLE `user_kyc_extended` (
              `id` INT AUTO_INCREMENT PRIMARY KEY,
              `user_id` INT NOT NULL UNIQUE,
              `username` VARCHAR(50) DEFAULT NULL,
              `dob` DATE DEFAULT NULL,
              `nationality` VARCHAR(50) DEFAULT 'Nigerian',
              `state_of_origin` VARCHAR(50) DEFAULT NULL,
              `state_of_residence` VARCHAR(50) DEFAULT NULL,
              `whatsapp_number` VARCHAR(30) DEFAULT NULL,
              `telegram_username` VARCHAR(50) DEFAULT NULL,
              `x_handle` VARCHAR(50) DEFAULT NULL,
              `facebook_profile` VARCHAR(255) DEFAULT NULL,
              `instagram_username` VARCHAR(50) DEFAULT NULL,
              `linkedin_profile` VARCHAR(255) DEFAULT NULL,
              `highest_qualification` VARCHAR(100) DEFAULT NULL,
              `institution` VARCHAR(255) DEFAULT NULL,
              `course_of_study` VARCHAR(255) DEFAULT NULL,
              `graduation_year` INT DEFAULT NULL,
              `employer` VARCHAR(255) DEFAULT NULL,
              `industry` VARCHAR(100) DEFAULT NULL,
              `skills_expertise` TEXT DEFAULT NULL,
              `digital_skills_data` TEXT DEFAULT NULL, 
              `tech_interests` TEXT DEFAULT NULL,
              `innovation_interests` TEXT DEFAULT NULL,
              `ai_knowledge_level` VARCHAR(50) DEFAULT NULL,
              `entrepreneurial_interests` TEXT DEFAULT NULL,
              `preferred_training_areas` TEXT DEFAULT NULL,
              `why_join` TEXT DEFAULT NULL,
              `preferred_role` VARCHAR(100) DEFAULT NULL,
              `areas_of_interest` TEXT DEFAULT NULL,
              `volunteer_availability` VARCHAR(100) DEFAULT NULL,
              `outreach_experience` TEXT DEFAULT NULL,
              `leadership_experience` TEXT DEFAULT NULL,
              `community_engagement` TEXT DEFAULT NULL,
              `smart_nation_topics` TEXT DEFAULT NULL,
              `two_factor_enabled` TINYINT(1) DEFAULT 0,
              `security_question` VARCHAR(255) DEFAULT NULL,
              `security_answer_hash` VARCHAR(255) DEFAULT NULL,
              `government_id_path` VARCHAR(255) DEFAULT NULL,
              `selfie_path` VARCHAR(255) DEFAULT NULL,
              `passport_photo_path` VARCHAR(255) DEFAULT NULL,
              `utility_bill_path` VARCHAR(255) DEFAULT NULL,
              `cv_path` VARCHAR(255) DEFAULT NULL,
              `recommendation_letter_path` VARCHAR(255) DEFAULT NULL,
              `proof_of_address_path` VARCHAR(255) DEFAULT NULL,
              `kyc_status` VARCHAR(50) DEFAULT 'pending_review',
              `kyc_status_message` TEXT DEFAULT NULL,
              `face_match_score` DECIMAL(5,2) DEFAULT NULL,
              `digital_signature` TEXT DEFAULT NULL,
              `latitude` DECIMAL(10,8) DEFAULT NULL,
              `longitude` DECIMAL(11,8) DEFAULT NULL,
              `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
              `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
              FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        $output_logs[] = "Created table: `user_kyc_extended`";
    } else {
        $output_logs[] = "Table `user_kyc_extended` already exists.";
    }

    // 9. Create NSC Tasks Table
    if (!tableExists($pdo, 'nsc_tasks')) {
        $pdo->exec("
            CREATE TABLE `nsc_tasks` (
              `id` INT AUTO_INCREMENT PRIMARY KEY,
              `title` VARCHAR(255) NOT NULL,
              `description` TEXT NOT NULL,
              `target_type` ENUM('zone', 'state') NOT NULL,
              `target_name` VARCHAR(100) NOT NULL,
              `deadline` DATE NOT NULL,
              `status` ENUM('pending', 'completed') DEFAULT 'pending',
              `created_by` INT NOT NULL,
              `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
              FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        $output_logs[] = "Created table: `nsc_tasks`";
    } else {
        $output_logs[] = "Table `nsc_tasks` already exists.";
    }

    // 10. Create NSC Polls Table
    if (!tableExists($pdo, 'nsc_polls')) {
        $pdo->exec("
            CREATE TABLE `nsc_polls` (
              `id` INT AUTO_INCREMENT PRIMARY KEY,
              `question` VARCHAR(255) NOT NULL,
              `options_json` TEXT NOT NULL,
              `votes_json` TEXT NOT NULL,
              `status` ENUM('active', 'closed') DEFAULT 'active',
              `created_by` INT NOT NULL,
              `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
              FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        $output_logs[] = "Created table: `nsc_polls`";
    } else {
        $output_logs[] = "Table `nsc_polls` already exists.";
    }

    // 11. Add Missing Columns to users Table
    $users_columns = [
        'address' => "VARCHAR(255) DEFAULT NULL",
        'age' => "INT DEFAULT NULL",
        'gender' => "VARCHAR(20) DEFAULT NULL",
        'occupation' => "VARCHAR(100) DEFAULT NULL",
        'profile_completed' => "TINYINT(1) DEFAULT 0",
        'membership_code' => "VARCHAR(50) DEFAULT NULL",
        'last_reminder_sent' => "TIMESTAMP NULL DEFAULT NULL"
    ];

    foreach ($users_columns as $col => $definition) {
        if (!columnExists($pdo, 'users', $col)) {
            $pdo->exec("ALTER TABLE `users` ADD COLUMN `{$col}` {$definition}");
            $output_logs[] = "Added column `{$col}` to table `users`";
        } else {
            $output_logs[] = "Column `{$col}` already exists on `users` table.";
        }
    }

    // 12. Seed Default Settings, Permissions, and Role Mappings
    // Permissions seeding
    $permissions_seed = [
        [1, 'create_campaign', 'Create Campaigns', 'Allows writing and scheduling regional tech campaigns.'],
        [2, 'approve_report', 'Approve Reports', 'Allows reviewing and verifying activity reports from ambassadors.'],
        [3, 'manage_states', 'Manage States', 'Allows editing regional coordinates and state metrics.'],
        [4, 'view_analytics', 'View Analytics', 'Allows checking comprehensive national participation heatmaps.'],
        [5, 'manage_livestreams', 'Manage Livestreams', 'Allows adding stream countdowns and television links.']
    ];
    $perm_stmt = $pdo->prepare("INSERT IGNORE INTO `permissions` (`id`, `name`, `display_name`, `description`) VALUES (?, ?, ?, ?)");
    foreach ($permissions_seed as $p) {
        $perm_stmt->execute($p);
    }
    $output_logs[] = "Seeded core system permissions.";

    // Role permissions mapping
    $role_perms_seed = [
        [1, 1], [1, 2], [1, 3], [1, 4], [1, 5],
        [2, 1], [2, 2], [2, 4], [2, 5]
    ];
    $rp_stmt = $pdo->prepare("INSERT IGNORE INTO `role_permissions` (`role_id`, `permission_id`) VALUES (?, ?)");
    foreach ($role_perms_seed as $rp) {
        $rp_stmt->execute($rp);
    }
    $output_logs[] = "Mapped default role permissions.";

    // System Settings seeding
    $settings_seed = [
        'site_name' => 'PBAT Smart Nation Initiative',
        'logo_url' => '',
        'theme_primary' => '#063C1E',
        'theme_accent' => '#D4AF37',
        'footer_copyright' => '&copy; 2026 PBAT Smart Nation Initiative. All rights reserved.',
        'contact_email' => 'info@pbat-smartnation.ng',
        'contact_phone' => '+2348030000001'
    ];
    $set_stmt = $pdo->prepare("INSERT IGNORE INTO `system_settings` (`setting_key`, `setting_value`) VALUES (?, ?)");
    foreach ($settings_seed as $key => $val) {
        $set_stmt->execute([$key, $val]);
    }
    $output_logs[] = "Seeded default system configuration settings.";

    // 13. Create Talent Pipeline Table
    if (!tableExists($pdo, 'talent_pipeline')) {
        $pdo->exec("
            CREATE TABLE `talent_pipeline` (
              `id` INT AUTO_INCREMENT PRIMARY KEY,
              `user_id` INT NOT NULL,
              `skill` VARCHAR(100) NOT NULL,
              `role_type` ENUM('trainer', 'trainee') NOT NULL,
              `experience_years` INT DEFAULT 0,
              `additional_notes` TEXT DEFAULT NULL,
              `status` ENUM('pending', 'shortlisted', 'approved', 'rejected') DEFAULT 'pending',
              `moderation_notes` TEXT DEFAULT NULL,
              `moderated_by` INT DEFAULT NULL,
              `moderated_at` TIMESTAMP NULL DEFAULT NULL,
              `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
              `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
              FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
              FOREIGN KEY (`moderated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        $output_logs[] = "Created table: `talent_pipeline`";
    } else {
        $output_logs[] = "Table `talent_pipeline` already exists.";
    }

    // Add missing columns to talent_pipeline table
    $tp_columns = [
        'registration_type' => "VARCHAR(50) DEFAULT 'self'",
        'talent_name' => "VARCHAR(150) DEFAULT NULL",
        'talent_email' => "VARCHAR(100) DEFAULT NULL",
        'talent_phone' => "VARCHAR(20) DEFAULT NULL"
    ];

    foreach ($tp_columns as $col => $definition) {
        if (!columnExists($pdo, 'talent_pipeline', $col)) {
            $pdo->exec("ALTER TABLE `talent_pipeline` ADD COLUMN `{$col}` {$definition}");
            $output_logs[] = "Added column `{$col}` to table `talent_pipeline`";
        } else {
            $output_logs[] = "Column `{$col}` already exists on `talent_pipeline` table.";
        }
    }


    // 14. Create Volunteers Table
    if (!tableExists($pdo, 'volunteers')) {
        $pdo->exec("
            CREATE TABLE `volunteers` (
              `id` INT AUTO_INCREMENT PRIMARY KEY,
              `user_id` INT NOT NULL,
              `volunteer_areas` TEXT NOT NULL,
              `availability` VARCHAR(100) DEFAULT NULL,
              `experience` TEXT DEFAULT NULL,
              `status` ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
              `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
              `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
              FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        $output_logs[] = "Created table: `volunteers`";
    } else {
        $output_logs[] = "Table `volunteers` already exists.";
    }

    // 15. Create Youtube Videos Table
    if (!tableExists($pdo, 'youtube_videos')) {
        $pdo->exec("
            CREATE TABLE `youtube_videos` (
              `id` INT AUTO_INCREMENT PRIMARY KEY,
              `title` VARCHAR(255) NOT NULL,
              `description` TEXT DEFAULT NULL,
              `youtube_id` VARCHAR(100) DEFAULT NULL,
              `video_source` VARCHAR(50) DEFAULT 'youtube',
              `video_url` VARCHAR(255) DEFAULT NULL,
              `duration` VARCHAR(50) DEFAULT NULL,
              `is_featured` TINYINT(1) DEFAULT 0,
              `created_by` INT NOT NULL,
              `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
              FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        $output_logs[] = "Created table: `youtube_videos`";
    } else {
        $output_logs[] = "Table `youtube_videos` already exists.";
    }

    // Alter existing youtube_videos table if columns are missing
    if (tableExists($pdo, 'youtube_videos')) {
        $yt_columns = [
            'video_source' => "VARCHAR(50) DEFAULT 'youtube'",
            'video_url'    => "VARCHAR(255) DEFAULT NULL"
        ];

        foreach ($yt_columns as $col => $definition) {
            if (!columnExists($pdo, 'youtube_videos', $col)) {
                $pdo->exec("ALTER TABLE `youtube_videos` ADD COLUMN `{$col}` {$definition}");
                $output_logs[] = "Added column `{$col}` to table `youtube_videos`";
            } else {
                $output_logs[] = "Column `{$col}` already exists on `youtube_videos` table.";
            }
        }
        
        try {
            $pdo->exec("ALTER TABLE `youtube_videos` MODIFY COLUMN `youtube_id` VARCHAR(100) DEFAULT NULL");
            $output_logs[] = "Modified column `youtube_id` in table `youtube_videos` to be nullable.";
        } catch (Exception $e) {
            $output_logs[] = "Failed to modify column `youtube_id` in `youtube_videos`: " . $e->getMessage();
        }
    }

    // Alter user_kyc_extended table to add passport_photo_path if missing
    if (tableExists($pdo, 'user_kyc_extended')) {
        if (!columnExists($pdo, 'user_kyc_extended', 'passport_photo_path')) {
            $pdo->exec("ALTER TABLE `user_kyc_extended` ADD COLUMN `passport_photo_path` VARCHAR(255) DEFAULT NULL");
            $output_logs[] = "Added column `passport_photo_path` to table `user_kyc_extended`";
        } else {
            $output_logs[] = "Column `passport_photo_path` already exists on `user_kyc_extended` table.";
        }
    }

    // 15b. Create Command Resources Table
    if (!tableExists($pdo, 'command_resources')) {
        $pdo->exec("
            CREATE TABLE `command_resources` (
              `id` INT AUTO_INCREMENT PRIMARY KEY,
              `title` VARCHAR(255) NOT NULL,
              `description` TEXT DEFAULT NULL,
              `file_path` VARCHAR(255) NOT NULL,
              `file_type` VARCHAR(100) NOT NULL,
              `target_role` VARCHAR(50) DEFAULT 'all',
              `uploaded_by` INT NOT NULL,
              `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
              FOREIGN KEY (`uploaded_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        $output_logs[] = "Created table: `command_resources`";
    } else {
        $output_logs[] = "Table `command_resources` already exists.";
    }

    // Seed approved kyc status for mock users 7 and 8 if not already set
    if (tableExists($pdo, 'user_kyc_extended')) {
        $stmt_check = $pdo->prepare("SELECT COUNT(1) FROM `user_kyc_extended` WHERE `user_id` IN (7, 8)");
        $stmt_check->execute();
        if ($stmt_check->fetchColumn() == 0) {
            $pdo->exec("
                INSERT IGNORE INTO `user_kyc_extended` (`user_id`, `kyc_status`, `username`, `dob`, `nationality`, `state_of_origin`, `state_of_residence`) VALUES
                (7, 'approved', 'tunde_coker', '1998-05-15', 'Nigerian', 'Lagos', 'Lagos'),
                (8, 'approved', 'amara_eke', '1999-10-20', 'Nigerian', 'Enugu', 'Lagos')
            ");
            $output_logs[] = "Seeded approved KYC status for default users 7 and 8.";
        }
    }

    // 16. Alter events table to add virtual meeting credentials
    $events_columns = [
        'meeting_platform' => "VARCHAR(50) DEFAULT 'none'",
        'meeting_link'     => "VARCHAR(255) DEFAULT NULL",
        'meeting_id'       => "VARCHAR(100) DEFAULT NULL",
        'meeting_passcode' => "VARCHAR(50) DEFAULT NULL",
        'max_capacity'     => "INT DEFAULT 0"
    ];

    foreach ($events_columns as $col => $definition) {
        if (!columnExists($pdo, 'events', $col)) {
            $pdo->exec("ALTER TABLE `events` ADD COLUMN `{$col}` {$definition}");
            $output_logs[] = "Added column `{$col}` to table `events`";
        } else {
            $output_logs[] = "Column `{$col}` already exists on `events` table.";
        }
    }

    // 17. Create Newsletters Table
    if (!tableExists($pdo, 'newsletters')) {
        $pdo->exec("
            CREATE TABLE `newsletters` (
              `id` INT AUTO_INCREMENT PRIMARY KEY,
              `email` VARCHAR(150) UNIQUE NOT NULL,
              `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        $output_logs[] = "Created table: `newsletters`";
    } else {
        $output_logs[] = "Table `newsletters` already exists.";
    }

    // 18. Create Project Sponsors Table
    if (!tableExists($pdo, 'project_sponsors')) {
        $pdo->exec("
            CREATE TABLE `project_sponsors` (
              `id` INT AUTO_INCREMENT PRIMARY KEY,
              `company_name` VARCHAR(255) NOT NULL,
              `contact_name` VARCHAR(150) NOT NULL,
              `contact_email` VARCHAR(150) NOT NULL,
              `contact_phone` VARCHAR(20) DEFAULT NULL,
              `sponsorship_category` VARCHAR(100) DEFAULT 'General',
              `sponsor_amount` DECIMAL(15,2) DEFAULT 0.00,
              `message` TEXT DEFAULT NULL,
              `status` VARCHAR(50) DEFAULT 'pending',
              `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        $output_logs[] = "Created table: `project_sponsors`";
    } else {
        $output_logs[] = "Table `project_sponsors` already exists.";
    }

    // 19. Create Contact Submissions Table
    if (!tableExists($pdo, 'contact_submissions')) {
        $pdo->exec("
            CREATE TABLE `contact_submissions` (
              `id` INT AUTO_INCREMENT PRIMARY KEY,
              `name` VARCHAR(150) NOT NULL,
              `email` VARCHAR(150) NOT NULL,
              `subject` VARCHAR(255) NOT NULL,
              `message` TEXT NOT NULL,
              `status` VARCHAR(50) DEFAULT 'pending',
              `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        $output_logs[] = "Created table: `contact_submissions`";
    } else {
        $output_logs[] = "Table `contact_submissions` already exists.";
    }

    // 20. Seed New CMS Settings if they don't exist
    if (tableExists($pdo, 'system_settings')) {
        $seeds = [
            // Hero section keys
            'hero_badge' => "Nigeria's Smart Evolution",
            'hero_title' => "PBAT SMART \r\nNATION INITIATIVE",
            'hero_desc' => "An independent, high-impact advocacy platform driving youth tech capacity building, AI sensitization, localized innovation hubs, and community technology leadership templates.",
            'hero_btn1_text' => "JOIN ADVOCATES",
            'hero_btn1_url' => "register.php",
            'hero_btn2_text' => "READ OUR CHARTER",
            'hero_btn2_url' => "#about",
            'hero_image_url' => "uploads/pbat_hero.jpg",
            'hero_patron_name' => "PRESIDENT BOLA AHMED TINUBU",
            'hero_patron_tag' => "Patron",
            'hero_widget_label' => "Digital Literacy Campaign",
            'hero_widget_val' => "36 States + FCT",
            
            // About section keys
            'about_image_url' => "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=500&q=80",
            'about_badge' => "Strategic Mandate",
            'about_heading' => "As an Advocacy Group, our vision is to work with the Presidency, the States, Local Governments, Communities and Private Investors in Empowering Every Citizen Through Digital Excellence.",
            'about_content' => "The PBAT Smart Nation Initiative functions as a catalyst. We are dedicated to ensuring that digital technologies are not localized inside financial hubs alone, but integrated thoroughly into agricultural sectors, state primary education programs, and municipal workflows.",
            'about_val1_title' => "PUBLIC TRUST",
            'about_val1_text' => "Ensuring clear, unbiased, state-level monitoring and performance indexes.",
            'about_val2_title' => "CAPACITY BUILDING",
            'about_val2_text' => "Standardizing coding bootcamps and tech skill classes for local youths.",
            'about_val3_title' => "INCLUSIVE GROWTH",
            'about_val3_text' => "Targeting underserved LGAs and giving direct access to software pathways.",
            
            // Separating Banner keys
            'banner_badge' => "National Core Ideology",
            'banner_title' => "\"BUILDING A SMART, UNITED NIGERIA\"",
            'banner_subtitle' => "Our initiative envisions a tech-driven nation where innovation drives prosperity, administration guarantees seamless transparency, and communities unified through digital access.",
            'banner_btn_text' => "Register as Grassroots Ambassador",
            'banner_btn_url' => "register.php",
            
            // Pillars Section keys
            'pillars_badge' => "Development Pillars",
            'pillars_heading' => "Our Key Pillars",
            'pillars_subtitle' => "Focus areas driving national digital transformation awareness and skills training.",
            'pillars_intro_title' => "Building Nigeria's Digital Future",
            'pillars_intro_desc1' => "The PBAT Smart Nation Initiative is anchored on a vision of technological empowerment, civic transparency, and sustainable development. By dividing our focus into five specialized strategic pillars, we ensure that every community, local business, and public department gets custom advocacy, sensitization, and practical digital training.",
            'pillars_intro_desc2' => "Explore each pillar below to understand how we are coordinating grassroots ambassadors, deploying community coding hubs, advocating for fiber-optic expansion, and promoting telehealth and digital security awareness across Nigeria.",
            
            // "Who We Are" page keys
            'page_about_banner_badge' => "Advocacy Identity",
            'page_about_banner_title' => "Who We Are",
            'page_about_banner_desc' => "Understanding the structural mandate, vision guidelines, and national coordinator network driving inclusive digital evolution.",
            'page_about_vision_title' => "Our Strategic Vision",
            'page_about_vision_desc' => "To serve as a premier non-governmental technology sensitizer across Nigeria, actively bridging connectivity gaps, fostering data intelligence literacy, and establishing active technology centers within rural local government areas.",
            'page_about_mission_title' => "Our Core Mission",
            'page_about_mission_desc' => "We are structured to design regional educational templates, provision certified digital skill paths for youth organizations, and partner with private capital entities to enable robust, inclusive digital transformations.",
            'page_about_org_title' => "Organizational Structure",
            'page_about_org_desc' => "PBAT Smart Nation operates a disciplined multi-tiered network coordinating digital awareness across geo-political zones.",
            'page_about_charter_title' => "Our Independence Charter",
            'page_about_charter_desc' => "Important Security & Scope Announcement: The PBAT Smart Nation Initiative is a 100% independent, non-governmental public advocacy movement. We function strictly to sensitize citizens on digital policy parameters and empower local youths.",
            
            // "Key Pillars" page keys
            'page_pillars_banner_badge' => "Development Vectors",
            'page_pillars_banner_title' => "Our Key Pillars",
            'page_pillars_banner_desc' => "Exploring the structural parameters driving open administration, cashless trading, and broadband accessibility.",
            'page_pillars_intro_desc1' => "Our Key Pillars represent the core values and strategic focus areas that drive our vision for growth, innovation, and sustainable impact. They serve as the foundation for every initiative, program, and partnership we undertake, ensuring that our efforts remain aligned with our mission to empower people, strengthen communities, and create lasting transformation.",
            'page_pillars_intro_desc2' => "Through these pillars, we are committed to advancing opportunities in education, technology, entrepreneurship, leadership, and social development. Each pillar is carefully designed to address critical challenges, encourage innovation, and promote inclusive progress across different sectors and communities.",
            'page_pillars_intro_desc3' => "We believe that meaningful development is achieved through collaboration, creativity, and consistent investment in people and ideas. By focusing on these essential areas, we create pathways for individuals and organizations to grow, thrive, and contribute positively to society.",
            'page_pillars_intro_desc4' => "Our Key Pillars are more than just areas of focus — they are a reflection of our commitment to building a future driven by knowledge, empowerment, sustainability, and measurable impact. Together, they guide our journey toward creating innovative solutions and transformative opportunities for generations to come.",
            
            // "Courses" Academy page keys
            'page_courses_banner_badge' => "Smart Academy",
            'page_courses_banner_title' => "Digital Skills & Innovation",
            'page_courses_banner_desc' => "Free verified courses and educational pathways created to sensitize Nigerian youths and local representatives on emerging technologies, smart city developments, and AI solutions.",
            'system_version' => '1.0.0',
            's3_enabled' => '0',
            's3_bucket' => '',
            's3_region' => 'us-east-1',
            's3_key' => '',
            's3_secret' => ''
        ];
        
        $stmt_check = $pdo->prepare("SELECT COUNT(1) FROM `system_settings` WHERE `setting_key` = ?");
        $stmt_insert = $pdo->prepare("INSERT INTO `system_settings` (`setting_key`, `setting_value`) VALUES (?, ?)");
        
        $inserted_count = 0;
        foreach ($seeds as $key => $val) {
            $stmt_check->execute([$key]);
            if ($stmt_check->fetchColumn() == 0) {
                $stmt_insert->execute([$key, $val]);
                $inserted_count++;
            }
        }
        if ($inserted_count > 0) {
            $output_logs[] = "Seeded {$inserted_count} default settings for Homepage and Sub-pages CMS.";
        } else {
            $output_logs[] = "CMS settings seeds already exist in `system_settings` table.";
        }
    }

    // 21. Add is_approved column to blog_posts table to allow approval moderation
    if (tableExists($pdo, 'blog_posts')) {
        if (!columnExists($pdo, 'blog_posts', 'is_approved')) {
            $pdo->exec("ALTER TABLE `blog_posts` ADD COLUMN `is_approved` TINYINT(1) NOT NULL DEFAULT 1");
            $output_logs[] = "Added column `is_approved` to table `blog_posts` (defaulted to 1 to auto-approve existing posts).";
        } else {
            $output_logs[] = "Column `is_approved` already exists on `blog_posts` table.";
        }
    }


} catch (Exception $e) {
    $success = false;
    $output_logs[] = "Error running migrations: " . $e->getMessage();
}

// If accessed directly from browser, render nice diagnostic page
if (php_sapi_name() !== 'cli') {
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Database Repair Wizard - PBAT Smart Nation</title>
        <script src="https://cdn.tailwindcss.com"></script>
        <script>
            tailwind.config = {
                theme: {
                    extend: {
                        colors: {
                            bushgreen: '#063C1E',
                            gold: '#D4AF37'
                        }
                    }
                }
            }
        </script>
        <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;600;700&display=swap" rel="stylesheet">
        <style>
            body { font-family: 'Outfit', sans-serif; }
        </style>
    </head>
    <body class="bg-slate-50 min-h-screen flex items-center justify-center p-4">
        <div class="max-w-2xl w-full bg-white rounded-3xl shadow-xl border border-slate-100 overflow-hidden my-8">
            <div class="bg-bushgreen p-8 text-center relative overflow-hidden">
                <div class="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-emerald-800/50 via-bushgreen to-bushgreen opacity-95"></div>
                <div class="relative z-10">
                    <h1 class="text-white text-2xl font-bold tracking-tight">Database Schema Repair & Migration</h1>
                    <p class="text-gold text-xs uppercase tracking-widest mt-1">Non-Destructive Database Alignment Tool</p>
                </div>
            </div>
            
            <div class="p-8 space-y-6">
                <?php if ($success): ?>
                    <div class="p-4 bg-emerald-50 border-l-4 border-emerald-500 rounded-r-xl text-emerald-800 flex items-center gap-2">
                        <svg class="w-5 h-5 text-emerald-500 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/></svg>
                        <span class="text-sm font-bold">Database Repair Completed Successfully!</span>
                    </div>
                <?php else: ?>
                    <div class="p-4 bg-red-50 border-l-4 border-red-500 rounded-r-xl text-red-800 flex items-center gap-2">
                        <svg class="w-5 h-5 text-red-500 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clip-rule="evenodd"/></svg>
                        <span class="text-sm font-bold">Database Repair Encountered Failures</span>
                    </div>
                <?php endif; ?>

                <div class="bg-slate-900 rounded-2xl p-6 text-xs text-slate-300 font-mono space-y-2 h-80 overflow-y-auto shadow-inner border border-slate-950">
                    <?php foreach ($output_logs as $log): ?>
                        <div class="border-b border-slate-800 pb-1 last:border-0"><?php echo htmlspecialchars($log); ?></div>
                    <?php endforeach; ?>
                </div>

                <div class="flex justify-end pt-4 border-t border-slate-100">
                    <a href="admin/dashboard.php" class="py-2.5 px-6 bg-bushgreen hover:bg-emerald-800 text-white rounded-xl text-xs font-bold transition shadow">
                        Back to Admin Dashboard
                    </a>
                </div>
            </div>
        </div>
    </body>
    </html>
    <?php
} else {
    // CLI execution
    echo "========================================\n";
    echo "DATABASE MIGRATION & REPAIR RESULTS:\n";
    echo "========================================\n";
    foreach ($output_logs as $log) {
        echo $log . "\n";
    }
    echo "========================================\n";
    if ($success) {
        echo "SUCCESS: Database aligned.\n";
    } else {
        echo "ERROR: Migration runner failed.\n";
    }
}
