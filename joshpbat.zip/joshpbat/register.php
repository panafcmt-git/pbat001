<?php
/**
 * PBAT Smart Nation Initiative - Grassroots Ambassador Registration
 * Beautiful dynamic cascading form for State & LGA selection.
 */
require_once __DIR__ . '/helpers/auth.php';
require_once __DIR__ . '/helpers/common.php';
require_once __DIR__ . '/helpers/notifications.php';
require_once __DIR__ . '/config/database.php';

if (Auth::isLoggedIn()) {
    header("Location: admin/dashboard.php");
    exit;
}

$error = '';
$success = '';

// Load states and LGAs from the database
$states = [];
$lgas_by_state = [];
$state_zones = [];

try {
    $db = Database::connect();
    
    // Fetch States
    $stmt = $db->query("SELECT * FROM `states` ORDER BY `name` ASC");
    $states = $stmt->fetchAll();
    
    foreach ($states as $s) {
        $state_zones[$s['id']] = $s['zone'];
    }
    
    // Fetch LGAs
    $stmt = $db->query("SELECT * FROM `lgas` ORDER BY `name` ASC");
    $all_lgas = $stmt->fetchAll();
    
    foreach ($all_lgas as $lga) {
        $lgas_by_state[$lga['state_id']][] = [
            'id' => (int)$lga['id'],
            'name' => $lga['name']
        ];
    }
} catch (Exception $e) {
    // Elegant fallback data if database isn't fully set up or has missing tables
    // Read from the JSON file to populate all 36 states + FCT and their LGAs dynamically
    $json_file = __DIR__ . '/database/lgas-with-wards.json';
    $geo_data = [];
    if (file_exists($json_file)) {
        $geo_data = json_decode(file_get_contents($json_file), true);
    }
    
    $zone_mapping = [
        'Abia' => 'South-East', 'Adamawa' => 'North-East', 'Akwa Ibom' => 'South-South',
        'Anambra' => 'South-East', 'Bauchi' => 'North-East', 'Bayelsa' => 'South-South',
        'Benue' => 'North-Central', 'Borno' => 'North-East', 'Cross River' => 'South-South',
        'Delta' => 'South-South', 'Ebonyi' => 'South-East', 'Edo' => 'South-South',
        'Ekiti' => 'South-West', 'Enugu' => 'South-East', 'Federal Capital Territory' => 'North-Central',
        'Gombe' => 'North-East', 'Imo' => 'South-East', 'Jigawa' => 'North-West',
        'Kaduna' => 'North-West', 'Kano' => 'North-West', 'Katsina' => 'North-West',
        'Kebbi' => 'North-West', 'Kogi' => 'North-Central', 'Kwara' => 'North-Central',
        'Lagos' => 'South-West', 'Nasarawa' => 'North-Central', 'Niger' => 'North-Central',
        'Ogun' => 'South-West', 'Ondo' => 'South-West', 'Osun' => 'South-West',
        'Oyo' => 'South-West', 'Plateau' => 'North-Central', 'Rivers' => 'South-South',
        'Sokoto' => 'North-West', 'Taraba' => 'North-East', 'Yobe' => 'North-East',
        'Zamfara' => 'North-West'
    ];

    $states = [];
    $state_zones = [];
    $lgas_by_state = [];
    
    if (is_array($geo_data) && !empty($geo_data)) {
        $idx = 1;
        foreach ($geo_data as $state_name => $lgas) {
            $states[] = ['id' => $idx, 'name' => $state_name];
            $state_zones[$idx] = $zone_mapping[$state_name] ?? 'Unmapped';
            
            $lga_idx = 1;
            foreach ($lgas as $lga_name => $wards) {
                $lgas_by_state[$idx][] = [
                    'id' => $lga_idx,
                    'name' => $lga_name
                ];
                $lga_idx++;
            }
            $idx++;
        }
    } else {
        $states = [
            ['id' => 1, 'name' => 'Lagos'],
            ['id' => 2, 'name' => 'Federal Capital Territory'],
            ['id' => 3, 'name' => 'Rivers'],
            ['id' => 4, 'name' => 'Kano']
        ];
        $state_zones = [
            1 => 'South-West',
            2 => 'North-Central',
            3 => 'South-South',
            4 => 'North-West'
        ];
        $lgas_by_state = [
            1 => [
                ['id' => 1, 'name' => 'Ikeja'],
                ['id' => 2, 'name' => 'Alimosho'],
                ['id' => 3, 'name' => 'Lagos Island'],
                ['id' => 4, 'name' => 'Epe']
            ],
            2 => [
                ['id' => 5, 'name' => 'Municipal Area Council (AMAC)'],
                ['id' => 6, 'name' => 'Bwari'],
                ['id' => 7, 'name' => 'Gwagwalada']
            ],
            3 => [
                ['id' => 8, 'name' => 'Port Harcourt'],
                ['id' => 9, 'name' => 'Obio-Akpor'],
                ['id' => 10, 'name' => 'Eleme']
            ],
            4 => [
                ['id' => 11, 'name' => 'Kano Municipal'],
                ['id' => 12, 'name' => 'Fagge'],
                ['id' => 13, 'name' => 'Gwale']
            ]
        ];
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!Auth::validateCsrf($_POST['csrf_token'] ?? '')) {
        $error = "Security validation expired. Please refresh and try again.";
    } else {
        $name = trim($_POST['name']);
        $email = trim($_POST['email']);
        $phone = trim($_POST['phone']);
        $password = $_POST['password'];
        $state_id = (int)($_POST['state'] ?? 0);
        $lga_id = (int)($_POST['lga'] ?? 0);
        $ward_id = (int)($_POST['ward'] ?? 0);
        $bio = trim($_POST['bio'] ?? '');

        if (empty($name) || empty($email) || empty($password) || empty($state_id) || empty($lga_id) || empty($ward_id)) {
            $error = "Please fill in all required fields.";
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = "Invalid email formatting.";
        } else {
            try {
                $db = Database::connect();
                
                // Check if user already exists
                $stmt = $db->prepare("SELECT `id` FROM `users` WHERE `email` = ? LIMIT 1");
                $stmt->execute([$email]);
                if ($stmt->fetch()) {
                    $error = "An account with this email address already exists.";
                } else {
                    $db->beginTransaction();
                    
                    // 1. Insert into users (role_id = 7 for Grassroots Ambassador)
                    $hashed_pass = password_hash($password, PASSWORD_BCRYPT);
                    $email_token = bin2hex(random_bytes(32));
                    $stmt = $db->prepare("INSERT INTO `users` (`name`, `email`, `password`, `role_id`, `phone`, `status`, `email_verified`, `email_token`) VALUES (?, ?, ?, 7, ?, 'pending', 0, ?)");
                    $stmt->execute([$name, $email, $hashed_pass, $phone, $email_token]);
                    $user_id = $db->lastInsertId();

                    // 2. Generate unique credential properties
                    $uuid = generateUuid('AMB-');
                    $qr_hash = hash('sha256', $uuid . time());

                    // 3. Insert into ambassadors
                    $stmt = $db->prepare("INSERT INTO `ambassadors` (`user_id`, `uuid`, `bio`, `state_id`, `lga_id`, `ward_id`, `impact_score`, `qr_code_hash`, `is_verified`) VALUES (?, ?, ?, ?, ?, ?, 10, ?, 1)");
                    $stmt->execute([$user_id, $uuid, $bio, $state_id, $lga_id, $ward_id, $qr_hash]);

                    // 3.5 Dispatch colorful HTML email verification notification
                    $http_host = $_SERVER['HTTP_HOST'] ?? 'localhost';
                    $verify_link = "http://{$http_host}" . dirname($_SERVER['PHP_SELF']) . "/verify-email.php?token=" . $email_token;
                    NotificationEmail::sendOnboardingVerification($email, $name, $verify_link);

                    // 4. Log actions
                    Auth::logAction($user_id, 'USER_REGISTER', 'Self registered as a pending Grassroots Ambassador.');

                    $db->commit();
                    
                    $_SESSION['success_msg'] = "Registration completed successfully! Please check your email inbox to verify your account.";
                    header("Location: onboard.php?email=" . urlencode($email));
                    exit;
                }
            } catch (Exception $e) {
                if (isset($db) && $db->inTransaction()) {
                    $db->rollBack();
                }
                $error = "System Database Error: " . $e->getMessage();
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Become Ambassador - PBAT Smart Nation</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        bushgreen: {
                            DEFAULT: '#063C1E',
                            light: '#0A4D27',
                            dark: '#03200F',
                        },
                        gold: '#D4AF37'
                    }
                }
            }
        }
    </script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700&display=swap" rel="stylesheet">
    <!-- Alpine.js for interactive dynamic select dropdowns -->
    <script src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js" defer></script>
    <style>
        body { font-family: 'Outfit', sans-serif; }
    </style>
</head>
<body class="bg-slate-50 min-h-screen flex items-center justify-center p-4 relative overflow-hidden">
    <!-- Visual background glows -->
    <div class="absolute w-[500px] h-[500px] bg-bushgreen/10 rounded-full blur-[100px] -top-40 -left-40 pointer-events-none"></div>
    <div class="absolute w-[500px] h-[500px] bg-gold/5 rounded-full blur-[100px] -bottom-40 -right-40 pointer-events-none"></div>

    <div class="max-w-xl w-full bg-white rounded-3xl shadow-2xl overflow-hidden border border-slate-100 relative z-10 my-8">
        
        <!-- Curved Banner -->
        <div class="bg-bushgreen p-8 text-center relative overflow-hidden">
            <div class="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-emerald-800/50 via-bushgreen to-bushgreen opacity-95"></div>
            <div class="relative z-10 space-y-2">
                <a href="index.php" class="inline-block">
                    <div class="w-12 h-12 bg-white/10 rounded-xl flex items-center justify-center mx-auto border border-white/20 hover:scale-105 transition">
                        <svg class="w-6 h-6 text-gold" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z"/>
                        </svg>
                    </div>
                </a>
                <h1 class="text-white text-xl font-bold tracking-tight">Become an Advocacy Ambassador</h1>
                <p class="text-gold/90 text-xs uppercase tracking-widest font-semibold">Join PBAT Smart Nation Network</p>
            </div>
        </div>

        <div class="p-8">
            <!-- Alerts -->
            <?php if (!empty($error)): ?>
                <div class="mb-5 p-3.5 bg-red-50 border-l-4 border-red-500 rounded-r-lg text-xs text-red-700 font-semibold flex items-center gap-2">
                    <svg class="w-4 h-4 text-red-500 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clip-rule="evenodd"/></svg>
                    <?php echo $error; ?>
                </div>
            <?php endif; ?>

            <form method="POST" action="" class="space-y-5">
                <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">

                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label class="block text-slate-700 text-xs font-semibold mb-1.5" for="name">Full Official Name *</label>
                        <input type="text" name="name" id="name" required placeholder="e.g. Kolawole Davies"
                               class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 focus:outline-none focus:ring-2 focus:ring-bushgreen/20 focus:border-bushgreen transition text-xs">
                    </div>
                    <div>
                        <label class="block text-slate-700 text-xs font-semibold mb-1.5" for="email">Email Address *</label>
                        <input type="email" name="email" id="email" required placeholder="e.g. user@gmail.com"
                               class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 focus:outline-none focus:ring-2 focus:ring-bushgreen/20 focus:border-bushgreen transition text-xs">
                    </div>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label class="block text-slate-700 text-xs font-semibold mb-1.5" for="phone">Phone Number *</label>
                        <input type="text" name="phone" id="phone" required placeholder="e.g. +234805..."
                               class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 focus:outline-none focus:ring-2 focus:ring-bushgreen/20 focus:border-bushgreen transition text-xs font-mono">
                    </div>
                    <div>
                        <label class="block text-slate-700 text-xs font-semibold mb-1.5" for="password">Account Password *</label>
                        <input type="password" name="password" id="password" required placeholder="Create key passcode"
                               class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 focus:outline-none focus:ring-2 focus:ring-bushgreen/20 focus:border-bushgreen transition text-xs">
                    </div>
                </div>

                <!-- Dynamic Cascading State, LGA & Ward Dropdowns -->
                <div class="space-y-5" x-data="{ 
                    selectedState: '',
                    selectedLga: '',
                    selectedWard: '',
                    lgas: <?php echo htmlspecialchars(json_encode($lgas_by_state), ENT_QUOTES, 'UTF-8'); ?>,
                    stateZones: <?php echo htmlspecialchars(json_encode($state_zones), ENT_QUOTES, 'UTF-8'); ?>,
                    wards: [],
                    loadingWards: false,
                    fetchWards() {
                        if (!this.selectedLga) {
                            this.wards = [];
                            this.selectedWard = '';
                            return;
                        }
                        this.loadingWards = true;
                        this.selectedWard = '';
                        fetch('api/wards.php?lga_id=' + this.selectedLga)
                            .then(res => res.json())
                            .then(data => {
                                this.wards = data;
                                this.loadingWards = false;
                            })
                            .catch(err => {
                                console.error('Error fetching wards:', err);
                                this.loadingWards = false;
                            });
                    }
                }">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-slate-700 text-xs font-semibold mb-1.5" for="state">State of Assignment *</label>
                            <select name="state" id="state" required x-model="selectedState" @change="selectedLga = ''; wards = []; selectedWard = '';"
                                    class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 focus:outline-none focus:ring-2 focus:ring-bushgreen/20 focus:border-bushgreen transition text-xs">
                                <option value="">-- Choose State --</option>
                                <?php foreach ($states as $state): ?>
                                    <option value="<?php echo $state['id']; ?>"><?php echo htmlspecialchars($state['name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div>
                            <label class="block text-slate-700 text-xs font-semibold mb-1.5" for="lga">LGA representing *</label>
                            <select name="lga" id="lga" required x-model="selectedLga" @change="fetchWards()"
                                    class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 focus:outline-none focus:ring-2 focus:ring-bushgreen/20 focus:border-bushgreen transition text-xs">
                                <option value="">-- Choose LGA --</option>
                                <template x-if="selectedState && lgas[selectedState]">
                                    <template x-for="lga in lgas[selectedState]" :key="lga.id">
                                        <option :value="lga.id" x-text="lga.name"></option>
                                    </template>
                                </template>
                            </select>
                        </div>
                    </div>

                    <!-- Geopolitical Zone Badge -->
                    <template x-if="selectedState && stateZones[selectedState]">
                        <div class="p-3 bg-bushgreen/5 border border-bushgreen/10 rounded-2xl text-[11px] text-bushgreen font-semibold flex items-center gap-2 animate-[fadeIn_0.3s_ease] transition-all text-left">
                            <svg class="w-4 h-4 text-gold flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7"/></svg>
                            <span>Representing Geopolitical Zone: <strong class="font-bold text-gold uppercase tracking-wider" x-text="stateZones[selectedState]"></strong></span>
                        </div>
                    </template>

                    <div>
                        <label class="block text-slate-700 text-xs font-semibold mb-1.5" for="ward">Ward Operating Level *</label>
                        <div class="relative">
                            <select name="ward" id="ward" required x-model="selectedWard" :disabled="loadingWards || !selectedLga"
                                    class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 focus:outline-none focus:ring-2 focus:ring-bushgreen/20 focus:border-bushgreen transition text-xs disabled:opacity-60">
                                <option value="">-- Choose Ward --</option>
                                <template x-for="ward in wards" :key="ward.id">
                                    <option :value="ward.id" x-text="ward.name"></option>
                                </template>
                            </select>
                            <div x-show="loadingWards" class="absolute right-3 top-2.5 flex items-center gap-1.5 text-[10px] text-slate-400 font-medium bg-white px-2 py-0.5 rounded border border-slate-100 shadow-sm">
                                <span class="w-1.5 h-1.5 rounded-full bg-gold animate-ping"></span>
                                <span>fetching...</span>
                            </div>
                        </div>
                    </div>
                </div>

                <div>
                    <label class="block text-slate-700 text-xs font-semibold mb-1.5" for="bio">Short Brief Bio / Intent *</label>
                    <textarea name="bio" id="bio" rows="3" placeholder="Brief statement about your advocacy plans..."
                              class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 focus:outline-none focus:ring-2 focus:ring-bushgreen/20 focus:border-bushgreen transition text-xs"></textarea>
                </div>

                <div class="pt-4 border-t border-slate-100 flex flex-col gap-4">
                    <button type="submit" class="w-full py-3 bg-bushgreen hover:bg-bushgreen-light text-white font-bold rounded-xl text-xs shadow-md shadow-bushgreen/10 transition-all flex items-center justify-center gap-1.5 hover:scale-105">
                        <svg class="w-4 h-4 text-gold" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                        REGISTER AS ADVOCATE
                    </button>
                    
                    <a href="login.php" class="text-center text-xs text-slate-500 hover:text-bushgreen">Already an ambassador? <strong class="font-bold">Log in instead</strong></a>
                </div>
            </form>
        </div>
    </div>
</body>
</html>
