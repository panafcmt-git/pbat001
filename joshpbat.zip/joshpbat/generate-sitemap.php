<?php
/**
 * PBAT Smart Nation Initiative - Dynamic Sitemap Generator
 * Compiles all static pathways, published blog articles, and townhall events
 * into a production-grade sitemap.xml.
 */

// Disable direct browser rendering limits if run via server
ini_set('max_execution_time', 300);

$baseUrl = 'https://app.pbatsmartnation.org.ng';
$currentDate = date('Y-m-d');

// Static Pages Definition
$staticPages = [
    ['loc' => '/', 'changefreq' => 'daily', 'priority' => '1.00'],
    ['loc' => '/about', 'changefreq' => 'monthly', 'priority' => '0.90'],
    ['loc' => '/pillars', 'changefreq' => 'monthly', 'priority' => '0.80'],
    ['loc' => '/media', 'changefreq' => 'daily', 'priority' => '0.80'],
    ['loc' => '/courses', 'changefreq' => 'weekly', 'priority' => '0.80'],
    ['loc' => '/leadership', 'changefreq' => 'monthly', 'priority' => '0.70'],
    ['loc' => '/ambassadors', 'changefreq' => 'weekly', 'priority' => '0.70'],
    ['loc' => '/townhall', 'changefreq' => 'daily', 'priority' => '0.80'],
    ['loc' => '/sponsors', 'changefreq' => 'monthly', 'priority' => '0.60'],
    ['loc' => '/partner', 'changefreq' => 'monthly', 'priority' => '0.60'],
    ['loc' => '/donate', 'changefreq' => 'monthly', 'priority' => '0.60'],
    ['loc' => '/contact', 'changefreq' => 'monthly', 'priority' => '0.60']
];

$urls = [];

// 1. Process Static URLs
foreach ($staticPages as $page) {
    $urls[] = [
        'loc' => $baseUrl . $page['loc'],
        'lastmod' => $currentDate,
        'changefreq' => $page['changefreq'],
        'priority' => $page['priority']
    ];
}

// Load configurations independently to avoid Database::connect() script termination
$host = '127.0.0.1';
$db_name = 'pbat_smartnation';
$username = 'root';
$password = '';

$config_file = __DIR__ . '/config/config.php';
if (file_exists($config_file)) {
    try {
        @include_once $config_file;
        if (defined('DB_HOST')) $host = DB_HOST;
        if (defined('DB_NAME')) $db_name = DB_NAME;
        if (defined('DB_USER')) $username = DB_USER;
        if (defined('DB_PASS')) $password = DB_PASS;
    } catch (Exception $e) {}
}

// 2. Query and Add Dynamic Blog Posts
try {
    $dsn = "mysql:host={$host};dbname={$db_name};charset=utf8mb4";
    $db = new PDO($dsn, $username, $password, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_TIMEOUT            => 2
    ]);
    
    $stmt = $db->query("SELECT `id`, `updated_at`, `created_at` FROM `blog_posts` WHERE `status` = 'published' AND `is_approved` = 1 ORDER BY `created_at` DESC");
    $posts = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    foreach ($posts as $post) {
        $timestamp = !empty($post['updated_at']) ? $post['updated_at'] : $post['created_at'];
        $lastmod = date('Y-m-d', strtotime($timestamp));
        
        $urls[] = [
            'loc' => $baseUrl . '/article.php?id=' . $post['id'],
            'lastmod' => $lastmod,
            'changefreq' => 'weekly',
            'priority' => '0.75'
        ];
    }
} catch (Exception $e) {
    // If database connection fails, log error and fallback to static paths only
    error_log("SEO Sitemap dynamic articles parsing warning: " . $e->getMessage());
}

// 3. Query and Add Dynamic Events
try {
    if (isset($db)) {
        $stmt = $db->query("SELECT `id`, `created_at` FROM `events` ORDER BY `event_date` DESC");
        $events = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        foreach ($events as $event) {
            $lastmod = date('Y-m-d', strtotime($event['created_at']));
            
            $urls[] = [
                'loc' => $baseUrl . '/townhalls.php',
                'lastmod' => $lastmod,
                'changefreq' => 'daily',
                'priority' => '0.80'
            ];
        }
    }
} catch (Exception $e) {
    error_log("SEO Sitemap dynamic events parsing warning: " . $e->getMessage());
}

// 4. Generate XML output
$xml = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
$xml .= '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";

foreach ($urls as $url) {
    $xml .= "    <url>\n";
    $xml .= "        <loc>" . htmlspecialchars($url['loc']) . "</loc>\n";
    $xml .= "        <lastmod>" . $url['lastmod'] . "</lastmod>\n";
    $xml .= "        <changefreq>" . $url['changefreq'] . "</changefreq>\n";
    $xml .= "        <priority>" . $url['priority'] . "</priority>\n";
    $xml .= "    </url>\n";
}

$xml .= '</urlset>';

// Write XML output to sitemap.xml
$sitemapPath = __DIR__ . '/sitemap.xml';
if (file_put_contents($sitemapPath, $xml) !== false) {
    echo "Sitemap successfully generated at: {$sitemapPath}\n";
    echo "Total links mapped: " . count($urls) . "\n";
} else {
    echo "Error writing sitemap to: {$sitemapPath}\n";
}
