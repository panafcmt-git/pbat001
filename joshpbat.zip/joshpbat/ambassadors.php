<?php
/**
 * PBAT Smart Nation Initiative - Dynamic Grassroots Ambassadors Directory
 * Premium directory page showcasing verified community leaders, LGA coordinators, and grassroots ambassadors.
 */
require_once __DIR__ . '/helpers/seo.php';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/helpers/common.php';

SEO::init([
    'title' => 'Verified Grassroots Ambassadors Directory | PBAT Smart Nation',
    'description' => 'Browse the registry of certified grassroots ambassadors and LGA coordinators leading digital transformation sensitizations across Nigeria.',
    'keywords' => 'Verified Ambassadors Nigeria, LGA Coordinators, Grassroots tech mobilizers, Digital Literacy Advocates, PBAT Smart Nation Directory',
    'breadcrumbs' => [
        ['name' => 'Ambassadors', 'url' => '/ambassadors']
    ]
]);

$ambassadors = [];
$errorMsg = '';

try {
    $db = Database::connect();
    // Retrieve verified ambassadors with their users details, states and LGAs
    $stmt = $db->query("
        SELECT a.*, u.name, u.avatar, s.name as state_name, l.name as lga_name 
        FROM `ambassadors` a
        JOIN `users` u ON a.user_id = u.id
        JOIN `states` s ON a.state_id = s.id
        JOIN `lgas` l ON a.lga_id = l.id
        WHERE a.is_verified = 1
        ORDER BY a.impact_score DESC
        LIMIT 20
    ");
    $ambassadors = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $errorMsg = $e->getMessage();
    // Fallback static profiles if database offline
    $ambassadors = [
        [
            'name' => 'Tunde Coker',
            'avatar' => 'assets/img/default-avatar.png',
            'state_name' => 'Lagos',
            'lga_name' => 'Alimosho',
            'bio' => 'Grassroots digital strategist dedicated to youth tech literacy in Alimosho.',
            'skills' => 'Community Mobilization, Social Media, Web Design',
            'impact_score' => 75
        ],
        [
            'name' => 'Amara Eke',
            'avatar' => 'assets/img/default-avatar.png',
            'state_name' => 'Lagos',
            'lga_name' => 'Ikeja',
            'bio' => 'AI researcher and Smart Tech advocate based in Ikeja.',
            'skills' => 'Data Analysis, Coding, Digital Literacy Advocacy',
            'impact_score' => 120
        ]
    ];
}

require_once __DIR__ . '/includes/header.php';
?>

<!-- Ambassadors Hero Banner -->
<section class="relative bg-bushgreen text-white py-24 overflow-hidden border-b-4 border-gold">
    <div class="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-bushgreen-light/70 via-bushgreen to-bushgreen-dark opacity-95"></div>
    <div class="absolute inset-0 bg-[linear-gradient(to_right,#ffffff02_1px,transparent_1px),linear-gradient(to_bottom,#ffffff02_1px,transparent_1px)] bg-[size:3rem_3rem]"></div>
    
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center space-y-4">
        <span class="text-gold font-bold text-xs uppercase tracking-widest font-display block">Grassroots Mobilizers</span>
        <h1 class="text-4xl sm:text-6xl font-black font-display tracking-tight uppercase">Verified Ambassadors</h1>
        <p class="text-slate-300 text-xs sm:text-base max-w-2xl mx-auto font-light leading-relaxed">
            Meet the active pioneers driving digital education, local sensitizations, and smart network setups inside their respective Local Government Areas.
        </p>
    </div>
</section>

<!-- Ambassadors Grid Directory -->
<section class="py-24 bg-slate-50">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        <div class="max-w-xl text-left space-y-2">
            <span class="text-gold font-bold text-xs uppercase tracking-widest font-display block">Pioneer Registry</span>
            <h2 class="text-3xl font-extrabold text-bushgreen font-display">Active Tech Leaders</h2>
            <p class="text-slate-500 text-sm font-light leading-relaxed">Verified coordinators ranked by their community mobilization merit impact scores.</p>
        </div>

        <!-- Directory Grid -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <?php foreach ($ambassadors as $amb): ?>
                <div class="bg-white rounded-3xl border border-slate-100 shadow-sm p-6 hover:shadow-md hover:border-gold/30 transition duration-300 flex flex-col justify-between">
                    <div class="space-y-4">
                        <!-- Header with avatar and impact badge -->
                        <div class="flex justify-between items-start">
                            <div class="flex items-center gap-3">
                                <img src="<?php echo htmlspecialchars($amb['avatar'] ?? 'assets/img/default-avatar.png'); ?>" alt="<?php echo htmlspecialchars($amb['name']); ?>" class="w-12 h-12 rounded-xl border border-slate-200 object-cover">
                                <div>
                                    <h3 class="font-bold text-slate-800 text-sm font-display"><?php echo htmlspecialchars($amb['name']); ?></h3>
                                    <span class="text-[9px] text-slate-400 font-semibold uppercase tracking-wider block"><?php echo htmlspecialchars($amb['lga_name'] . ', ' . $amb['state_name']); ?></span>
                                </div>
                            </div>
                            <span class="inline-flex items-center gap-1 bg-gold/10 text-gold-dark font-extrabold text-[10px] px-2.5 py-1 rounded-full border border-gold/20 font-display">
                                Score: <?php echo htmlspecialchars($amb['impact_score']); ?>
                            </span>
                        </div>

                        <!-- Bio info -->
                        <p class="text-slate-500 text-xs font-light leading-relaxed line-clamp-3">
                            <?php echo htmlspecialchars($amb['bio'] ?? 'Dedicated member focusing on digital sensitizations and youth training.'); ?>
                        </p>
                    </div>

                    <!-- Foot details -->
                    <div class="pt-4 border-t border-slate-50 mt-4 space-y-2 text-[10px] text-slate-400">
                        <div>
                            <strong>Core Skills:</strong> 
                            <span class="font-light text-slate-600 block truncate mt-0.5"><?php echo htmlspecialchars($amb['skills'] ?? 'Digital Literacy, Community Organizing'); ?></span>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<?php
require_once __DIR__ . '/includes/footer.php';
?>
