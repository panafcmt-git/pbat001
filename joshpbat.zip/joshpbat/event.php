<?php
/**
 * PBAT Smart Nation Initiative - Event Detail Page
 * Shows full event details, meeting information, stream embed, and RSVP functionality.
 */
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/helpers/auth.php';
require_once __DIR__ . '/helpers/common.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$event_id = (int)($_GET['id'] ?? 0);
$rsvp_error = '';
$event = null;
$rsvp_count = 0;
$user_has_rsvped = false;

if ($event_id <= 0) {
    header("Location: townhalls.php");
    exit;
}

// Handle RSVP Form Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'event_rsvp') {
    if (!Auth::isLoggedIn()) {
        header("Location: login.php?redirect=" . urlencode("event.php?id={$event_id}"));
        exit;
    }
    if (!Auth::validateCsrf($_POST['csrf_token'] ?? '')) {
        $rsvp_error = "Security token invalid. Please try again.";
    } else {
        $uid = Auth::user()['id'];
        try {
            $db = Database::connect();
            $check = $db->prepare("SELECT id FROM `event_registrants` WHERE user_id = ? AND event_id = ?");
            $check->execute([$uid, $event_id]);
            if ($check->fetch()) {
                $rsvp_error = "You have already registered for this event.";
            } else {
                $stmt = $db->prepare("INSERT INTO `event_registrants` (event_id, user_id) VALUES (?, ?)");
                $stmt->execute([$event_id, $uid]);
                // Reward ambassador impact points
                $stmt_amb = $db->prepare("SELECT id FROM `ambassadors` WHERE user_id = ?");
                $stmt_amb->execute([$uid]);
                if ($stmt_amb->fetch()) {
                    $db->prepare("UPDATE `ambassadors` SET `impact_score` = `impact_score` + 10 WHERE user_id = ?")->execute([$uid]);
                    Auth::logAction($uid, 'AMBASSADOR_EVENT_RSVP', "Ambassador RSVPed to Event ID {$event_id}");
                    $_SESSION['success_msg'] = "RSVP confirmed! You earned +10 Impact Points.";
                } else {
                    Auth::logAction($uid, 'USER_EVENT_RSVP', "User RSVPed to Event ID {$event_id}");
                    $_SESSION['success_msg'] = "RSVP confirmed! You are registered for this event.";
                }
                header("Location: event.php?id={$event_id}");
                exit;
            }
        } catch (Exception $e) {
            $rsvp_error = "Error recording RSVP. Please try again.";
        }
    }
}

// Fetch event
try {
    $db = Database::connect();
    $stmt = $db->prepare("
        SELECT e.*, u.name as author_name,
               COUNT(r.id) as rsvp_count
        FROM `events` e
        JOIN `users` u ON e.created_by = u.id
        LEFT JOIN `event_registrants` r ON r.event_id = e.id
        WHERE e.id = ?
        GROUP BY e.id
        LIMIT 1
    ");
    $stmt->execute([$event_id]);
    $event = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$event) {
        header("Location: townhalls.php");
        exit;
    }

    $rsvp_count = (int)$event['rsvp_count'];

    // Check if current user has RSVPed
    if (Auth::isLoggedIn()) {
        $uid = Auth::user()['id'];
        $check = $db->prepare("SELECT id FROM `event_registrants` WHERE user_id = ? AND event_id = ?");
        $check->execute([$uid, $event_id]);
        $user_has_rsvped = (bool)$check->fetch();
    }

} catch (Exception $e) {
    // If DB fails, redirect to townhalls
    header("Location: townhalls.php");
    exit;
}

// SEO
require_once __DIR__ . '/helpers/seo.php';
SEO::init([
    'title' => htmlspecialchars($event['title']) . ' | PBAT Smart Nation Events',
    'description' => mb_substr(strip_tags($event['description']), 0, 160),
    'keywords' => 'Town Hall Nigeria, PBAT Smart Nation Event, ' . htmlspecialchars($event['event_type']),
    'breadcrumbs' => [
        ['name' => 'Town Halls', 'url' => '/townhalls.php'],
        ['name' => $event['title'], 'url' => '/event.php?id=' . $event_id]
    ]
]);

require_once __DIR__ . '/includes/header.php';

$event_ts      = strtotime($event['event_date']);
$is_upcoming   = $event_ts > time();
$platform_map  = [
    'zoom'         => ['label' => 'Zoom', 'color' => 'blue'],
    'google_meet'  => ['label' => 'Google Meet', 'color' => 'emerald'],
    'youtube_live' => ['label' => 'YouTube Live', 'color' => 'red'],
    'other'        => ['label' => 'Virtual Platform', 'color' => 'gold'],
];
$platform = $platform_map[$event['meeting_platform'] ?? 'other'] ?? $platform_map['other'];
?>

<!-- Sub-Page Hero Banner -->
<section class="relative bg-bushgreen text-white py-16 sm:py-24 overflow-hidden border-b-4 border-gold">
    <div class="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-bushgreen-light/70 via-bushgreen to-bushgreen-dark opacity-95"></div>
    <div class="absolute inset-0 bg-[linear-gradient(to_right,#ffffff02_1px,transparent_1px),linear-gradient(to_bottom,#ffffff02_1px,transparent_1px)] bg-[size:3rem_3rem]"></div>
    <div class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 space-y-5">
        <!-- Breadcrumb -->
        <nav class="flex items-center gap-2 text-[11px] text-slate-300 font-semibold">
            <a href="index.php" class="hover:text-gold transition">Home</a>
            <span class="text-slate-500">/</span>
            <a href="townhalls.php" class="hover:text-gold transition">Town Halls &amp; Conferences</a>
            <span class="text-slate-500">/</span>
            <span class="text-gold line-clamp-1"><?php echo htmlspecialchars($event['title']); ?></span>
        </nav>

        <!-- Event type badge + date -->
        <div class="flex flex-wrap gap-3 items-center">
            <span class="px-3 py-1 bg-gold/20 border border-gold/40 text-gold text-[10px] font-bold uppercase tracking-widest rounded-full">
                <?php echo htmlspecialchars($event['event_type']); ?>
            </span>
            <?php if ($event['is_virtual']): ?>
            <span class="px-3 py-1 bg-white/10 border border-white/20 text-slate-200 text-[10px] font-bold uppercase tracking-widest rounded-full flex items-center gap-1">
                <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z"/></svg>
                Virtual Event
            </span>
            <?php endif; ?>
            <?php if ($is_upcoming): ?>
            <span class="px-3 py-1 bg-emerald-500/20 border border-emerald-400/40 text-emerald-300 text-[10px] font-bold uppercase tracking-widest rounded-full flex items-center gap-1">
                <span class="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-pulse"></span> Upcoming
            </span>
            <?php else: ?>
            <span class="px-3 py-1 bg-slate-500/20 border border-slate-400/40 text-slate-300 text-[10px] font-bold uppercase tracking-widest rounded-full">Past Event</span>
            <?php endif; ?>
        </div>

        <h1 class="text-2xl sm:text-4xl font-black font-display tracking-tight leading-tight">
            <?php echo htmlspecialchars($event['title']); ?>
        </h1>

        <div class="flex flex-wrap gap-4 text-sm text-slate-300 font-semibold">
            <span class="flex items-center gap-1.5">
                <svg class="w-4 h-4 text-gold flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
                <?php echo date('l, F j, Y', $event_ts); ?>
            </span>
            <span class="flex items-center gap-1.5">
                <svg class="w-4 h-4 text-gold flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                <?php echo date('g:i A', $event_ts); ?> (WAT)
            </span>
            <span class="flex items-center gap-1.5">
                <svg class="w-4 h-4 text-gold flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                <?php echo htmlspecialchars($event['location']); ?>
            </span>
            <span class="flex items-center gap-1.5">
                <svg class="w-4 h-4 text-gold flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                <?php echo $rsvp_count; ?> registered<?php echo $event['max_capacity'] > 0 ? ' / ' . (int)$event['max_capacity'] . ' max' : ''; ?>
            </span>
        </div>
    </div>
</section>

<!-- Main Content -->
<section class="py-16 bg-white">
    <div class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-10">

            <!-- Left: Description + Stream -->
            <div class="lg:col-span-2 space-y-8">

                <!-- Success / Error alerts -->
                <?php if (!empty($rsvp_error)): ?>
                <div class="p-4 bg-red-50 border-l-4 border-red-500 text-red-800 rounded-r-xl text-sm font-semibold">
                    <?php echo htmlspecialchars($rsvp_error); ?>
                </div>
                <?php elseif (isset($_SESSION['success_msg'])): ?>
                <div class="p-4 bg-emerald-50 border-l-4 border-emerald-500 text-emerald-800 rounded-r-xl text-sm font-semibold">
                    <?php echo htmlspecialchars($_SESSION['success_msg']); unset($_SESSION['success_msg']); ?>
                </div>
                <?php endif; ?>

                <!-- Description -->
                <div class="space-y-4">
                    <h2 class="text-lg font-extrabold text-bushgreen font-display">About This Event</h2>
                    <p class="text-slate-600 text-sm leading-relaxed"><?php echo nl2br(htmlspecialchars($event['description'])); ?></p>
                </div>

                <!-- Countdown (if upcoming) -->
                <?php if ($is_upcoming): ?>
                <div class="bg-bushgreen/5 border border-bushgreen/15 rounded-2xl p-5 space-y-3"
                     x-data="{
                         target: <?php echo $event_ts * 1000; ?>,
                         d:0, h:0, m:0, s:0,
                         init() { this.tick(); setInterval(() => this.tick(), 1000); },
                         tick() {
                             const diff = this.target - Date.now();
                             if (diff <= 0) { this.d=this.h=this.m=this.s=0; return; }
                             this.d = Math.floor(diff/86400000);
                             this.h = Math.floor((diff%86400000)/3600000);
                             this.m = Math.floor((diff%3600000)/60000);
                             this.s = Math.floor((diff%60000)/1000);
                         }
                     }">
                    <p class="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Event Countdown</p>
                    <div class="grid grid-cols-4 gap-3 text-center">
                        <div class="bg-white rounded-xl p-3 border border-slate-100 shadow-sm">
                            <div class="text-xl font-black text-bushgreen font-mono" x-text="String(d).padStart(2,'0')">00</div>
                            <div class="text-[9px] uppercase font-bold text-slate-400 mt-0.5">Days</div>
                        </div>
                        <div class="bg-white rounded-xl p-3 border border-slate-100 shadow-sm">
                            <div class="text-xl font-black text-bushgreen font-mono" x-text="String(h).padStart(2,'0')">00</div>
                            <div class="text-[9px] uppercase font-bold text-slate-400 mt-0.5">Hours</div>
                        </div>
                        <div class="bg-white rounded-xl p-3 border border-slate-100 shadow-sm">
                            <div class="text-xl font-black text-bushgreen font-mono" x-text="String(m).padStart(2,'0')">00</div>
                            <div class="text-[9px] uppercase font-bold text-slate-400 mt-0.5">Mins</div>
                        </div>
                        <div class="bg-white rounded-xl p-3 border border-slate-100 shadow-sm">
                            <div class="text-xl font-black text-bushgreen font-mono" x-text="String(s).padStart(2,'0')">00</div>
                            <div class="text-[9px] uppercase font-bold text-slate-400 mt-0.5">Secs</div>
                        </div>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Stream Embed (if virtual + stream URL) -->
                <?php if ($event['is_virtual'] && !empty($event['stream_url'])): ?>
                <div class="space-y-3">
                    <h2 class="text-lg font-extrabold text-bushgreen font-display">Live Stream</h2>
                    <div class="aspect-video w-full rounded-2xl overflow-hidden border border-slate-100 shadow-sm bg-slate-950">
                        <iframe class="w-full h-full"
                                src="<?php echo htmlspecialchars($event['stream_url']); ?>"
                                frameborder="0"
                                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                                allowfullscreen>
                        </iframe>
                    </div>
                </div>
                <?php endif; ?>

            </div>

            <!-- Right Sidebar: RSVP + Meeting Info -->
            <div class="space-y-6">

                <!-- RSVP Card -->
                <div class="bg-slate-50 border border-slate-100 rounded-2xl p-6 shadow-sm space-y-4 sticky top-8">
                    <div class="space-y-1">
                        <h3 class="font-extrabold text-bushgreen font-display text-base">Confirm Your Seat</h3>
                        <p class="text-[11px] text-slate-500 font-light">RSVP to reserve your spot and get event reminders.</p>
                    </div>

                    <!-- RSVP counter bar -->
                    <?php if ($event['max_capacity'] > 0): ?>
                    <div class="space-y-1">
                        <div class="flex justify-between text-[10px] text-slate-500 font-semibold">
                            <span><?php echo $rsvp_count; ?> registered</span>
                            <span><?php echo (int)$event['max_capacity']; ?> max</span>
                        </div>
                        <div class="h-1.5 bg-slate-200 rounded-full overflow-hidden">
                            <div class="h-full bg-bushgreen rounded-full transition-all" style="width: <?php echo min(100, round($rsvp_count / $event['max_capacity'] * 100)); ?>%"></div>
                        </div>
                    </div>
                    <?php else: ?>
                    <p class="text-[11px] text-slate-400 font-semibold"><?php echo $rsvp_count; ?> registered &bull; Unlimited capacity</p>
                    <?php endif; ?>

                    <?php if ($user_has_rsvped): ?>
                        <div class="flex items-center gap-2 p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 text-xs font-semibold">
                            <svg class="w-4 h-4 text-emerald-600 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
                            You are registered for this event!
                        </div>
                    <?php elseif ($is_upcoming): ?>
                        <?php if (Auth::isLoggedIn()): ?>
                        <form method="POST" action="">
                            <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                            <input type="hidden" name="action" value="event_rsvp">
                            <input type="hidden" name="event_id" value="<?php echo $event['id']; ?>">
                            <button type="submit" class="w-full py-3 bg-bushgreen hover:bg-bushgreen-light text-white font-bold text-sm rounded-xl shadow-md shadow-bushgreen/20 transition-all hover:scale-[1.02] flex items-center justify-center gap-2">
                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
                                RSVP Attendance
                            </button>
                        </form>
                        <?php else: ?>
                        <a href="login.php?redirect=<?php echo urlencode("event.php?id={$event_id}"); ?>" class="block w-full py-3 bg-bushgreen hover:bg-bushgreen-light text-white font-bold text-sm rounded-xl text-center shadow-md transition">
                            Login to RSVP
                        </a>
                        <?php endif; ?>
                    <?php else: ?>
                        <div class="p-3 bg-slate-100 border border-slate-200 rounded-xl text-slate-500 text-xs font-semibold text-center">
                            This event has already taken place.
                        </div>
                    <?php endif; ?>

                    <!-- Add to Calendar (if upcoming) -->
                    <?php if ($is_upcoming): ?>
                    <a href="https://calendar.google.com/calendar/render?action=TEMPLATE&text=<?php echo urlencode($event['title']); ?>&details=<?php echo urlencode($event['description']); ?>&location=<?php echo urlencode($event['location']); ?>&dates=<?php echo date('Ymd\THis', $event_ts); ?>/<?php echo date('Ymd\THis', $event_ts + 7200); ?>"
                       target="_blank"
                       class="flex items-center justify-center gap-1.5 w-full py-2.5 border border-slate-200 hover:border-gold text-slate-500 hover:text-gold font-semibold text-xs rounded-xl transition">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
                        Add to Google Calendar
                    </a>
                    <?php endif; ?>
                </div>

                <!-- Meeting / Join Info -->
                <?php if ($event['is_virtual'] && !empty($event['meeting_platform']) && $event['meeting_platform'] !== 'none'): ?>
                <div class="bg-white border border-slate-100 rounded-2xl p-5 shadow-sm space-y-4">
                    <h3 class="font-extrabold text-bushgreen font-display text-sm flex items-center gap-2">
                        <svg class="w-4 h-4 text-gold" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z"/></svg>
                        <?php echo $platform['label']; ?> Meeting Info
                    </h3>
                    <div class="space-y-2 text-xs text-slate-600">
                        <?php if (!empty($event['meeting_link'])): ?>
                        <div class="flex flex-col gap-0.5">
                            <span class="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Join Link</span>
                            <a href="<?php echo htmlspecialchars($event['meeting_link']); ?>" target="_blank"
                               class="text-blue-600 hover:text-gold hover:underline break-all font-mono transition">
                                <?php echo htmlspecialchars($event['meeting_link']); ?>
                            </a>
                        </div>
                        <?php endif; ?>
                        <?php if (!empty($event['meeting_id'])): ?>
                        <div class="flex flex-col gap-0.5">
                            <span class="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Meeting ID</span>
                            <span class="font-mono bg-slate-50 border border-slate-100 px-2 py-1 rounded-lg"><?php echo htmlspecialchars($event['meeting_id']); ?></span>
                        </div>
                        <?php endif; ?>
                        <?php if (!empty($event['meeting_passcode'])): ?>
                        <div class="flex flex-col gap-0.5">
                            <span class="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Passcode / PIN</span>
                            <span class="font-mono bg-slate-50 border border-slate-100 px-2 py-1 rounded-lg"><?php echo htmlspecialchars($event['meeting_passcode']); ?></span>
                        </div>
                        <?php endif; ?>
                        <?php if (!empty($event['meeting_link'])): ?>
                        <a href="<?php echo htmlspecialchars($event['meeting_link']); ?>" target="_blank"
                           class="flex items-center justify-center gap-1.5 w-full py-2.5 bg-gold hover:bg-yellow-500 text-bushgreen font-bold rounded-xl text-xs transition mt-2">
                            <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"/></svg>
                            Join Meeting Now
                        </a>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Organiser info -->
                <div class="bg-white border border-slate-100 rounded-2xl p-5 shadow-sm space-y-2">
                    <p class="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Organiser</p>
                    <p class="text-sm font-semibold text-slate-800"><?php echo htmlspecialchars($event['author_name']); ?></p>
                    <p class="text-[11px] text-slate-500">PBAT Smart Nation Initiative</p>
                </div>

                <!-- Back link -->
                <a href="townhalls.php" class="flex items-center gap-1.5 text-slate-500 hover:text-bushgreen font-semibold text-xs transition">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/></svg>
                    Back to all Town Halls
                </a>

            </div>
        </div>
    </div>
</section>

<?php
require_once __DIR__ . '/includes/footer.php';
?>
