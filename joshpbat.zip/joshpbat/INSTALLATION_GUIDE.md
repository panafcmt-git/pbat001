# PBAT Smart Nation Initiative - cPanel Installation Guide

This guide provides step-by-step instructions for deploying and installing the PBAT Smart Nation Initiative application on any standard cPanel web hosting environment.

---

## 📋 System Prerequisites

Before beginning the installation, ensure your cPanel hosting account meets the following requirements:
* **PHP Engine:** Version `8.0` or higher (PHP 8.1 / 8.2 recommended).
* **Database Server:** MySQL `5.7`+ or MariaDB `10.3`+ with InnoDB support.
* **PHP Extensions:** `PDO`, `pdo_mysql`, `mbstring`, `json`, `fileinfo`, `openssl`.
* **Web Server:** Apache with `mod_rewrite` enabled.

---

## 🛠️ Step-by-Step Deployment Procedure

### Step 1: Upload the Application Source Files
1. Log in to your **cPanel Dashboard**.
2. Open the **File Manager** tool.
3. Navigate to the root directory where you want to host the app:
   * Main domain: `/public_html`
   * Subdomain/Addon domain: `/public_html/subfolder` or custom path.
4. Click **Upload** at the top menu and select your application ZIP archive.
5. Once the upload finishes, right-click the uploaded ZIP file in File Manager and select **Extract**.

---

### Step 2: Set Directory Write Permissions
The installer and application require write permissions to specific folders to write configurations and store media uploads:
1. Ensure the following directories exist. If not, the installer will attempt to create them:
   * `/config`
   * `/uploads`
   * `/emails`
2. In File Manager, right-click each of these folders, choose **Change Permissions**, and verify that the permissions are set to **`755`** (or **`777`** if your server requires group write access).
3. If permissions are correct, they will be reported as **Writable** in the requirements check step of the wizard.

---

### Step 3: Create the MySQL Database & User
1. In cPanel, navigate to the **Databases** section and open the **MySQL Database Wizard**.
2. **Step 1: Create a Database:** Enter a database name (e.g. `cpaneluser_pbat`) and click *Next Step*.
3. **Step 2: Create Database Users:** Enter a username (e.g. `cpaneluser_admin`), generate a strong password, and click *Create User*. **Make sure to save this username and password.**
4. **Step 3: Add User to Database:** Check **ALL PRIVILEGES** to grant the user permissions to create tables and modify schema, then click *Make Changes*.

---

### Step 4: Run the Installation Wizard
1. Open your web browser and navigate to:
   ```
   http://yourdomain.com/install.php
   ```
2. **Step 1: Requirements Check:** The wizard will check your PHP version and verify that the `/config`, `/uploads`, and `/emails` directories are writable. Click *Proceed to Setup* once all checks are green (✓).
3. **Step 2: Database Configuration:** Fill in the MySQL Database details:
   * **MySQL Hostname:** Usually `127.0.0.1` or `localhost`.
   * **Database Name:** The exact name created in Step 3 (including prefix, e.g., `cpaneluser_pbat`).
   * **Database Username:** The username created in Step 3 (including prefix, e.g., `cpaneluser_admin`).
   * **Database Password:** The database user password.
4. Click **Build DB & Generate Configs**. The installer will:
   * Establish the database connection.
   * Run the database layout schema from `database/schema.sql`.
   * Automatically import States, LGAs, and Wards data from the packaged `database/lgas-with-wards.json` file.
   * Write the credentials to `config/config.php`.

---

### Step 5: Post-Installation Security Actions
1. **Remove the Installer File:** Once the success screen is displayed, return to your cPanel File Manager and **delete `install.php`** from your root folder. This prevents unauthorized database recreation.
2. **First Log In:** Go to the portal login screen (`http://yourdomain.com/login.php`) and access the panel using the seeded super admin credentials:
   * **Email:** `admin@pbat-smartnation.ng`
   * **Password:** `password123`
3. **Change Default Password:** Once inside the dashboard, navigate to User Profile Settings and immediately change the password to a secure one.
4. **Setup Email SMTP:** Navigate to **System settings Panel** &rarr; **SMTP Gateway Config** and input your cPanel email account credentials (SMTP host, port, username, password) to enable secure transactional welcome notifications.
