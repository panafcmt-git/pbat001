<?php
/**
 * PBAT Smart Nation Initiative - Upcoming Town Halls
 * Granular catalog of virtual webinars, physical workshops, and community sensitization meetings.
 */
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/helpers/auth.php';
require_once __DIR__ . '/helpers/common.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$rsvp_success = '';
$rsvp_error = '';

// Handle RSVP Form Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'townhall_rsvp') {
    if (!Auth::isLoggedIn()) {
        header("Location: login.php");
        exit;
    }
    
    if (!Auth::validateCsrf($_POST['csrf_token'] ?? '')) {
        $rsvp_error = "CSRF Token validation failed.";
    } else {
        $event_id = (int)$_POST['event_id'];
        $user_id = Auth::user()['id'];
        
        try {
            $db = Database::connect();
            // Check if already registered
            $check = $db->prepare("SELECT id FROM `event_registrants` WHERE user_id = ? AND event_id = ?");
            $check->execute([$user_id, $event_id]);
            if ($check->fetch()) {
                $rsvp_error = "You have already registered for this event!";
            } else {
                // Register user
                $stmt = $db->prepare("INSERT INTO `event_registrants` (event_id, user_id) VALUES (?, ?)");
                $stmt->execute([$event_id, $user_id]);
                
                // Reward points
                $stmt_amb = $db->prepare("SELECT id FROM `ambassadors` WHERE user_id = ?");
                $stmt_amb->execute([$user_id]);
                if ($stmt_amb->fetch()) {
                    $db->prepare("UPDATE `ambassadors` SET `impact_score` = `impact_score` + 10 WHERE user_id = ?")->execute([$user_id]);
                    Auth::logAction($user_id, 'AMBASSADOR_EVENT_RSVP', "Ambassador RSVPed to Event ID {$event_id} from town halls page");
                    $_SESSION['success_msg'] = "You have successfully RSVPed and earned +10 Impact Points!";
                } else {
                    $_SESSION['success_msg'] = "You have successfully RSVPed for this event!";
                }
                
                header("Location: townhalls.php");
                exit;
            }
        } catch (Exception $e) {
            $rsvp_error = "Error recording RSVP: " . $e->getMessage();
        }
    }
}

require_once __DIR__ . '/helpers/seo.php';
SEO::init([
    'title' => 'Upcoming Town Halls & Technology Conferences | PBAT Smart Nation',
    'description' => 'Browse upcoming virtual webinars, physical workshops, and civic tech conferences hosted by PBAT Smart Nation Initiative. RSVP to attend.',
    'keywords' => 'Technology Town Halls Nigeria, Digital Transition Conferences, Abuja Tech Webinars, Civic Engagement Workshops',
    'breadcrumbs' => [
        ['name' => 'Town Halls', 'url' => '/townhall']
    ]
]);

require_once __DIR__ . '/includes/header.php';

$events = [];
$user_rsvps = [];

try {
    $db = Database::connect();
    // Fetch upcoming programs
    $stmt = $db->query("SELECT e.*, u.name as author_name FROM `events` e JOIN `users` u ON e.created_by = u.id ORDER BY e.event_date ASC");
    $events = $stmt->fetchAll();

    // Fetch user RSVPs if logged in
    if (Auth::isLoggedIn()) {
        $user_id = Auth::user()['id'];
        $stmt_rsvps = $db->prepare("SELECT event_id FROM `event_registrants` WHERE user_id = ?");
        $stmt_rsvps->execute([$user_id]);
        $user_rsvps = $stmt_rsvps->fetchAll(PDO::FETCH_COLUMN);
    }
} catch (Exception $e) {
    // Fallback if DB offline
    $events = [
        [
            'id' => 1,
            'title' => 'Digital Revolution Town Hall',
            'description' => 'Discussing Smart Governance and local community mobilization through technology.',
            'event_date' => '2026-06-15 14:00:00',
            'location' => 'Interactive Virtual Hub & YouTube Live',
            'event_type' => 'Digital Town Hall',
            'author_name' => 'Hon. Yusuf Bello',
            'is_virtual' => 1,
            'stream_url' => 'https://www.youtube.com/embed/dQw4w9WgXcQ'
        ],
        [
            'id' => 2,
            'title' => 'State Tech Leadership Forum',
            'description' => 'Strategic alignment meeting for state and LGA coordinators across South-West Nigeria.',
            'event_date' => '2026-06-25 10:00:00',
            'location' => 'Ikeja Innovation Hub, Lagos',
            'event_type' => 'Conference',
            'author_name' => 'Engr. Funsho Balogun',
            'is_virtual' => 0,
            'stream_url' => NULL
        ]
    ];
}
?>

<!-- Sub-Page Hero Banner -->
<section class="relative bg-bushgreen text-white py-20 overflow-hidden border-b-4 border-gold">
    <div class="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-bushgreen-light/70 via-bushgreen to-bushgreen-dark opacity-95"></div>
    <div class="absolute inset-0 bg-[linear-gradient(to_right,#ffffff02_1px,transparent_1px),linear-gradient(to_bottom,#ffffff02_1px,transparent_1px)] bg-[size:3rem_3rem]"></div>
    
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center space-y-4">
        <span class="text-gold font-bold text-xs uppercase tracking-widest font-display block">Community Gatherings</span>
        <h1 class="text-3xl sm:text-5xl font-black font-display tracking-tight uppercase">Town Halls & Conferences</h1>
        <p class="text-slate-300 text-xs sm:text-sm max-w-xl mx-auto font-light leading-relaxed">
            Attend regional physical digital workshops or join active webinars scheduled near your local government.
        </p>
    </div>
</section>

<!-- Upcoming Programs List -->
<section class="py-24 bg-white">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        <div class="space-y-2 max-w-xl">
            <span class="text-gold font-bold text-xs uppercase tracking-widest font-display block">Scheduled Assemblies</span>
            <h2 class="text-2xl font-extrabold text-bushgreen font-display">Upcoming Mobilization Programs</h2>
            <p class="text-slate-500 text-xs font-light">RSVP and join interactive sensitization programs to support national tech adaptation.</p>
        </div>

        <!-- Alerts / Feedbacks -->
        <?php if (!empty($rsvp_error)): ?>
            <div class="max-w-md mx-auto p-3 bg-red-50 border border-red-200 text-red-800 text-xs font-semibold rounded-xl text-center">
                <?php echo htmlspecialchars($rsvp_error); ?>
            </div>
        <?php elseif (isset($_SESSION['success_msg'])): ?>
            <div class="max-w-md mx-auto p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-semibold rounded-xl text-center">
                <?php 
                    echo htmlspecialchars($_SESSION['success_msg']); 
                    unset($_SESSION['success_msg']);
                ?>
            </div>
        <?php endif; ?>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
            <?php foreach ($events as $event): ?>
                <div class="bg-slate-50 rounded-3xl p-8 border border-slate-100 shadow-sm hover:shadow-md hover:border-gold hover:ring-1 hover:ring-gold/40 transition-all flex flex-col justify-between space-y-6">
                    <div class="space-y-4">
                        <div class="flex justify-between items-center">
                            <span class="px-2.5 py-1 rounded bg-bushgreen/10 text-bushgreen font-bold text-[9px] uppercase tracking-widest leading-none font-display">
                                <?php echo htmlspecialchars($event['event_type']); ?>
                            </span>
                            <span class="text-xs text-slate-400 font-semibold">
                                <?php echo date('M d, Y @ h:i A', strtotime($event['event_date'])); ?>
                            </span>
                        </div>
                        <h3 class="text-slate-800 font-bold text-lg font-display"><?php echo htmlspecialchars($event['title']); ?></h3>
                        <p class="text-slate-600 text-xs leading-relaxed font-light"><?php echo htmlspecialchars($event['description']); ?></p>
                    </div>

                    <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center pt-6 border-t border-slate-200/60 gap-4">
                        <span class="text-[11px] text-slate-500 font-semibold flex items-center gap-1.5">
                            <svg class="w-4 h-4 text-gold flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                            Venue: <?php echo htmlspecialchars($event['location']); ?>
                        </span>
                        
                        <div class="flex gap-2 flex-wrap">
                            <a href="event.php?id=<?php echo $event['id']; ?>" class="px-4 py-2 border border-bushgreen/30 hover:border-gold text-bushgreen hover:text-gold font-bold text-xs rounded-xl transition inline-flex items-center gap-1">
                                View Details
                                <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"/></svg>
                            </a>
                            <?php if ($event['is_virtual'] && !empty($event['stream_url'])): ?>
                                <a href="media.php" class="px-4 py-2 bg-bushgreen hover:bg-bushgreen-light text-white font-bold text-xs rounded-xl shadow transition">
                                    Watch Stream
                                </a>
                            <?php endif; ?>
                            
                            <?php if (Auth::isLoggedIn()): ?>
                                <?php if (in_array($event['id'], $user_rsvps)): ?>
                                    <span class="px-4 py-2 bg-emerald-50 border border-emerald-200 text-emerald-800 font-bold text-xs rounded-xl flex items-center gap-1">
                                        <svg class="w-3.5 h-3.5 text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
                                        RSVPed
                                    </span>
                                <?php else: ?>
                                    <form method="POST" action="">
                                        <input type="hidden" name="csrf_token" value="<?php echo Auth::csrfToken(); ?>">
                                        <input type="hidden" name="action" value="townhall_rsvp">
                                        <input type="hidden" name="event_id" value="<?php echo $event['id']; ?>">
                                        <button type="submit" class="px-4 py-2 border border-slate-200 hover:border-gold hover:text-gold text-slate-600 font-bold text-xs rounded-xl transition">
                                            RSVP Attendance
                                        </button>
                                    </form>
                                <?php endif; ?>
                            <?php else: ?>
                                <a href="login.php" class="px-4 py-2 border border-slate-200 hover:border-gold hover:text-gold text-slate-600 font-bold text-xs rounded-xl transition">
                                    RSVP Attendance
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<?php
require_once __DIR__ . '/includes/footer.php';
?>
