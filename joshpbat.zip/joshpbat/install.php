<?php
/**
 * PBAT Smart Nation Initiative - Dynamic cPanel Installer Wizard
 * Beautiful, secure, multi-step auto-installer for MySQL, Schema, and Localized Geopolitical Data.
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

$config_file = __DIR__ . '/config/config.php';
$schema_file = __DIR__ . '/database/schema.sql';
$json_file = __DIR__ . '/database/lgas-with-wards.json';

// Automatically attempt to create directories if missing
$required_dirs = [
    'config' => __DIR__ . '/config',
    'uploads' => __DIR__ . '/uploads',
    'emails' => __DIR__ . '/emails'
];

foreach ($required_dirs as $name => $path) {
    if (!is_dir($path)) {
        @mkdir($path, 0755, true);
    }
}

// Check folder write permissions
$permissions = [];
$requirements_passed = true;

// Check PHP version >= 8.0
$php_version = PHP_VERSION;
$php_version_passed = version_compare($php_version, '8.0.0', '>=');
if (!$php_version_passed) {
    $requirements_passed = false;
}

foreach ($required_dirs as $name => $path) {
    $writable = is_writable($path);
    $permissions[$name] = [
        'path' => $path,
        'writable' => $writable,
        'perms' => file_exists($path) ? substr(sprintf('%o', fileperms($path)), -4) : '0000'
    ];
    if (!$writable) {
        $requirements_passed = false;
    }
}

// Check if already installed
$is_installed = false;
if (file_exists($config_file)) {
    require_once $config_file;
    if (defined('DB_HOST') && defined('DB_NAME') && defined('DB_USER') && defined('DB_PASS')) {
        try {
            $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
            $pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_TIMEOUT => 2
            ]);
            $pdo->query("SELECT 1 FROM `users` LIMIT 1");
            $is_installed = true;
        } catch (Exception $e) {
            $is_installed = false; // database is empty or connection changed
        }
    }
}

$error = '';
$success = '';
$current_step = isset($_GET['step']) ? (int)$_GET['step'] : 1;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['install_db'])) {
        $db_host = trim($_POST['db_host']);
        $db_name = trim($_POST['db_name']);
        $db_user = trim($_POST['db_user']);
        $db_pass = $_POST['db_pass'];

        try {
            // 1. Establish MySQL Socket connection
            $dsn = "mysql:host={$db_host};charset=utf8mb4";
            $pdo = new PDO($dsn, $db_user, $db_pass, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_TIMEOUT => 8
            ]);

            // 2. Drop existing database and create fresh schema (cPanel user needs appropriate CREATE/DROP rights)
            $pdo->exec("DROP DATABASE IF EXISTS `{$db_name}`");
            $pdo->exec("CREATE DATABASE `{$db_name}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
            $pdo->exec("USE `{$db_name}`");

            // 3. Read and execute database/schema.sql
            if (!file_exists($schema_file)) {
                throw new Exception("Schema file not found at " . $schema_file);
            }
            $sql = file_get_contents($schema_file);
            
            // Execute batch database statements
            $pdo->exec("SET FOREIGN_KEY_CHECKS = 0");
            $pdo->exec($sql);
            $pdo->exec("SET FOREIGN_KEY_CHECKS = 1");

            // 4. Import Geopolitical Zones, States, LGAs, and Wards from JSON
            if (file_exists($json_file)) {
                set_time_limit(600); // Prevent PHP execution timeout on large inserts
                $geo_data = json_decode(file_get_contents($json_file), true);
                if (is_array($geo_data)) {
                    $zone_mapping = [
                        'Abia' => 'South-East', 'Adamawa' => 'North-East', 'Akwa Ibom' => 'South-South',
                        'Anambra' => 'South-East', 'Bauchi' => 'North-East', 'Bayelsa' => 'South-South',
                        'Benue' => 'North-Central', 'Borno' => 'North-East', 'Cross River' => 'South-South',
                        'Delta' => 'South-South', 'Ebonyi' => 'South-East', 'Edo' => 'South-South',
                        'Ekiti' => 'South-West', 'Enugu' => 'South-East', 'Federal Capital Territory' => 'North-Central',
                        'Gombe' => 'North-East', 'Imo' => 'South-East', 'Jigawa' => 'North-West',
                        'Kaduna' => 'North-West', 'Kano' => 'North-West', 'Katsina' => 'North-West',
                        'Kebbi' => 'North-West', 'Kogi' => 'North-Central', 'Kwara' => 'North-Central',
                        'Lagos' => 'South-West', 'Nasarawa' => 'North-Central', 'Niger' => 'North-Central',
                        'Ogun' => 'South-West', 'Ondo' => 'South-West', 'Osun' => 'South-West',
                        'Oyo' => 'South-West', 'Plateau' => 'North-Central', 'Rivers' => 'South-South',
                        'Sokoto' => 'North-West', 'Taraba' => 'North-East', 'Yobe' => 'North-East',
                        'Zamfara' => 'North-West'
                    ];
                    $state_codes = [
                        'Abia' => 'AB', 'Adamawa' => 'AD', 'Akwa Ibom' => 'AK', 'Anambra' => 'AN', 'Bauchi' => 'BA',
                        'Bayelsa' => 'BY', 'Benue' => 'BE', 'Borno' => 'BO', 'Cross River' => 'CR', 'Delta' => 'DE',
                        'Ebonyi' => 'EB', 'Edo' => 'ED', 'Ekiti' => 'EK', 'Enugu' => 'EN', 'Federal Capital Territory' => 'FCT',
                        'Gombe' => 'GO', 'Imo' => 'IM', 'Jigawa' => 'JI', 'Kaduna' => 'KD', 'Kano' => 'KN',
                        'Katsina' => 'KT', 'Kebbi' => 'KE', 'Kogi' => 'KO', 'Kwara' => 'KW', 'Lagos' => 'LA',
                        'Nasarawa' => 'NA', 'Niger' => 'NI', 'Ogun' => 'OG', 'Ondo' => 'ON', 'Osun' => 'OS',
                        'Oyo' => 'OY', 'Plateau' => 'PL', 'Rivers' => 'RV', 'Sokoto' => 'SO', 'Taraba' => 'TA',
                        'Yobe' => 'YO', 'Zamfara' => 'ZA'
                    ];

                    // First, query currently seeded states to avoid duplication and keep their primary key IDs
                    $stmt = $pdo->query("SELECT `id`, `name` FROM `states`");
                    $existing_states = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
                    $state_ids = array_flip($existing_states);

                    // Seed States
                    $state_insert_stmt = $pdo->prepare("INSERT INTO `states` (`name`, `code`, `zone`) VALUES (?, ?, ?)");
                    foreach ($geo_data as $state_name => $lgas) {
                        if (!isset($state_ids[$state_name])) {
                            $code = $state_codes[$state_name] ?? strtoupper(substr($state_name, 0, 3));
                            $zone = $zone_mapping[$state_name] ?? 'Unmapped';
                            $state_insert_stmt->execute([$state_name, $code, $zone]);
                            $state_ids[$state_name] = $pdo->lastInsertId();
                        }
                    }

                    // Query currently seeded LGAs to prevent duplication and preserve primary keys
                    $stmt = $pdo->query("SELECT `id`, `name`, `state_id` FROM `lgas`");
                    $existing_lgas = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    $lga_id_map = [];
                    foreach ($existing_lgas as $el) {
                        $lga_id_map[$el['state_id']][strtolower(trim($el['name']))] = $el['id'];
                    }

                    // Prepare LGA and Ward statements
                    $lga_insert_stmt = $pdo->prepare("INSERT INTO `lgas` (`state_id`, `name`) VALUES (?, ?)");
                    $ward_insert_stmt = $pdo->prepare("INSERT INTO `wards` (`lga_id`, `name`) VALUES (?, ?)");

                    $pdo->beginTransaction();
                    foreach ($geo_data as $state_name => $lgas) {
                        $state_id = $state_ids[$state_name] ?? null;
                        if (!$state_id) continue;

                        foreach ($lgas as $lga_name => $wards) {
                            $lga_key = strtolower(trim($lga_name));
                            
                            // Insert LGA if it doesn't exist
                            if (!isset($lga_id_map[$state_id][$lga_key])) {
                                $lga_insert_stmt->execute([$state_id, $lga_name]);
                                $lga_id_map[$state_id][$lga_key] = $pdo->lastInsertId();
                            }
                            $lga_id = $lga_id_map[$state_id][$lga_key];

                            if (is_array($wards)) {
                                foreach ($wards as $ward) {
                                    $ward_name = is_array($ward) ? ($ward['name'] ?? '') : $ward;
                                    $ward_name = trim($ward_name);
                                    if ($ward_name !== '') {
                                        $ward_insert_stmt->execute([$lga_id, $ward_name]);
                                    }
                                }
                            }
                        }
                    }
                    $pdo->commit();

                    // Re-link sample ambassadors in user records to their local seeded databases
                    $stmt = $pdo->query("SELECT `id` FROM `wards` WHERE `lga_id` = 1 LIMIT 1");
                    $ikeja_ward_id = $stmt->fetchColumn();
                    if ($ikeja_ward_id) {
                        $pdo->exec("UPDATE `ambassadors` SET `ward_id` = {$ikeja_ward_id} WHERE `id` = 2");
                    }

                    $stmt = $pdo->query("SELECT `id` FROM `wards` WHERE `lga_id` = 2 LIMIT 1");
                    $alimosho_ward_id = $stmt->fetchColumn();
                    if ($alimosho_ward_id) {
                        $pdo->exec("UPDATE `ambassadors` SET `ward_id` = {$alimosho_ward_id} WHERE `id` = 1");
                    }
                }
            }

            // 5. Generate database config.php credentials file
            $config_content = "<?php\n";
            $config_content .= "// PBAT Smart Nation Initiative - Autogenerated DB Config\n";
            $config_content .= "define('DB_HOST', '" . addslashes($db_host) . "');\n";
            $config_content .= "define('DB_NAME', '" . addslashes($db_name) . "');\n";
            $config_content .= "define('DB_USER', '" . addslashes($db_user) . "');\n";
            $config_content .= "define('DB_PASS', '" . addslashes($db_pass) . "');\n";
            
            if (file_put_contents($config_file, $config_content) === false) {
                throw new Exception("Unable to write config/config.php file. Check permissions.");
            }

            $success = "Installer completed schema creation and loaded all geopolitical maps successfully!";
            header("Location: install.php?step=3");
            exit;

        } catch (Exception $e) {
            if (isset($pdo) && $pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $error = "Installer Failed: " . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>cPanel Installer Wizard - PBAT Smart Nation</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        bushgreen: '#063C1E',
                        gold: '#D4AF37'
                    }
                }
            }
        }
    </script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700&display=swap" rel="stylesheet">
    <style>
        html, body {
            margin: 0;
            padding: 0;
            width: 100%;
            height: 100%;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: #f8fafc;
        }
        body { 
            font-family: 'Outfit', sans-serif; 
        }
    </style>
</head>
<body class="bg-slate-50 min-h-screen flex items-center justify-center p-4">
    <div class="max-w-xl w-full bg-white rounded-3xl shadow-2xl overflow-hidden border border-slate-100 my-8">
        
        <!-- Wizard Banner -->
        <div class="bg-bushgreen p-8 text-center relative overflow-hidden">
            <div class="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-emerald-800/50 via-bushgreen to-bushgreen opacity-95"></div>
            <div class="relative z-10">
                <div class="w-14 h-14 bg-white/10 rounded-full flex items-center justify-center mx-auto mb-3 border border-white/20">
                    <svg class="w-6.5 h-6.5 text-gold animate-pulse" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
                    </svg>
                </div>
                <h1 class="text-white text-2xl font-bold tracking-tight">PBAT Smart Nation Initiative</h1>
                <p class="text-gold text-xs font-semibold uppercase tracking-widest mt-1">cPanel Multi-Step Installation Wizard</p>
            </div>
        </div>

        <!-- Wizard Process Tracker Header -->
        <div class="bg-slate-100 border-b border-slate-200/60 px-8 py-3.5 flex justify-between items-center text-xs font-bold text-slate-400">
            <span class="<?php echo $current_step === 1 ? 'text-bushgreen font-extrabold' : ''; ?>">1. Requirements Check</span>
            <span>&rarr;</span>
            <span class="<?php echo $current_step === 2 ? 'text-bushgreen font-extrabold' : ''; ?>">2. Database Setup</span>
            <span>&rarr;</span>
            <span class="<?php echo $current_step === 3 ? 'text-bushgreen font-extrabold' : ''; ?>">3. Installation Done</span>
        </div>

        <div class="p-8">
            <!-- Errors -->
            <?php if (!empty($error)): ?>
                <div class="mb-6 p-4 bg-red-50 border-l-4 border-red-500 rounded-r-lg text-xs text-red-700 font-semibold flex items-center gap-2">
                    <svg class="w-4 h-4 text-red-500 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clip-rule="evenodd"/></svg>
                    <?php echo $error; ?>
                </div>
            <?php endif; ?>

            <?php if ($is_installed && $current_step !== 3): ?>
                <!-- Already Installed Banner -->
                <div class="bg-amber-50 border border-amber-200 rounded-2xl p-6 text-center space-y-4">
                    <svg class="w-12 h-12 text-amber-500 mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                    </svg>
                    <h3 class="text-slate-800 font-bold text-base">App Already Configured</h3>
                    <p class="text-slate-650 text-xs leading-relaxed">
                        A config file already exists with verified database parameters. To run the installer again, delete `config/config.php` from your hosting file manager first.
                    </p>
                    <div class="flex justify-center gap-3 pt-2">
                        <a href="index.php" class="py-2 px-5 bg-slate-800 text-white rounded-lg text-xs font-semibold hover:bg-slate-700 transition">Go to Homepage</a>
                        <a href="login.php" class="py-2 px-5 bg-bushgreen text-white rounded-lg text-xs font-semibold hover:bg-emerald-800 transition">Portal Login</a>
                    </div>
                </div>
            
            <?php elseif ($current_step === 1): ?>
                <!-- STEP 1: Requirements check -->
                <div class="space-y-6">
                    <div class="space-y-1">
                        <h3 class="text-slate-800 font-bold text-sm">Verify Server Compatibility</h3>
                        <p class="text-slate-550 text-xs font-light">cPanel hosting environment settings and directory write permissions checks.</p>
                    </div>

                    <div class="space-y-3 pt-2">
                        <!-- PHP version -->
                        <div class="flex justify-between items-center p-3 rounded-xl border <?php echo $php_version_passed ? 'bg-emerald-50/50 border-emerald-100' : 'bg-red-50/50 border-red-100'; ?>">
                            <div class="text-xs">
                                <span class="font-bold text-slate-850 block">PHP Version (>= 8.0)</span>
                                <span class="text-slate-400 text-[10px] block">Current Version: <?php echo $php_version; ?></span>
                            </div>
                            <?php if ($php_version_passed): ?>
                                <span class="text-emerald-600 font-extrabold text-xs flex items-center gap-1">✓ Pass</span>
                            <?php else: ?>
                                <span class="text-red-650 font-extrabold text-xs flex items-center gap-1">✗ Failed</span>
                            <?php endif; ?>
                        </div>

                        <!-- Write Checkups -->
                        <?php foreach ($permissions as $name => $info): ?>
                            <div class="flex justify-between items-center p-3 rounded-xl border <?php echo $info['writable'] ? 'bg-emerald-50/50 border-emerald-100' : 'bg-red-50/50 border-red-100'; ?>">
                                <div class="text-xs">
                                    <span class="font-bold text-slate-850 block uppercase">Folder: /<?php echo $name; ?></span>
                                    <span class="text-slate-400 text-[10px] block font-mono">Perms: <?php echo $info['perms']; ?></span>
                                </div>
                                <?php if ($info['writable']): ?>
                                    <span class="text-emerald-600 font-extrabold text-xs flex items-center gap-1">✓ Writable</span>
                                <?php else: ?>
                                    <span class="text-red-650 font-extrabold text-xs flex items-center gap-1">✗ Not Writable</span>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>

                    <?php if (!$requirements_passed): ?>
                        <div class="p-4 bg-amber-50 rounded-xl text-xs text-amber-800 border border-amber-100 leading-relaxed font-light">
                            <strong class="font-bold">Attention Needed:</strong> One or more checks failed. Please adjust directories permissions to <strong>755</strong> (or <strong>777</strong> if required by webserver) in cPanel File Manager and refresh the page.
                        </div>
                    <?php endif; ?>

                    <div class="pt-4 border-t border-slate-100 flex justify-between items-center">
                        <a href="install.php?step=1" class="py-2 px-4 border border-slate-200 rounded-lg text-slate-650 text-xs font-semibold hover:bg-slate-50 transition">Refresh Checks</a>
                        
                        <?php if ($requirements_passed): ?>
                            <a href="install.php?step=2" class="py-2 px-6 bg-bushgreen hover:bg-emerald-800 text-white rounded-lg text-xs font-semibold transition flex items-center gap-1.5 shadow">
                                Proceed to Setup
                                <svg class="w-3 h-3 text-gold" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/></svg>
                            </a>
                        <?php else: ?>
                            <button disabled class="py-2 px-6 bg-slate-300 text-white rounded-lg text-xs font-semibold cursor-not-allowed">Fix Checks to Proceed</button>
                        <?php endif; ?>
                    </div>
                </div>

            <?php elseif ($current_step === 2): ?>
                <!-- STEP 2: Database details form -->
                <div class="space-y-6">
                    <div class="space-y-1">
                        <h3 class="text-slate-800 font-bold text-sm">Database Configuration</h3>
                        <p class="text-slate-550 text-xs font-light">Enter the MySQL database connection credentials created inside cPanel.</p>
                    </div>

                    <form method="POST" action="" class="space-y-4">
                        <div>
                            <label class="block text-slate-700 text-xs font-semibold mb-1.5" for="db_host">MySQL Database Hostname</label>
                            <input type="text" name="db_host" id="db_host" value="127.0.0.1" required
                                   class="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 focus:outline-none focus:border-bushgreen text-xs font-mono">
                            <p class="text-[9px] text-slate-400 mt-1">cPanel usually matches "127.0.0.1" or "localhost".</p>
                        </div>

                        <div>
                            <label class="block text-slate-700 text-xs font-semibold mb-1.5" for="db_name">MySQL Database Name</label>
                            <input type="text" name="db_name" id="db_name" required placeholder="e.g. cpaneluser_pbatdb"
                                   class="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 focus:outline-none focus:border-bushgreen text-xs font-mono">
                            <p class="text-[9px] text-slate-400 mt-1">Make sure you have created this database in cPanel's MySQL Databases panel.</p>
                        </div>

                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label class="block text-slate-700 text-xs font-semibold mb-1.5" for="db_user">MySQL Username</label>
                                <input type="text" name="db_user" id="db_user" required placeholder="e.g. cpaneluser_dbuser"
                                       class="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 focus:outline-none focus:border-bushgreen text-xs font-mono">
                            </div>
                            <div>
                                <label class="block text-slate-700 text-xs font-semibold mb-1.5" for="db_pass">MySQL User Password</label>
                                <input type="password" name="db_pass" id="db_pass" placeholder="Database user password key"
                                       class="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 focus:outline-none focus:border-bushgreen text-xs font-mono">
                            </div>
                        </div>

                        <div class="pt-4 border-t border-slate-100 flex justify-between items-center gap-3">
                            <a href="install.php?step=1" class="py-2 px-4 border border-slate-200 rounded-lg text-slate-650 text-xs font-semibold hover:bg-slate-50 transition">&larr; Back</a>
                            
                            <button type="submit" name="install_db" class="py-2.5 px-6 bg-bushgreen hover:bg-emerald-800 text-white rounded-lg text-xs font-bold transition flex items-center gap-1.5 shadow">
                                Build DB & Generate Configs
                                <svg class="w-3.5 h-3.5 text-gold" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                            </button>
                        </div>
                    </form>
                </div>

            <?php elseif ($current_step === 3): ?>
                <!-- STEP 3: Complete -->
                <div class="space-y-6">
                    <div class="text-center space-y-2">
                        <div class="w-12 h-12 bg-emerald-50 text-emerald-500 rounded-full border border-emerald-100 flex items-center justify-center mx-auto">
                            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
                        </div>
                        <h3 class="text-slate-800 font-bold text-base">Setup Completed Successfully!</h3>
                        <p class="text-slate-500 text-xs font-light">All schemas, states, LGAs, and wards have been successfully seeded.</p>
                    </div>

                    <div class="p-5 bg-slate-50 border border-slate-150 rounded-2xl space-y-4">
                        <span class="text-[10px] text-slate-400 font-bold uppercase tracking-wider block border-b pb-2">Seeded Default Administrator Access</span>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs font-mono text-slate-600">
                            <div><strong class="text-slate-800 block">Default Email:</strong> admin@pbat-smartnation.ng</div>
                            <div><strong class="text-slate-800 block">Default Password:</strong> password123</div>
                        </div>
                        <div class="p-3 bg-amber-50 border border-amber-100 rounded-lg text-[10px] text-amber-800 font-sans leading-relaxed">
                            <strong>RECOMMENDED SECURITY ACTION:</strong> Log in immediately and update the password for the super admin account under user profile settings.
                        </div>
                    </div>

                    <div class="pt-4 border-t border-slate-100 flex flex-col sm:flex-row gap-3">
                        <a href="index.php" class="flex-grow py-2.5 px-4 border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-bold text-center rounded-xl transition">
                            Visit Site Home
                        </a>
                        <a href="login.php" class="flex-grow py-2.5 px-4 bg-bushgreen hover:bg-emerald-800 text-white text-xs font-bold text-center rounded-xl transition shadow">
                            Access Admin Portal
                        </a>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
