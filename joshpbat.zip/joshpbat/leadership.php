<?php
/**
 * PBAT Smart Nation Initiative - Leadership Registry
 * Premium page listing key national executive council, regional chairmen, and the founder.
 */
require_once __DIR__ . '/helpers/seo.php';

SEO::init([
    'title' => 'Leadership Council & Founder | PBAT Smart Nation Initiative',
    'description' => 'Meet the national steering team and strategic directors driving the PBAT Smart Nation Initiative. Spotlight on founder Joshua Omeiza Emmanuel (TechLord).',
    'keywords' => 'Joshua Omeiza Emmanuel, TechLord, PBAT Smart Nation Leadership, State Chairmen Nigeria, Digital Transformation Coordinators, National Steering Council',
    'breadcrumbs' => [
        ['name' => 'Leadership', 'url' => '/leadership']
    ]
]);

require_once __DIR__ . '/includes/header.php';
?>

<!-- Leadership Hero Banner -->
<section class="relative bg-bushgreen text-white py-24 overflow-hidden border-b-4 border-gold">
    <div class="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-bushgreen-light/70 via-bushgreen to-bushgreen-dark opacity-95"></div>
    <div class="absolute inset-0 bg-[linear-gradient(to_right,#ffffff02_1px,transparent_1px),linear-gradient(to_bottom,#ffffff02_1px,transparent_1px)] bg-[size:3rem_3rem]"></div>
    
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center space-y-4">
        <span class="text-gold font-bold text-xs uppercase tracking-widest font-display block">Leadership Circle</span>
        <h1 class="text-4xl sm:text-6xl font-black font-display tracking-tight uppercase">Advocacy Council</h1>
        <p class="text-slate-300 text-xs sm:text-base max-w-2xl mx-auto font-light leading-relaxed">
            Coordinating digital transformation programs and AI sensitizations through structured levels across all 36 States and 774 LGAs of Nigeria.
        </p>
    </div>
</section>

<!-- Founder Spotlight -->
<section class="py-24 bg-white">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            <!-- Founder Image -->
            <div class="lg:col-span-5 relative">
                <div class="absolute inset-0 bg-gradient-to-tr from-gold to-emerald-600 rounded-3xl transform rotate-3 scale-95 opacity-20"></div>
                <div class="relative bg-slate-100 rounded-3xl border border-slate-200 overflow-hidden shadow-xl aspect-square">
                    <img src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=800&q=80" alt="Joshua Omeiza Emmanuel (TechLord)" class="w-full h-full object-cover">
                </div>
            </div>

            <!-- Founder Bio -->
            <div class="lg:col-span-7 space-y-6">
                <div class="space-y-2">
                    <span class="text-gold font-bold text-xs uppercase tracking-widest font-display block">Founder & Tech Lead</span>
                    <h2 class="text-3xl sm:text-4xl font-extrabold text-bushgreen font-display">Joshua Omeiza Emmanuel</h2>
                    <span class="inline-block px-3 py-1 bg-emerald-50 text-emerald-800 text-[10px] font-extrabold uppercase rounded-full border border-emerald-100 tracking-wider">A.K.A. TechLord</span>
                </div>
                
                <p class="text-slate-600 text-sm font-light leading-relaxed">
                    Joshua Omeiza Emmanuel (TechLord) founded the **PBAT Smart Nation Initiative** in 2022. As a digital pioneer, tech architect, and civic coordinator, his primary mission is to bridge the technological divide in Nigeria. Through grassroots youth networks and strategic digital literacy training, he guides national transformations aimed at empowering small businesses and local governments.
                </p>
                <p class="text-slate-600 text-sm font-light leading-relaxed">
                    Under his leadership, the initiative has grown into a vital advocacy channel, mobilizing over thousands of active digital ambassadors to track connectivity indices, lead region-specific town halls, and expand digital integration across primary schools and markets.
                </p>

                <div class="pt-4 flex gap-4">
                    <a href="partner.php" class="py-2.5 px-6 bg-bushgreen hover:bg-bushgreen-light text-white text-xs font-bold rounded-xl transition shadow">Partner with Joshua</a>
                    <a href="contact.php" class="py-2.5 px-6 border border-slate-200 hover:bg-slate-50 text-slate-600 text-xs font-bold rounded-xl transition">Contact Executive Office</a>
                </div>
            </div>

        </div>
    </div>
</section>

<!-- Executive Steering Council -->
<section class="py-24 bg-slate-50 border-t border-slate-100">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
        <div class="text-center space-y-2 max-w-xl mx-auto">
            <span class="text-gold font-bold text-xs uppercase tracking-widest font-display block">Coordinating Directors</span>
            <h2 class="text-3xl font-extrabold text-bushgreen font-display">Strategic Council</h2>
            <p class="text-slate-500 text-xs sm:text-sm font-light leading-relaxed">The administrative council steering state expansions, policy drafting, and digital campaign rollouts.</p>
        </div>

        <!-- Team Grid -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
            
            <!-- Executive 1 -->
            <div class="bg-white rounded-3xl border border-slate-100 shadow-sm p-6 text-center space-y-4 hover:shadow-md hover:border-gold/30 transition duration-300">
                <img src="https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&w=300&q=80" alt="Hon. Yusuf Bello" class="w-24 h-24 rounded-2xl mx-auto object-cover border-2 border-gold/45">
                <div class="space-y-1">
                    <h3 class="text-slate-800 font-bold text-sm font-display">Hon. Yusuf Bello</h3>
                    <span class="text-[10px] text-gold font-bold uppercase tracking-wider block">Super Admin & System Director</span>
                </div>
                <p class="text-slate-500 text-xs font-light leading-relaxed">
                    Manages national user registries, administrative settings, system updates, and verification protocols.
                </p>
            </div>

            <!-- Executive 2 -->
            <div class="bg-white rounded-3xl border border-slate-100 shadow-sm p-6 text-center space-y-4 hover:shadow-md hover:border-gold/30 transition duration-300">
                <img src="https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=300&q=80" alt="Dr. Chioma Nnaji" class="w-24 h-24 rounded-2xl mx-auto object-cover border-2 border-gold/45">
                <div class="space-y-1">
                    <h3 class="text-slate-800 font-bold text-sm font-display">Dr. Chioma Nnaji</h3>
                    <span class="text-[10px] text-gold font-bold uppercase tracking-wider block">National Steering Director</span>
                </div>
                <p class="text-slate-500 text-xs font-light leading-relaxed">
                    Oversees local policy blueprints, youth training curricula, and national educational webinars.
                </p>
            </div>

            <!-- Executive 3 -->
            <div class="bg-white rounded-3xl border border-slate-100 shadow-sm p-6 text-center space-y-4 hover:shadow-md hover:border-gold/30 transition duration-300">
                <img src="https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&w=300&q=80" alt="Chief Adebayo Adeola" class="w-24 h-24 rounded-2xl mx-auto object-cover border-2 border-gold/45">
                <div class="space-y-1">
                    <h3 class="text-slate-800 font-bold text-sm font-display">Chief Adebayo Adeola</h3>
                    <span class="text-[10px] text-gold font-bold uppercase tracking-wider block">Zonal South-West Chairman</span>
                </div>
                <p class="text-slate-500 text-xs font-light leading-relaxed">
                    Coordinates state steering chapters, reports collection, and regional town halls across South-West Nigeria.
                </p>
            </div>

        </div>
    </div>
</section>

<?php
require_once __DIR__ . '/includes/footer.php';
?>
